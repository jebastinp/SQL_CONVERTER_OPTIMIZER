# SQL Forge

A SAAS for SQL dialect conversion + rule-based optimization + complexity analysis.

**Stack**

- **Backend:** Python · Flask · SQLite · [sqlglot](https://github.com/tobymao/sqlglot) (real AST-based SQL parser/transpiler — same library used by Apache Superset, dbt, and SQLMesh)
- **Frontend:** plain HTML/CSS/JS — no framework, no build step
- **Auth:** email + bcrypt password hashing, bearer-token sessions

**Features**

- Convert between MSSQL, PostgreSQL, MySQL, Oracle, SQLite, Snowflake, BigQuery, Redshift, DuckDB
- AST-based analysis (not regex) — detects:
  - `SELECT *`
  - Leading-wildcard `LIKE`
  - Non-SARGable functions in `WHERE`
  - Correlated subqueries (with table-reference checking)
  - `NOT IN (SELECT ...)`
  - Possible Cartesian products
  - `ORDER BY` without `LIMIT`
  - `DISTINCT` as a smell
- Time-complexity estimate (Big-O) + relative cost score
- User accounts, query history, saved queries
- Proper SQL tokenizer for syntax highlighting (state machine, won't break)

---

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Open <http://localhost:5000>.

The first run creates `sqlforge.db` (SQLite) in the project directory.

## Environment variables

| Variable          | Default                       | Notes                           |
| ----------------- | ----------------------------- | ------------------------------- |
| `PORT`            | `5000`                        | HTTP port                       |
| `SQLFORGE_DB`     | `./sqlforge.db`               | SQLite path                     |
| `SQLFORGE_SECRET` | random per start              | Set to a fixed value in prod    |

## Production

Use Gunicorn (already in `requirements.txt`):

```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

Behind nginx, with HTTPS via Let's Encrypt. Set `SQLFORGE_SECRET` to a long random string.

## Migrating to PostgreSQL

The app uses SQLite via `sqlite3`. To move to PostgreSQL:

1. `pip install psycopg2-binary`
2. Replace `get_db()` to return a `psycopg2` connection
3. Adjust the schema (mostly `AUTOINCREMENT` → `SERIAL`, parameter style `?` → `%s`)

The schema is intentionally simple to make this swap easy.

## API

| Endpoint                 | Method | Auth | Body                                                    |
| ------------------------ | ------ | ---- | ------------------------------------------------------- |
| `/api/health`            | GET    | -    | -                                                       |
| `/api/dialects`          | GET    | -    | -                                                       |
| `/api/auth/signup`       | POST   | -    | `{email, password}`                                     |
| `/api/auth/login`        | POST   | -    | `{email, password}`                                     |
| `/api/auth/logout`       | POST   | ✓    | -                                                       |
| `/api/auth/me`           | GET    | ?    | -                                                       |
| `/api/convert`           | POST   | opt. | `{sql, source_dialect, target_dialect, optimize, format}` |
| `/api/history`           | GET    | ✓    | -                                                       |
| `/api/saved`             | GET    | ✓    | -                                                       |
| `/api/saved`             | POST   | ✓    | `{name, source_dialect, target_dialect, source_sql, output_sql}` |
| `/api/saved/<id>`        | DELETE | ✓    | -                                                       |

Auth header: `Authorization: Bearer <token>`.

## License

MIT.
