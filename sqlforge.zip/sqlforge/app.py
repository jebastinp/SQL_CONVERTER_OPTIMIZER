"""
SQL Forge — Backend
A SAAS for SQL dialect conversion and optimization.

Stack:
- Flask (web framework)
- SQLite (database, expandable to PostgreSQL later)
- sqlglot (real SQL parser/transpiler, supports 20+ dialects)
- bcrypt (password hashing)

Run:
    pip install -r requirements.txt
    python app.py
"""
import os
import re
import json
import time
import secrets
import sqlite3
import bcrypt
import sqlglot
from sqlglot import exp
from flask import Flask, request, jsonify, g, send_from_directory, make_response

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("SQLFORGE_DB", os.path.join(APP_DIR, "sqlforge.db"))
STATIC_DIR = os.path.join(APP_DIR, "static")

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")
app.config["SECRET_KEY"] = os.environ.get("SQLFORGE_SECRET", secrets.token_hex(32))

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    plan TEXT NOT NULL DEFAULT 'free',
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conversions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    source_dialect TEXT NOT NULL,
    target_dialect TEXT NOT NULL,
    source_sql TEXT NOT NULL,
    output_sql TEXT NOT NULL,
    notes_json TEXT NOT NULL,
    complexity_json TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS saved_queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    source_dialect TEXT NOT NULL,
    target_dialect TEXT NOT NULL,
    source_sql TEXT NOT NULL,
    output_sql TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_conversions_user ON conversions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_saved_user ON saved_queries(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
SESSION_TTL = 60 * 60 * 24 * 30  # 30 days


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()


def check_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except Exception:
        return False


def create_session(user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    db = get_db()
    db.execute(
        "INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
        (token, user_id, now, now + SESSION_TTL),
    )
    db.commit()
    return token


def current_user():
    """Resolve the current user from the Authorization header. Returns sqlite3.Row or None."""
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[7:].strip()
    if not token:
        return None
    db = get_db()
    row = db.execute(
        """SELECT u.* FROM users u
           JOIN sessions s ON s.user_id = u.id
           WHERE s.token = ? AND s.expires_at > ?""",
        (token, int(time.time())),
    ).fetchone()
    return row


def require_auth():
    """Returns user row or None; if None, sends a 401 JSON response."""
    user = current_user()
    if not user:
        return None, (jsonify({"error": "Authentication required"}), 401)
    return user, None


# ---------------------------------------------------------------------------
# SQL conversion + optimization
# ---------------------------------------------------------------------------
SUPPORTED_DIALECTS = {
    "mssql": "tsql",
    "tsql": "tsql",
    "postgresql": "postgres",
    "postgres": "postgres",
    "mysql": "mysql",
    "oracle": "oracle",
    "sqlite": "sqlite",
    "snowflake": "snowflake",
    "bigquery": "bigquery",
    "redshift": "redshift",
    "duckdb": "duckdb",
}

DIALECT_NAMES = {
    "tsql": "MSSQL",
    "postgres": "PostgreSQL",
    "mysql": "MySQL",
    "oracle": "Oracle",
    "sqlite": "SQLite",
    "snowflake": "Snowflake",
    "bigquery": "BigQuery",
    "redshift": "Redshift",
    "duckdb": "DuckDB",
}


def normalize_dialect(d: str) -> str:
    return SUPPORTED_DIALECTS.get((d or "").lower().strip(), "postgres")


def transpile_sql(sql: str, src: str, tgt: str, pretty: bool = True) -> dict:
    """
    Use sqlglot to parse + transpile + (optionally) optimize the SQL.
    Returns {ok, sql, error, conversion_notes}.
    """
    src_d = normalize_dialect(src)
    tgt_d = normalize_dialect(tgt)
    notes = []

    if not sql.strip():
        return {"ok": False, "sql": "", "error": "Empty query", "conversion_notes": notes}

    try:
        # Parse in source dialect
        try:
            parsed = sqlglot.parse(sql, read=src_d)
        except Exception as parse_err:
            return {
                "ok": False,
                "sql": "",
                "error": f"Parse error in {DIALECT_NAMES.get(src_d, src_d)}: {parse_err}",
                "conversion_notes": notes,
            }

        if not parsed or all(p is None for p in parsed):
            return {"ok": False, "sql": "", "error": "Could not parse any statements", "conversion_notes": notes}

        # Detect things that will be converted
        original_upper = sql.upper()
        if src_d == "tsql" and tgt_d == "postgres":
            if re.search(r"\bTOP\s+\d+\b", original_upper):
                notes.append({"type": "info", "title": "TOP → LIMIT",
                              "desc": "MSSQL TOP clause converted to PostgreSQL LIMIT."})
            if re.search(r"\bGETDATE\s*\(\s*\)", original_upper):
                notes.append({"type": "info", "title": "GETDATE() → CURRENT_TIMESTAMP",
                              "desc": "MSSQL date function converted to PostgreSQL equivalent."})
            if re.search(r"\bISNULL\s*\(", original_upper):
                notes.append({"type": "info", "title": "ISNULL → COALESCE",
                              "desc": "MSSQL ISNULL converted to ANSI-standard COALESCE."})
            if re.search(r"\[\w+\]", sql):
                notes.append({"type": "info", "title": "Bracket identifiers requoted",
                              "desc": "MSSQL [bracket] identifiers converted to PostgreSQL double-quotes."})
        elif src_d == "postgres" and tgt_d == "tsql":
            if re.search(r"\bLIMIT\s+\d+", original_upper):
                notes.append({"type": "info", "title": "LIMIT → TOP",
                              "desc": "PostgreSQL LIMIT converted to MSSQL TOP."})
        elif src_d == "mysql":
            if re.search(r"`\w+`", sql):
                notes.append({"type": "info", "title": "Backticks requoted",
                              "desc": f"MySQL backtick identifiers converted for {DIALECT_NAMES.get(tgt_d)}."})
            if re.search(r"\bIFNULL\s*\(", original_upper):
                notes.append({"type": "info", "title": "IFNULL → COALESCE",
                              "desc": "MySQL IFNULL converted to ANSI COALESCE."})
        elif src_d == "oracle":
            if re.search(r"\bNVL\s*\(", original_upper):
                notes.append({"type": "info", "title": "NVL → COALESCE",
                              "desc": "Oracle NVL converted to ANSI COALESCE."})
            if re.search(r"\bROWNUM\b", original_upper):
                notes.append({"type": "info", "title": "ROWNUM → LIMIT/FETCH",
                              "desc": "Oracle ROWNUM converted to standard row-limiting clause."})

        # Transpile each statement
        outputs = []
        for tree in parsed:
            if tree is None:
                continue
            out = tree.sql(dialect=tgt_d, pretty=pretty)
            outputs.append(out)

        result_sql = ";\n\n".join(outputs)
        if not result_sql.rstrip().endswith(";") and len(outputs) == 1:
            result_sql = result_sql.rstrip() + ";"

        return {"ok": True, "sql": result_sql, "error": None, "conversion_notes": notes}

    except Exception as e:
        return {"ok": False, "sql": "", "error": f"Conversion failed: {e}", "conversion_notes": notes}


# Optimization rules — operate on the AST for accuracy
def analyze_and_optimize(sql: str, dialect: str) -> dict:
    """
    Run AST-based analysis. Returns:
    {
      issues: [{type, title, desc, impact}],
      rewritten_sql: str or None,
      complexity: {bigO, desc, cost, costLabel}
    }
    """
    d = normalize_dialect(dialect)
    issues = []
    rewritten = None

    try:
        trees = sqlglot.parse(sql, read=d)
    except Exception:
        return {
            "issues": [{"type": "warn", "title": "Could not parse for analysis",
                        "desc": "AST-based analysis skipped — only the converted text is shown.",
                        "impact": "—"}],
            "rewritten_sql": None,
            "complexity": estimate_complexity_text(sql),
        }

    join_count = 0
    subquery_count = 0
    correlated_count = 0
    has_select_star = False
    has_distinct = False
    has_order = False
    has_limit = False
    has_group = False
    has_leading_wildcard = False
    has_func_in_where = False
    has_not_in_subquery = False
    has_implicit_cross = False

    for tree in trees:
        if tree is None:
            continue

        # SELECT *
        for star in tree.find_all(exp.Star):
            has_select_star = True

        # JOINs
        for _ in tree.find_all(exp.Join):
            join_count += 1

        # Subqueries
        for sub in tree.find_all(exp.Subquery):
            subquery_count += 1

        # DISTINCT
        for sel in tree.find_all(exp.Select):
            if sel.args.get("distinct"):
                has_distinct = True

        # ORDER BY / LIMIT / GROUP BY
        if list(tree.find_all(exp.Order)):
            has_order = True
        if list(tree.find_all(exp.Limit)) or list(tree.find_all(exp.Fetch)):
            has_limit = True
        if list(tree.find_all(exp.Group)):
            has_group = True

        # WHERE analysis
        for where in tree.find_all(exp.Where):
            # Leading-wildcard LIKE
            for like in where.find_all(exp.Like):
                rhs = like.args.get("expression")
                if rhs and isinstance(rhs, exp.Literal) and rhs.is_string:
                    if rhs.this.startswith("%"):
                        has_leading_wildcard = True

            # Function on column in WHERE (non-SARGable)
            # Any function call inside WHERE is suspect — even when the parser
            # doesn't formally tag the argument as a Column node.
            for func in where.find_all(exp.Func):
                has_func_in_where = True
                break

            # NOT IN (SELECT ...)
            for not_node in where.find_all(exp.Not):
                inner = not_node.this
                if isinstance(inner, exp.In) and inner.args.get("query"):
                    has_not_in_subquery = True

        # Correlated subqueries: a Subquery whose body references the outer table aliases
        def _name_of(t):
            return getattr(t, "alias_or_name", None) or getattr(t, "name", "") or ""

        for sub in tree.find_all(exp.Subquery):
            outer_tables = {_name_of(t) for t in tree.find_all(exp.Table)} - \
                           {_name_of(t) for t in sub.find_all(exp.Table)}
            outer_tables.discard("")
            for col in sub.find_all(exp.Column):
                table_ref = col.table
                if table_ref and table_ref in outer_tables:
                    correlated_count += 1
                    break

        # Implicit cross join: multiple tables in FROM with no JOIN and no WHERE join condition
        for select in tree.find_all(exp.Select):
            from_clause = select.args.get("from")
            if from_clause:
                tables_in_from = list(from_clause.find_all(exp.Table))
                joins = select.args.get("joins") or []
                if len(tables_in_from) > 1 and not joins:
                    # multiple comma-separated tables
                    where_node = select.args.get("where")
                    if not where_node:
                        has_implicit_cross = True

    # Build issues list
    if has_select_star:
        issues.append({"type": "warn", "title": "SELECT * detected",
                       "desc": "Selecting all columns prevents covering-index use, increases I/O, and breaks consumers on schema changes. List only the columns you need.",
                       "impact": "High"})
    if has_leading_wildcard:
        issues.append({"type": "warn", "title": "Leading-wildcard LIKE",
                       "desc": "LIKE '%foo%' forces a full scan. Use a trigram index (pg_trgm), full-text index, or restructure the search.",
                       "impact": "High"})
    if has_func_in_where:
        issues.append({"type": "warn", "title": "Function on column in WHERE",
                       "desc": "Wrapping an indexed column in a function (UPPER, EXTRACT, CAST, …) makes the predicate non-SARGable and disables index use. Rewrite as a range, or add a functional/expression index.",
                       "impact": "High"})
    if correlated_count > 0:
        issues.append({"type": "crit", "title": f"Correlated subquery detected ({correlated_count})",
                       "desc": "Correlated subqueries re-execute per outer row → O(N·M). Rewrite as a LEFT JOIN + GROUP BY (or LATERAL) for O(N+M) with proper indexes.",
                       "impact": "Critical"})
    if has_not_in_subquery:
        issues.append({"type": "crit", "title": "NOT IN with subquery",
                       "desc": "NOT IN has NULL-sensitive semantics and often defeats indexes. Use NOT EXISTS or LEFT JOIN … WHERE col IS NULL.",
                       "impact": "High"})
    if has_implicit_cross:
        issues.append({"type": "crit", "title": "Possible Cartesian product",
                       "desc": "Multiple tables in FROM without explicit JOIN ON conditions produce N×M rows. Use explicit JOIN … ON.",
                       "impact": "Critical"})
    if has_order and not has_limit:
        issues.append({"type": "info", "title": "ORDER BY without LIMIT",
                       "desc": "Sorting the full result set is expensive. If only top-N rows are needed, add LIMIT/TOP for top-K optimization.",
                       "impact": "Medium"})
    if has_distinct:
        issues.append({"type": "info", "title": "DISTINCT in use",
                       "desc": "DISTINCT triggers a sort/hash dedup. Often a symptom of an incorrect duplicating JOIN — verify joins instead.",
                       "impact": "Low"})
    if join_count >= 1:
        issues.append({"type": "info", "title": f"{join_count} JOIN{'s' if join_count != 1 else ''} present",
                       "desc": "Verify every JOIN key has an index on both sides. Otherwise the planner falls back to hash/merge over full scans.",
                       "impact": "Medium" if join_count >= 2 else "Low"})

    # Complexity estimate
    complexity = compute_complexity(
        join_count=join_count,
        correlated=correlated_count,
        has_order=has_order,
        has_limit=has_limit,
        has_group=has_group,
        has_distinct=has_distinct,
        has_leading_wildcard=has_leading_wildcard,
        has_func_in_where=has_func_in_where,
        has_implicit_cross=has_implicit_cross,
    )

    return {"issues": issues, "rewritten_sql": rewritten, "complexity": complexity}


def compute_complexity(*, join_count, correlated, has_order, has_limit, has_group,
                       has_distinct, has_leading_wildcard, has_func_in_where, has_implicit_cross):
    if has_implicit_cross:
        big_o = "O(N · M)"
        desc = "Cartesian product"
    elif correlated > 0:
        big_o = "O(N · M)"
        desc = "Correlated subquery — per-row lookup"
    elif join_count >= 3:
        big_o = "O(N · M · K)"
        desc = f"{join_count}-way join"
    elif join_count == 2:
        big_o = "O(N · M)"
        desc = "Two-way join"
    elif join_count == 1:
        big_o = "O(N + M)"
        desc = "Hash/merge join"
    elif has_order and not has_limit:
        big_o = "O(N log N)"
        desc = "Full sort"
    else:
        big_o = "O(N)"
        desc = "Single-table scan"

    cost = 10
    if has_implicit_cross: cost = 95
    if correlated > 0: cost = max(cost, 85)
    cost += join_count * 12
    if has_order and not has_limit: cost += 15
    if has_group: cost += 8
    if has_distinct: cost += 6
    if has_leading_wildcard: cost += 25
    if has_func_in_where: cost += 18
    if has_limit and cost > 10: cost = max(10, cost - 10)
    cost = max(5, min(100, cost))

    if cost <= 25:
        label = "Low cost · likely fast"
        klass = "good"
    elif cost <= 55:
        label = "Moderate · acceptable"
        klass = ""
    elif cost <= 80:
        label = "High cost · review"
        klass = "bad"
    else:
        label = "Very high · rewrite recommended"
        klass = "bad"

    return {"bigO": big_o, "desc": desc, "cost": cost, "costLabel": label, "costClass": klass}


def estimate_complexity_text(sql: str) -> dict:
    """Fallback when AST parse fails — regex-based rough estimate."""
    upper = sql.upper()
    joins = len(re.findall(r"\bJOIN\b", upper))
    correlated = len(re.findall(r"\(\s*SELECT\s+COUNT", upper))
    return compute_complexity(
        join_count=joins, correlated=correlated,
        has_order=bool(re.search(r"\bORDER\s+BY\b", upper)),
        has_limit=bool(re.search(r"\b(LIMIT|TOP|FETCH\s+FIRST)\b", upper)),
        has_group=bool(re.search(r"\bGROUP\s+BY\b", upper)),
        has_distinct=bool(re.search(r"\bDISTINCT\b", upper)),
        has_leading_wildcard=bool(re.search(r"LIKE\s+'%", sql)),
        has_func_in_where=bool(re.search(r"WHERE[\s\S]*?\b(UPPER|LOWER|YEAR|EXTRACT|DATEPART|CAST|CONVERT)\s*\(", upper)),
        has_implicit_cross=False,
    )


# ---------------------------------------------------------------------------
# API routes
# ---------------------------------------------------------------------------
@app.route("/api/health")
def health():
    return jsonify({"ok": True, "version": "1.0.0", "sqlglot": sqlglot.__version__})


@app.route("/api/dialects")
def dialects():
    """List dialects available in the dropdown."""
    return jsonify({
        "dialects": [
            {"id": "mssql", "name": "MSSQL"},
            {"id": "postgresql", "name": "PostgreSQL"},
            {"id": "mysql", "name": "MySQL"},
            {"id": "oracle", "name": "Oracle"},
            {"id": "sqlite", "name": "SQLite"},
            {"id": "snowflake", "name": "Snowflake"},
            {"id": "bigquery", "name": "BigQuery"},
            {"id": "redshift", "name": "Redshift"},
            {"id": "duckdb", "name": "DuckDB"},
        ]
    })


@app.route("/api/auth/signup", methods=["POST"])
def signup():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email or "@" not in email:
        return jsonify({"error": "Valid email required"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400

    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, ?)",
            (email, hash_password(password), int(time.time())),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": "Email already registered"}), 409

    user_id = cur.lastrowid
    token = create_session(user_id)
    return jsonify({"token": token, "user": {"id": user_id, "email": email, "plan": "free"}})


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    db = get_db()
    row = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if not row or not check_password(password, row["password_hash"]):
        return jsonify({"error": "Invalid email or password"}), 401

    token = create_session(row["id"])
    return jsonify({
        "token": token,
        "user": {"id": row["id"], "email": row["email"], "plan": row["plan"]},
    })


@app.route("/api/auth/logout", methods=["POST"])
def logout():
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:].strip()
        db = get_db()
        db.execute("DELETE FROM sessions WHERE token = ?", (token,))
        db.commit()
    return jsonify({"ok": True})


@app.route("/api/auth/me")
def me():
    user = current_user()
    if not user:
        return jsonify({"authenticated": False})
    return jsonify({
        "authenticated": True,
        "user": {"id": user["id"], "email": user["email"], "plan": user["plan"]},
    })


@app.route("/api/convert", methods=["POST"])
def convert():
    """
    Anonymous use is allowed (rate-limited in production); logged-in users get history.
    """
    data = request.get_json(silent=True) or {}
    sql = data.get("sql", "")
    src = data.get("source_dialect", "mssql")
    tgt = data.get("target_dialect", "postgresql")
    do_optimize = bool(data.get("optimize", True))
    do_format = bool(data.get("format", True))

    if not sql.strip():
        return jsonify({"error": "Empty query"}), 400
    if len(sql) > 100_000:
        return jsonify({"error": "Query too large (100KB max)"}), 413

    # 1) Transpile
    transpiled = transpile_sql(sql, src, tgt, pretty=do_format)
    if not transpiled["ok"]:
        return jsonify({
            "ok": False,
            "error": transpiled["error"],
            "conversion_notes": transpiled["conversion_notes"],
        }), 200  # 200 because it's a "soft" error the UI displays

    output_sql = transpiled["sql"]
    conversion_notes = transpiled["conversion_notes"]

    # 2) Analyze and optionally optimize
    analysis = analyze_and_optimize(output_sql, tgt) if do_optimize else {
        "issues": [], "rewritten_sql": None,
        "complexity": estimate_complexity_text(output_sql),
    }

    all_notes = conversion_notes + analysis["issues"]
    final_sql = analysis["rewritten_sql"] or output_sql

    # 3) Save to history if logged in
    user = current_user()
    if user:
        db = get_db()
        db.execute(
            """INSERT INTO conversions
               (user_id, source_dialect, target_dialect, source_sql, output_sql, notes_json, complexity_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                user["id"], src, tgt, sql, final_sql,
                json.dumps(all_notes),
                json.dumps(analysis["complexity"]),
                int(time.time()),
            ),
        )
        db.commit()

    return jsonify({
        "ok": True,
        "output_sql": final_sql,
        "conversion_notes": conversion_notes,
        "issues": analysis["issues"],
        "complexity": analysis["complexity"],
        "stats": {
            "conversions_applied": len(conversion_notes),
            "issues_found": len([i for i in analysis["issues"] if i["type"] in ("warn", "crit")]),
        },
    })


@app.route("/api/history")
def history():
    user, err = require_auth()
    if err: return err
    db = get_db()
    rows = db.execute(
        """SELECT id, source_dialect, target_dialect, source_sql, output_sql, complexity_json, created_at
           FROM conversions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50""",
        (user["id"],),
    ).fetchall()
    return jsonify({
        "history": [
            {
                "id": r["id"],
                "source_dialect": r["source_dialect"],
                "target_dialect": r["target_dialect"],
                "source_sql": r["source_sql"],
                "output_sql": r["output_sql"],
                "complexity": json.loads(r["complexity_json"]),
                "created_at": r["created_at"],
            }
            for r in rows
        ]
    })


@app.route("/api/saved", methods=["GET", "POST"])
def saved_queries():
    user, err = require_auth()
    if err: return err
    db = get_db()

    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        name = (data.get("name") or "").strip()
        if not name:
            return jsonify({"error": "Name required"}), 400
        db.execute(
            """INSERT INTO saved_queries
               (user_id, name, source_dialect, target_dialect, source_sql, output_sql, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                user["id"], name,
                data.get("source_dialect", ""), data.get("target_dialect", ""),
                data.get("source_sql", ""), data.get("output_sql", ""),
                int(time.time()),
            ),
        )
        db.commit()
        return jsonify({"ok": True})

    rows = db.execute(
        "SELECT * FROM saved_queries WHERE user_id = ? ORDER BY created_at DESC",
        (user["id"],),
    ).fetchall()
    return jsonify({
        "saved": [
            {
                "id": r["id"], "name": r["name"],
                "source_dialect": r["source_dialect"],
                "target_dialect": r["target_dialect"],
                "source_sql": r["source_sql"],
                "output_sql": r["output_sql"],
                "created_at": r["created_at"],
            } for r in rows
        ]
    })


@app.route("/api/saved/<int:saved_id>", methods=["DELETE"])
def delete_saved(saved_id):
    user, err = require_auth()
    if err: return err
    db = get_db()
    db.execute("DELETE FROM saved_queries WHERE id = ? AND user_id = ?", (saved_id, user["id"]))
    db.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


# CORS (simple)
@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return resp


@app.route("/<path:path>", methods=["OPTIONS"])
@app.route("/", methods=["OPTIONS"])
def cors_preflight(path=""):
    return make_response("", 204)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
