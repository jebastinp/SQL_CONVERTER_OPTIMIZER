/* =========================================================
   SQL Forge — Frontend (single file, no framework)
   ========================================================= */

const API = ""; // same-origin

/* ---------------- Sample queries ---------------- */
const SAMPLES = {
  mssql: `-- Find top customers and their recent orders
SELECT TOP 10 c.CustomerID, c.Name, c.Email,
    (SELECT COUNT(*) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS OrderCount,
    GETDATE() AS RetrievedAt,
    ISNULL(c.Country, 'Unknown') AS Country
FROM Customers c
WHERE c.Status = 'active'
    AND c.Email LIKE '%@example.com'
    AND YEAR(c.CreatedAt) = 2024
ORDER BY OrderCount DESC;`,
  postgresql: `SELECT c.customer_id, c.name, c.email,
    COUNT(o.order_id) AS order_count
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.customer_id
WHERE c.status = 'active'
GROUP BY c.customer_id, c.name, c.email
ORDER BY order_count DESC
LIMIT 10;`,
  mysql: `SELECT c.id, c.name, c.email,
    DATE_FORMAT(c.created_at, '%Y-%m-%d') AS joined,
    IFNULL(c.country, 'N/A') AS country
FROM customers c
WHERE c.status = 'active'
LIMIT 10;`,
  oracle: `SELECT c.customer_id, c.name, NVL(c.country, 'Unknown') AS country
FROM customers c
WHERE ROWNUM <= 10
  AND SYSDATE - c.created_at < 365;`,
  sqlite: `SELECT c.id, c.name, c.email
FROM customers c
WHERE c.status = 'active'
LIMIT 10;`,
  snowflake: `SELECT c.id, c.name, CURRENT_TIMESTAMP() AS now
FROM customers c
QUALIFY ROW_NUMBER() OVER (PARTITION BY c.country ORDER BY c.created_at DESC) = 1;`,
  bigquery: `SELECT c.id, c.name, FORMAT_TIMESTAMP('%Y-%m-%d', c.created_at) AS joined
FROM \`project.dataset.customers\` c
WHERE c.status = 'active'
LIMIT 10;`,
  redshift: `SELECT c.id, c.name, GETDATE() AS now
FROM customers c LIMIT 10;`,
  duckdb: `SELECT c.id, c.name FROM customers c WHERE c.status = 'active' LIMIT 10;`
};

/* =========================================================
   PROPER SQL TOKENIZER (state machine, not regex)
   This is what was broken before — operators were eating
   parts of HTML attributes. Now tokens are built explicitly.
   ========================================================= */
const SQL_KEYWORDS = new Set([
  'SELECT','FROM','WHERE','GROUP','BY','ORDER','HAVING','LIMIT','OFFSET',
  'INNER','LEFT','RIGHT','FULL','OUTER','CROSS','JOIN','ON','USING',
  'AND','OR','NOT','IN','EXISTS','LIKE','ILIKE','BETWEEN','IS','NULL',
  'AS','UNION','ALL','INSERT','INTO','VALUES','UPDATE','SET','DELETE',
  'CASE','WHEN','THEN','ELSE','END','WITH','RECURSIVE','DISTINCT','TOP',
  'FETCH','FIRST','NEXT','ROWS','ONLY','PARTITION','OVER','WINDOW',
  'CREATE','TABLE','VIEW','INDEX','DROP','ALTER','ADD','COLUMN',
  'PRIMARY','KEY','FOREIGN','REFERENCES','CONSTRAINT','UNIQUE','DEFAULT',
  'CAST','CONVERT','ASC','DESC','TRUE','FALSE','LATERAL','QUALIFY',
  'GENERATED','ALWAYS','IDENTITY','RETURNING','EXTRACT'
]);

function tokenize(sql) {
  const tokens = [];
  let i = 0;
  const len = sql.length;

  while (i < len) {
    const ch = sql[i];

    // ---- Whitespace ----
    if (/\s/.test(ch)) {
      let j = i;
      while (j < len && /\s/.test(sql[j])) j++;
      tokens.push({ type: 'ws', value: sql.slice(i, j) });
      i = j;
      continue;
    }

    // ---- Line comment ----
    if (ch === '-' && sql[i + 1] === '-') {
      let j = i;
      while (j < len && sql[j] !== '\n') j++;
      tokens.push({ type: 'comment', value: sql.slice(i, j) });
      i = j;
      continue;
    }

    // ---- Block comment ----
    if (ch === '/' && sql[i + 1] === '*') {
      let j = i + 2;
      while (j < len - 1 && !(sql[j] === '*' && sql[j + 1] === '/')) j++;
      j = Math.min(len, j + 2);
      tokens.push({ type: 'comment', value: sql.slice(i, j) });
      i = j;
      continue;
    }

    // ---- String literal (single quote, handles escaped '') ----
    if (ch === "'") {
      let j = i + 1;
      while (j < len) {
        if (sql[j] === "'" && sql[j + 1] === "'") { j += 2; continue; }
        if (sql[j] === "'") { j++; break; }
        j++;
      }
      tokens.push({ type: 'string', value: sql.slice(i, j) });
      i = j;
      continue;
    }

    // ---- Quoted identifier "x" or `x` or [x] ----
    if (ch === '"' || ch === '`') {
      const close = ch;
      let j = i + 1;
      while (j < len && sql[j] !== close) j++;
      j = Math.min(len, j + 1);
      tokens.push({ type: 'identifier', value: sql.slice(i, j) });
      i = j;
      continue;
    }
    if (ch === '[') {
      let j = i + 1;
      while (j < len && sql[j] !== ']') j++;
      j = Math.min(len, j + 1);
      tokens.push({ type: 'identifier', value: sql.slice(i, j) });
      i = j;
      continue;
    }

    // ---- Number ----
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(sql[i + 1] || ''))) {
      let j = i;
      while (j < len && /[0-9.]/.test(sql[j])) j++;
      tokens.push({ type: 'number', value: sql.slice(i, j) });
      i = j;
      continue;
    }

    // ---- Operator / punctuation ----
    if (/[=<>!+\-*\/%,;().|&^]/.test(ch)) {
      // multi-char operators
      const two = sql.slice(i, i + 2);
      if (['<=', '>=', '<>', '!=', '||', '&&', '::'].includes(two)) {
        tokens.push({ type: 'operator', value: two });
        i += 2;
        continue;
      }
      if (',;().'.includes(ch)) {
        tokens.push({ type: 'punct', value: ch });
      } else {
        tokens.push({ type: 'operator', value: ch });
      }
      i++;
      continue;
    }

    // ---- Word (identifier or keyword) ----
    if (/[A-Za-z_]/.test(ch)) {
      let j = i;
      while (j < len && /[A-Za-z0-9_]/.test(sql[j])) j++;
      const word = sql.slice(i, j);
      const upper = word.toUpperCase();

      // Check if it's a function: word followed by optional whitespace then (
      let k = j;
      while (k < len && /\s/.test(sql[k])) k++;
      const isFunction = sql[k] === '(' && !SQL_KEYWORDS.has(upper);

      if (SQL_KEYWORDS.has(upper)) {
        tokens.push({ type: 'keyword', value: word });
      } else if (isFunction) {
        tokens.push({ type: 'function', value: word });
      } else {
        tokens.push({ type: 'identifier', value: word });
      }
      i = j;
      continue;
    }

    // ---- Anything else: pass through ----
    tokens.push({ type: 'other', value: ch });
    i++;
  }

  return tokens;
}

function escapeHtml(s) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function highlight(sql) {
  const tokens = tokenize(sql);
  return tokens.map(t => {
    const escaped = escapeHtml(t.value);
    switch (t.type) {
      case 'keyword':    return `<span class="tok-kw">${escaped}</span>`;
      case 'function':   return `<span class="tok-fn">${escaped}</span>`;
      case 'string':     return `<span class="tok-str">${escaped}</span>`;
      case 'number':     return `<span class="tok-num">${escaped}</span>`;
      case 'comment':    return `<span class="tok-com">${escaped}</span>`;
      case 'operator':   return `<span class="tok-op">${escaped}</span>`;
      case 'identifier': return `<span class="tok-id">${escaped}</span>`;
      default:           return escaped;
    }
  }).join('');
}

/* =========================================================
   State + auth
   ========================================================= */
const state = {
  token: localStorage.getItem('sqlforge_token') || null,
  user: null,
  dialects: [],
  lastConvert: null,
};

async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (state.token) headers['Authorization'] = `Bearer ${state.token}`;
  const res = await fetch(API + path, { ...opts, headers });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  return { ok: res.ok, status: res.status, data };
}

/* =========================================================
   DOM helpers
   ========================================================= */
const $ = id => document.getElementById(id);

function showToast(msg, isError = false) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.toggle('error', !!isError);
  t.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => t.classList.remove('show'), 1800);
}

function setView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  const target = $('view-' + name);
  if (target) target.classList.add('active');
  if (name === 'history') loadHistory();
  if (name === 'saved') loadSaved();
}

/* =========================================================
   Initial setup
   ========================================================= */
async function loadDialects() {
  const res = await api('/api/dialects');
  if (!res.ok) {
    // Fallback list if backend not reachable
    state.dialects = [
      { id: 'mssql', name: 'MSSQL' }, { id: 'postgresql', name: 'PostgreSQL' },
      { id: 'mysql', name: 'MySQL' }, { id: 'oracle', name: 'Oracle' },
      { id: 'sqlite', name: 'SQLite' },
    ];
  } else {
    state.dialects = res.data.dialects;
  }
  const srcSel = $('srcDialect');
  const tgtSel = $('tgtDialect');
  srcSel.innerHTML = state.dialects.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
  tgtSel.innerHTML = state.dialects.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
  srcSel.value = 'mssql';
  tgtSel.value = 'postgresql';
  updateLabels();
}

function updateLabels() {
  const srcSel = $('srcDialect');
  const tgtSel = $('tgtDialect');
  const find = id => state.dialects.find(d => d.id === id);
  const s = find(srcSel.value); const t = find(tgtSel.value);
  if (s) $('srcLabel').textContent = s.name;
  if (t) $('tgtLabel').textContent = t.name;
}

async function checkAuth() {
  if (!state.token) {
    document.body.classList.remove('authed');
    renderAuthArea();
    return;
  }
  const res = await api('/api/auth/me');
  if (res.ok && res.data.authenticated) {
    state.user = res.data.user;
    document.body.classList.add('authed');
  } else {
    state.token = null;
    localStorage.removeItem('sqlforge_token');
    document.body.classList.remove('authed');
  }
  renderAuthArea();
}

function renderAuthArea() {
  const area = $('authArea');
  if (state.user) {
    area.innerHTML = `
      <span class="user-chip">${state.user.email}</span>
      <button class="btn btn-ghost" id="logoutBtn">Log out</button>
    `;
    $('logoutBtn').onclick = logout;
  } else {
    area.innerHTML = `
      <button class="btn btn-ghost" id="loginBtn">Log in</button>
      <button class="btn btn-primary" id="signupBtn">Sign up free</button>
    `;
    $('loginBtn').onclick = () => openAuth('login');
    $('signupBtn').onclick = () => openAuth('signup');
  }
}

/* =========================================================
   Auth modal
   ========================================================= */
let authMode = 'login';

function openAuth(mode) {
  authMode = mode;
  $('authTitle').textContent = mode === 'login' ? 'Log in' : 'Sign up';
  $('authSub').textContent = mode === 'login'
    ? 'Welcome back. Sign in to save queries and view history.'
    : 'Create a free account to save queries and view your history.';
  $('authSubmit').textContent = mode === 'login' ? 'Log in' : 'Create account';
  $('authSwitchText').textContent = mode === 'login' ? "Don't have an account?" : 'Already have an account?';
  $('authSwitchBtn').textContent = mode === 'login' ? 'Sign up' : 'Log in';
  $('authError').textContent = '';
  $('authPassword').setAttribute('autocomplete', mode === 'login' ? 'current-password' : 'new-password');
  $('authModal').classList.add('open');
  setTimeout(() => $('authEmail').focus(), 50);
}

function closeModal(el) {
  el.classList.remove('open');
}

async function submitAuth(e) {
  e.preventDefault();
  const email = $('authEmail').value.trim();
  const password = $('authPassword').value;
  $('authError').textContent = '';
  $('authSubmit').disabled = true;
  $('authSubmit').textContent = '...';

  const res = await api(`/api/auth/${authMode === 'login' ? 'login' : 'signup'}`, {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  $('authSubmit').disabled = false;
  $('authSubmit').textContent = authMode === 'login' ? 'Log in' : 'Create account';

  if (!res.ok) {
    $('authError').textContent = (res.data && res.data.error) || 'Something went wrong';
    return;
  }

  state.token = res.data.token;
  state.user = res.data.user;
  localStorage.setItem('sqlforge_token', state.token);
  document.body.classList.add('authed');
  renderAuthArea();
  closeModal($('authModal'));
  showToast(authMode === 'login' ? 'Logged in' : 'Welcome!');
}

async function logout() {
  await api('/api/auth/logout', { method: 'POST' });
  state.token = null;
  state.user = null;
  localStorage.removeItem('sqlforge_token');
  document.body.classList.remove('authed');
  renderAuthArea();
  setView('convert');
  showToast('Logged out');
}

/* =========================================================
   Convert
   ========================================================= */
function updateLineNumbers() {
  const input = $('inputSQL');
  const lnIn = $('lnInput');
  const lines = (input.value.split('\n').length) || 1;
  lnIn.innerHTML = Array.from({ length: lines }, (_, i) => i + 1).join('<br>');
}

function setOutputLineNumbers(text) {
  const lnOut = $('lnOutput');
  const lines = text.split('\n').length;
  lnOut.innerHTML = Array.from({ length: lines }, (_, i) => i + 1).join('<br>');
}

function getOpt(name) {
  const el = document.querySelector(`.toggle[data-opt="${name}"]`);
  return el && el.classList.contains('active');
}

function resetStats() {
  $('statBigO').textContent = 'O(?)';
  $('statBigOSub').textContent = 'Run conversion to estimate';
  $('statCost').textContent = '—';
  $('statCostSub').textContent = 'Relative scan + join cost';
  $('statCostSub').className = 'stat-sub';
  $('statOpt').textContent = '0';
  $('statOptSub').textContent = 'Dialect rewrites';
  $('statIssues').textContent = '0';
  $('statIssuesSub').textContent = 'Anti-patterns + warnings';
}

function renderReport(items) {
  const list = $('reportList');
  if (!items || !items.length) {
    list.innerHTML = '<div class="empty-report">No issues found — query looks clean ✓</div>';
    return;
  }
  list.innerHTML = items.map(it => `
    <div class="report-item ${it.type}">
      <div class="report-tag">${it.type === 'crit' ? 'Critical' : it.type === 'warn' ? 'Warning' : it.type === 'ok' ? 'Improved' : 'Info'}</div>
      <div class="report-body">
        <strong>${escapeHtml(it.title)}</strong>
        <span>${escapeHtml(it.desc)}</span>
      </div>
      <div class="report-impact">${it.impact ? 'Impact · ' + escapeHtml(it.impact) : ''}</div>
    </div>
  `).join('');
}

async function doConvert() {
  const sql = $('inputSQL').value.trim();
  if (!sql) { showToast('Paste a query first', true); return; }

  const loader = $('loader');
  loader.classList.add('on');
  $('convertBtn').disabled = true;

  const t0 = performance.now();
  const res = await api('/api/convert', {
    method: 'POST',
    body: JSON.stringify({
      sql,
      source_dialect: $('srcDialect').value,
      target_dialect: $('tgtDialect').value,
      optimize: getOpt('optimize'),
      format: getOpt('format'),
    }),
  });
  const t1 = performance.now();

  loader.classList.remove('on');
  $('convertBtn').disabled = false;

  if (!res.ok || !res.data) {
    showToast('Server error — check connection', true);
    return;
  }

  const data = res.data;
  if (data.ok === false) {
    // Soft error — show the parse error inline
    $('outputSQL').innerHTML = `<span class="tok-com">-- ${escapeHtml(data.error)}</span>`;
    setOutputLineNumbers('');
    resetStats();
    renderReport([{
      type: 'crit',
      title: 'Could not parse source query',
      desc: data.error || 'The query could not be parsed in the selected source dialect. Check the dialect and syntax.',
      impact: '—',
    }]);
    $('reportTime').textContent = `Failed in ${(t1 - t0).toFixed(1)} ms`;
    return;
  }

  // Success
  state.lastConvert = data;
  const out = data.output_sql || '';
  $('outputSQL').innerHTML = highlight(out);
  setOutputLineNumbers(out);

  const cx = data.complexity || {};
  $('statBigO').innerHTML = `<em>${escapeHtml(cx.bigO || 'O(?)')}</em>`;
  $('statBigOSub').textContent = cx.desc || '';
  $('statCost').textContent = (cx.cost != null) ? cx.cost + ' / 100' : '—';
  $('statCostSub').textContent = cx.costLabel || '';
  $('statCostSub').className = 'stat-sub ' + (cx.costClass || '');

  const stats = data.stats || {};
  $('statOpt').textContent = stats.conversions_applied || 0;
  $('statOptSub').textContent = stats.conversions_applied === 0 ? 'No rewrites needed' : 'Dialect rewrites';
  $('statIssues').textContent = stats.issues_found || 0;
  $('statIssuesSub').textContent = stats.issues_found === 0 ? 'No anti-patterns found' : 'See report below';

  const allNotes = [...(data.conversion_notes || []), ...(data.issues || [])];
  renderReport(allNotes);
  $('reportTime').textContent = `Generated in ${(t1 - t0).toFixed(1)} ms`;
}

/* =========================================================
   History
   ========================================================= */
function fmtTime(unix) {
  const d = new Date(unix * 1000);
  return d.toLocaleString();
}

async function loadHistory() {
  const list = $('historyList');
  list.innerHTML = '<div class="empty-report">Loading…</div>';

  if (!state.user) {
    list.innerHTML = '<div class="empty-report">Log in to view history.</div>';
    return;
  }
  const res = await api('/api/history');
  if (!res.ok) {
    list.innerHTML = '<div class="empty-report">Could not load history.</div>';
    return;
  }
  const items = res.data.history || [];
  if (!items.length) {
    list.innerHTML = '<div class="empty-report">No conversions yet. Run one and it will appear here.</div>';
    return;
  }
  list.innerHTML = items.map(h => `
    <div class="history-item" data-id="${h.id}">
      <div class="history-meta">
        <div><span class="dialect-pill">${h.source_dialect}</span> → <span class="dialect-pill">${h.target_dialect}</span></div>
        <div style="margin-top:4px">${fmtTime(h.created_at)}</div>
      </div>
      <div class="history-snippet">${escapeHtml(h.source_sql.split('\n')[0].slice(0, 120))}</div>
      <div class="history-meta">${escapeHtml(h.complexity.bigO || '')}</div>
    </div>
  `).join('');
  list.querySelectorAll('.history-item').forEach(el => {
    el.addEventListener('click', () => {
      const id = parseInt(el.dataset.id);
      const item = items.find(x => x.id === id);
      if (!item) return;
      $('srcDialect').value = item.source_dialect;
      $('tgtDialect').value = item.target_dialect;
      $('inputSQL').value = item.source_sql;
      updateLabels();
      updateLineNumbers();
      $('outputSQL').innerHTML = highlight(item.output_sql);
      setOutputLineNumbers(item.output_sql);
      setView('convert');
      showToast('Loaded from history');
    });
  });
}

/* =========================================================
   Saved queries
   ========================================================= */
async function loadSaved() {
  const list = $('savedList');
  list.innerHTML = '<div class="empty-report">Loading…</div>';

  if (!state.user) {
    list.innerHTML = '<div class="empty-report">Log in to view saved queries.</div>';
    return;
  }
  const res = await api('/api/saved');
  if (!res.ok) {
    list.innerHTML = '<div class="empty-report">Could not load saved queries.</div>';
    return;
  }
  const items = res.data.saved || [];
  if (!items.length) {
    list.innerHTML = '<div class="empty-report">No saved queries yet.</div>';
    return;
  }
  list.innerHTML = items.map(h => `
    <div class="history-item" data-id="${h.id}">
      <div class="history-meta">
        <div style="color:var(--text); font-family:'Inter',sans-serif; font-size:14px; text-transform:none; letter-spacing:0">
          ${escapeHtml(h.name)}
        </div>
        <div style="margin-top:4px">
          <span class="dialect-pill">${h.source_dialect}</span> → <span class="dialect-pill">${h.target_dialect}</span>
        </div>
      </div>
      <div class="history-snippet">${escapeHtml(h.source_sql.split('\n')[0].slice(0, 120))}</div>
      <div class="history-actions">
        <button class="icon-btn delete-saved" data-id="${h.id}" title="Delete">×</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.history-item').forEach(el => {
    el.addEventListener('click', e => {
      if (e.target.classList.contains('delete-saved')) return;
      const id = parseInt(el.dataset.id);
      const item = items.find(x => x.id === id);
      if (!item) return;
      $('srcDialect').value = item.source_dialect;
      $('tgtDialect').value = item.target_dialect;
      $('inputSQL').value = item.source_sql;
      updateLabels();
      updateLineNumbers();
      $('outputSQL').innerHTML = highlight(item.output_sql);
      setOutputLineNumbers(item.output_sql);
      setView('convert');
      showToast('Loaded saved query');
    });
  });

  list.querySelectorAll('.delete-saved').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const r = await api('/api/saved/' + id, { method: 'DELETE' });
      if (r.ok) { showToast('Deleted'); loadSaved(); }
      else showToast('Failed to delete', true);
    });
  });
}

/* =========================================================
   Wire it up
   ========================================================= */
function init() {
  // Nav
  document.querySelectorAll('.nav-link').forEach(b => {
    b.addEventListener('click', () => {
      if (b.dataset.authOnly !== undefined && !state.user) {
        openAuth('login'); return;
      }
      setView(b.dataset.view);
    });
  });

  // Toggles
  document.querySelectorAll('.toggle').forEach(t => {
    t.addEventListener('click', e => {
      if (e.target.tagName === 'INPUT') return;
      t.classList.toggle('active');
      const cb = t.querySelector('input');
      cb.checked = t.classList.contains('active');
    });
  });

  // Dialect changes
  $('srcDialect').addEventListener('change', updateLabels);
  $('tgtDialect').addEventListener('change', updateLabels);

  $('swapBtn').addEventListener('click', () => {
    const a = $('srcDialect').value, b = $('tgtDialect').value;
    $('srcDialect').value = b; $('tgtDialect').value = a;
    updateLabels();
  });

  // Sample
  $('sampleBtn').addEventListener('click', () => {
    const src = $('srcDialect').value;
    $('inputSQL').value = SAMPLES[src] || SAMPLES.mssql;
    updateLineNumbers();
  });

  // Clear
  $('clearBtn').addEventListener('click', () => {
    $('inputSQL').value = '';
    updateLineNumbers();
    $('outputSQL').innerHTML = '<span class="placeholder">-- Cleared.</span>';
    setOutputLineNumbers('');
    resetStats();
    $('reportList').innerHTML = '<div class="empty-report">Run a conversion to see what changed and why.</div>';
    $('reportTime').textContent = 'Awaiting input';
  });

  // Copy / paste / download
  $('copyInBtn').addEventListener('click', async () => {
    await navigator.clipboard.writeText($('inputSQL').value);
    showToast('Source copied');
  });
  $('pasteBtn').addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      $('inputSQL').value = text;
      updateLineNumbers();
    } catch (e) { showToast('Clipboard blocked', true); }
  });
  $('copyOutBtn').addEventListener('click', async () => {
    await navigator.clipboard.writeText($('outputSQL').textContent);
    showToast('Output copied');
  });
  $('downloadBtn').addEventListener('click', () => {
    const blob = new Blob([$('outputSQL').textContent], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `query_${$('tgtDialect').value}.sql`;
    a.click();
    showToast('Downloaded');
  });

  // Convert
  $('convertBtn').addEventListener('click', doConvert);

  // Save
  $('saveBtn').addEventListener('click', () => {
    if (!state.user) { openAuth('login'); return; }
    if (!state.lastConvert) { showToast('Run a conversion first', true); return; }
    $('saveModal').classList.add('open');
    $('saveName').focus();
  });

  // Input change → line numbers
  $('inputSQL').addEventListener('input', updateLineNumbers);

  // Modals
  document.querySelectorAll('[data-close]').forEach(b => {
    b.addEventListener('click', () => closeModal(b.closest('.modal-backdrop')));
  });
  document.querySelectorAll('.modal-backdrop').forEach(b => {
    b.addEventListener('click', e => {
      if (e.target === b) closeModal(b);
    });
  });

  // Auth form
  $('authForm').addEventListener('submit', submitAuth);
  $('authSwitchBtn').addEventListener('click', () => {
    openAuth(authMode === 'login' ? 'signup' : 'login');
  });

  // Save form
  $('saveForm').addEventListener('submit', async e => {
    e.preventDefault();
    const name = $('saveName').value.trim();
    if (!name || !state.lastConvert) return;
    const res = await api('/api/saved', {
      method: 'POST',
      body: JSON.stringify({
        name,
        source_dialect: $('srcDialect').value,
        target_dialect: $('tgtDialect').value,
        source_sql: $('inputSQL').value,
        output_sql: state.lastConvert.output_sql,
      }),
    });
    if (res.ok) {
      showToast('Saved');
      closeModal($('saveModal'));
      $('saveName').value = '';
    } else {
      showToast((res.data && res.data.error) || 'Save failed', true);
    }
  });
}

/* =========================================================
   Boot
   ========================================================= */
(async function boot() {
  init();
  await loadDialects();
  await checkAuth();
  // Pre-load sample so first impression is good
  $('inputSQL').value = SAMPLES.mssql;
  updateLineNumbers();
})();
