import type { AppProps } from 'next/app';
import Head from 'next/head';
import { useEffect } from 'react';
import '@/styles/globals.css';

export default function App({ Component, pageProps }: AppProps) {
  // Apply theme before paint to avoid flash
  useEffect(() => {
    const saved = localStorage.getItem('theme');
    const isDark = saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if (isDark) document.documentElement.classList.add('dark');
  }, []);

  return (
    <>
      <Head>
        <title>RouteFlow AI</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="AI route optimization for delivery operations" />
        <link rel="icon" href="/favicon.svg" />
      </Head>
      <Component {...pageProps} />
    </>
  );
}
