import { useEffect, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { Zap, Upload, Users, Route as RouteIcon, TrendingUp } from 'lucide-react';

export default function DashboardPage() {
  const [stats, setStats] = useState({ orders: 0, drivers: 0, routes: [] as any[] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const [o, d, r] = await Promise.all([
        sb.from('orders').select('id', { count: 'exact', head: true }),
        sb.from('drivers').select('id', { count: 'exact', head: true }),
        sb.from('routes').select('*').order('created_at', { ascending: false }).limit(20),
      ]);
      setStats({ orders: o.count || 0, drivers: d.count || 0, routes: r.data || [] });
      setLoading(false);
    })();
  }, []);

  const completed = stats.routes.filter((r) => r.status === 'completed').length;
  const totalFuel = stats.routes.reduce((s, r: any) => s + Number(r.fuel_saved_gbp || 0), 0);
  const totalDistance = stats.routes.reduce((s, r: any) => s + Number(r.distance_km || 0), 0);

  return (
    <AppShell>
      <Topbar title="Dashboard" subtitle="Welcome back · Operations overview"
        actions={<Link href="/routes" className="btn btn-accent"><Zap size={14} />Optimize routes</Link>} />

      <div className="p-6 overflow-auto flex-1">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 fade-up">
          <KPI label="Total Orders" value={String(stats.orders)} icon={Upload} hint="All time" />
          <KPI label="Drivers" value={String(stats.drivers)} icon={Users} hint="In fleet" />
          <KPI label="Routes" value={String(stats.routes.length)} icon={RouteIcon} hint={`${completed} completed`} />
          <KPI label="Fuel Saved" value={`£${totalFuel.toFixed(0)}`} icon={TrendingUp} hint={`${totalDistance.toFixed(0)}km optimized`} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 surface p-6 fade-up">
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="font-serif text-xl">Recent routes</div>
                <div className="text-[12px]" style={{ color: 'var(--ink-3)' }}>Last 20 optimizations</div>
              </div>
            </div>
            {loading ? (
              <div className="text-sm" style={{ color: 'var(--ink-3)' }}>Loading…</div>
            ) : stats.routes.length === 0 ? (
              <div className="text-center py-16">
                <div className="text-[40px] mb-3 opacity-30">⌖</div>
                <div className="text-sm mb-1" style={{ color: 'var(--ink-2)' }}>No routes yet</div>
                <div className="text-[12px]" style={{ color: 'var(--ink-3)' }}>
                  <Link href="/orders" style={{ color: 'var(--accent)' }} className="font-medium">Import orders</Link> to get started
                </div>
              </div>
            ) : (
              <table className="data">
                <thead>
                  <tr><th>Date</th><th>Distance</th><th>Duration</th><th>Saved</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {stats.routes.slice(0, 10).map((r: any) => (
                    <tr key={r.id}>
                      <td>{new Date(r.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                      <td className="font-mono">{Number(r.distance_km || 0).toFixed(1)}km</td>
                      <td className="font-mono">{Number(r.duration_minutes || 0).toFixed(0)}m</td>
                      <td className="font-mono" style={{ color: 'var(--good)' }}>£{Number(r.fuel_saved_gbp || 0).toFixed(2)}</td>
                      <td><span className={`pill ${r.status === 'completed' ? 'pill-ok' : r.status === 'in_progress' ? 'pill-info' : 'pill-neutral'}`}>{r.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="surface p-6 fade-up">
            <div className="font-serif text-xl mb-4">Quick start</div>
            <div className="space-y-3">
              {[
                { n: 1, t: 'Add drivers', d: 'Set up the people who deliver', href: '/drivers' },
                { n: 2, t: 'Import orders', d: 'Upload CSV with customer info', href: '/orders' },
                { n: 3, t: 'Optimize', d: 'Let AI assign and order stops', href: '/routes' },
                { n: 4, t: 'Track live', d: 'Share driver links and monitor', href: '/routes' },
              ].map((s) => (
                <Link key={s.n} href={s.href} className="block surface-soft p-3 hover:translate-x-0.5 transition-transform">
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-[12px] font-semibold shrink-0"
                         style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
                      {s.n}
                    </div>
                    <div>
                      <div className="text-[13px] font-medium">{s.t}</div>
                      <div className="text-[11.5px] mt-0.5" style={{ color: 'var(--ink-3)' }}>{s.d}</div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function KPI({ label, value, hint, icon: Icon }: { label: string; value: string; hint: string; icon: any }) {
  return (
    <div className="surface p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="text-[11px] uppercase tracking-wider font-medium" style={{ color: 'var(--ink-3)' }}>{label}</div>
        <Icon size={15} style={{ color: 'var(--ink-3)' }} />
      </div>
      <div className="font-serif text-3xl tracking-tight">{value}</div>
      <div className="text-[11.5px] mt-1.5" style={{ color: 'var(--ink-3)' }}>{hint}</div>
    </div>
  );
}
