import Link from 'next/link';
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowRight, MapPin, Route, Zap } from 'lucide-react';

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  return (
    <div className="min-h-screen relative" style={{ background: 'var(--bg)' }}>
      <div className="hero-bg pulse-slow" />

      <nav className="relative z-10 px-6 py-5 flex items-center justify-between max-w-6xl mx-auto">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--ink)' }}>
            <MapPin size={15} style={{ color: 'var(--bg)' }} />
          </div>
          <div className="font-serif text-xl tracking-tight">RouteFlow</div>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link href="/login" className="btn btn-ghost">Sign in</Link>
        </div>
      </nav>

      <main className="relative z-10 max-w-3xl mx-auto px-6 pt-16 pb-20 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full surface mb-8 fade-up text-xs"
             style={{ color: 'var(--ink-3)' }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: 'var(--good)' }} />
          Live · AI route intelligence
        </div>

        <h1 className="font-serif text-5xl md:text-7xl tracking-tight leading-[1.05] mb-7 fade-up">
          AI route intelligence for{' '}
          <em style={{ color: 'var(--accent)' }}>modern</em> delivery operations.
        </h1>

        <p className="text-lg fade-up mb-10" style={{ color: 'var(--ink-3)' }}>
          Reduce fuel costs, balance drivers automatically, and orchestrate fleets in real time —
          all powered by intelligent VRP optimization.
        </p>

        <div className="flex gap-3 flex-wrap justify-center fade-up mb-20">
          <Link href="/signup" className="btn btn-primary !text-base !px-6 !py-3">
            Get started <ArrowRight size={16} />
          </Link>
          <Link href="/login" className="btn btn-ghost !text-base !px-6 !py-3">
            Sign in
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 fade-up">
          {[
            { i: Zap, t: 'Upload CSV', d: 'Drop a list of name + address + phone. We geocode and verify in seconds.' },
            { i: Route, t: 'AI Optimize', d: 'OR-Tools VRP solver assigns stops and orders them for minimum distance.' },
            { i: MapPin, t: 'Track Live', d: 'Drivers update positions in real time. Customers see live ETAs.' },
          ].map((f, i) => {
            const Icon = f.i;
            return (
              <div key={i} className="surface p-6 text-left">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                     style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
                  <Icon size={18} />
                </div>
                <div className="font-medium text-base mb-1.5">{f.t}</div>
                <div className="text-[13px]" style={{ color: 'var(--ink-3)' }}>{f.d}</div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-[11px]" style={{ color: 'var(--ink-mute)' }}>
          First time setup? Visit <Link href="/diagnostic" className="underline" style={{ color: 'var(--accent)' }}>/diagnostic</Link>
        </div>
      </main>
    </div>
  );
}
