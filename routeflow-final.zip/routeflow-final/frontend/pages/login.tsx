import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowLeft } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { error } = await supabase().auth.signInWithPassword({ email, password });
      if (error) throw error;
      router.push('/dashboard');
    } catch (e: any) {
      setError(e.message || 'Sign in failed');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen relative" style={{ background: 'var(--bg)' }}>
      <div className="hero-bg pulse-slow" />
      <div className="absolute top-5 right-5 z-10"><ThemeToggle /></div>

      <main className="relative z-10 min-h-screen flex items-center justify-center px-6">
        <div className="surface p-9 w-full max-w-md fade-up" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <Link href="/" className="inline-flex items-center gap-1.5 text-[13px] mb-7"
                style={{ color: 'var(--ink-3)' }}>
            <ArrowLeft size={14} /> Back
          </Link>
          <h1 className="font-serif text-4xl tracking-tight mb-2">
            Welcome <em style={{ color: 'var(--accent)' }}>back</em>
          </h1>
          <p className="text-sm mb-8" style={{ color: 'var(--ink-3)' }}>Sign in to RouteFlow AI</p>

          <form onSubmit={signIn} className="space-y-4">
            <div>
              <label className="fld">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
                className="input" placeholder="you@company.com" />
            </div>
            <div>
              <label className="fld">Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required
                className="input" placeholder="••••••••" />
            </div>
            {error && (
              <div className="text-[13px] px-3 py-2.5 rounded-lg"
                   style={{ color: 'var(--bad)', background: 'color-mix(in srgb, var(--bad) 8%, transparent)', border: '1px solid color-mix(in srgb, var(--bad) 20%, transparent)' }}>
                {error}
              </div>
            )}
            <button type="submit" disabled={loading} className="btn btn-primary w-full !py-3">
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <p className="text-center text-[13px] mt-7" style={{ color: 'var(--ink-3)' }}>
            No account? <Link href="/signup" className="font-medium" style={{ color: 'var(--accent)' }}>Sign up</Link>
          </p>
        </div>
      </main>
    </div>
  );
}
