import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowLeft } from 'lucide-react';

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    setError(null); setInfo(null);
    setLoading(true);
    try {
      const sb = supabase();
      const { data, error } = await sb.auth.signUp({
        email, password,
        options: { data: { full_name: fullName } },
      });
      if (error) throw error;

      if (data.user && companyName) {
        await sb.from('profiles').update({ company_name: companyName }).eq('id', data.user.id);
      }
      if (data.session) {
        router.push('/dashboard');
      } else {
        setInfo('Check your email to confirm, then sign in.');
      }
    } catch (e: any) {
      setError(e.message || 'Signup failed');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen relative" style={{ background: 'var(--bg)' }}>
      <div className="hero-bg pulse-slow" />
      <div className="absolute top-5 right-5 z-10"><ThemeToggle /></div>

      <main className="relative z-10 min-h-screen flex items-center justify-center px-6 py-12">
        <div className="surface p-9 w-full max-w-md fade-up" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <Link href="/" className="inline-flex items-center gap-1.5 text-[13px] mb-7"
                style={{ color: 'var(--ink-3)' }}>
            <ArrowLeft size={14} /> Back
          </Link>
          <h1 className="font-serif text-4xl tracking-tight mb-2">
            Get <em style={{ color: 'var(--accent)' }}>started</em>
          </h1>
          <p className="text-sm mb-8" style={{ color: 'var(--ink-3)' }}>Create your RouteFlow account</p>

          <form onSubmit={signUp} className="space-y-4">
            <div>
              <label className="fld">Full name</label>
              <input value={fullName} onChange={(e) => setFullName(e.target.value)} required className="input" />
            </div>
            <div>
              <label className="fld">Company (optional)</label>
              <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="input" />
            </div>
            <div>
              <label className="fld">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="input" />
            </div>
            <div>
              <label className="fld">Password (min 6)</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="input" />
            </div>
            {error && (
              <div className="text-[13px] px-3 py-2.5 rounded-lg"
                   style={{ color: 'var(--bad)', background: 'color-mix(in srgb, var(--bad) 8%, transparent)', border: '1px solid color-mix(in srgb, var(--bad) 20%, transparent)' }}>
                {error}
              </div>
            )}
            {info && (
              <div className="text-[13px] px-3 py-2.5 rounded-lg"
                   style={{ color: 'var(--good)', background: 'color-mix(in srgb, var(--good) 8%, transparent)', border: '1px solid color-mix(in srgb, var(--good) 20%, transparent)' }}>
                {info}
              </div>
            )}
            <button type="submit" disabled={loading} className="btn btn-primary w-full !py-3">
              {loading ? 'Creating…' : 'Create account'}
            </button>
          </form>

          <p className="text-center text-[13px] mt-7" style={{ color: 'var(--ink-3)' }}>
            Already have one? <Link href="/login" className="font-medium" style={{ color: 'var(--accent)' }}>Sign in</Link>
          </p>
        </div>
      </main>
    </div>
  );
}
