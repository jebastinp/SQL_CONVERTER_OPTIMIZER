import { useEffect, useState } from 'react';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { apiOptimize } from '@/lib/api';
import type { Order, Driver, Profile, OptimizeResponse } from '@/lib/types';
import { Zap, Download, AlertTriangle } from 'lucide-react';

const RouteMap = dynamic(() => import('@/components/RouteMap'), { ssr: false });

export default function RoutesPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [optimization, setOptimization] = useState<OptimizeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [driverPositions, setDriverPositions] = useState<Record<string, { lat: number; lng: number }>>({});

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      const [o, d, p] = await Promise.all([
        sb.from('orders').select('*').eq('geocoded', true),
        sb.from('drivers').select('*'),
        sb.from('profiles').select('*').eq('id', user.id).single(),
      ]);
      setOrders((o.data as Order[]) || []);
      setDrivers((d.data as Driver[]) || []);
      setProfile(p.data as Profile);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const sb = supabase();
    const channel = sb.channel('driver_positions_live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'driver_positions' }, (payload: any) => {
        const p = payload.new;
        setDriverPositions((prev) => ({ ...prev, [p.driver_id]: { lat: Number(p.lat), lng: Number(p.lng) } }));
      })
      .subscribe();
    return () => { sb.removeChannel(channel); };
  }, []);

  async function optimize() {
    if (!profile) return;
    if (orders.length === 0) { setError('No geocoded orders. Import & geocode first.'); return; }
    if (drivers.length === 0) { setError('No drivers. Add at least one driver first.'); return; }
    setError(null);
    setOptimizing(true);
    try {
      const body = {
        depot: { lat: Number(profile.depot_lat), lng: Number(profile.depot_lng) },
        orders: orders.map((o) => ({
          id: o.id, customer_name: o.customer_name, address: o.address,
          lat: Number(o.lat), lng: Number(o.lng),
        })),
        drivers: drivers.map((d) => ({
          id: d.id, name: d.name, vehicle: d.vehicle || '',
          capacity: d.capacity, color: d.color,
        })),
        avg_speed_kmh: Number(profile.avg_speed_kmh),
        fuel_price_gbp: Number(profile.fuel_price_gbp),
        vehicle_kml: Number(profile.vehicle_kml),
      };
      const result: OptimizeResponse = await apiOptimize(body);
      setOptimization(result);

      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      for (const route of result.routes) {
        const { data: routeRow } = await sb.from('routes').insert({
          user_id: user.id,
          driver_id: route.driver_id,
          status: 'planned',
          depot_lat: profile.depot_lat,
          depot_lng: profile.depot_lng,
          distance_km: route.distance_km,
          duration_minutes: route.duration_minutes,
          fuel_saved_gbp: result.fuel_saved_gbp / Math.max(1, result.routes.length),
          baseline_km: result.baseline_distance_km / Math.max(1, result.routes.length),
        }).select().single();
        if (routeRow) {
          await sb.from('delivery_stops').insert(route.stops.map((s) => ({
            route_id: routeRow.id,
            order_id: s.order_id,
            user_id: user.id,
            sequence: s.sequence,
            eta_clock: s.eta_clock,
            status: 'pending',
          })));
          await sb.from('orders').update({ status: 'assigned' })
            .in('id', route.stops.map((s) => s.order_id).filter(Boolean));
        }
      }
    } catch (e: any) {
      setError(e.message);
    }
    setOptimizing(false);
  }

  function exportCSV() {
    if (!optimization) return;
    let csv = 'Driver,Sequence,Customer,Address,ETA,Lat,Lng\n';
    for (const r of optimization.routes) {
      for (const s of r.stops) {
        csv += `"${r.driver_name}",${s.sequence},"${s.customer_name}","${s.address}","${s.eta_clock}",${s.lat},${s.lng}\n`;
      }
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `routes-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  }

  const canOptimize = orders.length > 0 && drivers.length > 0 && !loading;

  return (
    <AppShell>
      <Topbar
        title="Live Routes"
        subtitle={optimization
          ? `${optimization.routes.length} routes · saved ${optimization.distance_saved_km.toFixed(1)}km · £${optimization.fuel_saved_gbp.toFixed(2)}`
          : 'Plan and dispatch'}
        actions={
          <div className="flex gap-2">
            {optimization && (
              <button onClick={exportCSV} className="btn btn-ghost"><Download size={14} />Export</button>
            )}
            <button onClick={optimize} disabled={optimizing || !canOptimize} className="btn btn-accent">
              <Zap size={14} />{optimizing ? 'Optimizing…' : 'Optimize routes'}
            </button>
          </div>
        }
      />

      {error && (
        <div className="mx-6 mt-4 px-4 py-3 rounded-lg text-[13px] flex items-center gap-2"
             style={{ color: 'var(--bad)', background: 'color-mix(in srgb, var(--bad) 8%, transparent)', border: '1px solid color-mix(in srgb, var(--bad) 20%, transparent)' }}>
          <AlertTriangle size={15} />
          {error}
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[340px_1fr] overflow-hidden">
        <aside className="overflow-auto p-4 space-y-3"
               style={{ background: 'var(--bg-soft)', borderRight: '1px solid var(--stroke)' }}>
          {!optimization ? (
            <div className="text-center py-12 fade-up">
              {loading ? (
                <div className="text-sm" style={{ color: 'var(--ink-3)' }}>Loading…</div>
              ) : (
                <>
                  <div className="text-[40px] mb-3 opacity-30">⌖</div>
                  <div className="text-sm mb-2" style={{ color: 'var(--ink-2)' }}>
                    {canOptimize ? 'Ready to optimize' : 'Setup required'}
                  </div>
                  <div className="text-[12px] mb-4" style={{ color: 'var(--ink-3)' }}>
                    {orders.length} geocoded orders · {drivers.length} drivers
                  </div>
                  {!canOptimize && (
                    <div className="space-y-2 mt-4">
                      {orders.length === 0 && (
                        <Link href="/orders" className="btn btn-ghost text-[12px]">Import orders →</Link>
                      )}
                      {drivers.length === 0 && (
                        <Link href="/drivers" className="btn btn-ghost text-[12px]">Add drivers →</Link>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          ) : (
            <>
              <div className="surface p-4 fade-up">
                <div className="text-[10px] uppercase tracking-widest mb-2" style={{ color: 'var(--ink-3)' }}>Summary</div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--ink-3)' }}>Total km</div>
                    <div className="font-mono text-base">{optimization.total_distance_km.toFixed(1)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--ink-3)' }}>Saved km</div>
                    <div className="font-mono text-base" style={{ color: 'var(--good)' }}>{optimization.distance_saved_km.toFixed(1)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--ink-3)' }}>Fuel £</div>
                    <div className="font-mono text-base" style={{ color: 'var(--good)' }}>£{optimization.fuel_saved_gbp.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--ink-3)' }}>Algo</div>
                    <div className="font-mono text-[10px]" style={{ color: 'var(--ink-3)' }}>{optimization.algorithm}</div>
                  </div>
                </div>
              </div>

              {optimization.routes.map((route) => (
                <div key={route.driver_id} className="fade-up">
                  <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg mb-2"
                       style={{ background: 'var(--bg-elev)', borderLeft: `3px solid ${route.driver_color}` }}>
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: route.driver_color }} />
                    <div className="text-[13px] font-medium flex-1">{route.driver_name}</div>
                    <div className="text-[11px] font-mono" style={{ color: 'var(--ink-3)' }}>
                      {route.stops.length} · {route.distance_km.toFixed(1)}km
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    {route.stops.map((s) => (
                      <div key={s.sequence} className="surface flex items-center gap-2.5 px-2.5 py-2 text-[12px]">
                        <div className="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-bold text-white font-mono shrink-0"
                             style={{ background: route.driver_color }}>
                          {s.sequence}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate">{s.customer_name}</div>
                          <div className="text-[10.5px] truncate" style={{ color: 'var(--ink-3)' }}>{s.address}</div>
                        </div>
                        <div className="text-[10.5px] font-mono" style={{ color: 'var(--accent)' }}>{s.eta_clock}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}
        </aside>

        <div className="relative">
          <RouteMap optimization={optimization} profile={profile} driverPositions={driverPositions} />
        </div>
      </div>
    </AppShell>
  );
}
