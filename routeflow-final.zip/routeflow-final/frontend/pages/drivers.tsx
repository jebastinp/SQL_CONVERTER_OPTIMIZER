import { useEffect, useState } from 'react';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import type { Driver } from '@/lib/types';
import { Plus, Trash2, Copy, Smartphone, X, Check } from 'lucide-react';

const COLORS = ['#2563eb', '#0ea5e9', '#8b5cf6', '#d97706', '#059669', '#dc2626', '#db2777', '#0891b2'];

export default function DriversPage() {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [adding, setAdding] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '', phone: '', vehicle: '', capacity: 30, color: COLORS[0],
  });

  async function refresh() {
    const { data } = await supabase().from('drivers').select('*').order('created_at', { ascending: false });
    setDrivers((data as Driver[]) || []);
    setLoading(false);
  }
  useEffect(() => { refresh(); }, []);

  async function addDriver(e: React.FormEvent) {
    e.preventDefault();
    setAdding(true);
    const sb = supabase();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) { setAdding(false); return; }
    await sb.from('drivers').insert({ ...form, user_id: user.id });
    setForm({ name: '', phone: '', vehicle: '', capacity: 30, color: COLORS[(drivers.length + 1) % COLORS.length] });
    setShowAdd(false);
    await refresh();
    setAdding(false);
  }

  async function deleteDriver(id: string) {
    if (!confirm('Delete this driver?')) return;
    await supabase().from('drivers').delete().eq('id', id);
    await refresh();
  }

  function copyLink(token: string, id: string) {
    const url = `${location.origin}/driver/${token}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  return (
    <AppShell>
      <Topbar
        title="Drivers"
        subtitle={`${drivers.length} in fleet`}
        actions={
          <button onClick={() => setShowAdd(!showAdd)} className="btn btn-accent">
            <Plus size={14} />Add driver
          </button>
        }
      />

      <div className="p-6 overflow-auto flex-1 space-y-5">
        {showAdd && (
          <div className="surface p-5 fade-up">
            <div className="flex items-center justify-between mb-4">
              <div className="font-serif text-lg">New driver</div>
              <button onClick={() => setShowAdd(false)} className="btn btn-ghost !p-1.5"><X size={14} /></button>
            </div>
            <form onSubmit={addDriver} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className="fld">Name</label>
                <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required placeholder="Sarah Johnson" />
              </div>
              <div>
                <label className="fld">Phone</label>
                <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="07700 900123" />
              </div>
              <div>
                <label className="fld">Vehicle</label>
                <input className="input" value={form.vehicle} onChange={(e) => setForm({ ...form, vehicle: e.target.value })} placeholder="VW Crafter" />
              </div>
              <div>
                <label className="fld">Capacity</label>
                <input type="number" className="input" min={1} value={form.capacity} onChange={(e) => setForm({ ...form, capacity: parseInt(e.target.value) || 30 })} />
              </div>
              <div className="md:col-span-2 lg:col-span-4">
                <label className="fld">Marker color</label>
                <div className="flex gap-1.5 flex-wrap">
                  {COLORS.map((c) => (
                    <button key={c} type="button" onClick={() => setForm({ ...form, color: c })}
                      className="w-8 h-8 rounded-lg transition-transform"
                      style={{
                        background: c,
                        transform: form.color === c ? 'scale(1.15)' : 'scale(1)',
                        boxShadow: form.color === c ? '0 0 0 2px var(--bg), 0 0 0 4px var(--ink)' : 'var(--shadow-sm)',
                      }} />
                  ))}
                </div>
              </div>
              <div className="md:col-span-2 lg:col-span-4 flex justify-end">
                <button type="submit" disabled={adding} className="btn btn-primary">
                  {adding ? 'Adding…' : 'Add driver'}
                </button>
              </div>
            </form>
          </div>
        )}

        {loading ? (
          <div className="text-sm" style={{ color: 'var(--ink-3)' }}>Loading…</div>
        ) : drivers.length === 0 ? (
          <div className="surface p-12 text-center fade-up">
            <div className="text-[40px] mb-3 opacity-30">👤</div>
            <div className="text-sm mb-1" style={{ color: 'var(--ink-2)' }}>No drivers yet</div>
            <div className="text-[12px] mb-4" style={{ color: 'var(--ink-3)' }}>Add your first driver to start optimizing routes.</div>
            <button onClick={() => setShowAdd(true)} className="btn btn-primary mx-auto">
              <Plus size={14} />Add driver
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {drivers.map((d) => {
              const initials = d.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase();
              return (
                <div key={d.id} className="surface p-5 fade-up">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center font-semibold text-white text-sm shrink-0"
                         style={{ background: d.color }}>
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-[14px] truncate">{d.name}</div>
                      <div className="text-[12px] truncate" style={{ color: 'var(--ink-3)' }}>
                        {d.vehicle || 'No vehicle'}
                      </div>
                    </div>
                    <button onClick={() => deleteDriver(d.id)} className="btn-danger-ghost p-1.5 rounded">
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    <div className="surface-soft p-2.5 text-center">
                      <div className="font-serif text-xl">{d.capacity}</div>
                      <div className="text-[10px] uppercase tracking-wider mt-0.5" style={{ color: 'var(--ink-3)' }}>Capacity</div>
                    </div>
                    <div className="surface-soft p-2.5 text-center">
                      <div className="font-mono text-[13px] mt-0.5 truncate">{d.phone || '—'}</div>
                      <div className="text-[10px] uppercase tracking-wider mt-0.5" style={{ color: 'var(--ink-3)' }}>Phone</div>
                    </div>
                  </div>
                  <button onClick={() => copyLink(d.access_token, d.id)} className="btn btn-ghost w-full !py-2 !text-[12px]">
                    {copiedId === d.id ? (
                      <><Check size={12} style={{ color: 'var(--good)' }} /> Copied!</>
                    ) : (
                      <><Smartphone size={12} /> Copy driver app link <Copy size={12} /></>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppShell>
  );
}
