import { useEffect, useRef, useState } from 'react';
import Papa from 'papaparse';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { apiGeocodeBatch } from '@/lib/api';
import type { Order } from '@/lib/types';
import { Plus, MapPin, Upload as UploadIcon, Trash2, CheckCircle2, X, FileText, AlertCircle } from 'lucide-react';

type ParsedRow = {
  customer_name: string;
  address: string;
  phone?: string;
  valid: boolean;
  reasons: string[];
};

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [geocoding, setGeocoding] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ customer_name: '', address: '', phone: '' });
  const [adding, setAdding] = useState(false);

  // Upload state
  const fileRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [parsed, setParsed] = useState<ParsedRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [uploadMsg, setUploadMsg] = useState<string | null>(null);

  async function refresh() {
    const { data } = await supabase().from('orders').select('*').order('created_at', { ascending: false });
    setOrders((data as Order[]) || []);
    setLoading(false);
  }
  useEffect(() => { refresh(); }, []);

  function validateRow(r: any): ParsedRow {
    const customer_name = (r['Customer Name'] || r['Name'] || r.customer_name || r.name || '').trim();
    const address = (r['Address'] || r.address || '').trim();
    const phone = (r['Phone'] || r['Phone Number'] || r.phone || '').trim();
    const reasons: string[] = [];
    if (!customer_name) reasons.push('missing name');
    if (!address) reasons.push('missing address');
    if (address && address.length < 5) reasons.push('address too short');
    return { customer_name, address, phone, valid: reasons.length === 0, reasons };
  }

  function parseFile(file: File) {
    setUploadMsg(null);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const rows = (results.data as any[]).map(validateRow);
        setParsed(rows);
        const valid = rows.filter((r) => r.valid).length;
        setUploadMsg(`Parsed ${rows.length} rows · ${valid} valid · ${rows.length - valid} invalid`);
      },
      error: (err) => setUploadMsg(`Parse error: ${err.message}`),
    });
  }

  function loadDemo() {
    fetch('/sample-orders.csv').then((r) => r.text()).then((text) => {
      const file = new File([new Blob([text])], 'sample.csv');
      parseFile(file);
    });
  }

  async function importValid() {
    const valid = parsed.filter((r) => r.valid);
    if (!valid.length) return;
    setImporting(true);
    setUploadMsg('Geocoding addresses…');
    try {
      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) throw new Error('Not signed in');

      let geocoded: Array<{ lat?: number; lng?: number; geocoded: boolean }> = valid.map(() => ({ geocoded: false }));
      try {
        const items = valid.map((r) => ({ address: r.address, country: 'GB' }));
        const result = await apiGeocodeBatch(items);
        geocoded = result.results.map((res: any) => res.result
          ? { lat: res.result.lat, lng: res.result.lng, geocoded: true }
          : { geocoded: false });
      } catch (e: any) {
        setUploadMsg(`Geocoding failed: ${e.message} · inserting without coordinates`);
      }

      setUploadMsg('Saving to database…');
      const payload = valid.map((r, i) => ({
        customer_name: r.customer_name,
        address: r.address,
        phone: r.phone || null,
        ...geocoded[i],
        user_id: user.id,
      }));
      const { error } = await sb.from('orders').insert(payload);
      if (error) throw error;

      const succeeded = geocoded.filter((g) => g.geocoded).length;
      setUploadMsg(`✓ Imported ${valid.length} orders · ${succeeded} geocoded successfully`);
      setParsed([]);
      await refresh();
    } catch (e: any) {
      setUploadMsg(`Failed: ${e.message}`);
    }
    setImporting(false);
  }

  async function addOrder(e: React.FormEvent) {
    e.preventDefault();
    setAdding(true);
    const sb = supabase();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) { setAdding(false); return; }

    // Try to geocode
    let geo: any = { geocoded: false };
    try {
      const result = await apiGeocodeBatch([{ address: form.address, country: 'GB' }]);
      const r = result.results[0]?.result;
      if (r) geo = { lat: r.lat, lng: r.lng, geocoded: true };
    } catch {}

    await sb.from('orders').insert({ ...form, ...geo, user_id: user.id });
    setForm({ customer_name: '', address: '', phone: '' });
    setShowAdd(false);
    await refresh();
    setAdding(false);
  }

  async function geocodeAll() {
    const pending = orders.filter((o) => !o.geocoded);
    if (!pending.length) return alert('All orders already geocoded.');
    setGeocoding(true);
    try {
      const items = pending.map((o) => ({ address: o.address, country: 'GB' }));
      const result = await apiGeocodeBatch(items);
      const sb = supabase();
      for (let i = 0; i < pending.length; i++) {
        const r = result.results[i]?.result;
        if (r) {
          await sb.from('orders').update({ lat: r.lat, lng: r.lng, geocoded: true }).eq('id', pending[i].id);
        }
      }
      await refresh();
    } catch (e: any) {
      alert(`Geocoding failed: ${e.message}`);
    }
    setGeocoding(false);
  }

  async function deleteOrder(id: string) {
    if (!confirm('Delete this order?')) return;
    await supabase().from('orders').delete().eq('id', id);
    await refresh();
  }

  async function deleteAll() {
    if (!confirm(`Delete ALL ${orders.length} orders? This cannot be undone.`)) return;
    const sb = supabase();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) return;
    await sb.from('orders').delete().eq('user_id', user.id);
    await refresh();
  }

  const pendingGeo = orders.filter((o) => !o.geocoded).length;

  return (
    <AppShell>
      <Topbar
        title="Orders"
        subtitle={`${orders.length} total · ${pendingGeo} need geocoding`}
        actions={
          <div className="flex gap-2">
            <button onClick={() => setShowAdd(!showAdd)} className="btn btn-ghost"><Plus size={14} />Add</button>
            {pendingGeo > 0 && (
              <button onClick={geocodeAll} disabled={geocoding} className="btn btn-accent">
                <MapPin size={14} />{geocoding ? 'Geocoding…' : `Geocode ${pendingGeo}`}
              </button>
            )}
          </div>
        }
      />

      <div className="p-6 overflow-auto flex-1 space-y-5">
        {/* Manual add form */}
        {showAdd && (
          <div className="surface p-5 fade-up">
            <div className="flex items-center justify-between mb-4">
              <div className="font-serif text-lg">Add order manually</div>
              <button onClick={() => setShowAdd(false)} className="btn btn-ghost !p-1.5"><X size={14} /></button>
            </div>
            <form onSubmit={addOrder} className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="fld">Customer name</label>
                <input className="input" value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} required />
              </div>
              <div>
                <label className="fld">Address</label>
                <input className="input" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} required placeholder="221B Baker St, London NW1 6XE" />
              </div>
              <div>
                <label className="fld">Phone (optional)</label>
                <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div className="md:col-span-3 flex justify-end">
                <button type="submit" disabled={adding} className="btn btn-primary">
                  {adding ? 'Adding…' : 'Add order'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* CSV Upload */}
        {parsed.length === 0 && (
          <div
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) parseFile(f); }}
            onClick={() => fileRef.current?.click()}
            className="surface p-10 text-center cursor-pointer transition-all fade-up"
            style={{
              borderStyle: 'dashed',
              borderWidth: '2px',
              borderColor: dragging ? 'var(--accent)' : 'var(--stroke-2)',
              background: dragging ? 'var(--accent-soft)' : 'var(--bg-elev)',
            }}
          >
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
                 style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
              <UploadIcon size={22} />
            </div>
            <div className="font-medium text-base mb-1">Drop CSV file here</div>
            <div className="text-[12px] mb-4" style={{ color: 'var(--ink-3)' }}>
              Required columns: <code style={{ color: 'var(--ink-2)' }}>Customer Name</code>, <code style={{ color: 'var(--ink-2)' }}>Address</code>, <code style={{ color: 'var(--ink-2)' }}>Phone</code>
            </div>
            <div className="flex gap-2 justify-center">
              <button type="button" className="btn btn-ghost" onClick={(e) => { e.stopPropagation(); fileRef.current?.click(); }}>
                <FileText size={14} />Browse files
              </button>
              <button type="button" className="btn btn-primary" onClick={(e) => { e.stopPropagation(); loadDemo(); }}>
                Load demo
              </button>
            </div>
            <input ref={fileRef} type="file" accept=".csv" className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) parseFile(f); }} />
          </div>
        )}

        {/* Parsed preview / verify */}
        {parsed.length > 0 && (
          <div className="surface p-5 fade-up">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="font-serif text-lg">Verify uploaded rows</div>
                <div className="text-[12px]" style={{ color: 'var(--ink-3)' }}>
                  {parsed.filter((r) => r.valid).length} valid · {parsed.filter((r) => !r.valid).length} invalid · all valid rows will be imported
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => { setParsed([]); setUploadMsg(null); }} className="btn btn-ghost">
                  <X size={14} />Cancel
                </button>
                <button onClick={importValid} disabled={importing || parsed.filter((r) => r.valid).length === 0} className="btn btn-accent">
                  <UploadIcon size={14} />{importing ? 'Importing…' : `Import ${parsed.filter((r) => r.valid).length} valid`}
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="data">
                <thead>
                  <tr><th style={{ width: 50 }}></th><th>Customer</th><th>Address</th><th>Phone</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {parsed.slice(0, 50).map((r, i) => (
                    <tr key={i}>
                      <td>
                        {r.valid
                          ? <CheckCircle2 size={16} style={{ color: 'var(--good)' }} />
                          : <AlertCircle size={16} style={{ color: 'var(--bad)' }} />}
                      </td>
                      <td style={{ color: 'var(--ink)' }}>{r.customer_name || <span style={{ color: 'var(--ink-mute)' }}>—</span>}</td>
                      <td>{r.address || <span style={{ color: 'var(--ink-mute)' }}>—</span>}</td>
                      <td className="font-mono text-[12px]">{r.phone || <span style={{ color: 'var(--ink-mute)' }}>—</span>}</td>
                      <td>
                        {r.valid
                          ? <span className="pill pill-ok">valid</span>
                          : <span className="pill pill-bad">{r.reasons.join(', ')}</span>}
                      </td>
                    </tr>
                  ))}
                  {parsed.length > 50 && (
                    <tr><td colSpan={5} className="text-center" style={{ color: 'var(--ink-mute)' }}>+ {parsed.length - 50} more rows</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {uploadMsg && (
          <div className="surface p-3 text-[13px]" style={{ color: uploadMsg.startsWith('✓') ? 'var(--good)' : 'var(--ink-2)' }}>
            {uploadMsg}
          </div>
        )}

        {/* Orders table */}
        <div className="surface p-5 fade-up">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="font-serif text-lg">All orders</div>
              <div className="text-[12px]" style={{ color: 'var(--ink-3)' }}>{orders.length} total</div>
            </div>
            {orders.length > 0 && (
              <button onClick={deleteAll} className="btn btn-danger-ghost"><Trash2 size={14} />Clear all</button>
            )}
          </div>
          {loading ? (
            <div className="text-sm" style={{ color: 'var(--ink-3)' }}>Loading…</div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12" style={{ color: 'var(--ink-3)' }}>
              <div className="text-sm">No orders yet. Upload a CSV or add manually.</div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="data">
                <thead>
                  <tr><th>Customer</th><th>Address</th><th>Phone</th><th>Geo</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                  {orders.map((o) => (
                    <tr key={o.id}>
                      <td style={{ color: 'var(--ink)' }}>{o.customer_name}</td>
                      <td className="max-w-[260px] truncate" title={o.address}>{o.address}</td>
                      <td className="font-mono text-[12px]">{o.phone || '—'}</td>
                      <td>
                        {o.geocoded
                          ? <span className="pill pill-ok">✓</span>
                          : <span className="pill pill-warn">pending</span>}
                      </td>
                      <td><span className="pill pill-neutral">{o.status}</span></td>
                      <td>
                        <button onClick={() => deleteOrder(o.id)} className="btn-danger-ghost p-1.5 rounded">
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
