import { useEffect, useRef, useState } from 'react';

type Props = {
  stopLat: number;
  stopLng: number;
  driverPos: { lat: number; lng: number } | null;
  driverColor: string;
};

export default function TrackMap({ stopLat, stopLng, driverPos, driverColor }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<any>(null);
  const driverMarkerRef = useRef<any>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || mapObj.current) return;
    let cancelled = false;
    (async () => {
      const L = (await import('leaflet')).default;
      if (cancelled) return;
      const map = L.map(mapRef.current!, { zoomControl: true, attributionControl: false })
        .setView([stopLat, stopLng], 14);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

      const stopIcon = L.divIcon({
        className: '',
        html: `<div class="stop-marker" style="background:${driverColor};width:32px;height:32px;font-size:14px">📍</div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });
      L.marker([stopLat, stopLng], { icon: stopIcon }).addTo(map);

      mapObj.current = map;
      setReady(true);
    })();
    return () => { cancelled = true; if (mapObj.current) { mapObj.current.remove(); mapObj.current = null; } };
  }, [stopLat, stopLng, driverColor]);

  useEffect(() => {
    if (!ready || !mapObj.current || !driverPos) return;
    (async () => {
      const L = (await import('leaflet')).default;
      const icon = L.divIcon({
        className: '',
        html: `<div class="driver-marker" style="border:3px solid ${driverColor}"></div>`,
        iconSize: [20, 20],
        iconAnchor: [10, 10],
      });
      if (driverMarkerRef.current) {
        driverMarkerRef.current.setLatLng([driverPos.lat, driverPos.lng]);
      } else {
        driverMarkerRef.current = L.marker([driverPos.lat, driverPos.lng], { icon }).addTo(mapObj.current);
      }
      const bounds = L.latLngBounds([[stopLat, stopLng], [driverPos.lat, driverPos.lng]]);
      mapObj.current.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    })();
  }, [ready, driverPos, stopLat, stopLng, driverColor]);

  return <div ref={mapRef} className="w-full h-full" />;
}
