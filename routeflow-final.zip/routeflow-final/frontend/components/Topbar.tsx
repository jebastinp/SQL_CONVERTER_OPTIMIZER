import { ReactNode } from 'react';
import ThemeToggle from './ThemeToggle';

export default function Topbar({ title, subtitle, actions }: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <header
      className="flex items-center gap-4 px-6 py-4"
      style={{ borderBottom: '1px solid var(--stroke)', background: 'var(--bg-elev)' }}
    >
      <div className="flex-1">
        <div className="font-serif text-2xl tracking-tight leading-none">{title}</div>
        {subtitle && <div className="text-[12px] mt-1" style={{ color: 'var(--ink-3)' }}>{subtitle}</div>}
      </div>
      {actions}
      <ThemeToggle />
    </header>
  );
}
