import Link from 'next/link';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';
import { LayoutGrid, Route, Upload, Users, BarChart3, LogOut } from 'lucide-react';

const items = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutGrid },
  { href: '/orders', label: 'Orders', icon: Upload },
  { href: '/drivers', label: 'Drivers', icon: Users },
  { href: '/routes', label: 'Live Routes', icon: Route },
  { href: '/analytics', label: 'Analytics', icon: BarChart3 },
];

export default function Sidebar({ profile }: { profile: { full_name?: string; email: string } | null }) {
  const router = useRouter();

  async function signOut() {
    await supabase().auth.signOut();
    router.push('/login');
  }

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase()
    : profile?.email?.slice(0, 2).toUpperCase() || '??';

  return (
    <aside className="w-60 shrink-0 flex flex-col p-3 gap-1 h-screen sticky top-0"
           style={{ background: 'var(--bg-elev)', borderRight: '1px solid var(--stroke)' }}>
      <div className="flex items-center gap-2.5 px-2.5 pt-2 pb-4">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center"
             style={{ background: 'var(--ink)' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--bg)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 0-8 8c0 1.892.402 3.13 1.5 4.5L12 22l6.5-7.5c1.098-1.37 1.5-2.608 1.5-4.5a8 8 0 0 0-8-8z"/>
          </svg>
        </div>
        <div>
          <div className="font-serif text-xl tracking-tight leading-none">RouteFlow</div>
          <div className="text-[10px] uppercase tracking-widest" style={{ color: 'var(--ink-3)' }}>AI Routing</div>
        </div>
      </div>

      <div className="text-[10px] uppercase tracking-widest px-2.5 pt-3 pb-1.5" style={{ color: 'var(--ink-mute)' }}>
        Workspace
      </div>

      {items.map((item) => {
        const active = router.pathname === item.href || router.pathname.startsWith(item.href + '/');
        const Icon = item.icon;
        return (
          <Link key={item.href} href={item.href}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-[13.5px] font-medium transition-all"
            style={{
              color: active ? 'var(--ink)' : 'var(--ink-3)',
              background: active ? 'var(--accent-soft)' : 'transparent',
            }}>
            <Icon size={15} />
            {item.label}
          </Link>
        );
      })}

      <div className="mt-auto pt-3" style={{ borderTop: '1px solid var(--stroke)' }}>
        <div className="flex items-center gap-2.5 px-2.5 py-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-semibold text-white"
               style={{ background: 'var(--accent)' }}>
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[12px] font-medium truncate">{profile?.full_name || 'User'}</div>
            <div className="text-[10.5px] truncate" style={{ color: 'var(--ink-3)' }}>{profile?.email}</div>
          </div>
          <button onClick={signOut} className="btn-danger-ghost p-1.5 rounded" title="Sign out">
            <LogOut size={14} />
          </button>
        </div>
      </div>
    </aside>
  );
}
