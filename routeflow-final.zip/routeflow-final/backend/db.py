"""JWT verification using Supabase JWT secret."""
import os
import base64
import jwt
from typing import Optional


def _decode_jwt_secret(raw: str) -> bytes:
    """Supabase JWT secrets are base64-encoded random bytes."""
    if not raw:
        return b""
    try:
        return base64.b64decode(raw)
    except Exception:
        return raw.encode()


def verify_user_jwt(token: str) -> Optional[dict]:
    secret_raw = os.getenv("SUPABASE_JWT_SECRET", "")
    if not secret_raw:
        return None
    # Try base64-decoded secret first, then raw — handles both formats Supabase uses
    for secret in [_decode_jwt_secret(secret_raw), secret_raw.encode()]:
        try:
            payload = jwt.decode(
                token, secret, algorithms=["HS256"], audience="authenticated"
            )
            return payload
        except Exception:
            continue
    return None
