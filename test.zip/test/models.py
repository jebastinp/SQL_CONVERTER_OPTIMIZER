from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default='team')  # admin, martin, danny, team
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Customer(db.Model):
    __tablename__ = 'customers'
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.String(20), unique=True)
    name = db.Column(db.String(150), nullable=False)
    phone = db.Column(db.String(30))
    address = db.Column(db.Text)
    area = db.Column(db.String(100))
    postcode = db.Column(db.String(15))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    orders = db.relationship('Order', backref='customer', lazy=True)

class FishMaster(db.Model):
    __tablename__ = 'fish_master'
    id = db.Column(db.Integer, primary_key=True)
    fish_name = db.Column(db.String(200), nullable=False)
    english_name = db.Column(db.String(150))
    tamil_name = db.Column(db.String(150))
    malayalam_name = db.Column(db.String(150))
    size = db.Column(db.String(10))
    avra_impex_price = db.Column(db.Numeric(10, 2))
    global_food_price = db.Column(db.Numeric(10, 2))
    half_kg_price = db.Column(db.Numeric(10, 2))
    one_kg_price = db.Column(db.Numeric(10, 2))
    selling_price = db.Column(db.Numeric(10, 2))
    cut_type = db.Column(db.String(100))
    is_fish = db.Column(db.Boolean, default=True)
    is_active = db.Column(db.Boolean, default=True)

class DeliveryWeek(db.Model):
    __tablename__ = 'delivery_weeks'
    id = db.Column(db.Integer, primary_key=True)
    week_start = db.Column(db.Date)
    week_end = db.Column(db.Date)
    delivery_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    orders = db.relationship('Order', backref='delivery_week', lazy=True)

class Order(db.Model):
    __tablename__ = 'orders'
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    delivery_week_id = db.Column(db.Integer, db.ForeignKey('delivery_weeks.id'))
    payment_reference = db.Column(db.String(30))
    order_date = db.Column(db.Date, default=datetime.utcnow)
    delivery_date = db.Column(db.Date)
    driver = db.Column(db.String(50))
    route = db.Column(db.String(50))
    delivery_stop_number = db.Column(db.Integer)
    status = db.Column(db.String(30), default='received')
    delivery_instructions = db.Column(db.Text)
    order_platform = db.Column(db.String(50), default='WhatsApp')
    raw_whatsapp_text = db.Column(db.Text)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    items = db.relationship('OrderItem', backref='order', lazy=True, cascade='all, delete-orphan')
    invoice = db.relationship('Invoice', backref='order', uselist=False)
    payments = db.relationship('Payment', backref='order', lazy=True)

class OrderItem(db.Model):
    __tablename__ = 'order_items'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    fish_master_id = db.Column(db.Integer, db.ForeignKey('fish_master.id'))
    fish_name = db.Column(db.String(200))
    quantity_kg = db.Column(db.Numeric(10, 3))
    unit_price = db.Column(db.Numeric(10, 2))
    line_total = db.Column(db.Numeric(10, 2))
    cut_instructions = db.Column(db.Text)
    availability_status = db.Column(db.String(20), default='pending')
    availability_checked_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    availability_checked_at = db.Column(db.DateTime)
    fish = db.relationship('FishMaster', backref='order_items')

class Invoice(db.Model):
    __tablename__ = 'invoices'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'))
    invoice_number = db.Column(db.String(30))
    subtotal = db.Column(db.Numeric(10, 2))
    freight_surcharge = db.Column(db.Numeric(10, 2))
    delivery_charge = db.Column(db.Numeric(10, 2))
    total = db.Column(db.Numeric(10, 2))
    pdf_path = db.Column(db.String(500))
    generated_at = db.Column(db.DateTime)
    sent_at = db.Column(db.DateTime)
    sent_by = db.Column(db.Integer, db.ForeignKey('users.id'))

class Payment(db.Model):
    __tablename__ = 'payments'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'))
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'))
    amount = db.Column(db.Numeric(10, 2))
    payment_mode = db.Column(db.String(50))
    payment_name = db.Column(db.String(150))
    bank_reference = db.Column(db.String(100))
    payment_received_date = db.Column(db.Date)
    payment_verified_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    payment_verified_at = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='pending')
    screenshot_path = db.Column(db.Text)

class Expense(db.Model):
    __tablename__ = 'expenses'
    id = db.Column(db.Integer, primary_key=True)
    expense_date = db.Column(db.Date)
    description = db.Column(db.String(200))
    category = db.Column(db.String(100))
    amount = db.Column(db.Numeric(10, 2))
    payment_status = db.Column(db.String(20), default='paid')
    delivery_week_id = db.Column(db.Integer, db.ForeignKey('delivery_weeks.id'))
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))

class Income(db.Model):
    __tablename__ = 'income'
    id = db.Column(db.Integer, primary_key=True)
    income_date = db.Column(db.Date)
    description = db.Column(db.String(200))
    amount = db.Column(db.Numeric(10, 2))
    fish_profit = db.Column(db.Numeric(10, 2))
    delivery_week_id = db.Column(db.Integer, db.ForeignKey('delivery_weeks.id'))

class VendorReport(db.Model):
    __tablename__ = 'vendor_reports'
    id = db.Column(db.Integer, primary_key=True)
    delivery_week_id = db.Column(db.Integer, db.ForeignKey('delivery_weeks.id'))
    generated_at = db.Column(db.DateTime)
    generated_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    sent_at = db.Column(db.DateTime)
    report_data = db.Column(db.JSON)

class WhatsAppMessage(db.Model):
    __tablename__ = 'whatsapp_messages'
    id = db.Column(db.Integer, primary_key=True)
    direction = db.Column(db.String(10))  # 'in' or 'out'
    phone = db.Column(db.String(30))
    message = db.Column(db.Text)
    status = db.Column(db.String(20), default='received')
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

class Settings(db.Model):
    __tablename__ = 'settings'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True)
    value = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
