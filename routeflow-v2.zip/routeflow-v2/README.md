# RouteFlow AI — Full System

A production-ready, multi-tenant route optimization SaaS for UK delivery operations. Built with Next.js 14 + FastAPI + Supabase + OR-Tools.

## ⚡ TL;DR — Run it locally

```bash
# 1. Set up Supabase (5 min) → see docs/SETUP.md step 1
# 2. Set up OpenRouteService API key (2 min) → see docs/SETUP.md step 2

# 3. Backend
cd backend
python -m venv venv && source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # fill in values
uvicorn main:app --reload --port 8000

# 4. Frontend (in new terminal)
cd frontend
npm install
cp .env.local.example .env.local  # fill in values
npm run dev
```

Open **http://localhost:3000** → sign up → start optimizing.

## 📁 Project structure

```
routeflow-v2/
├── frontend/                Next.js 14 (App Router) — dispatcher UI, driver PWA, customer tracking
│   ├── app/                 Pages: dashboard, routes, orders, drivers, import, driver, track
│   ├── components/          Reusable UI: Sidebar, Map, Charts, KPI cards
│   ├── lib/                 Supabase client, API client, utils, types
│   └── public/              Static assets
├── backend/                 FastAPI — optimizer + geocoding proxy
│   ├── main.py              All routes
│   ├── optimizer.py         OR-Tools VRP/TSP solver
│   ├── geocode.py           OpenRouteService client with caching
│   ├── db.py                Supabase admin client
│   └── requirements.txt
├── supabase/
│   ├── schema.sql           Tables, RLS policies, triggers, functions
│   └── seed.sql             Optional: demo data for testing
├── docs/
│   ├── SETUP.md             Step-by-step: get every API key
│   ├── DEPLOY.md            Deploy to Vercel + Render + Supabase
│   ├── API_KEYS.md          Where each key goes, why it's needed
│   └── ARCHITECTURE.md      System design
└── data/
    └── sample-orders.csv    24 London demo orders
```

## 🔑 External services you need (all free to start)

| Service | What for | Free tier | Setup time |
|---|---|---|---|
| **Supabase** | Postgres + Auth + Realtime + Storage | 500MB DB, 50k auth users | 5 min |
| **OpenRouteService** | UK geocoding + road distances | 2,000 requests/day | 2 min |
| **Vercel** | Frontend hosting | Generous, free for hobby | 3 min |
| **Render** | Backend hosting | 750 hrs/month free | 3 min |

**Total cost to launch and run with 5–10 customers: £0/month.** Scales to ~£50/month around 50 customers.

See `docs/SETUP.md` for the exact click-by-click setup of each service.

## 🎯 What's wired up

- ✅ **Auth** — Supabase Auth (email + password, magic link, Google OAuth)
- ✅ **Multi-tenant** — Row-Level Security so each user only sees their own data
- ✅ **Route optimization** — Google OR-Tools VRP solver (1–5000 stops in seconds)
- ✅ **UK geocoding** — OpenRouteService with database-backed caching
- ✅ **Live map** — Leaflet + OpenStreetMap with animated routes & driver markers
- ✅ **CSV import** — drag-drop with validation, auto-geocoding
- ✅ **Driver PWA** — mobile route view with stop checklists, photo PoD upload
- ✅ **Customer tracking** — public link, no login, shows live ETA
- ✅ **Real-time updates** — driver positions push via Supabase Realtime
- ✅ **Analytics** — fuel saved, on-time rate, driver performance

## ⏭️ What's NOT included (deliberately)

- ❌ Stripe billing (you said skip this for now)
- ❌ Native iOS/Android apps (PWA is enough to start)
- ❌ SMS notifications (add Twilio later)
- ❌ Multi-language (English only)

## Next read

Open `docs/SETUP.md` to get the system running in ~15 minutes.
