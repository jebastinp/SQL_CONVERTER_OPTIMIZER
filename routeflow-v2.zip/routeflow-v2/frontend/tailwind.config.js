/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: {
          0: '#05070d',
          1: '#0a0e1a',
          2: '#10162a',
        },
        glass: {
          DEFAULT: 'rgba(20,28,48,.55)',
          2: 'rgba(255,255,255,.04)',
        },
        stroke: {
          DEFAULT: 'rgba(255,255,255,.08)',
          2: 'rgba(255,255,255,.14)',
        },
        ink: {
          DEFAULT: '#e7ecf5',
          dim: '#8893a8',
          mute: '#5b6478',
        },
        accent: {
          DEFAULT: '#5b8cff',
          2: '#7af6ff',
          glow: 'rgba(91,140,255,.45)',
        },
        good: '#3ddc97',
        warn: '#ffb547',
        bad: '#ff5d6c',
        purple: '#b48cff',
      },
      fontFamily: {
        sans: ['Geist', 'system-ui', 'sans-serif'],
        serif: ['"Instrument Serif"', 'serif'],
        mono: ['"Geist Mono"', 'ui-monospace', 'monospace'],
      },
      backdropBlur: { 16: '16px', 20: '20px' },
      animation: {
        pulse: 'pulse 1.4s ease-in-out infinite',
        drift1: 'drift1 22s ease-in-out infinite alternate',
        drift2: 'drift2 28s ease-in-out infinite alternate',
        fadeIn: 'fadeIn .4s ease',
      },
      keyframes: {
        drift1: { to: { transform: 'translate(80px,60px) scale(1.1)' } },
        drift2: { to: { transform: 'translate(-60px,-40px) scale(1.15)' } },
        fadeIn: { from: { opacity: '0', transform: 'translateY(6px)' }, to: { opacity: '1', transform: 'none' } },
      },
    },
  },
  plugins: [],
};
