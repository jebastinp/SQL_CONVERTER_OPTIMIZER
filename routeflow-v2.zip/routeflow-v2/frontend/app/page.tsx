import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-8 text-sm text-ink-dim">
        <span className="w-1.5 h-1.5 rounded-full bg-good animate-pulse" />
        Live · AI route intelligence
      </div>

      <h1 className="font-serif text-6xl md:text-8xl tracking-tight leading-none mb-6 max-w-4xl">
        AI route intelligence for{' '}
        <em className="bg-gradient-to-r from-accent-2 via-accent to-purple bg-clip-text text-transparent">
          modern
        </em>{' '}
        UK delivery operations.
      </h1>

      <p className="text-lg text-ink-dim max-w-xl mb-10">
        Reduce fuel costs by up to 31%, balance drivers automatically, and orchestrate fleets with real-time AI optimization.
      </p>

      <div className="flex gap-3 flex-wrap justify-center">
        <Link href="/signup" className="btn btn-primary text-base px-6 py-3">
          Get started free →
        </Link>
        <Link href="/login" className="btn btn-ghost text-base px-6 py-3">
          Sign in
        </Link>
      </div>

      <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl w-full">
        {[
          { v: '31%', l: 'Lower fuel costs' },
          { v: '42m', l: 'Saved per driver/day' },
          { v: '5,000', l: 'Stops in <3 sec' },
          { v: '96%', l: 'On-time rate' },
        ].map((s) => (
          <div key={s.l} className="glass p-5">
            <div className="font-serif text-3xl bg-gradient-to-r from-white to-accent-2 bg-clip-text text-transparent">
              {s.v}
            </div>
            <div className="text-xs text-ink-dim mt-1">{s.l}</div>
          </div>
        ))}
      </div>
    </main>
  );
}
