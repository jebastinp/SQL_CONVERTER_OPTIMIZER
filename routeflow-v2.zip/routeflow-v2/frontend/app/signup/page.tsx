'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase-browser';

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    const sb = createClient();
    const { data, error } = await sb.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName },
        emailRedirectTo: `${location.origin}/dashboard`,
      },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    // Update profile with company name after signup
    if (data.user && companyName) {
      await sb.from('profiles').update({ company_name: companyName }).eq('id', data.user.id);
    }
    if (data.session) {
      router.push('/dashboard');
      router.refresh();
    } else {
      setInfo('Check your email to confirm your account.');
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="glass-strong p-10 rounded-2xl w-full max-w-md">
        <Link href="/" className="text-ink-dim text-sm hover:text-ink mb-6 inline-block">
          ← Back
        </Link>
        <h1 className="font-serif text-4xl mb-2">
          Get <em className="text-accent-2">started</em>
        </h1>
        <p className="text-ink-dim text-sm mb-8">Create your RouteFlow account</p>

        <form onSubmit={signUp} className="space-y-4">
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Full name</label>
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} required className="input mt-1.5" placeholder="Sarah Kowalski" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Company</label>
            <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="input mt-1.5" placeholder="Acme Logistics Ltd" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="input mt-1.5" placeholder="you@company.co.uk" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Password (min 6)</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="input mt-1.5" />
          </div>
          {error && <div className="text-bad text-sm bg-bad/10 border border-bad/20 rounded-lg p-3">{error}</div>}
          {info && <div className="text-good text-sm bg-good/10 border border-good/20 rounded-lg p-3">{info}</div>}
          <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-3">
            {loading ? 'Creating…' : 'Create account'}
          </button>
        </form>

        <p className="text-center text-sm text-ink-dim mt-8">
          Already have an account?{' '}
          <Link href="/login" className="text-accent-2 hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </main>
  );
}
