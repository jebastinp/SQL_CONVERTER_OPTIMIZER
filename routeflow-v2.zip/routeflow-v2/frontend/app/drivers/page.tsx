'use client';

import { useEffect, useState } from 'react';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { createClient } from '@/lib/supabase-browser';
import type { Driver } from '@/lib/types';
import { Plus, Trash2, Copy, Smartphone } from 'lucide-react';

const COLORS = ['#5b8cff', '#7af6ff', '#b48cff', '#ffb547', '#3ddc97', '#ff5d6c'];

export default function DriversPage() {
  const sb = createClient();
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({
    name: '', email: '', phone: '', vehicle: '', capacity: 30,
    shift_start: '08:00', shift_end: '17:00',
    color: COLORS[0],
  });

  async function refresh() {
    const { data } = await sb.from('drivers').select('*').order('created_at', { ascending: false });
    setDrivers((data as Driver[]) || []);
    setLoading(false);
  }
  useEffect(() => { refresh(); }, []);

  async function addDriver(e: React.FormEvent) {
    e.preventDefault();
    setAdding(true);
    const { data: { user } } = await sb.auth.getUser();
    if (!user) return;
    await sb.from('drivers').insert({ ...form, user_id: user.id });
    setForm({ name: '', email: '', phone: '', vehicle: '', capacity: 30, shift_start: '08:00', shift_end: '17:00', color: COLORS[drivers.length % COLORS.length] });
    await refresh();
    setAdding(false);
  }

  async function deleteDriver(id: string) {
    if (!confirm('Delete this driver?')) return;
    await sb.from('drivers').delete().eq('id', id);
    await refresh();
  }

  function copyLink(token: string) {
    const url = `${location.origin}/driver/${token}`;
    navigator.clipboard.writeText(url);
    alert(`Driver link copied!\n\n${url}\n\nShare this with the driver. They'll see their route on their phone.`);
  }

  return (
    <AppShell>
      <Topbar title="Drivers" subtitle={`${drivers.length} in fleet`} />
      <div className="p-6 overflow-auto flex-1 grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2">
          {loading ? <div className="text-ink-dim text-sm">Loading…</div> :
            drivers.length === 0 ? (
              <div className="glass p-10 text-center text-ink-dim text-sm">
                No drivers yet. Add one from the form on the right.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {drivers.map((d) => {
                  const initials = d.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase();
                  return (
                    <div key={d.id} className="glass p-5">
                      <div className="flex items-center gap-3 mb-3.5">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center font-semibold text-white text-sm"
                             style={{ background: `linear-gradient(135deg,${d.color},${d.color}aa)` }}>
                          {initials}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm truncate">{d.name}</div>
                          <div className="text-[11px] text-ink-mute truncate">{d.vehicle || 'No vehicle set'}</div>
                        </div>
                        <div className="w-2 h-2 rounded-full bg-good shadow-[0_0_8px_currentColor] text-good" />
                        <button onClick={() => deleteDriver(d.id)} className="text-ink-mute hover:text-bad p-1"><Trash2 size={13} /></button>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                        <div className="bg-glass-2 rounded-lg p-2">
                          <div className="font-serif text-base">{d.capacity}</div>
                          <div className="text-[9px] uppercase tracking-wider text-ink-mute mt-0.5">Capacity</div>
                        </div>
                        <div className="bg-glass-2 rounded-lg p-2">
                          <div className="font-serif text-base">{d.shift_start}</div>
                          <div className="text-[9px] uppercase tracking-wider text-ink-mute mt-0.5">Start</div>
                        </div>
                        <div className="bg-glass-2 rounded-lg p-2">
                          <div className="font-serif text-base">{d.shift_end}</div>
                          <div className="text-[9px] uppercase tracking-wider text-ink-mute mt-0.5">End</div>
                        </div>
                      </div>
                      <button onClick={() => copyLink(d.access_token)} className="btn btn-ghost w-full justify-center text-xs py-2">
                        <Smartphone size={12} /> Copy driver app link <Copy size={12} />
                      </button>
                    </div>
                  );
                })}
              </div>
            )
          }
        </div>

        <div className="glass p-5 h-fit">
          <div className="text-sm font-semibold mb-3.5 flex items-center gap-2"><Plus size={14} />Add driver</div>
          <form onSubmit={addDriver} className="space-y-3">
            <input className="input" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <input className="input" placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <input className="input" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <input className="input" placeholder="Vehicle (e.g. VW Crafter · LV23 KPM)" value={form.vehicle} onChange={(e) => setForm({ ...form, vehicle: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-ink-mute">Capacity</label>
                <input className="input" type="number" min={1} value={form.capacity} onChange={(e) => setForm({ ...form, capacity: parseInt(e.target.value) || 30 })} />
              </div>
              <div>
                <label className="text-xs text-ink-mute">Color</label>
                <div className="flex gap-1.5 mt-1.5 flex-wrap">
                  {COLORS.map((c) => (
                    <button key={c} type="button" onClick={() => setForm({ ...form, color: c })}
                      className={`w-7 h-7 rounded-lg transition-all ${form.color === c ? 'ring-2 ring-white scale-110' : ''}`}
                      style={{ background: c }} />
                  ))}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-ink-mute">Shift start</label>
                <input className="input" type="time" value={form.shift_start} onChange={(e) => setForm({ ...form, shift_start: e.target.value })} />
              </div>
              <div>
                <label className="text-xs text-ink-mute">Shift end</label>
                <input className="input" type="time" value={form.shift_end} onChange={(e) => setForm({ ...form, shift_end: e.target.value })} />
              </div>
            </div>
            <button type="submit" disabled={adding} className="btn btn-primary w-full justify-center">{adding ? 'Adding…' : 'Add driver'}</button>
          </form>
        </div>
      </div>
    </AppShell>
  );
}
