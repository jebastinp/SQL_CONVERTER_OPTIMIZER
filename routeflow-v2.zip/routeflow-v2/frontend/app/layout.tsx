import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RouteFlow AI — Logistics Intelligence',
  description: 'AI route optimization for UK delivery operations',
  manifest: '/manifest.json',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#05070d',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="ambient" />
        <div className="grid-bg" />
        <div className="relative z-10">{children}</div>
      </body>
    </html>
  );
}
