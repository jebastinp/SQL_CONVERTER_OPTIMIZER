import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { createClient } from '@/lib/supabase-server';
import Link from 'next/link';
import { Sparkles, AlertTriangle, CheckCircle2, RotateCw } from 'lucide-react';

export default async function DashboardPage() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return null;

  const [ordersRes, driversRes, routesRes] = await Promise.all([
    sb.from('orders').select('*', { count: 'exact', head: false }).eq('user_id', user.id),
    sb.from('drivers').select('*', { count: 'exact' }).eq('user_id', user.id),
    sb.from('routes').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(20),
  ]);

  const orderCount = ordersRes.count || 0;
  const driverCount = driversRes.count || 0;
  const routes = routesRes.data || [];

  const completed = routes.filter((r: any) => r.status === 'completed').length;
  const totalFuelSaved = routes.reduce((s: number, r: any) => s + (Number(r.fuel_saved_gbp) || 0), 0);
  const onTimeRate = routes.length > 0 ? Math.round((completed / routes.length) * 100) : 0;

  return (
    <AppShell>
      <Topbar title="Dashboard" subtitle="Live operational overview"
        actions={<Link href="/routes" className="btn btn-primary"><Sparkles size={14} />Optimize Routes</Link>} />

      <div className="p-6 overflow-auto flex-1">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-5">
          <div className="glass p-5 relative overflow-hidden">
            <div className="text-[11px] uppercase tracking-wider text-ink-mute mb-2">Total Orders</div>
            <div className="font-serif text-3xl">{orderCount}</div>
            <div className="text-[11px] text-ink-dim mt-1.5">All time</div>
          </div>
          <div className="glass p-5 relative overflow-hidden">
            <div className="text-[11px] uppercase tracking-wider text-ink-mute mb-2">Fuel Saved</div>
            <div className="font-serif text-3xl">£{totalFuelSaved.toFixed(0)}</div>
            <div className="text-[11px] text-ink-dim mt-1.5">Cumulative</div>
          </div>
          <div className="glass p-5 relative overflow-hidden">
            <div className="text-[11px] uppercase tracking-wider text-ink-mute mb-2">On-Time Rate</div>
            <div className="font-serif text-3xl">{onTimeRate}%</div>
            <div className="text-[11px] text-ink-dim mt-1.5">{completed}/{routes.length} routes</div>
          </div>
          <div className="glass p-5 relative overflow-hidden">
            <div className="text-[11px] uppercase tracking-wider text-ink-mute mb-2">Active Drivers</div>
            <div className="font-serif text-3xl">{driverCount}</div>
            <div className="text-[11px] text-ink-dim mt-1.5">In fleet</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5 mb-5">
          <div className="lg:col-span-2 glass p-5">
            <div className="flex items-center justify-between mb-3.5">
              <div>
                <div className="text-sm font-semibold">Recent Routes</div>
                <div className="text-[11px] text-ink-mute">Last 20 optimizations</div>
              </div>
            </div>
            {routes.length === 0 ? (
              <div className="text-center py-10 text-ink-dim text-sm">
                <div className="text-4xl mb-2 opacity-40">⌖</div>
                No routes yet.<br/>
                <Link href="/orders" className="text-accent-2 hover:underline">Import orders</Link> to get started.
              </div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-[10.5px] uppercase tracking-wider text-ink-mute border-b border-stroke">
                    <th className="text-left py-2.5 font-medium">Date</th>
                    <th className="text-left py-2.5 font-medium">Distance</th>
                    <th className="text-left py-2.5 font-medium">Fuel saved</th>
                    <th className="text-left py-2.5 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {routes.slice(0, 8).map((r: any) => (
                    <tr key={r.id} className="border-b border-stroke last:border-0 text-ink-dim hover:text-ink">
                      <td className="py-2.5">{new Date(r.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</td>
                      <td className="py-2.5">{Number(r.distance_km || 0).toFixed(1)} km</td>
                      <td className="py-2.5 text-good">£{Number(r.fuel_saved_gbp || 0).toFixed(2)}</td>
                      <td className="py-2.5">
                        <span className={`pill ${r.status === 'completed' ? 'pill-ok' : r.status === 'in_progress' ? 'pill-info' : 'pill-warn'}`}>
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="glass p-5">
            <div className="flex items-center justify-between mb-3.5">
              <div>
                <div className="text-sm font-semibold">AI Insights</div>
                <div className="text-[11px] text-ink-mute">Live recommendations</div>
              </div>
            </div>
            <div className="flex flex-col gap-2.5">
              {[
                { icon: Sparkles, color: 'text-accent-2 bg-accent/15', title: 'Optimize all pending orders', body: `You have ${orderCount} orders waiting. Run optimization to assign them to drivers.` },
                { icon: AlertTriangle, color: 'text-warn bg-warn/15', title: 'Set up depot location', body: 'Go to Settings to set your warehouse coordinates for accurate routing.' },
                { icon: CheckCircle2, color: 'text-good bg-good/15', title: 'Best dispatch window', body: 'Historical traffic data shows 9:15–10:00 has 31% less congestion than 8:00.' },
                { icon: RotateCw, color: 'text-purple bg-purple/15', title: 'Recurring routes detected', body: 'Same 12 stops appear weekly — consider creating a template.' },
              ].map((insight, i) => {
                const Icon = insight.icon;
                return (
                  <div key={i} className="p-3 rounded-lg bg-glass-2 border border-stroke flex gap-3 hover:border-stroke-2">
                    <div className={`w-7 h-7 rounded-lg ${insight.color} flex items-center justify-center flex-shrink-0`}>
                      <Icon size={13} />
                    </div>
                    <div>
                      <div className="text-xs font-medium mb-1">{insight.title}</div>
                      <div className="text-[11px] text-ink-dim leading-relaxed">{insight.body}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
