'use client';

import { useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import Papa from 'papaparse';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { createClient } from '@/lib/supabase-browser';
import { apiGeocodeBatch } from '@/lib/api';
import { Upload as UploadIcon, FileText, Zap } from 'lucide-react';

type Row = {
  customer_name: string;
  address: string;
  postcode: string;
  phone?: string;
  delivery_window?: string;
  priority?: string;
};

export default function ImportPage() {
  const router = useRouter();
  const sb = createClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [dragging, setDragging] = useState(false);
  const [importing, setImporting] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  function parseFile(file: File) {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data = (results.data as any[])
          .map((r) => ({
            customer_name: r['Customer Name'] || r.customer_name || r.Customer || r.name || '',
            address: r.Address || r.address || r.Street || '',
            postcode: (r.Postcode || r.postcode || r.PostCode || r.zip || '').toUpperCase().trim(),
            phone: r.Phone || r.phone || '',
            delivery_window: r['Delivery Window'] || r.delivery_window || r.Window || 'Anytime',
            priority: r.Priority || r.priority || 'Med',
          }))
          .filter((r) => r.customer_name && r.address && r.postcode);
        setRows(data);
        setStatus(`Parsed ${data.length} valid rows`);
      },
      error: (err) => setStatus(`Parse error: ${err.message}`),
    });
  }

  async function doImport(withGeocoding: boolean) {
    if (!rows.length) return;
    setImporting(true);
    setStatus('Importing…');
    try {
      const { data: { user } } = await sb.auth.getUser();
      if (!user) throw new Error('Not signed in');

      // 1. Geocode all if requested
      let geocoded: Array<{ lat?: number; lng?: number; geocoded: boolean }> = rows.map(() => ({ geocoded: false }));
      if (withGeocoding) {
        setStatus('Geocoding addresses…');
        try {
          const items = rows.map((r) => ({ address: r.address, postcode: r.postcode, country: 'GB' }));
          const result = await apiGeocodeBatch(items);
          geocoded = result.results.map((res: any) => res.result
            ? { lat: res.result.lat, lng: res.result.lng, geocoded: true }
            : { geocoded: false });
        } catch (e: any) {
          setStatus(`Geocoding failed: ${e.message} — inserting orders without coordinates`);
        }
      }

      // 2. Insert
      setStatus('Saving to database…');
      const payload = rows.map((r, i) => ({
        ...r,
        ...geocoded[i],
        user_id: user.id,
      }));
      const { error } = await sb.from('orders').insert(payload);
      if (error) throw error;

      setStatus(`✓ Imported ${rows.length} orders successfully.`);
      setTimeout(() => router.push('/orders'), 1500);
    } catch (e: any) {
      setStatus(`Failed: ${e.message}`);
    }
    setImporting(false);
  }

  function loadDemo() {
    fetch('/sample-orders.csv')
      .then((r) => r.text())
      .then((text) => {
        const blob = new Blob([text]);
        const file = new File([blob], 'sample.csv');
        parseFile(file);
      });
  }

  return (
    <AppShell>
      <Topbar title="Import Orders" subtitle="CSV upload with auto-geocoding" />
      <div className="p-6 overflow-auto flex-1">
        <div className="max-w-3xl mx-auto">
          <div
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) parseFile(f); }}
            onClick={() => fileRef.current?.click()}
            className={`glass border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all
              ${dragging ? 'border-accent bg-accent/5 -translate-y-1' : 'border-stroke-2 hover:border-accent'}`}
          >
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent/25 to-accent-2/10 border border-accent/30 mx-auto mb-4 flex items-center justify-center">
              <UploadIcon size={22} className="text-accent-2" />
            </div>
            <div className="text-base font-medium mb-1">Drop CSV file here</div>
            <div className="text-xs text-ink-mute">Customer Name, Address, Postcode, Phone, Delivery Window, Priority</div>
            <div className="text-[11px] text-ink-mute my-4">— or —</div>
            <div className="flex gap-2 justify-center">
              <button type="button" className="btn btn-ghost" onClick={(e) => { e.stopPropagation(); fileRef.current?.click(); }}>Browse files</button>
              <button type="button" className="btn btn-primary" onClick={(e) => { e.stopPropagation(); loadDemo(); }}>Load demo (24)</button>
            </div>
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) parseFile(f); }} />
          </div>

          {status && (
            <div className={`mt-4 px-4 py-3 rounded-lg text-sm ${status.startsWith('✓') ? 'bg-good/10 border border-good/20 text-good' : 'bg-glass text-ink-dim'}`}>
              {status}
            </div>
          )}

          {rows.length > 0 && (
            <>
              <div className="mt-6 flex items-center justify-between">
                <div>
                  <div className="text-base font-semibold">{rows.length} orders ready</div>
                  <div className="text-xs text-ink-mute">Choose how to import:</div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => doImport(false)} disabled={importing} className="btn btn-ghost">
                    <FileText size={13} />Import without geocoding
                  </button>
                  <button onClick={() => doImport(true)} disabled={importing} className="btn btn-primary">
                    <Zap size={13} />Import & geocode
                  </button>
                </div>
              </div>

              <div className="mt-4 glass overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-white/[.03] border-b border-stroke">
                      <th className="text-left p-3 text-[11px] uppercase tracking-wider text-ink-mute font-medium">#</th>
                      <th className="text-left p-3 text-[11px] uppercase tracking-wider text-ink-mute font-medium">Customer</th>
                      <th className="text-left p-3 text-[11px] uppercase tracking-wider text-ink-mute font-medium">Address</th>
                      <th className="text-left p-3 text-[11px] uppercase tracking-wider text-ink-mute font-medium">Postcode</th>
                      <th className="text-left p-3 text-[11px] uppercase tracking-wider text-ink-mute font-medium">Window</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.slice(0, 10).map((r, i) => (
                      <tr key={i} className="border-b border-stroke last:border-0 text-ink-dim hover:text-ink">
                        <td className="p-3">{i + 1}</td>
                        <td className="p-3 text-ink">{r.customer_name}</td>
                        <td className="p-3">{r.address}</td>
                        <td className="p-3"><span className="pill pill-info">{r.postcode}</span></td>
                        <td className="p-3 text-[11px]">{r.delivery_window}</td>
                      </tr>
                    ))}
                    {rows.length > 10 && (
                      <tr><td colSpan={5} className="text-center text-ink-mute py-3">+ {rows.length - 10} more</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>
    </AppShell>
  );
}
