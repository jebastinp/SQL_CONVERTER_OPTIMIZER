import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { createClient } from '@/lib/supabase-server';

export default async function AnalyticsPage() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return null;

  const { data: routes } = await sb.from('routes').select('*').eq('user_id', user.id);
  const { data: stops } = await sb.from('delivery_stops').select('*').eq('user_id', user.id);

  const totalRoutes = routes?.length || 0;
  const totalDistance = (routes || []).reduce((s: number, r: any) => s + Number(r.distance_km || 0), 0);
  const totalFuel = (routes || []).reduce((s: number, r: any) => s + Number(r.fuel_saved_gbp || 0), 0);
  const totalStops = stops?.length || 0;
  const delivered = (stops || []).filter((s: any) => s.status === 'completed').length;
  const onTime = totalStops > 0 ? Math.round((delivered / totalStops) * 100) : 0;

  return (
    <AppShell>
      <Topbar title="Analytics" subtitle="Operational performance" />
      <div className="p-6 overflow-auto flex-1">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-5">
          {[
            { label: 'Total Routes', val: totalRoutes, sub: 'All time' },
            { label: 'Distance Optimized', val: `${totalDistance.toFixed(0)}km`, sub: 'Cumulative' },
            { label: 'Fuel Saved', val: `£${totalFuel.toFixed(0)}`, sub: 'Cumulative' },
            { label: 'Delivery Rate', val: `${onTime}%`, sub: `${delivered}/${totalStops}` },
          ].map((k) => (
            <div key={k.label} className="glass p-5">
              <div className="text-[11px] uppercase tracking-wider text-ink-mute mb-2">{k.label}</div>
              <div className="font-serif text-3xl">{k.val}</div>
              <div className="text-[11px] text-ink-dim mt-1.5">{k.sub}</div>
            </div>
          ))}
        </div>

        <div className="glass p-6">
          <div className="text-sm font-semibold mb-4">Per-route history</div>
          {totalRoutes === 0 ? (
            <div className="text-center text-ink-dim text-sm py-10">No routes yet. Optimize your first route to see analytics.</div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10.5px] uppercase tracking-wider text-ink-mute border-b border-stroke">
                  <th className="text-left py-2 font-medium">Date</th>
                  <th className="text-left py-2 font-medium">Driver</th>
                  <th className="text-left py-2 font-medium">Distance</th>
                  <th className="text-left py-2 font-medium">Duration</th>
                  <th className="text-left py-2 font-medium">Fuel saved</th>
                  <th className="text-left py-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {(routes || []).map((r: any) => (
                  <tr key={r.id} className="border-b border-stroke last:border-0 text-ink-dim hover:text-ink">
                    <td className="py-2.5">{new Date(r.created_at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                    <td className="py-2.5 font-mono text-[10px]">{r.driver_id.slice(0, 8)}</td>
                    <td className="py-2.5">{Number(r.distance_km || 0).toFixed(1)}km</td>
                    <td className="py-2.5">{Number(r.duration_minutes || 0).toFixed(0)}m</td>
                    <td className="py-2.5 text-good">£{Number(r.fuel_saved_gbp || 0).toFixed(2)}</td>
                    <td className="py-2.5"><span className={`pill ${r.status === 'completed' ? 'pill-ok' : 'pill-info'}`}>{r.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </AppShell>
  );
}
