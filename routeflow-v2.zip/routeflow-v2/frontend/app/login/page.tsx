'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase-browser';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const sb = createClient();
    const { error } = await sb.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.push('/dashboard');
    router.refresh();
  }

  async function signInGoogle() {
    const sb = createClient();
    await sb.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${location.origin}/dashboard` },
    });
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="glass-strong p-10 rounded-2xl w-full max-w-md">
        <Link href="/" className="text-ink-dim text-sm hover:text-ink mb-6 inline-block">
          ← Back
        </Link>
        <h1 className="font-serif text-4xl mb-2">
          Welcome <em className="text-accent-2">back</em>
        </h1>
        <p className="text-ink-dim text-sm mb-8">Sign in to RouteFlow AI</p>

        <form onSubmit={signIn} className="space-y-4">
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="input mt-1.5"
              placeholder="you@company.co.uk"
            />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="input mt-1.5"
              placeholder="••••••••"
            />
          </div>
          {error && (
            <div className="text-bad text-sm bg-bad/10 border border-bad/20 rounded-lg p-3">
              {error}
            </div>
          )}
          <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-3">
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px bg-stroke" />
          <span className="text-xs text-ink-mute">OR</span>
          <div className="flex-1 h-px bg-stroke" />
        </div>

        <button onClick={signInGoogle} className="btn btn-ghost w-full justify-center py-3">
          Continue with Google
        </button>

        <p className="text-center text-sm text-ink-dim mt-8">
          No account?{' '}
          <Link href="/signup" className="text-accent-2 hover:underline">
            Sign up
          </Link>
        </p>
      </div>
    </main>
  );
}
