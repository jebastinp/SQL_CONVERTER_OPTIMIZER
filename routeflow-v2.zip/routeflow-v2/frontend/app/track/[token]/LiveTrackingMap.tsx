'use client';

import { useEffect, useRef, useState } from 'react';

type Props = {
  stopLat: number;
  stopLng: number;
  driverPos: { lat: number; lng: number } | null;
  driverColor: string;
};

export default function LiveTrackingMap({ stopLat, stopLng, driverPos, driverColor }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<any>(null);
  const driverMarkerRef = useRef<any>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || mapObj.current) return;
    let cancelled = false;
    (async () => {
      const L = await import('leaflet');
      if (cancelled) return;
      const map = L.map(mapRef.current!, { zoomControl: true, attributionControl: false })
        .setView([stopLat, stopLng], 14);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);

      // Stop pin
      const stopIcon = L.divIcon({
        className: '',
        html: `<div class="stop-marker" style="background:linear-gradient(135deg,${driverColor},${driverColor}cc);width:28px;height:28px;font-size:11px">📍</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });
      L.marker([stopLat, stopLng], { icon: stopIcon }).addTo(map);

      mapObj.current = map;
      setReady(true);
    })();
    return () => {
      cancelled = true;
      if (mapObj.current) { mapObj.current.remove(); mapObj.current = null; }
    };
  }, [stopLat, stopLng, driverColor]);

  // Update driver marker on each position
  useEffect(() => {
    if (!ready || !mapObj.current) return;
    (async () => {
      const L = await import('leaflet');
      if (!driverPos) return;
      const icon = L.divIcon({
        className: '',
        html: `<div class="driver-marker" style="border-color:${driverColor};box-shadow:0 0 0 4px ${driverColor}55,0 0 12px ${driverColor}"></div>`,
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      });
      if (driverMarkerRef.current) {
        driverMarkerRef.current.setLatLng([driverPos.lat, driverPos.lng]);
      } else {
        driverMarkerRef.current = L.marker([driverPos.lat, driverPos.lng], { icon }).addTo(mapObj.current);
      }
      // Fit bounds to include both
      const bounds = L.latLngBounds([[stopLat, stopLng], [driverPos.lat, driverPos.lng]]);
      mapObj.current.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    })();
  }, [ready, driverPos, stopLat, stopLng, driverColor]);

  return <div ref={mapRef} className="w-full h-full" />;
}
