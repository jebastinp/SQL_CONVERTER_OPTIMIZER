export type Order = {
  id: string;
  user_id: string;
  customer_name: string;
  address: string;
  postcode: string;
  phone?: string;
  lat?: number;
  lng?: number;
  geocoded: boolean;
  delivery_window: string;
  priority: string;
  service_minutes: number;
  notes?: string;
  status: 'pending' | 'assigned' | 'en_route' | 'delivered' | 'failed';
  created_at: string;
  updated_at: string;
};

export type Driver = {
  id: string;
  user_id: string;
  name: string;
  email?: string;
  phone?: string;
  vehicle?: string;
  capacity: number;
  shift_start: string;
  shift_end: string;
  color: string;
  status: 'active' | 'offline' | 'on_break';
  access_token: string;
  current_lat?: number;
  current_lng?: number;
  last_seen?: string;
  created_at: string;
  updated_at: string;
};

export type DeliveryStop = {
  id: string;
  route_id: string;
  order_id: string;
  user_id: string;
  sequence: number;
  eta_minutes: number;
  eta_clock: string;
  arrived_at?: string;
  completed_at?: string;
  status: 'pending' | 'arrived' | 'completed' | 'skipped' | 'failed';
  proof_url?: string;
  notes?: string;
  customer_token: string;
};

export type Route = {
  id: string;
  user_id: string;
  driver_id: string;
  status: 'planned' | 'in_progress' | 'completed' | 'cancelled';
  depot_lat: number;
  depot_lng: number;
  distance_km: number;
  duration_minutes: number;
  fuel_saved_gbp: number;
  baseline_km: number;
  optimized_at: string;
  started_at?: string;
  completed_at?: string;
  created_at: string;
};

export type Profile = {
  id: string;
  email: string;
  full_name?: string;
  company_name?: string;
  role: string;
  depot_lat: number;
  depot_lng: number;
  depot_address: string;
  depot_postcode: string;
  avg_speed_kmh: number;
  fuel_price_gbp: number;
  vehicle_kml: number;
};

export type OptimizeResponse = {
  routes: Array<{
    driver_id: string;
    driver_name: string;
    driver_color: string;
    stops: Array<{
      order_id: string;
      customer_name: string;
      address: string;
      postcode: string;
      lat: number;
      lng: number;
      sequence: number;
      eta_minutes: number;
      eta_clock: string;
    }>;
    distance_km: number;
    duration_minutes: number;
  }>;
  total_distance_km: number;
  baseline_distance_km: number;
  distance_saved_km: number;
  fuel_saved_litres: number;
  fuel_saved_gbp: number;
  optimization_time_ms: number;
  algorithm: string;
};
