import { create } from 'zustand';
import type { Order, Driver, Profile, OptimizeResponse } from './types';

type Store = {
  profile: Profile | null;
  orders: Order[];
  drivers: Driver[];
  lastOptimization: OptimizeResponse | null;
  setProfile: (p: Profile | null) => void;
  setOrders: (o: Order[]) => void;
  setDrivers: (d: Driver[]) => void;
  setOptimization: (r: OptimizeResponse | null) => void;
};

export const useStore = create<Store>((set) => ({
  profile: null,
  orders: [],
  drivers: [],
  lastOptimization: null,
  setProfile: (p) => set({ profile: p }),
  setOrders: (o) => set({ orders: o }),
  setDrivers: (d) => set({ drivers: d }),
  setOptimization: (r) => set({ lastOptimization: r }),
}));
