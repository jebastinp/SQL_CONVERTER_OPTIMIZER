'use client';

import { Search, Bell } from 'lucide-react';

export default function Topbar({ title, subtitle, actions }: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <header className="flex items-center gap-5 px-6 py-3.5 border-b border-stroke bg-bg-0/50 backdrop-blur-xl">
      <div className="flex-1">
        <div className="text-sm">
          <span className="text-ink font-medium">{title}</span>
          {subtitle && <span className="text-ink-dim"> · {subtitle}</span>}
        </div>
      </div>

      <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-glass-2 border border-stroke w-72">
        <Search size={13} className="text-ink-mute" />
        <input
          placeholder="Search routes, drivers, postcodes…"
          className="bg-transparent border-0 outline-0 flex-1 text-xs text-ink placeholder:text-ink-mute"
        />
        <kbd className="text-[10px] text-ink-mute border border-stroke px-1.5 rounded font-mono">⌘K</kbd>
      </div>

      <button className="w-8 h-8 rounded-lg border border-stroke bg-glass-2 text-ink-dim hover:text-ink flex items-center justify-center">
        <Bell size={14} />
      </button>

      {actions}
    </header>
  );
}
