'use client';

import { useEffect, useRef, useState } from 'react';
import type { OptimizeResponse, Profile } from '@/lib/types';
import { createClient } from '@/lib/supabase-browser';

type Props = {
  optimization: OptimizeResponse | null;
  profile: Profile | null;
  driverPositions?: Record<string, { lat: number; lng: number }>;
};

export default function RouteMap({ optimization, profile, driverPositions }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<any>(null);
  const layersRef = useRef<any[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || mapObj.current) return;
    let cancelled = false;
    (async () => {
      const L = await import('leaflet');
      if (cancelled) return;
      const map = L.map(mapRef.current!, { zoomControl: false }).setView(
        [profile?.depot_lat || 51.5095, profile?.depot_lng || -0.1245],
        12,
      );
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap',
        maxZoom: 19,
      }).addTo(map);
      L.control.zoom({ position: 'bottomright' }).addTo(map);
      mapObj.current = map;
      setReady(true);
    })();
    return () => {
      cancelled = true;
      if (mapObj.current) {
        mapObj.current.remove();
        mapObj.current = null;
      }
    };
  }, [profile?.depot_lat, profile?.depot_lng]);

  // Render routes whenever optimization changes
  useEffect(() => {
    if (!ready || !mapObj.current) return;
    (async () => {
      const L = await import('leaflet');
      const map = mapObj.current;

      layersRef.current.forEach((l) => map.removeLayer(l));
      layersRef.current = [];

      const depotLat = profile?.depot_lat || 51.5095;
      const depotLng = profile?.depot_lng || -0.1245;

      const depotIcon = L.divIcon({
        className: '',
        html: '<div class="depot-marker">★</div>',
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });
      const depotMarker = L.marker([depotLat, depotLng], { icon: depotIcon })
        .addTo(map)
        .bindPopup(`<b>${profile?.depot_address || 'Depot'}</b><br>${profile?.depot_postcode || ''}`);
      layersRef.current.push(depotMarker);

      if (!optimization || optimization.routes.length === 0) {
        map.setView([depotLat, depotLng], 12);
        return;
      }

      const allPoints: [number, number][] = [[depotLat, depotLng]];

      optimization.routes.forEach((route, ridx) => {
        const coords: [number, number][] = [
          [depotLat, depotLng],
          ...route.stops.map((s) => [s.lat, s.lng] as [number, number]),
          [depotLat, depotLng],
        ];

        const polyline = L.polyline([], {
          color: route.driver_color,
          weight: 3.5,
          opacity: 0.9,
        }).addTo(map);
        layersRef.current.push(polyline);

        let i = 0;
        const animate = () => {
          if (i > coords.length) return;
          polyline.setLatLngs(coords.slice(0, i));
          i++;
          if (i <= coords.length) setTimeout(animate, 30);
        };
        setTimeout(animate, ridx * 150);

        route.stops.forEach((stop, sidx) => {
          allPoints.push([stop.lat, stop.lng]);
          const icon = L.divIcon({
            className: '',
            html: `<div class="stop-marker" style="background:linear-gradient(135deg,${route.driver_color},${route.driver_color}cc);box-shadow:0 0 0 3px ${route.driver_color}33">${sidx + 1}</div>`,
            iconSize: [22, 22],
            iconAnchor: [11, 11],
          });
          const m = L.marker([stop.lat, stop.lng], { icon })
            .addTo(map)
            .bindPopup(`<b>${stop.customer_name}</b><br>${stop.address}<br>${stop.postcode}<br><br>ETA: <b>${stop.eta_clock}</b><br>Driver: ${route.driver_name}`);
          layersRef.current.push(m);
        });
      });

      // Live driver markers
      if (driverPositions) {
        for (const [driverId, pos] of Object.entries(driverPositions)) {
          const route = optimization.routes.find((r) => r.driver_id === driverId);
          const color = route?.driver_color || '#3ddc97';
          const icon = L.divIcon({
            className: '',
            html: `<div class="driver-marker" style="border-color:${color};box-shadow:0 0 0 4px ${color}55,0 0 12px ${color}"></div>`,
            iconSize: [18, 18],
            iconAnchor: [9, 9],
          });
          const m = L.marker([pos.lat, pos.lng], { icon }).addTo(map);
          layersRef.current.push(m);
        }
      }

      if (allPoints.length > 1) {
        const bounds = L.latLngBounds(allPoints);
        map.fitBounds(bounds, { padding: [60, 60] });
      }
    })();
  }, [ready, optimization, profile, driverPositions]);

  return <div ref={mapRef} className="w-full h-full" />;
}
