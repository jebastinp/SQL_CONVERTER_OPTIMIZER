'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';
import {
  LayoutGrid, Route as RouteIcon, Upload, Users,
  BarChart3, Sparkles, LogOut, Settings,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const items = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutGrid },
  { href: '/routes', label: 'Live Routes', icon: RouteIcon },
  { href: '/orders', label: 'Orders', icon: Upload },
  { href: '/drivers', label: 'Drivers', icon: Users },
  { href: '/analytics', label: 'Analytics', icon: BarChart3 },
];

export default function Sidebar({ profile }: { profile: { full_name?: string; email: string } | null }) {
  const pathname = usePathname();
  const router = useRouter();

  async function signOut() {
    const sb = createClient();
    await sb.auth.signOut();
    router.push('/login');
    router.refresh();
  }

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase()
    : profile?.email?.slice(0, 2).toUpperCase() || '??';

  return (
    <aside className="w-60 glass-strong flex flex-col p-4 gap-1.5 h-screen sticky top-0">
      <div className="flex items-center gap-2.5 px-2 pb-5 pt-1">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent via-accent-2 to-purple shadow-lg shadow-accent/50" />
        <div className="font-serif text-xl tracking-tight">
          Route<span className="text-accent-2 italic">Flow</span>
        </div>
      </div>

      <div className="text-[10px] uppercase tracking-widest text-ink-mute px-2.5 pt-3 pb-1">
        Workspace
      </div>
      {items.map((item) => {
        const active = pathname === item.href || pathname.startsWith(item.href + '/');
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              'flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium transition-all relative',
              active ? 'text-ink bg-gradient-to-r from-accent/20 to-accent/5 shadow-[inset_0_0_0_1px_rgba(91,140,255,.25)]'
                     : 'text-ink-dim hover:text-ink hover:bg-glass-2',
            )}
          >
            {active && (
              <div className="absolute -left-4 top-2 bottom-2 w-0.5 bg-accent rounded-full shadow-[0_0_8px_currentColor]" />
            )}
            <Icon size={16} className="opacity-85" />
            {item.label}
          </Link>
        );
      })}

      <div className="text-[10px] uppercase tracking-widest text-ink-mute px-2.5 pt-4 pb-1">
        Intelligence
      </div>
      <Link href="/dashboard" className="flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium text-ink-dim hover:text-ink hover:bg-glass-2">
        <Sparkles size={16} className="opacity-85" />
        AI Insights
      </Link>

      <div className="mt-auto pt-3 border-t border-stroke">
        <Link href="/dashboard" className="flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm text-ink-dim hover:text-ink hover:bg-glass-2 mb-2">
          <Settings size={15} />
          Settings
        </Link>
        <div className="flex items-center gap-2.5 px-2.5 py-2">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-accent to-purple flex items-center justify-center text-xs font-semibold text-white">
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium truncate">{profile?.full_name || profile?.email || 'User'}</div>
            <div className="text-[10px] text-ink-mute truncate">{profile?.email}</div>
          </div>
          <button onClick={signOut} className="text-ink-mute hover:text-bad p-1" title="Sign out">
            <LogOut size={14} />
          </button>
        </div>
      </div>
    </aside>
  );
}
