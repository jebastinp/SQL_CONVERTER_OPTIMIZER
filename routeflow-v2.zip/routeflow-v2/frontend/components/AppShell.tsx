import { createClient } from '@/lib/supabase-server';
import Sidebar from '@/components/Sidebar';
import { redirect } from 'next/navigation';

export default async function AppShell({ children }: { children: React.ReactNode }) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await sb.from('profiles').select('*').eq('id', user.id).single();

  return (
    <div className="flex min-h-screen">
      <Sidebar profile={profile || { email: user.email || '' }} />
      <main className="flex-1 flex flex-col overflow-hidden">
        {children}
      </main>
    </div>
  );
}
