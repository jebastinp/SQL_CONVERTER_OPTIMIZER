# Architecture

How RouteFlow AI is structured and why.

## System diagram

```
                              ┌──────────────────────────────┐
                              │       END USERS              │
                              │                              │
   Dispatcher                 │   Driver                     │   Customer
   (laptop, web)              │   (phone, web/PWA)           │   (phone, web)
        │                     │       │                      │       │
        ▼                     │       ▼                      │       ▼
┌────────────────────────────────────────────────────────────────────────────────┐
│                                                                                │
│                       VERCEL — Next.js 14 (App Router)                         │
│                                                                                │
│   /dashboard /routes /orders /drivers /analytics   ← dispatcher (auth req'd)   │
│   /driver/[token]                                  ← driver app (token auth)   │
│   /track/[token]                                   ← customer (public)         │
│   /login /signup /                                 ← public                    │
│                                                                                │
│   Server components → query Supabase directly                                  │
│   Client components → use Supabase JS SDK + custom API wrapper                 │
└─────────┬─────────────────────────────────────────────┬────────────────────────┘
          │ HTTPS                                       │ HTTPS + JWT
          │                                             │
          ▼                                             ▼
┌──────────────────────────┐               ┌──────────────────────────┐
│  SUPABASE — managed PG    │               │   RENDER — FastAPI       │
│                          │               │                          │
│  • Auth (email, OAuth)   │               │  POST /optimize          │
│  • Postgres + RLS        │               │   → OR-Tools VRP solver  │
│  • Realtime (websockets) │               │  POST /geocode           │
│  • Storage (PoD photos)  │               │   → OpenRouteService     │
│  • REST + GraphQL APIs   │               │    + Supabase cache      │
└─────────────┬────────────┘               └──────────┬───────────────┘
              │                                       │
              │                                       │ HTTPS
              │                                       ▼
              │                            ┌──────────────────────────┐
              │                            │  OPENROUTESERVICE        │
              │                            │  (third-party API)       │
              │                            │  Geocoding + ETA matrix  │
              │                            └──────────────────────────┘
              │
              └─────── Realtime subscriptions ──────► browsers (live driver positions, status updates)
```

## Why this split?

**Vercel for frontend** — Edge caching means the dashboard loads fast from anywhere in the world. Next.js App Router gives us server components for SEO + initial paint, plus client components for interactivity. Free tier handles ~100k page views/month.

**Render for backend** — OR-Tools is a heavy native binary (~150MB); it doesn't fit Vercel serverless function limits. Render Web Services give us a long-running Python process with enough RAM. The route optimization is CPU-bound, not I/O bound, so we want it on dedicated compute.

**Supabase for data + auth + realtime** — Three services in one. Postgres is the right database for relational data (orders, routes, stops have natural foreign keys). Built-in auth means we don't write password hashing or session management. Realtime gives us WebSocket subscriptions for live driver tracking without running our own pub/sub.

**OpenRouteService for geocoding** — Open-source maps & OSM-based routing. Generous free tier (2000 req/day). UK postcode coverage is good. Alternative is Google Maps Geocoding API (more accurate but paid).

## Data model

```
auth.users                         ← Supabase-managed
   │
   │ 1:1 via id
   ▼
profiles                            ← extends user with company settings
   │
   │ 1:many
   ├──► drivers ─────────┐
   │       │             │
   ├──► orders ───┐      │
   │              ▼      ▼
   ├──► routes ──────────┐
   │       │             │
   │       │ 1:many      │
   │       ▼             │
   ├──► delivery_stops ──┘
   │       │
   │       │ has customer_token (public tracking)
   │       │
   └──► driver_positions  ← time-series, written by driver phone GPS
```

All tenant tables have `user_id` and an RLS policy `user_id = auth.uid()`. The only shared table is `geocode_cache` — different users delivering to the same postcode share the cached coordinates.

## Request flows

### 1. Optimize a route (the core workflow)

```
Dispatcher clicks "Optimize Routes"
        │
        ▼
Frontend gathers geocoded orders + drivers + profile from Supabase
        │
        ▼
Frontend POST /optimize  with Authorization: Bearer <user JWT>
        │
        ▼
Render backend verifies JWT (HS256 with SUPABASE_JWT_SECRET)
        │
        ▼
optimizer.py:
  1. k-means cluster orders → driver groups (geographic balance)
  2. For each cluster: OR-Tools TSP with PATH_CHEAPEST_ARC + GUIDED_LOCAL_SEARCH
  3. Compute ETAs from haversine distance ÷ avg_speed + dwell time
  4. Calculate fuel savings vs naive (depot → orders in input order)
        │
        ▼
Returns JSON: { routes: [...], total_km, saved_km, fuel_gbp }
        │
        ▼
Frontend persists to Supabase:
  - INSERT routes (one per driver)
  - INSERT delivery_stops (one per stop, with customer_token auto-generated)
  - UPDATE orders SET status = 'assigned'
        │
        ▼
Map renders the routes with animated polylines
```

### 2. Driver mobile app (PWA)

```
Dispatcher copies driver link → driver opens on phone
        │
        ▼
GET /driver/[token]  → no auth, just token in URL
        │
        ▼
Page calls Supabase: SELECT * FROM drivers WHERE access_token = token
        │
        ▼
Then fetches their latest planned/in_progress route with stops + orders joined
        │
        ▼
Driver taps "Start route" → navigator.geolocation.watchPosition()
        │
        ▼
Each position update INSERTs into driver_positions
        │
        ▼
This insert fires Supabase Realtime → dispatcher dashboard subscribers receive it
        │
        ▼
Dashboard updates the driver's marker on the map in real-time
```

### 3. Customer tracking page

```
Customer clicks tracking link in their notification email/SMS
        │
        ▼
GET /track/[customer_token]  → no auth, public
        │
        ▼
SELECT * FROM delivery_stops WHERE customer_token = ?
        │ (RLS allows this query — customer_token is the ACL itself)
        ▼
Page shows: stop position, ETA, driver name, live map
        │
        ▼
Subscribes to Realtime channel for this driver_id
        │
        ▼
Each driver_positions INSERT pushes update to customer's browser
```

## RLS strategy

Because every tenant table has a `user_id` column and a policy `user_id = auth.uid()`, the database itself enforces multi-tenancy. Even if our application code has a bug and queries `SELECT * FROM orders` without a `WHERE user_id`, Supabase will silently filter out other users' rows.

**Public access** for `/driver/[token]` and `/track/[token]` works because we look up by an opaque random token (16 hex chars for drivers, 12 for stops). The token *is* the access credential — anyone with it can read that one row.

> ⚠️ This means if a customer forwards their tracking link, the recipient can see the delivery. That's by design for delivery tracking. If you need stronger privacy, consider expiring tokens after the delivery is complete.

## Optimizer choice: why OR-Tools?

OR-Tools is Google's industrial-strength VRP/TSP solver. For our scale:

| Stops | OR-Tools (GLS, 5s) | Greedy nearest-neighbor |
|---|---|---|
| 10 | optimal, <1s | 8-15% longer |
| 50 | within 2% of optimal | 20-30% longer |
| 200 | within 5% of optimal | 35-50% longer |
| 1000 | within 8% of optimal | not viable |

Falling back to nearest-neighbor (if ortools fails to install) is good enough for the small-scale demo but you'll feel the difference once routes get past 30 stops.

## Realtime: what's enabled

We enable Supabase Realtime on three tables in `schema.sql`:
- `driver_positions` — live GPS pings from driver phones
- `delivery_stops` — status changes (pending → arrived → completed)
- `routes` — high-level route status

Other tables (orders, drivers, profiles) aren't on realtime — they don't need to push updates to subscribers, and broadcasting their changes wastes bandwidth.

## File hosting (proof-of-delivery photos)

When a driver takes a photo to confirm delivery, it uploads to Supabase Storage with an RLS policy scoped to their `user_id`. The URL is stored in `delivery_stops.proof_url`. We haven't wired this up in the UI yet — see the future enhancements list in `README.md`.

## Where to extend

- **Notifications** — add a `notifications` table and use Supabase Edge Functions to call Twilio when a stop is approaching.
- **Multiple depots** — add a `depots` table FK'd to profile, and update optimizer to take depot per driver.
- **Time windows** — `optimizer.py` already accepts delivery_window strings. Wire them into the OR-Tools time dimension for hard constraints.
- **Vehicle capacity** — add `capacity` constraint to the OR-Tools model using a capacity dimension.
- **Real road distances** — instead of haversine, call ORS Matrix API for the distance/duration matrix. Costs more requests but much more accurate.
