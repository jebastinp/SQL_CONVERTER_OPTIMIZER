# Deployment Guide — Vercel + Render + Supabase

Once you have RouteFlow running locally (see `SETUP.md`), this guide gets it live on the internet with a custom domain. **Total cost to start: £0/month.** All three services have generous free tiers.

## What you're building

```
       Customer / Driver / Dispatcher
                    │
                    ▼
        ┌───────────────────────┐
        │   Vercel (frontend)   │ ◄── Next.js app, edge-cached globally
        │   routeflow.app       │
        └──────────┬────────────┘
                   │ HTTPS API calls
                   ▼
        ┌───────────────────────┐
        │   Render (backend)    │ ◄── FastAPI + OR-Tools
        │   *.onrender.com      │
        └──────────┬────────────┘
                   │
                   ▼
        ┌───────────────────────┐
        │  Supabase (db+auth)   │ ◄── Postgres, Auth, Realtime
        │  *.supabase.co        │
        └───────────────────────┘
```

---

## Prerequisite — get your code into a Git repo

Vercel and Render both deploy from GitHub.

```bash
cd /path/to/routeflow-v2
git init
git add .
git commit -m "initial commit"
```

Then create a private repo on **github.com**, follow the instructions to push:
```bash
git remote add origin git@github.com:YOUR_USERNAME/routeflow.git
git branch -M main
git push -u origin main
```

> ⚠️ Make sure `.env`, `.env.local`, and `node_modules/` are in `.gitignore` (they already are).

---

## Step 1 — Supabase is already production-ready

The Supabase project you set up in `SETUP.md` works for production as-is. No changes needed yet.

When you grow:
- **Free tier:** 500MB DB, 50k monthly active users, 2GB bandwidth — fine for ~5–10 small customers.
- **Pro tier (£25/mo):** 8GB DB, 100k MAU, daily backups, dedicated support — good for ~50 customers.

To upgrade: Supabase dashboard → **Settings → Billing**.

---

## Step 2 — Deploy backend to Render (5 min)

1. Go to **https://render.com**, sign up with GitHub.

2. Click **New +** → **Web Service**.

3. **Connect a repository** → choose your `routeflow` repo.

4. Fill in the form:

   | Field | Value |
   |---|---|
   | **Name** | `routeflow-backend` |
   | **Region** | **Frankfurt** (closest to UK) |
   | **Branch** | `main` |
   | **Root Directory** | `backend` |
   | **Runtime** | `Python 3` |
   | **Build Command** | `pip install -r requirements.txt` |
   | **Start Command** | `uvicorn main:app --host 0.0.0.0 --port $PORT` |
   | **Instance Type** | **Free** (or **Starter** £7/mo for always-on) |

5. Click **Advanced** → add environment variables (same names as your local `backend/.env`):

   ```
   SUPABASE_URL = https://xxxxxxxx.supabase.co
   SUPABASE_SERVICE_KEY = eyJhbGc...   (service_role key)
   SUPABASE_JWT_SECRET  = ...
   ORS_API_KEY          = 5b3ce3...
   ALLOWED_ORIGINS      = https://routeflow.vercel.app,https://your-custom-domain.com
   PYTHON_VERSION       = 3.11
   ```

   > **Important:** `ALLOWED_ORIGINS` must include the URL where your frontend will live (you'll know this after Step 3).

6. Click **Create Web Service**. First build takes ~5 minutes (OR-Tools is large).

7. When deployed, Render gives you a URL like `https://routeflow-backend-abc123.onrender.com`. Copy it.

8. Test: open `https://routeflow-backend-abc123.onrender.com/health` — should return JSON with `"status":"ok"`.

> **Render free tier sleeps after 15 min of inactivity** and takes ~30 sec to wake up on first request. For production with paying customers, upgrade to **Starter ($7/mo)** for always-on.

---

## Step 3 — Deploy frontend to Vercel (3 min)

1. Go to **https://vercel.com**, sign up with GitHub.

2. Click **Add New → Project** → import your `routeflow` repo.

3. Vercel will auto-detect Next.js. Configure:

   | Field | Value |
   |---|---|
   | **Framework Preset** | Next.js (auto-detected) |
   | **Root Directory** | `frontend` |
   | **Build Command** | (leave default) `npm run build` |
   | **Install Command** | (leave default) `npm install` |
   | **Output Directory** | (leave default) `.next` |

4. Expand **Environment Variables** and add:

   ```
   NEXT_PUBLIC_SUPABASE_URL      = https://xxxxxxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGc...   (anon, NOT service_role)
   NEXT_PUBLIC_API_URL           = https://routeflow-backend-abc123.onrender.com
   ```

   Use the Render URL from Step 2 for `NEXT_PUBLIC_API_URL`.

5. Click **Deploy**. Takes ~90 seconds.

6. When done, Vercel gives you a URL like `https://routeflow-xyz.vercel.app`. Open it — your app is live.

7. **Update CORS on Render:** go back to Render → your service → **Environment** → edit `ALLOWED_ORIGINS` to include your Vercel URL:
   ```
   ALLOWED_ORIGINS=http://localhost:3000,https://routeflow-xyz.vercel.app
   ```
   Render will redeploy automatically (~1 min).

---

## Step 4 — Add your custom domain (optional, 5 min)

1. Buy a domain (e.g. `routeflow.app`) from any registrar — Cloudflare, Namecheap, or Google Domains.

2. **In Vercel** → Your Project → **Settings → Domains** → **Add** `routeflow.app`.

3. Vercel shows you DNS records to add. Go to your registrar and add them:
   - Type `A` → name `@` → value `76.76.21.21`
   - Type `CNAME` → name `www` → value `cname.vercel-dns.com`

4. Wait 5–60 minutes for DNS to propagate. Vercel auto-issues an SSL cert.

5. Update Render `ALLOWED_ORIGINS`:
   ```
   ALLOWED_ORIGINS=https://routeflow.app,https://www.routeflow.app
   ```

6. (Optional) Add a subdomain for the API:
   - **In Render** → your service → **Settings → Custom Domains** → add `api.routeflow.app`.
   - Add the CNAME record at your registrar.
   - Update `NEXT_PUBLIC_API_URL` in Vercel to `https://api.routeflow.app`.

---

## Step 5 — Update Supabase auth redirect URLs (1 min)

Once you have your production domain, tell Supabase to allow it:

1. Supabase dashboard → **Authentication → URL Configuration**.
2. **Site URL:** `https://routeflow.app`
3. **Redirect URLs (additional):**
   ```
   https://routeflow.app/**
   https://routeflow-xyz.vercel.app/**
   http://localhost:3000/**
   ```
4. **Save**.

This ensures email confirmation links and OAuth redirects work correctly on your production domain.

---

## Step 6 — Enable Google OAuth (optional, 5 min)

For the "Continue with Google" button on the login page:

1. Go to **https://console.cloud.google.com** → create a project (or use existing).
2. **APIs & Services → OAuth consent screen** → External → fill in app name + your email.
3. **Credentials → + Create Credentials → OAuth client ID → Web application**.
   - **Authorized redirect URI:** copy the one Supabase shows you in step 5 below.
4. Copy the **Client ID** and **Client Secret**.
5. Supabase dashboard → **Authentication → Providers → Google** → paste credentials → toggle **Enabled** → **Save**.

---

## Ongoing — monitoring

- **Render logs:** dashboard → your service → **Logs** tab. Watch for errors.
- **Vercel logs:** dashboard → your project → **Logs** tab.
- **Supabase logs:** dashboard → **Logs** in sidebar.

## Scaling beyond free tiers

| Stage | Cost/mo | Capacity |
|---|---|---|
| Free tier all-around | £0 | 5–10 small customers, backend sleeps |
| Render Starter (£7) | £7 | Always-on backend, no cold starts |
| Render Starter + Supabase Pro (£25) | £32 | ~50 customers, daily backups |
| Plus Vercel Pro (£15) | £47 | Production-grade frontend, analytics |

That's it — you're live. Run through `SETUP.md` step 5 against the production URLs to verify everything works end-to-end.
