# Setup Guide — Get RouteFlow Running in 15 Minutes

This walks you through getting the system fully running on your laptop. You'll need:
- A computer with Node.js 18+ and Python 3.10+ installed
- A web browser
- An email address for sign-ups
- About 15 minutes

By the end you'll have a working dispatcher dashboard, optimizer, driver mobile app, and customer tracking — all running on your machine.

---

## Step 1 — Create your Supabase project (5 min)

Supabase gives you Postgres database + authentication + realtime + storage in one free service.

1. Go to **https://supabase.com** and click **Start your project**. Sign up with GitHub or email.
2. Click **New project**.
   - **Name:** `routeflow` (anything)
   - **Database password:** generate a strong one and **save it somewhere** (you may need it later)
   - **Region:** choose **London (eu-west-2)** — closest to UK customers
   - **Pricing plan:** **Free**
3. Wait ~2 minutes for the project to provision.

4. Once the project is ready, click **SQL Editor** in the left sidebar → **+ New query**.
5. Open the file `supabase/schema.sql` from this project, copy its entire contents, paste into the editor, and click **RUN** (or press Ctrl/Cmd+Enter).
6. You should see "Success. No rows returned." — verify by clicking **Table Editor**, you should see 7 tables: `profiles`, `drivers`, `orders`, `routes`, `delivery_stops`, `driver_positions`, `geocode_cache`.

### Get your Supabase API keys

7. Click the **gear icon** (Settings) at the bottom-left → **API**.
8. You'll see four values you need to copy. Keep this page open:

| What you see | What it's called | Where it goes |
|---|---|---|
| **Project URL** | `https://xxxxxxxx.supabase.co` | Both backend & frontend `.env` |
| **Project API keys → anon public** | `eyJhbGc...` | **Frontend only** — safe to expose |
| **Project API keys → service_role** | `eyJhbGc...` | **Backend only** — secret, never expose! |
| **JWT Settings → JWT Secret** | random string | **Backend only** |

> ⚠️ The **service_role** key bypasses Row-Level Security. Never paste it into frontend code or commit it to git.

---

## Step 2 — Get OpenRouteService API key (2 min)

This is what turns UK postcodes and addresses into latitude/longitude coordinates. Free tier: 2,000 requests/day, more than enough.

1. Go to **https://openrouteservice.org/dev/#/signup** and create an account.
2. After confirming your email, log in and go to the **Dashboard**.
3. Click **Request a token**:
   - **Token type:** `Standard`
   - **Token name:** `routeflow`
4. Click **CREATE TOKEN** and copy the long string that appears. This is your `ORS_API_KEY`.

---

## Step 3 — Configure & run the backend (3 min)

```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt   # takes ~1 min
cp .env.example .env
```

Now open `backend/.env` in a text editor and fill in:

```bash
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...    # from Step 1 (service_role)
SUPABASE_JWT_SECRET=...            # from Step 1 (JWT Secret)
ORS_API_KEY=5b3ce3597...           # from Step 2
ALLOWED_ORIGINS=http://localhost:3000
```

Start the backend:

```bash
uvicorn main:app --reload --port 8000
```

You should see:
```
🚀 RouteFlow backend starting
   CORS origins: ['http://localhost:3000']
   Supabase URL: https://xxxxxxxx.supabase.co…
   ORS API key:  set
INFO:     Uvicorn running on http://0.0.0.0:8000
```

Test it: open **http://localhost:8000/health** in a browser. You should see:
```json
{"status":"ok","ortools":true,"ors_configured":true,"supabase_configured":true}
```

> If `ortools` is `false`, the optimizer will fall back to a slower heuristic. To fix: `pip install ortools`. On Apple Silicon Macs you may need `brew install python@3.11` first.

---

## Step 4 — Configure & run the frontend (3 min)

Open a **new terminal** (keep the backend running):

```bash
cd frontend
npm install                       # takes ~2 min
cp .env.local.example .env.local
```

Open `frontend/.env.local` in a text editor and fill in:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...   # from Step 1 (anon public)
NEXT_PUBLIC_API_URL=http://localhost:8000
```

Start the frontend:

```bash
npm run dev
```

Open **http://localhost:3000**.

---

## Step 5 — Create your first account & data (2 min)

1. Click **Get started** → fill in name, company, email, password → **Create account**.
   - You'll be redirected to the dashboard automatically.
   - (If Supabase asks for email confirmation, check your inbox and click the link.)

2. **Add a driver:**
   - Click **Drivers** in the sidebar → fill in the form on the right → **Add driver**.
   - Pro tip: pick a color so this driver's route is easy to see on the map.

3. **Import demo orders:**
   - Click **Orders** → **Import CSV** → **Load demo (24)**.
   - You'll see 24 London orders parsed.
   - Click **Import & geocode** — this calls OpenRouteService for each address. Takes ~10 seconds.
   - You'll be redirected to Orders, and all 24 should have a ✓ in the Geo column.

4. **Optimize routes:**
   - Click **Live Routes** → **Optimize Routes**.
   - In a couple of seconds you'll see your optimized routes drawn on the map, with each stop numbered and the savings displayed.

5. **Test the driver app:**
   - Go to **Drivers** → click **Copy driver app link** on any driver card.
   - Paste the link in your phone's browser (or in a private window on your laptop). You'll see the mobile-style driver app with the assigned stops.
   - Tap **Start route & share location** — this begins streaming GPS back to the dashboard.

6. **Test customer tracking:**
   - Back in the dispatcher dashboard, go to Supabase → Table Editor → `delivery_stops` and copy any `customer_token` value.
   - Open `http://localhost:3000/track/PASTE_TOKEN_HERE` — you'll see the customer's view with the live driver position.

---

## What's next

- **Deploy to production:** see `docs/DEPLOY.md` to get this on Vercel + Render with a custom domain.
- **Customize:** every brand color, logo, copy is in `frontend/app/globals.css` and `frontend/app/page.tsx`.
- **Add real customers:** create accounts manually via the signup page, or add them via Supabase's auth dashboard.

## Troubleshooting

| Problem | Fix |
|---|---|
| "Supabase not configured" on backend | Check `.env` has `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` filled |
| Geocoding returns 401 | `ORS_API_KEY` is wrong or expired — regenerate at openrouteservice.org |
| Login screen loops back to itself | Clear cookies for localhost and try again |
| Map is blank | Open browser console (F12) — usually a Leaflet CSS import issue. Run `npm install` again |
| `npm install` errors about `react-leaflet` peer deps | Run with `npm install --legacy-peer-deps` |
| Backend says "ortools not installed" on M1 Mac | `pip install ortools` may fail; install Python 3.11 specifically: `brew install python@3.11` then recreate venv |
| Driver app shows "Invalid driver link" | The token in URL doesn't match any driver. Copy the link from the Drivers page again |

For anything else, check `docs/API_KEYS.md` to confirm every env var is in the right place.
