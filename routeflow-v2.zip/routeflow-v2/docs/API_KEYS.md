# API Keys Reference

Quick lookup for every environment variable in the system. If you're confused about which key goes where, check this table.

## Frontend (`frontend/.env.local`)

| Variable | Service | Where to get it | Public? |
|---|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase | Dashboard → Settings → API → "Project URL" | Yes — visible to browser |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase | Dashboard → Settings → API → "anon public" key | Yes — designed for browser |
| `NEXT_PUBLIC_API_URL` | Your backend | Render dashboard → service URL, e.g. `https://routeflow-backend-abc.onrender.com` | Yes — just a URL |

> `NEXT_PUBLIC_` prefix means Next.js bundles the value into the browser code. **Never** put secrets under this prefix.

## Backend (`backend/.env`)

| Variable | Service | Where to get it | Public? |
|---|---|---|---|
| `SUPABASE_URL` | Supabase | Dashboard → Settings → API → "Project URL" | OK to expose |
| `SUPABASE_SERVICE_KEY` | Supabase | Dashboard → Settings → API → "service_role" key | **NEVER expose** — bypasses RLS |
| `SUPABASE_JWT_SECRET` | Supabase | Dashboard → Settings → API → JWT Settings → "JWT Secret" | **NEVER expose** — verifies user tokens |
| `ORS_API_KEY` | OpenRouteService | openrouteservice.org/dev → Dashboard → Request a token (Standard) | Secret — keep on backend only |
| `ALLOWED_ORIGINS` | (config) | Comma-separated list of frontend URLs that may call the API | OK to expose (it's a config, not a secret) |
| `PORT` | (config) | Defaults to 8000 locally; Render sets this automatically | OK |

## Key visualization

```
┌─────────────────────────────────────────────────────┐
│ Public — safe in frontend, visible to anyone        │
├─────────────────────────────────────────────────────┤
│ NEXT_PUBLIC_SUPABASE_URL                            │
│ NEXT_PUBLIC_SUPABASE_ANON_KEY                       │
│ NEXT_PUBLIC_API_URL                                 │
│ SUPABASE_URL                                        │
│ ALLOWED_ORIGINS                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ SECRET — backend only, never in browser/git/logs    │
├─────────────────────────────────────────────────────┤
│ SUPABASE_SERVICE_KEY     ← bypasses RLS, full admin │
│ SUPABASE_JWT_SECRET      ← signs/verifies user JWTs │
│ ORS_API_KEY              ← rate-limited per account │
└─────────────────────────────────────────────────────┘
```

## How auth flows

1. User signs in via frontend → Supabase Auth issues a JWT.
2. Frontend stores JWT in a cookie + localStorage (handled by `@supabase/ssr`).
3. Frontend calls `/optimize` etc. with `Authorization: Bearer <JWT>`.
4. Backend verifies the JWT using `SUPABASE_JWT_SECRET` (HS256).
5. Backend extracts the `user_id` from the JWT and uses it for all queries.
6. Supabase RLS policies use `auth.uid()` to filter rows — each user only sees their own data.

This means even if a user gets hold of someone else's JWT URL params, RLS prevents data leakage.

## Rotating a key (if leaked)

| Key | Rotation |
|---|---|
| `SUPABASE_ANON_KEY` | Supabase Dashboard → Settings → API → click "Reset". Update everywhere it's used. |
| `SUPABASE_SERVICE_KEY` | Same — click "Reset" next to service_role. Existing sessions stay valid. |
| `SUPABASE_JWT_SECRET` | Supabase Dashboard → Settings → API → JWT Settings → "Generate new secret". **This invalidates all existing user sessions** — everyone has to log in again. Use only if compromised. |
| `ORS_API_KEY` | OpenRouteService Dashboard → revoke + create new token. |

## Quick checklist before going live

- [ ] `.env` files are NOT in your git repo (check `git status`)
- [ ] `SUPABASE_SERVICE_KEY` is only in backend env vars (Render), not in frontend env vars (Vercel)
- [ ] `ALLOWED_ORIGINS` on Render includes your production Vercel URL
- [ ] Supabase Auth → URL Configuration has your production domain in the allow list
- [ ] You've signed up with a real account on the production URL and verified you can optimize a route end-to-end
