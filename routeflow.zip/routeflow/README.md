# RouteFlow AI

> **AI route intelligence for modern UK delivery operations.**

A premium, glass-UI logistics platform for UK delivery businesses. This package contains a **working frontend prototype** with a real in-browser route optimizer, plus a **reference FastAPI backend**, **PostgreSQL schema**, and a complete **roadmap** to turn this foundation into a deployed SaaS.

---

## ⚡ Quick start (30 seconds — no install needed)

1. Unzip the project
2. Open `index.html` in any modern browser (Chrome, Safari, Firefox, Edge)
3. Click **Launch app →** (or open `app/index.html` directly)
4. Click **Load demo (24 orders)** then **Optimize Routes**
5. View the animated optimized routes on the live map

Everything runs locally in your browser. No backend, no API keys, no signup needed for the demo.

---

## 📦 What's in this package

```
routeflow/
├── index.html              ← Marketing landing page (premium hero, pricing, FAQ)
├── app/
│   └── index.html          ← The actual SaaS app (single-file, self-contained)
├── backend/
│   ├── main.py             ← FastAPI server with OR-Tools optimizer
│   ├── requirements.txt    ← Python dependencies
│   └── schema.sql          ← PostgreSQL schema (9 tables, indexes, triggers)
├── data/
│   └── sample-orders.csv   ← 24 London orders in the required CSV format
└── docs/
    ├── ROADMAP.md          ← Realistic plan to ship production SaaS
    └── ARCHITECTURE.md     ← System design, tech stack, deployment guide
```

---

## ✅ What works right now (in-browser, no setup)

- **Premium liquid-glass UI** — dark mode, gradient ambient lighting, Instrument Serif display font, micro-interactions
- **Real route optimization** — k-means clustering for multi-driver allocation + nearest-neighbor + 2-opt heuristic TSP solver
- **Live interactive map** — Leaflet + OpenStreetMap, animated route drawing, custom depot/stop/driver markers
- **CSV import** — drag-and-drop or browse, validates and previews
- **Multi-driver clustering** — geographic balancing across 5 drivers automatically
- **Animated KPI dashboards** — counters, sparklines, fuel trend, driver performance, recent deliveries
- **AI insights panel** — 4 contextual recommendations (overload, fuel, dispatch window, delay forecast)
- **Live driver simulation** — animated driver dots traverse routes in real-time
- **CSV export** — optimized routes with driver, sequence, ETA, coordinates
- **Driver management view** — capacity bars, on-time rates, shift info, status indicators
- **Fully responsive** — works on tablet and mobile

Try this: load the demo, click **Optimize Routes**, then click **▶ Simulate** to watch drivers move along their routes live.

---

## 🏗️ What needs to be built for production (and how)

This prototype is the **frontend foundation** of the full SaaS spec. To ship as a real product, you'll need:

| Component | Status | Effort |
|---|---|---|
| Frontend UI/UX | ✅ Built (this prototype) | — |
| Optimization algorithm | ✅ Built (in-browser version) | — |
| FastAPI backend reference | ✅ Scaffolded (see `backend/`) | 1–2 weeks to harden |
| PostgreSQL schema | ✅ Provided (`backend/schema.sql`) | — |
| User authentication (Clerk/Supabase) | ⏳ Not built | 3–5 days |
| Real UK postcode geocoding (OpenRouteService) | ⏳ Stub only | 2–3 days |
| Real driver mobile app (PWA) | ⏳ Not built | 1–2 weeks |
| Live GPS tracking via WebSockets | ⏳ Not built | 1 week |
| Billing (Stripe) | ⏳ Not built | 3–5 days |
| Deployment (Vercel + Render) | ⏳ Not built | 2 days |
| Production monitoring (Sentry, logs) | ⏳ Not built | 2 days |

**Honest estimate: 6–10 weeks of focused engineering** to take this from prototype to v1 SaaS. See `docs/ROADMAP.md` for the day-by-day breakdown.

---

## 🚀 Run the FastAPI backend (optional)

The backend is a reference implementation showing how to port the in-browser optimizer to a production-grade Python service using Google OR-Tools.

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Then POST to `http://localhost:8000/optimize`:

```bash
curl -X POST http://localhost:8000/optimize \
  -H "Content-Type: application/json" \
  -d '{
    "depot": {"lat": 51.5095, "lng": -0.1245},
    "orders": [
      {"name":"H. Patel","address":"12 Baker St","postcode":"NW1 6XE","lat":51.5217,"lng":-0.1571},
      {"name":"J. Donovan","address":"45 Borough High St","postcode":"SE1 1XF","lat":51.5045,"lng":-0.0908}
    ],
    "drivers": [
      {"id":"d1","name":"Marcus","vehicle":"VW Crafter","capacity":30}
    ]
  }'
```

The backend uses the same clustering + TSP approach as the frontend but with OR-Tools' Guided Local Search for higher accuracy on large fleets (5000+ stops).

---

## 🗄️ Set up the database

```bash
# Local Postgres
createdb routeflow
psql routeflow -f backend/schema.sql

# Or Supabase: paste backend/schema.sql into the SQL editor
```

The schema is in `backend/schema.sql`: 9 tables (users, drivers, vehicles, orders, routes, delivery_stops, analytics_daily, notifications, ai_insights) with proper foreign keys, indexes, triggers, and ready-to-enable RLS policies for multi-tenancy.

---

## 📐 Architecture overview

```
┌─────────────────────┐         ┌──────────────────┐         ┌────────────────┐
│  Next.js Frontend   │ ──HTTP─►│  FastAPI Backend │ ──SQL──►│   PostgreSQL   │
│  (Vercel)           │         │  (Render)        │         │   (Supabase)   │
│  - React + Tailwind │         │  - OR-Tools VRP  │         └────────────────┘
│  - Leaflet maps     │         │  - Auth (Clerk)  │
│  - Zustand state    │         │  - Geocoding     │ ───────►│ OpenRouteService│
│  - Framer Motion    │         │  - WebSockets    │         │  (geocoding)    │
└─────────────────────┘         └──────────────────┘         └─────────────────┘
        ▲                                                            
        │ WebSocket (live driver positions, ETAs, reroutes)         
        ▼                                                            
┌─────────────────────┐                                              
│   Driver PWA        │                                              
│  (mobile-installed) │                                              
└─────────────────────┘                                              
```

See `docs/ARCHITECTURE.md` for the deep dive on each piece.

---

## 🎯 Recommended next steps

1. **Today**: Open `index.html` in your browser, try the demo, get a feel for the UX
2. **This week**: Show the prototype to 3–5 potential customers (UK delivery operators); collect feedback
3. **Next 2 weeks**: Hire a full-stack dev (or use Claude Code) to wire up auth + Supabase + real geocoding using `backend/main.py` and `backend/schema.sql` as the foundation
4. **Month 2**: Build the driver PWA, deploy to Vercel + Render, run pilot with one paying customer
5. **Month 3**: Add Stripe billing, monitoring, launch publicly

Read `docs/ROADMAP.md` for the realistic week-by-week plan.

---

## 🤝 What this is — and isn't

**This IS**: a polished, working, demonstrable foundation. Investor-pitch ready. Customer-demo ready. Real algorithms running, real maps, real CSV processing. A genuine starting point you can build on.

**This ISN'T**: a deployed multi-tenant SaaS with auth, billing, real GPS tracking, and a mobile app. Building that takes a real team and real time. No AI chat can produce a finished product like that in one session — anyone claiming otherwise is selling shallow code that looks complete but breaks the moment you try to use it.

This package is honest about both halves. The frontend works beautifully. The backend is real and runnable. The schema is production-grade. The rest is laid out clearly in the roadmap so you (or a developer you hire) can finish it.

— Built with care.
