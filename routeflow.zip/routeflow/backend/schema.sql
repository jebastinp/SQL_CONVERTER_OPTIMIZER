-- RouteFlow AI — PostgreSQL schema
-- =================================
-- Production-ready schema for Supabase / vanilla Postgres 14+.
-- All tables include audit timestamps. UUID PKs. Strong FKs.
-- Run: psql -f schema.sql  (or paste into Supabase SQL editor)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";  -- optional, for geo queries

-- ---------- USERS / TENANCY ----------
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email           TEXT UNIQUE NOT NULL,
  full_name       TEXT NOT NULL,
  company_name    TEXT,
  role            TEXT NOT NULL DEFAULT 'operator', -- operator | admin | driver
  plan            TEXT NOT NULL DEFAULT 'starter',  -- starter | pro | enterprise
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- DRIVERS ----------
CREATE TABLE drivers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  phone           TEXT,
  email           TEXT,
  status          TEXT NOT NULL DEFAULT 'active',   -- active | offline | on_break
  shift_start     TIME NOT NULL DEFAULT '08:00',
  shift_end       TIME NOT NULL DEFAULT '17:00',
  avatar_color    TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX drivers_user_idx ON drivers(user_id);

-- ---------- VEHICLES ----------
CREATE TABLE vehicles (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  driver_id       UUID REFERENCES drivers(id) ON DELETE SET NULL,
  registration    TEXT NOT NULL,                    -- UK plate, e.g. LV23 KPM
  make_model      TEXT NOT NULL,
  capacity        INT NOT NULL DEFAULT 30,          -- max stops
  fuel_type       TEXT DEFAULT 'diesel',
  kml             NUMERIC(6,2) DEFAULT 9.0,         -- km per litre
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX vehicles_user_idx ON vehicles(user_id);

-- ---------- ORDERS ----------
CREATE TABLE orders (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  customer_name   TEXT NOT NULL,
  address         TEXT NOT NULL,
  postcode        TEXT NOT NULL,
  phone           TEXT,
  lat             NUMERIC(10,7),
  lng             NUMERIC(10,7),
  delivery_window TEXT DEFAULT 'Anytime',           -- Morning | Afternoon | Anytime
  priority        TEXT DEFAULT 'Med',               -- Low | Med | High
  notes           TEXT,
  status          TEXT NOT NULL DEFAULT 'pending',  -- pending | assigned | en_route | delivered | failed
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX orders_user_idx ON orders(user_id);
CREATE INDEX orders_status_idx ON orders(status);
CREATE INDEX orders_postcode_idx ON orders(postcode);

-- ---------- ROUTES (one per driver per dispatch) ----------
CREATE TABLE routes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  driver_id       UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
  vehicle_id      UUID REFERENCES vehicles(id) ON DELETE SET NULL,
  status          TEXT NOT NULL DEFAULT 'planned',  -- planned | in_progress | completed | cancelled
  depot_lat       NUMERIC(10,7) NOT NULL,
  depot_lng       NUMERIC(10,7) NOT NULL,
  distance_km     NUMERIC(8,2),
  duration_min    NUMERIC(8,1),
  fuel_saved_gbp  NUMERIC(8,2),
  baseline_km     NUMERIC(8,2),
  optimized_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  metadata        JSONB DEFAULT '{}'::jsonb,        -- algorithm, version, etc.
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX routes_user_idx ON routes(user_id);
CREATE INDEX routes_driver_idx ON routes(driver_id);

-- ---------- DELIVERY STOPS (ordered sequence of stops per route) ----------
CREATE TABLE delivery_stops (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  route_id        UUID NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
  order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  sequence        INT NOT NULL,                     -- 1, 2, 3, …
  eta_minutes     NUMERIC(8,1),
  eta_clock       TEXT,                             -- "09:42"
  arrived_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  status          TEXT NOT NULL DEFAULT 'pending',  -- pending | arrived | completed | skipped
  proof_url       TEXT,                             -- signed URL to PoD photo
  signature_url   TEXT,
  notes           TEXT,
  UNIQUE(route_id, sequence)
);
CREATE INDEX stops_route_idx ON delivery_stops(route_id);
CREATE INDEX stops_order_idx ON delivery_stops(order_id);

-- ---------- ANALYTICS (daily rollups for dashboard speed) ----------
CREATE TABLE analytics_daily (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date            DATE NOT NULL,
  total_deliveries     INT DEFAULT 0,
  completed_deliveries INT DEFAULT 0,
  failed_deliveries    INT DEFAULT 0,
  total_distance_km    NUMERIC(10,2) DEFAULT 0,
  total_duration_min   NUMERIC(10,1) DEFAULT 0,
  fuel_saved_gbp       NUMERIC(10,2) DEFAULT 0,
  on_time_rate         NUMERIC(5,2),               -- 0–100
  active_drivers       INT DEFAULT 0,
  UNIQUE(user_id, date)
);
CREATE INDEX analytics_user_date_idx ON analytics_daily(user_id, date DESC);

-- ---------- NOTIFICATIONS ----------
CREATE TABLE notifications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  driver_id       UUID REFERENCES drivers(id) ON DELETE CASCADE,
  type            TEXT NOT NULL,                    -- delay | reroute | completed | system | insight
  title           TEXT NOT NULL,
  body            TEXT,
  read            BOOLEAN DEFAULT false,
  metadata        JSONB DEFAULT '{}'::jsonb,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON notifications(user_id, read, created_at DESC);

-- ---------- AI INSIGHTS (recommendations surfaced in dashboard) ----------
CREATE TABLE ai_insights (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category        TEXT NOT NULL,                    -- fuel | overload | window | traffic | anomaly
  severity        TEXT NOT NULL DEFAULT 'info',     -- info | warn | critical
  title           TEXT NOT NULL,
  body            TEXT NOT NULL,
  acted_on        BOOLEAN DEFAULT false,
  expires_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX insights_user_idx ON ai_insights(user_id, created_at DESC);

-- ---------- TRIGGERS: auto-update updated_at ----------
CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_touch     BEFORE UPDATE ON users     FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER drivers_touch   BEFORE UPDATE ON drivers   FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER orders_touch    BEFORE UPDATE ON orders    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- ---------- ROW-LEVEL SECURITY (Supabase) ----------
-- Enable then add per-tenant policies after authentication is wired up:
-- ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
-- CREATE POLICY orders_own ON orders FOR ALL USING (user_id = auth.uid());
-- (repeat for drivers, vehicles, routes, delivery_stops, analytics_daily, notifications, ai_insights)
