"""
RouteFlow AI — FastAPI backend reference
=========================================
A production-shaped reference implementation of the optimization backend.
Drop this into a `backend/` folder, install requirements, and run:

    pip install -r requirements.txt
    uvicorn main:app --reload --port 8000

Hit:  POST http://localhost:8000/optimize  with JSON body matching the schema.

This is the SAME optimization algorithm the frontend prototype runs in-browser,
ported to Python + OR-Tools for production accuracy on larger fleets (5000+ stops).
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
from math import radians, cos, sin, asin, sqrt
import os

try:
    from ortools.constraint_solver import routing_enums_pb2, pywrapcp
    HAS_ORTOOLS = True
except ImportError:
    HAS_ORTOOLS = False

app = FastAPI(title="RouteFlow AI", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ----------------------------- SCHEMAS -----------------------------

class Location(BaseModel):
    lat: float
    lng: float


class Order(BaseModel):
    id: Optional[str] = None
    name: str
    address: str
    postcode: str
    lat: float
    lng: float
    phone: Optional[str] = ""
    window: Optional[str] = "Anytime"
    priority: Optional[str] = "Med"
    service_minutes: int = 4  # dwell time per stop


class Driver(BaseModel):
    id: str
    name: str
    vehicle: str
    capacity: int = 30
    shift_start: str = "08:00"
    shift_end: str = "17:00"


class OptimizeRequest(BaseModel):
    depot: Location
    orders: List[Order]
    drivers: List[Driver]
    avg_speed_kmh: float = Field(22.0, description="Urban average")
    fuel_cost_per_litre_gbp: float = 1.48
    vehicle_kml: float = 9.0  # km per litre


class Stop(BaseModel):
    order: Order
    sequence: int
    eta_minutes: float
    eta_clock: str


class Route(BaseModel):
    driver: Driver
    stops: List[Stop]
    distance_km: float
    duration_minutes: float


class OptimizeResponse(BaseModel):
    routes: List[Route]
    total_distance_km: float
    baseline_distance_km: float
    distance_saved_km: float
    fuel_saved_litres: float
    fuel_saved_gbp: float
    optimization_time_ms: float


# ----------------------------- MATH -----------------------------

def haversine_km(a: Location, b: Location) -> float:
    R = 6371.0
    lat1, lat2 = radians(a.lat), radians(b.lat)
    dlat = lat2 - lat1
    dlng = radians(b.lng - a.lng)
    h = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlng / 2) ** 2
    return 2 * R * asin(sqrt(h))


def build_distance_matrix(depot: Location, stops: List[Order]) -> List[List[int]]:
    """Returns matrix in METERS (OR-Tools wants ints)."""
    nodes = [depot] + [Location(lat=s.lat, lng=s.lng) for s in stops]
    n = len(nodes)
    matrix = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i != j:
                matrix[i][j] = int(haversine_km(nodes[i], nodes[j]) * 1000)
    return matrix


# ----------------------------- OPTIMIZER -----------------------------

def kmeans_cluster(orders: List[Order], k: int, iters: int = 40):
    """Lightweight in-memory k-means by lat/lng for driver assignment."""
    if k <= 1 or len(orders) <= k:
        return {i: [i] if i < len(orders) else [] for i in range(k)}, [0] * len(orders)

    centroids = [(orders[0].lat, orders[0].lng)]
    for _ in range(1, k):
        best, best_d = None, -1
        for o in orders:
            d_min = min(((o.lat - c[0]) ** 2 + (o.lng - c[1]) ** 2) for c in centroids)
            if d_min > best_d:
                best_d = d_min
                best = (o.lat, o.lng)
        centroids.append(best)

    assigned = [0] * len(orders)
    for _ in range(iters):
        changed = False
        for i, o in enumerate(orders):
            best_k, best_d = 0, float("inf")
            for j, c in enumerate(centroids):
                d = (o.lat - c[0]) ** 2 + (o.lng - c[1]) ** 2
                if d < best_d:
                    best_d, best_k = d, j
            if assigned[i] != best_k:
                assigned[i] = best_k
                changed = True
        if not changed:
            break
        for j in range(k):
            members = [o for i, o in enumerate(orders) if assigned[i] == j]
            if members:
                centroids[j] = (
                    sum(m.lat for m in members) / len(members),
                    sum(m.lng for m in members) / len(members),
                )

    clusters = {j: [i for i, a in enumerate(assigned) if a == j] for j in range(k)}
    return clusters, assigned


def solve_tsp_ortools(matrix: List[List[int]], time_limit_sec: int = 5) -> List[int]:
    """Solve TSP for one driver's stops using OR-Tools."""
    n = len(matrix)
    if n <= 2:
        return list(range(n))

    manager = pywrapcp.RoutingIndexManager(n, 1, 0)  # 1 vehicle, depot=0
    routing = pywrapcp.RoutingModel(manager)

    def distance_callback(from_index, to_index):
        return matrix[manager.IndexToNode(from_index)][manager.IndexToNode(to_index)]

    transit_idx = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_idx)

    params = pywrapcp.DefaultRoutingSearchParameters()
    params.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    params.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    params.time_limit.seconds = time_limit_sec

    solution = routing.SolveWithParameters(params)
    if not solution:
        return list(range(n))

    index = routing.Start(0)
    route = []
    while not routing.IsEnd(index):
        route.append(manager.IndexToNode(index))
        index = solution.Value(routing.NextVar(index))
    return route


def nearest_neighbor_fallback(depot: Location, stops: List[Order]) -> List[int]:
    """Used when OR-Tools is not installed."""
    remaining = list(range(len(stops)))
    current = depot
    order = []
    while remaining:
        best_i, best_d = remaining[0], float("inf")
        for i in remaining:
            d = haversine_km(current, Location(lat=stops[i].lat, lng=stops[i].lng))
            if d < best_d:
                best_d, best_i = d, i
        order.append(best_i)
        current = Location(lat=stops[best_i].lat, lng=stops[best_i].lng)
        remaining.remove(best_i)
    return order


# ----------------------------- ENDPOINT -----------------------------

@app.get("/")
def root():
    return {
        "service": "RouteFlow AI",
        "version": "1.0.0",
        "ortools_available": HAS_ORTOOLS,
        "endpoints": ["/optimize", "/health"],
    }


@app.get("/health")
def health():
    return {"status": "ok", "ortools": HAS_ORTOOLS}


@app.post("/optimize", response_model=OptimizeResponse)
def optimize(req: OptimizeRequest):
    import time
    t0 = time.time()

    if not req.orders:
        raise HTTPException(400, "No orders provided")
    if not req.drivers:
        raise HTTPException(400, "No drivers provided")

    # cluster by k=min(drivers, ceil(orders/8))
    k = min(len(req.drivers), max(1, (len(req.orders) + 7) // 8))
    clusters, _ = kmeans_cluster(req.orders, k)

    routes: List[Route] = []
    total_dist = 0.0

    for cluster_idx in range(k):
        member_idxs = clusters.get(cluster_idx, [])
        if not member_idxs:
            continue
        driver = req.drivers[cluster_idx]
        driver_orders = [req.orders[i] for i in member_idxs]

        if HAS_ORTOOLS:
            matrix = build_distance_matrix(req.depot, driver_orders)
            tsp = solve_tsp_ortools(matrix)
            # tsp returns indices into [depot, *orders] — strip depot, return to it
            sequence = [i - 1 for i in tsp[1:] if i > 0]
        else:
            sequence = nearest_neighbor_fallback(req.depot, driver_orders)

        # build stops with ETA
        stops: List[Stop] = []
        cum_km = 0.0
        prev = req.depot
        start_h, start_m = map(int, driver.shift_start.split(":"))
        start_min = start_h * 60 + start_m

        for seq_i, order_i in enumerate(sequence):
            order = driver_orders[order_i]
            cum_km += haversine_km(prev, Location(lat=order.lat, lng=order.lng))
            drive_min = cum_km / req.avg_speed_kmh * 60
            cum_dwell = (seq_i + 1) * order.service_minutes
            eta_min = drive_min + cum_dwell
            clock_min = start_min + int(eta_min)
            h, m = clock_min // 60, clock_min % 60
            stops.append(Stop(
                order=order, sequence=seq_i + 1, eta_minutes=round(eta_min, 1),
                eta_clock=f"{h:02d}:{m:02d}"
            ))
            prev = Location(lat=order.lat, lng=order.lng)

        # close the loop
        cum_km += haversine_km(prev, req.depot)
        duration = cum_km / req.avg_speed_kmh * 60 + len(stops) * 4
        total_dist += cum_km

        routes.append(Route(
            driver=driver, stops=stops,
            distance_km=round(cum_km, 2),
            duration_minutes=round(duration, 1),
        ))

    # baseline = raw order traversed in input sequence
    baseline = 0.0
    prev = req.depot
    for o in req.orders:
        baseline += haversine_km(prev, Location(lat=o.lat, lng=o.lng))
        prev = Location(lat=o.lat, lng=o.lng)
    baseline += haversine_km(prev, req.depot)

    saved_km = max(0.0, baseline - total_dist)
    fuel_l = saved_km / req.vehicle_kml
    fuel_gbp = fuel_l * req.fuel_cost_per_litre_gbp
    elapsed_ms = (time.time() - t0) * 1000

    return OptimizeResponse(
        routes=routes,
        total_distance_km=round(total_dist, 2),
        baseline_distance_km=round(baseline, 2),
        distance_saved_km=round(saved_km, 2),
        fuel_saved_litres=round(fuel_l, 2),
        fuel_saved_gbp=round(fuel_gbp, 2),
        optimization_time_ms=round(elapsed_ms, 1),
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
