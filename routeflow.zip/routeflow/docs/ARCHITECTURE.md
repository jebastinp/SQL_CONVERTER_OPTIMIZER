# RouteFlow AI — Architecture

System design notes for the production version. The prototype in this package implements the entire frontend stack and a working reference of the optimizer; this document explains how everything fits together at scale.

---

## System diagram

```
                      ┌──────────────────────────┐
                      │   Marketing site         │
                      │   (Next.js · Vercel)     │
                      │   routeflow.ai           │
                      └────────────┬─────────────┘
                                   │
                                   ▼
                      ┌──────────────────────────┐
                      │   SaaS App (Next.js)     │
                      │   app.routeflow.ai       │◄────────┐
                      │   - Dispatcher UI        │         │
                      │   - Driver PWA           │         │
                      └────────────┬─────────────┘         │
                                   │ REST + WebSocket      │ Realtime
                                   ▼                       │ (Supabase channels)
              ┌────────────────────┴───────────────────┐   │
              │                                        │   │
   ┌──────────▼─────────────┐          ┌──────────────▼───┴─────────┐
   │  Supabase              │          │  Optimizer Service          │
   │  - Postgres            │          │  (FastAPI · Render)         │
   │  - Auth                │          │  - Google OR-Tools          │
   │  - Storage (PoD photos)│          │  - VRP / TSP / 2-opt        │
   │  - Realtime channels   │          │  - K-means clustering       │
   │  - Edge Functions      │          └──────────────┬──────────────┘
   └────────────────────────┘                         │
                                                       │ HTTP
                                                       ▼
                                      ┌─────────────────────────────┐
                                      │  OpenRouteService           │
                                      │  - Geocoding (UK postcodes) │
                                      │  - Road-distance matrix     │
                                      │  - Traffic-aware ETAs       │
                                      └─────────────────────────────┘

   ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐
   │  Stripe (billing)│   │  Sentry (errors) │   │  Resend (email)  │
   └──────────────────┘   └──────────────────┘   └──────────────────┘
```

---

## Frontend (Next.js)

Single Next.js 14 app with App Router serving three audiences from one codebase:

- `/` — Marketing site (the landing page in this package, ported to React)
- `/app/*` — Dispatcher SaaS (the prototype in this package, ported to React + Tailwind)
- `/driver/*` — Mobile-first driver PWA (built fresh)

**Why one codebase?** Shared auth, shared design system, shared types between dispatcher and driver flows (the dispatcher creates a route → driver immediately sees it).

**Key libraries:**

- `next` 14+ (App Router)
- `tailwindcss` + custom design tokens matching the prototype's CSS variables
- `framer-motion` for the choreographed animations the prototype uses CSS keyframes for
- `react-leaflet` (or `mapbox-gl` for the production map)
- `chart.js` (or `recharts`) for analytics
- `zustand` for client state, `@tanstack/react-query` for server state
- `zod` for runtime validation matching FastAPI's Pydantic models
- `@supabase/supabase-js` for auth, queries, realtime
- `papaparse` for CSV import

**State management pattern:**

The prototype uses a single global `state` object. In production, split into:

- **Server state** (orders, routes, drivers, vehicles) → React Query, cached, optimistic updates, mutations sync to Supabase
- **UI state** (selected driver, map zoom, modal open) → Zustand
- **Auth state** → Supabase auth helper

---

## Backend (FastAPI optimizer service)

A small, stateless Python service that does one thing well: optimize routes. The prototype's `backend/main.py` is the starting point.

**Why a separate service?** The Next.js app handles auth, CRUD, real-time, and UI. The optimizer is CPU-heavy Python with C++ underneath (OR-Tools). Keeping them separate lets the optimizer scale independently and lets the Next.js app stay on Vercel's edge runtime where Python isn't allowed.

**Endpoints:**

```
POST  /optimize              Run VRP on a set of orders + drivers
POST  /optimize/async        Same but returns a job ID for large fleets (>500 stops)
GET   /optimize/jobs/{id}    Poll for async results
POST  /distance-matrix       Get road distances for a list of points (cached)
POST  /geocode               Proxy to OpenRouteService with caching
GET   /health                Liveness probe
GET   /metrics               Prometheus metrics
```

**Optimization algorithm:**

1. **Cluster** orders into K groups (one per available driver) using k-means on lat/lng. Capacity-aware in v1.1: respect each driver's max stops.
2. **Solve TSP per cluster** using OR-Tools' `PATH_CHEAPEST_ARC` + `GUIDED_LOCAL_SEARCH` local-search metaheuristic. Time-limit 5s for <500 stops, 30s for larger fleets.
3. **Time-window constraints** (v1.2): respect Morning/Afternoon delivery windows by partitioning before clustering.
4. **Output**: ordered list of stops per driver, with ETAs computed from cumulative road distance ÷ avg speed + per-stop dwell time.

For fleets above ~500 stops, the algorithm degrades gracefully:

- 1–500 stops: solve in real-time, return inline
- 500–5,000 stops: async job, return job ID, poll for results (typically 10–30 sec)
- 5,000+ stops: split into geographic super-clusters first, solve each in parallel workers

---

## Database (Postgres on Supabase)

Schema is in `backend/schema.sql`. Nine tables, all UUID-keyed, all with proper foreign keys and indexes.

**Tenancy model:** Every business-data row has a `user_id` foreign key. Row-Level Security policies restrict reads/writes to `user_id = auth.uid()`. This gives each customer their own logical database with zero application-layer enforcement.

**Hot paths:**

- Dashboard load: `analytics_daily` rollup table (1 row/day/user) keeps the dashboard fast even after years of data. A daily Edge Function rolls up `delivery_stops` into `analytics_daily`.
- Live map: query `routes WHERE status='in_progress'` + subscribe to `driver_positions` realtime channel.
- Order import: bulk insert into `orders` via `COPY` for files >1,000 rows.

**Storage:** Supabase Storage holds proof-of-delivery photos and signature images. Pre-signed URLs (15-min expiry) protect privacy.

---

## Geocoding pipeline

UK addresses are deceptive: postcodes look standardized but rural addresses can resolve 100m+ off. Pipeline:

1. **Normalize** input (uppercase postcode, trim whitespace, validate against UK postcode regex).
2. **Cache check** in `geocode_cache` table (key = normalized address+postcode). Cache hit rate after 30 days of operation: ~80%.
3. **Cache miss** → call OpenRouteService geocoding API. Store result with confidence score.
4. **Low confidence** (<0.7) → flag for manual review in the dispatcher UI.
5. **Optional upgrade path** for enterprise: layer Royal Mail PAF (Postcode Address File) on top for guaranteed accuracy. ~£600/year licence.

---

## Real-time tracking

Two channels via Supabase Realtime (Postgres-backed pub/sub):

- `driver_positions:{user_id}` — driver PWA inserts every 30 seconds; dispatcher map subscribes
- `route_updates:{route_id}` — any change to a stop's status fires an event; both dispatcher and customer tracking link subscribe

**Geofencing:** Driver PWA checks distance to next stop every 10 sec when within 200m. When within 50m, auto-fires `arrived` event. Server confirms and updates `delivery_stops.arrived_at`.

**Battery considerations:** GPS every 30s drains phones. Adaptive: 10s when driving (high speed detected), 60s when stationary >5 min.

---

## Deployment

| Component | Provider | Cost (start) |
|---|---|---|
| Marketing site + SaaS app | Vercel | $0 → $20/mo (Pro plan above 100GB bandwidth) |
| FastAPI optimizer | Render (Standard, 2GB RAM) | $25/mo |
| Postgres + Auth + Storage + Realtime | Supabase | $0 → $25/mo (Pro plan above 500MB DB) |
| Geocoding | OpenRouteService | $0 (2k req/day free) → contact for more |
| Email | Resend | $0 (3k/mo free) → $20/mo |
| Monitoring | Sentry (free tier) + Posthog (free tier) | $0 |
| Domain + DNS | Cloudflare | $10/yr domain, DNS free |

**Total to launch: ~$50/month.** Scales linearly with customers.

CI/CD: GitHub → Vercel preview deploys per PR → main branch auto-deploys to production. FastAPI service auto-deploys via Render's Git integration.

---

## Security checklist for production

- [ ] All API routes behind Supabase Auth middleware
- [ ] Row-Level Security enabled on every table holding user data
- [ ] Stripe webhook signatures verified
- [ ] CSRF tokens on state-changing requests
- [ ] Rate limiting on `/optimize` and `/geocode` (Upstash Redis)
- [ ] CORS locked to `app.routeflow.ai` only
- [ ] Secrets in environment variables, never in code
- [ ] Driver PoD photos in private Supabase bucket, signed URLs only
- [ ] GDPR data export endpoint (`GET /me/export` → JSON dump of user's data)
- [ ] GDPR data deletion endpoint (`DELETE /me` → cascade-deletes all user data)
- [ ] Audit log for sensitive actions (route override, driver removal, plan change)

---

## Why this design

A few non-obvious choices worth flagging:

**Supabase over Firebase.** Postgres beats Firestore for relational data like routes/stops/drivers. RLS gives multi-tenancy free. Realtime is enough for the live-tracking use case without standing up a separate socket server.

**FastAPI separate from Next.js.** Tempting to put the optimizer in a Vercel Edge Function. Don't. OR-Tools is C++, won't run there, and you need persistent process state for large async jobs.

**Leaflet first, Mapbox later.** Leaflet + OSM is free and good enough for v1. Switch to Mapbox when you need traffic-aware ETAs or vector tile performance with >100 markers on screen.

**Single Next.js codebase for dispatcher + driver.** A separate React Native driver app sounds clean but doubles your maintenance. A PWA is good enough until you have 1,000+ drivers complaining.

**OR-Tools over commercial solvers.** Free, well-documented, used by Google internally. Commercial solvers (Gurobi, CPLEX) are 10–20% faster on huge problems but cost £20k+/year. Not worth it until you're solving for 10k+ stops nightly.

---

## Open questions to resolve before launch

These are decisions to make with your first customers, not solo at a desk:

1. **Pricing model.** Per-driver seat? Per delivery? Per route optimized? The prototype assumes flat tiers (£89/mo); test with real customers.
2. **Multi-depot support.** Many UK delivery operators have 2–5 regional warehouses. Does v1 support this, or push to v1.5?
3. **Driver self-onboarding.** Does the operator invite the driver (current schema assumption), or does the driver sign up themselves and request to join an org?
4. **Customer-facing tracking link.** SMS or just URL? Branded?
5. **Failed deliveries.** What happens when a customer isn't home? Auto-reschedule? Leave at neighbour? Photo of door?

Document the decisions, ship them in v1, iterate.

---

*This document is a starting blueprint. It will be wrong in interesting ways once you have real customers. That's the point — ship, learn, refine.*
