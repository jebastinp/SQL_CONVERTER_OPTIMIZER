# RouteFlow AI — Production Roadmap

A realistic, week-by-week plan to go from the prototype in this package to a deployed, multi-tenant, paid SaaS. Estimated total: **6–10 weeks** with one focused full-stack engineer (or a small team moving in parallel).

This plan assumes you keep the prototype's UI, optimizer math, and database schema — and add the infrastructure, integrations, and polish needed to ship.

---

## Week 1 — Foundation & auth

**Goal:** Get a Next.js app deployed with real user accounts and the database wired up.

- Day 1–2: Scaffold Next.js 14 (App Router) project. Port the prototype's UI from single-file HTML into React components: sidebar, topbar, dashboard cards, map view, import view, drivers view. Use Tailwind + the existing CSS variables.
- Day 3: Set up Supabase project (managed Postgres + auth + storage). Run `backend/schema.sql`. Enable Row-Level Security policies per the commented templates.
- Day 4: Wire up Supabase Auth (email magic link + Google OAuth). Build sign-up / sign-in / onboarding flow.
- Day 5: Build user settings page (profile, company, plan). Deploy to Vercel with environment variables. Confirm signup → dashboard works end-to-end.

**Deliverable:** A real user can sign up at a real URL and see an empty dashboard.

---

## Week 2 — Orders & drivers CRUD

**Goal:** Real persistence for orders and drivers.

- Day 1: Build the Orders API (Next.js route handlers or tRPC). Endpoints: list, create, bulk-import-CSV, update, delete.
- Day 2: Wire the Import view to upload CSVs to Supabase. Validate columns, show errors inline, persist to `orders` table.
- Day 3: Build the Drivers CRUD UI (create driver, assign vehicle, set shift hours, color/avatar).
- Day 4: Build the Vehicles CRUD UI. Link vehicles to drivers.
- Day 5: Replace prototype's hardcoded demo data with real Supabase queries. Add empty states, loading skeletons.

**Deliverable:** A user can sign up, add drivers/vehicles, upload a CSV of orders, and see them all listed.

---

## Week 3 — Real geocoding & FastAPI backend

**Goal:** Real UK addresses → real lat/lng. Real optimization service.

- Day 1: Sign up for OpenRouteService (free tier: 2,000 requests/day). Build a geocoding service that takes UK postcode + address, returns lat/lng. Cache results in a `geocode_cache` table to avoid repeated lookups.
- Day 2: Replace prototype's stub geocoding with the real service. Handle rate limits, retries, partial matches. Validate against UK postcode regex.
- Day 3: Deploy the FastAPI backend (`backend/main.py`) to Render or Fly.io. Add a real `/optimize` integration test that runs OR-Tools against 100 orders.
- Day 4: Wire the Next.js app to call the FastAPI backend for optimization. Persist results to `routes` and `delivery_stops` tables.
- Day 5: Add real fuel/distance calculations using actual road distances (OpenRouteService Matrix API) instead of haversine. Compare savings vs baseline.

**Deliverable:** A user can upload real UK addresses, hit Optimize, and see real routes drawn on a real map with real distances.

---

## Week 4 — Driver mobile PWA

**Goal:** Drivers can see their day, complete stops, and capture proof of delivery.

- Day 1–2: Build a separate `/driver` route in the Next.js app, mobile-first. Bottom-nav design. List today's stops with sequence, address, ETA, customer name, phone.
- Day 3: Build the stop detail screen: tap-to-call, tap-to-navigate (deep-link to Apple/Google Maps), notes field, photo capture for proof of delivery (upload to Supabase Storage).
- Day 4: Add status transitions (arrived → completed → next stop). Update `delivery_stops.status` and `arrived_at`/`completed_at`. Real-time UI updates.
- Day 5: Configure as installable PWA (manifest, service worker, offline cache for stop list). Test on iOS and Android.

**Deliverable:** A driver can install the app on their phone, log in, see their route, and complete deliveries with photo evidence.

---

## Week 5 — Live tracking & WebSockets

**Goal:** Dispatchers see drivers move in real-time.

- Day 1: Add a `driver_positions` table. Driver PWA pushes GPS every 30 seconds via Supabase Realtime (or socket.io).
- Day 2: Wire the dispatcher's map view to subscribe to position updates. Replace the prototype's simulation with real driver movement.
- Day 3: Add ETA recalculation based on current position. Detect delays (driver behind schedule by >10 minutes) and create notifications.
- Day 4: Build the customer-facing tracking link (no login required): "Your delivery is 3 stops away, ETA 14:25." Share via SMS/email when route starts.
- Day 5: Add geofencing — auto-detect "arrived at stop" when driver enters 50m radius.

**Deliverable:** Dispatchers watch drivers in real-time. Customers get tracking links. ETAs update automatically.

---

## Week 6 — Billing & plans

**Goal:** Charge customers.

- Day 1: Set up Stripe account. Create Products + Prices for Starter (£0), Pro (£89/mo), Enterprise (custom).
- Day 2: Build Stripe Checkout flow. Wire up Customer Portal for plan changes, payment methods, invoices.
- Day 3: Add Stripe webhooks → update `users.plan` field. Enforce plan limits (Starter = 100 deliveries/month, 2 drivers; Pro = 10k deliveries, 20 drivers).
- Day 4: Build the plan-limits guard middleware. Show upgrade prompts when limits are hit.
- Day 5: Build the admin billing dashboard for the operator: usage this month, plan, next invoice, upgrade/downgrade.

**Deliverable:** A user can pay £89/mo and unlock Pro features.

---

## Week 7 — AI insights (real, not faked)

**Goal:** The "AI Insights" panel surfaces genuinely useful recommendations.

- Day 1: Build the insights engine as a daily cron job (Vercel Cron or Supabase Edge Functions). Analyze last 30 days of routes per user.
- Day 2: Rule-based insights (no LLM needed for most): driver overload detection, fuel anomalies, recurring late stops, postcode clusters that need a second depot.
- Day 3: For natural-language explanations, integrate Claude API (`claude-opus-4-7`). Prompt: "Given this route data, write a 2-sentence actionable insight." Use it sparingly to control cost.
- Day 4: Build the `/insights` API and surface results in the Dashboard. Add "Apply suggestion" actions where automatic (e.g., reassign 3 stops from overloaded driver).
- Day 5: Add demand forecasting (simple: same day-of-week last 4 weeks averaged). Show forecasted deliveries in the dashboard.

**Deliverable:** Every morning, dispatchers see 3–5 specific, actionable recommendations.

---

## Week 8 — Analytics, polish, launch

**Goal:** Ship publicly.

- Day 1: Build the Analytics page properly. Charts for deliveries/day, fuel saved, on-time rate, by driver, by region. Use the `analytics_daily` rollup table.
- Day 2: Add notifications system (in-app, email digest, optional SMS via Twilio for critical alerts).
- Day 3: Set up monitoring: Sentry for errors, Posthog for product analytics, Better Stack for uptime.
- Day 4: Write docs site (docs.routeflow.ai): getting started, CSV format, API reference, integrations.
- Day 5: Soft-launch to 10 UK delivery businesses. Collect feedback. Fix top 3 issues.

**Deliverable:** A real SaaS with paying customers.

---

## Weeks 9–10 — Integrations & growth

If you hit weeks 1–8 and have 5+ paying customers, the next priorities:

- **Shopify integration** — auto-import orders when they're placed
- **WooCommerce, Square, Stripe** order imports
- **Royal Mail / DPD / Hermes** label printing
- **Xero / QuickBooks** invoice export
- **Slack / Microsoft Teams** notifications
- **Public API** with OpenAPI spec + API keys, for enterprise customers
- **Multi-depot support** for operators with regional warehouses
- **EV-aware routing** (range anxiety, charging stops) for electric fleets

---

## Team composition (suggested)

For 8-week timeline:

- **1 full-stack engineer** (Next.js + Python) — primary builder
- **1 part-time designer** — refines UI, drafts driver app screens, builds docs site
- **You (founder/operator)** — sales, customer interviews, content

For 6-week timeline, double the engineering team.

For 10-week timeline (solo founder using AI tools heavily), feasible with Claude Code or similar to accelerate the boilerplate.

---

## Tech stack summary

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js 14 + Tailwind + Framer Motion | Vercel-native, fast, beautiful |
| Maps | Leaflet (free) → Mapbox (production) | Leaflet to start, Mapbox for vector tiles & traffic |
| State | Zustand or React Query | Lightweight, no Redux ceremony |
| Backend | FastAPI (Python) | OR-Tools needs Python; FastAPI is the cleanest fit |
| Database | Supabase (Postgres + Auth + Storage + Realtime) | Auth, RLS, real-time, file storage in one |
| Optimization | Google OR-Tools | Industry standard for VRP/TSP |
| Geocoding | OpenRouteService | Free tier, good UK coverage |
| Billing | Stripe | Default choice |
| Hosting | Vercel (frontend) + Render (backend) | Both have generous free tiers |
| Monitoring | Sentry + Posthog + Better Stack | Errors, analytics, uptime |
| Email | Resend or Postmark | Modern, reliable |
| SMS | Twilio | UK delivery |

---

## What you can charge

Based on the spec and UK market for similar tools (Onfleet, Routific, OptimoRoute):

- **Starter (£0)**: Lead magnet. 100 deliveries/mo, 2 drivers, basic features. Converts to Pro.
- **Pro (£89/mo)**: The volume play. Target: 200 customers at £89 = **£17,800 MRR**.
- **Enterprise (custom)**: White-glove. £500–£5,000/mo per logo depending on fleet size.

A realistic year-1 outcome with this product, focused sales, and decent positioning: **£25k–£60k MRR** by month 12. Lean operation, profitable from month 6 with no outside funding.

---

## Risks & honest caveats

- **Geocoding accuracy is the #1 risk.** UK postcodes look uniform but rural addresses can be 100m+ off. Budget time to ground-truth your geocoding with real customers.
- **Drivers hate new apps.** The driver PWA needs to be radically simpler than the dispatcher UI. Aim for <3 taps to "completed."
- **The optimizer is necessary but not sufficient.** Customers will love it for week 1, then expect *everything else* (integrations, reports, mobile, support). Plan for that.
- **The market is competitive.** Onfleet, Routific, Circuit, and others exist. Differentiate on UK-specific (postcodes, addresses, fuel prices, regulations) and on UX polish (this prototype's biggest edge).

Good luck. The bones are good. Now go build it.
