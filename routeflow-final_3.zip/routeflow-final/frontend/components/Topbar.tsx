import { ReactNode } from 'react';
import ThemeToggle from './ThemeToggle';

export default function Topbar({ title, subtitle, actions }: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <header
      className="flex items-start gap-4 px-8 py-6"
      style={{ borderBottom: '1px solid var(--stroke)' }}
    >
      <div className="flex-1 min-w-0">
        <div className="serif text-[28px] leading-none tracking-tight" style={{ color: 'var(--ink)' }}>
          {title}
        </div>
        {subtitle && (
          <div className="text-[12.5px] mt-2" style={{ color: 'var(--ink-3)' }}>
            {subtitle}
          </div>
        )}
      </div>
      <div className="flex items-center gap-2 mt-1">
        {actions}
        <ThemeToggle />
      </div>
    </header>
  );
}
