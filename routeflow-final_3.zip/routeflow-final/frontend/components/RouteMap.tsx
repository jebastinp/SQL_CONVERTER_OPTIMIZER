import { useEffect, useRef, useState } from 'react';
import type { OptimizeResponse, Profile } from '@/lib/types';

type Props = {
  optimization: OptimizeResponse | null;
  profile: Profile | null;
  driverPositions?: Record<string, { lat: number; lng: number }>;
};

// CARTO Voyager — fast, beautiful, free, uses global CDN
// Falls back to OSM if CARTO is unreachable
const TILE_PROVIDERS = {
  light: {
    primary: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    fallback: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    subdomains: 'abcd',
    attribution: '© OpenStreetMap, © CARTO',
  },
  dark: {
    primary: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    fallback: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    subdomains: 'abcd',
    attribution: '© OpenStreetMap, © CARTO',
  },
};

export default function RouteMap({ optimization, profile, driverPositions }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<any>(null);
  const layersRef = useRef<any[]>([]);
  const tileLayerRef = useRef<any>(null);
  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState(false);

  // ─── Initialize map ───
  useEffect(() => {
    if (typeof window === 'undefined' || !mapRef.current || mapObj.current) return;
    let cancelled = false;
    let initTimeout: any;

    (async () => {
      try {
        const L = (await import('leaflet')).default;
        if (cancelled || !mapRef.current) return;

        const isDark = document.documentElement.classList.contains('dark');
        const provider = isDark ? TILE_PROVIDERS.dark : TILE_PROVIDERS.light;

        const map = L.map(mapRef.current, {
          zoomControl: false,
          preferCanvas: true, // faster rendering for many markers
          attributionControl: true,
          fadeAnimation: false, // less flicker
        }).setView(
          [Number(profile?.depot_lat) || 51.5095, Number(profile?.depot_lng) || -0.1245],
          12,
        );

        // Add primary tile layer with fallback handling
        const tileLayer = L.tileLayer(provider.primary, {
          maxZoom: 19,
          subdomains: provider.subdomains as any,
          attribution: provider.attribution,
          // Critical perf options:
          updateWhenIdle: false,       // load tiles while panning (smoother)
          updateWhenZooming: false,    // don't reload during zoom animation
          keepBuffer: 4,               // cache more off-screen tiles
          crossOrigin: true,
        });

        // Track tile errors — if too many fail, switch to fallback
        let errorCount = 0;
        tileLayer.on('tileerror', () => {
          errorCount++;
          if (errorCount > 3 && tileLayer.options.errorTileUrl !== provider.fallback) {
            console.warn('[map] CARTO tiles failing, switching to OSM fallback');
            tileLayer.setUrl(provider.fallback);
          }
        });

        tileLayer.addTo(map);
        tileLayerRef.current = tileLayer;

        L.control.zoom({ position: 'bottomright' }).addTo(map);

        mapObj.current = map;
        setReady(true);
      } catch (err) {
        console.error('[map] init failed:', err);
        setLoadError(true);
      }
    })();

    // Hard timeout — if map doesn't render in 8s, show error
    initTimeout = setTimeout(() => {
      if (!mapObj.current && !cancelled) {
        setLoadError(true);
      }
    }, 8000);

    return () => {
      cancelled = true;
      clearTimeout(initTimeout);
      if (mapObj.current) { mapObj.current.remove(); mapObj.current = null; }
    };
  }, []);

  // ─── React to theme changes (swap tile layer) ───
  useEffect(() => {
    if (!ready) return;
    const observer = new MutationObserver(() => {
      const isDark = document.documentElement.classList.contains('dark');
      const provider = isDark ? TILE_PROVIDERS.dark : TILE_PROVIDERS.light;
      if (tileLayerRef.current && mapObj.current) {
        tileLayerRef.current.setUrl(provider.primary);
      }
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, [ready]);

  // ─── Render markers/routes ───
  useEffect(() => {
    if (!ready || !mapObj.current) return;
    (async () => {
      const L = (await import('leaflet')).default;
      const map = mapObj.current;

      layersRef.current.forEach((l) => map.removeLayer(l));
      layersRef.current = [];

      const depotLat = Number(profile?.depot_lat) || 51.5095;
      const depotLng = Number(profile?.depot_lng) || -0.1245;

      const depotIcon = L.divIcon({
        className: '',
        html: '<div class="depot-marker">D</div>',
        iconSize: [30, 30],
        iconAnchor: [15, 15],
      });
      const depotMarker = L.marker([depotLat, depotLng], { icon: depotIcon })
        .addTo(map)
        .bindPopup(`<b>${profile?.depot_address || 'Depot'}</b>`);
      layersRef.current.push(depotMarker);

      if (!optimization || optimization.routes.length === 0) {
        map.setView([depotLat, depotLng], 12);
        return;
      }

      const allPoints: [number, number][] = [[depotLat, depotLng]];

      optimization.routes.forEach((route) => {
        const coords: [number, number][] = [
          [depotLat, depotLng],
          ...route.stops.map((s) => [s.lat, s.lng] as [number, number]),
          [depotLat, depotLng],
        ];
        const polyline = L.polyline(coords, {
          color: route.driver_color,
          weight: 3.5,
          opacity: 0.85,
          smoothFactor: 1.5, // optimize rendering
        }).addTo(map);
        layersRef.current.push(polyline);

        route.stops.forEach((stop, sidx) => {
          allPoints.push([stop.lat, stop.lng]);
          const icon = L.divIcon({
            className: '',
            html: `<div class="stop-marker" style="background:${route.driver_color}">${sidx + 1}</div>`,
            iconSize: [28, 28],
            iconAnchor: [14, 14],
          });
          const m = L.marker([stop.lat, stop.lng], { icon })
            .addTo(map)
            .bindPopup(`<b>${stop.customer_name}</b><br>${stop.address}<br><br>ETA: <b>${stop.eta_clock}</b><br>Driver: ${route.driver_name}`);
          layersRef.current.push(m);
        });
      });

      if (driverPositions) {
        for (const [driverId, pos] of Object.entries(driverPositions)) {
          const route = optimization.routes.find((r) => r.driver_id === driverId);
          const color = route?.driver_color || '#2C7A4E';
          const icon = L.divIcon({
            className: '',
            html: `<div class="driver-marker" style="border:3px solid ${color}"></div>`,
            iconSize: [22, 22],
            iconAnchor: [11, 11],
          });
          const m = L.marker([pos.lat, pos.lng], { icon }).addTo(map);
          layersRef.current.push(m);
        }
      }

      if (allPoints.length > 1) {
        const bounds = L.latLngBounds(allPoints);
        map.fitBounds(bounds, { padding: [60, 60], animate: false });
      }
    })();
  }, [ready, optimization, profile, driverPositions]);

  // ─── Render ───
  return (
    <div className="relative w-full h-full">
      {/* Skeleton while loading */}
      {!ready && !loadError && (
        <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none"
             style={{ background: 'var(--bg-soft)' }}>
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full border-2 border-current border-r-transparent animate-spin"
                 style={{ color: 'var(--accent)' }} />
            <div className="text-[12.5px]" style={{ color: 'var(--ink-3)' }}>
              Loading map…
            </div>
          </div>
        </div>
      )}

      {/* Error fallback */}
      {loadError && (
        <div className="absolute inset-0 flex items-center justify-center z-10"
             style={{ background: 'var(--bg-soft)' }}>
          <div className="text-center max-w-sm px-6">
            <div className="text-[40px] mb-3 opacity-40">🗺️</div>
            <div className="text-[14px] mb-2" style={{ color: 'var(--ink-2)' }}>Map couldn't load</div>
            <div className="text-[12px] mb-4" style={{ color: 'var(--ink-3)' }}>
              Tile servers may be blocked by your network or firewall. Your route data is still saved.
            </div>
            <button onClick={() => { setLoadError(false); window.location.reload(); }} className="btn btn-ghost text-[12px]">
              Retry
            </button>
          </div>
        </div>
      )}

      <div ref={mapRef} className="w-full h-full" />
    </div>
  );
}
