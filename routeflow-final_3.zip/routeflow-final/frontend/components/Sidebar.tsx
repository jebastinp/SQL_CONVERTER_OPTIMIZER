import Link from 'next/link';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';
import { LayoutGrid, Route, Upload, Users, BarChart3, LogOut, Settings } from 'lucide-react';

const navItems = [
  { href: '/dashboard', label: 'Overview', icon: LayoutGrid },
  { href: '/orders', label: 'Orders', icon: Upload },
  { href: '/drivers', label: 'Drivers', icon: Users },
  { href: '/routes', label: 'Routes', icon: Route },
  { href: '/analytics', label: 'Analytics', icon: BarChart3 },
];

export default function Sidebar({ profile }: { profile: { full_name?: string; email: string; company_name?: string } | null }) {
  const router = useRouter();

  async function signOut() {
    await supabase().auth.signOut();
    router.push('/login');
  }

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase()
    : profile?.email?.slice(0, 2).toUpperCase() || '??';

  return (
    <aside
      className="w-[232px] shrink-0 flex flex-col h-screen sticky top-0"
      style={{ background: 'var(--bg-sidebar)', borderRight: '1px solid var(--stroke)' }}
    >
      {/* Brand */}
      <div className="px-5 pt-6 pb-7">
        <Link href="/dashboard" className="flex items-center gap-2.5 group">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-105"
            style={{ background: 'var(--ink)' }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--bg)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="10" r="3" />
              <path d="M12 2a8 8 0 0 0-8 8c0 1.892.402 3.13 1.5 4.5L12 22l6.5-7.5c1.098-1.37 1.5-2.608 1.5-4.5a8 8 0 0 0-8-8z" />
            </svg>
          </div>
          <div className="leading-none">
            <div className="serif text-[22px] tracking-tight" style={{ color: 'var(--ink)' }}>RouteFlow</div>
            <div className="text-[9.5px] uppercase tracking-[0.18em] mt-1" style={{ color: 'var(--ink-mute)' }}>
              AI Routing
            </div>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="px-3 flex-1 overflow-y-auto">
        <div className="text-[10px] uppercase tracking-[0.15em] px-2.5 pb-2 font-medium" style={{ color: 'var(--ink-mute)' }}>
          Workspace
        </div>
        <div className="space-y-0.5">
          {navItems.map((item) => {
            const active = router.pathname === item.href || router.pathname.startsWith(item.href + '/');
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-2.5 py-2 rounded-lg text-[13px] font-medium transition-all relative group"
                style={{
                  color: active ? 'var(--ink)' : 'var(--ink-3)',
                  background: active ? 'var(--bg-elev)' : 'transparent',
                  boxShadow: active ? 'var(--shadow-xs)' : 'none',
                  border: active ? '1px solid var(--stroke)' : '1px solid transparent',
                }}
              >
                <Icon size={15} strokeWidth={active ? 2 : 1.75} />
                <span>{item.label}</span>
                {active && (
                  <span
                    className="absolute right-2.5 w-1 h-1 rounded-full"
                    style={{ background: 'var(--accent)' }}
                  />
                )}
              </Link>
            );
          })}
        </div>
      </nav>

      {/* User card */}
      <div className="p-3" style={{ borderTop: '1px solid var(--stroke)' }}>
        <div className="surface-elev p-3 flex items-center gap-2.5">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-[11px] font-semibold text-white shrink-0"
            style={{ background: 'var(--accent)' }}
          >
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[12.5px] font-medium truncate" style={{ color: 'var(--ink)' }}>
              {profile?.full_name || 'User'}
            </div>
            <div className="text-[10.5px] truncate mt-0.5" style={{ color: 'var(--ink-3)' }}>
              {profile?.company_name || profile?.email}
            </div>
          </div>
          <button
            onClick={signOut}
            className="p-1.5 rounded-md transition-colors"
            style={{ color: 'var(--ink-3)' }}
            title="Sign out"
            onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--bg-hover)'; e.currentTarget.style.color = 'var(--bad)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--ink-3)'; }}
          >
            <LogOut size={13} strokeWidth={1.75} />
          </button>
        </div>
      </div>
    </aside>
  );
}
