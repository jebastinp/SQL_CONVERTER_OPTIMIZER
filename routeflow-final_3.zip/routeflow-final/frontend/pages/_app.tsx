import type { AppProps } from 'next/app';
import Head from 'next/head';
import { useEffect } from 'react';
import '@/styles/globals.css';

export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    // Theme
    const saved = localStorage.getItem('theme');
    const isDark = saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if (isDark) document.documentElement.classList.add('dark');

    // Preload Leaflet library in background — so map opens instantly later
    import('leaflet').catch(() => {});

    // Warm up the CARTO tile CDN connection (saves ~200-500ms on first map load)
    const linkPreconnect = document.createElement('link');
    linkPreconnect.rel = 'preconnect';
    linkPreconnect.href = 'https://basemaps.cartocdn.com';
    linkPreconnect.crossOrigin = '';
    document.head.appendChild(linkPreconnect);

    const linkDns = document.createElement('link');
    linkDns.rel = 'dns-prefetch';
    linkDns.href = 'https://tile.openstreetmap.org';
    document.head.appendChild(linkDns);
  }, []);

  return (
    <>
      <Head>
        <title>RouteFlow AI</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="AI route optimization for delivery operations" />
        <link rel="icon" href="/favicon.svg" />
      </Head>
      <Component {...pageProps} />
    </>
  );
}
