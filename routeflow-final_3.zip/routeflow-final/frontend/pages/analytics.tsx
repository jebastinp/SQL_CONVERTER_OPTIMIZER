import { useEffect, useState } from 'react';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { TrendingUp, Route as RouteIcon, CheckCircle2, BarChart3 } from 'lucide-react';

export default function AnalyticsPage() {
  const [routes, setRoutes] = useState<any[]>([]);
  const [stops, setStops] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const [r, s] = await Promise.all([
        sb.from('routes').select('*').order('created_at', { ascending: false }),
        sb.from('delivery_stops').select('*'),
      ]);
      setRoutes(r.data || []);
      setStops(s.data || []);
      setLoading(false);
    })();
  }, []);

  const totalRoutes = routes.length;
  const totalDistance = routes.reduce((s, r: any) => s + Number(r.distance_km || 0), 0);
  const totalFuel = routes.reduce((s, r: any) => s + Number(r.fuel_saved_gbp || 0), 0);
  const totalStops = stops.length;
  const delivered = stops.filter((s) => s.status === 'completed').length;
  const onTime = totalStops > 0 ? Math.round((delivered / totalStops) * 100) : 0;
  const totalDuration = routes.reduce((s, r: any) => s + Number(r.duration_minutes || 0), 0);

  return (
    <AppShell>
      <Topbar title="Analytics" subtitle="Operational performance" />

      <div className="p-8 overflow-auto flex-1">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-6 fade-up">
          <KPI label="Total routes" value={String(totalRoutes)} hint="All time" icon={RouteIcon} />
          <KPI label="Distance" value={`${totalDistance.toFixed(0)} km`} hint="Cumulative optimized" icon={TrendingUp} />
          <KPI label="Fuel saved" value={`£${totalFuel.toFixed(0)}`} hint="vs naive routing" icon={TrendingUp} highlight />
          <KPI label="Delivery rate" value={`${onTime}%`} hint={`${delivered}/${totalStops} stops`} icon={CheckCircle2} />
        </div>

        <div className="surface-elev p-6 fade-up">
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="serif text-[22px] tracking-tight">Per-route history</div>
              <div className="text-[12px] mt-1" style={{ color: 'var(--ink-3)' }}>
                {totalRoutes} routes · {totalDuration.toFixed(0)} minutes total time
              </div>
            </div>
          </div>

          {loading ? (
            <div className="text-[13px] py-12 text-center" style={{ color: 'var(--ink-3)' }}>Loading…</div>
          ) : totalRoutes === 0 ? (
            <div className="text-center py-16">
              <div
                className="w-12 h-12 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                style={{ background: 'var(--bg-soft)', color: 'var(--ink-mute)' }}
              >
                <BarChart3 size={20} strokeWidth={1.5} />
              </div>
              <div className="text-[14px] mb-1.5" style={{ color: 'var(--ink-2)' }}>No data yet</div>
              <div className="text-[12.5px]" style={{ color: 'var(--ink-3)' }}>
                Optimize a route to see analytics here.
              </div>
            </div>
          ) : (
            <table className="data">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Distance</th>
                  <th>Duration</th>
                  <th>Fuel saved</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {routes.map((r: any) => (
                  <tr key={r.id}>
                    <td style={{ color: 'var(--ink)' }}>
                      {new Date(r.created_at).toLocaleString('en-GB', {
                        day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                    <td className="mono">{Number(r.distance_km || 0).toFixed(1)} km</td>
                    <td className="mono">{Number(r.duration_minutes || 0).toFixed(0)}m</td>
                    <td className="mono" style={{ color: 'var(--good)' }}>
                      £{Number(r.fuel_saved_gbp || 0).toFixed(2)}
                    </td>
                    <td>
                      <span className={`pill ${r.status === 'completed' ? 'pill-ok' : r.status === 'in_progress' ? 'pill-info' : 'pill-neutral'}`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </AppShell>
  );
}

function KPI({ label, value, hint, icon: Icon, highlight }: {
  label: string; value: string; hint: string; icon: any; highlight?: boolean;
}) {
  return (
    <div className="surface-elev p-5 transition-all hover:-translate-y-0.5">
      <div className="flex items-start justify-between mb-4">
        <div
          className="text-[10.5px] uppercase tracking-[0.08em] font-medium"
          style={{ color: 'var(--ink-3)' }}
        >
          {label}
        </div>
        <Icon
          size={14}
          strokeWidth={1.75}
          style={{ color: highlight ? 'var(--accent)' : 'var(--ink-mute)' }}
        />
      </div>
      <div
        className="serif text-[38px] leading-none tracking-tight"
        style={{ color: highlight ? 'var(--accent)' : 'var(--ink)' }}
      >
        {value}
      </div>
      <div className="text-[11px] mt-2" style={{ color: 'var(--ink-3)' }}>{hint}</div>
    </div>
  );
}
