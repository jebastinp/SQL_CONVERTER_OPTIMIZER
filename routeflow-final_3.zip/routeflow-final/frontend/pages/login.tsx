import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowLeft, MapPin } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { error } = await supabase().auth.signInWithPassword({ email, password });
      if (error) throw error;
      router.push('/dashboard');
    } catch (e: any) {
      setError(e.message || 'Sign in failed');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen relative paper-grain" style={{ background: 'var(--bg)' }}>
      <div className="ambient-bg" />
      <div className="absolute top-5 right-5 z-10"><ThemeToggle /></div>

      <main className="relative z-10 min-h-screen flex items-center justify-center px-6">
        <div className="w-full max-w-[420px] fade-up">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-[12.5px] mb-8 transition-colors"
            style={{ color: 'var(--ink-3)' }}
          >
            <ArrowLeft size={13} /> Back
          </Link>

          <div className="flex items-center gap-2.5 mb-7">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: 'var(--ink)' }}>
              <MapPin size={16} style={{ color: 'var(--bg)' }} strokeWidth={2} />
            </div>
            <div className="serif text-[26px] tracking-tight">RouteFlow</div>
          </div>

          <h1 className="serif text-[40px] tracking-tight leading-[1.05] mb-2">
            Welcome <em style={{ color: 'var(--accent)' }}>back</em>
          </h1>
          <p className="text-[14px] mb-9" style={{ color: 'var(--ink-3)' }}>
            Sign in to continue to your workspace.
          </p>

          <form onSubmit={signIn} className="space-y-4">
            <div>
              <label className="fld">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
                className="input"
                placeholder="you@company.com"
              />
            </div>
            <div>
              <label className="fld">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="input"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div
                className="text-[12.5px] px-3.5 py-2.5 rounded-lg flex items-start gap-2"
                style={{
                  color: 'var(--bad)',
                  background: 'color-mix(in srgb, var(--bad) 7%, transparent)',
                  border: '1px solid color-mix(in srgb, var(--bad) 22%, transparent)',
                }}
              >
                <span className="font-medium">Error:</span> {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn btn-primary w-full !py-3 !text-[14px]">
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <div className="my-8 divider-label">or</div>

          <p className="text-center text-[13px]" style={{ color: 'var(--ink-3)' }}>
            New here?{' '}
            <Link href="/signup" className="font-medium" style={{ color: 'var(--accent)' }}>
              Create an account →
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
