import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { MapPin, Phone, Check, X, Navigation } from 'lucide-react';

export default function DriverApp() {
  const router = useRouter();
  const token = router.query.token as string | undefined;

  const [driver, setDriver] = useState<any>(null);
  const [stops, setStops] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tracking, setTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!token) return;
    const sb = supabase();
    const { data: d, error: dErr } = await sb.from('drivers').select('*').eq('access_token', token).single();
    if (dErr || !d) { setError('Invalid driver link'); setLoading(false); return; }
    setDriver(d);

    const { data: routes } = await sb.from('routes').select('*')
      .eq('driver_id', d.id)
      .in('status', ['planned', 'in_progress'])
      .order('created_at', { ascending: false })
      .limit(1);

    if (routes && routes[0]) {
      const { data: stopData } = await sb.from('delivery_stops').select('*, orders(*)')
        .eq('route_id', routes[0].id).order('sequence');
      setStops(stopData || []);
    }
    setLoading(false);
  }
  useEffect(() => { if (token) load(); }, [token]);

  function startTracking() {
    if (!navigator.geolocation || !driver) return;
    setTracking(true);
    navigator.geolocation.watchPosition(
      async (pos) => {
        const sb = supabase();
        await sb.from('driver_positions').insert({
          driver_id: driver.id,
          user_id: driver.user_id,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        await sb.from('drivers').update({
          current_lat: pos.coords.latitude,
          current_lng: pos.coords.longitude,
          last_seen: new Date().toISOString(),
        }).eq('id', driver.id);
      },
      (err) => alert(`Location error: ${err.message}`),
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 30000 },
    );
  }

  async function markComplete(stopId: string) {
    await supabase().from('delivery_stops').update({
      status: 'completed', completed_at: new Date().toISOString(),
    }).eq('id', stopId);
    load();
  }

  async function markFailed(stopId: string) {
    if (!confirm('Mark this delivery as failed?')) return;
    await supabase().from('delivery_stops').update({
      status: 'failed', completed_at: new Date().toISOString(),
    }).eq('id', stopId);
    load();
  }

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg)' }}>
        <div className="text-sm" style={{ color: 'var(--ink-3)' }}>Loading…</div>
      </main>
    );
  }
  if (error) {
    return (
      <main className="min-h-screen flex items-center justify-center px-6" style={{ background: 'var(--bg)' }}>
        <div className="surface p-8 text-center max-w-sm">
          <div className="text-3xl mb-3">📦</div>
          <div className="text-[14px] font-medium mb-1" style={{ color: 'var(--bad)' }}>{error}</div>
          <div className="text-[12px]" style={{ color: 'var(--ink-3)' }}>Ask the dispatcher for a fresh link.</div>
        </div>
      </main>
    );
  }

  const pending = stops.filter((s) => s.status === 'pending').length;
  const done = stops.filter((s) => s.status === 'completed').length;
  const failed = stops.filter((s) => s.status === 'failed').length;

  return (
    <main className="min-h-screen pb-24" style={{ background: 'var(--bg)' }}>
      <div className="absolute top-4 right-4 z-10"><ThemeToggle /></div>

      <div className="max-w-md mx-auto px-4 pt-6">
        <div className="surface p-5 mb-4 fade-up">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl flex items-center justify-center font-semibold text-white"
                 style={{ background: driver.color }}>
              {driver.name.split(' ').map((n: string) => n[0]).slice(0, 2).join('').toUpperCase()}
            </div>
            <div className="flex-1">
              <div className="text-[14px] font-semibold">{driver.name}</div>
              <div className="text-[11px]" style={{ color: 'var(--ink-3)' }}>{driver.vehicle || 'Driver app'}</div>
            </div>
            {tracking && (
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full pulse-slow" style={{ background: 'var(--good)' }} />
                <div className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'var(--good)' }}>Live</div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 mt-4 text-center">
            <div className="surface-soft p-2.5">
              <div className="font-serif text-2xl" style={{ color: 'var(--accent)' }}>{pending}</div>
              <div className="text-[9px] uppercase tracking-wider mt-0.5" style={{ color: 'var(--ink-3)' }}>Pending</div>
            </div>
            <div className="surface-soft p-2.5">
              <div className="font-serif text-2xl" style={{ color: 'var(--good)' }}>{done}</div>
              <div className="text-[9px] uppercase tracking-wider mt-0.5" style={{ color: 'var(--ink-3)' }}>Done</div>
            </div>
            <div className="surface-soft p-2.5">
              <div className="font-serif text-2xl" style={{ color: 'var(--bad)' }}>{failed}</div>
              <div className="text-[9px] uppercase tracking-wider mt-0.5" style={{ color: 'var(--ink-3)' }}>Failed</div>
            </div>
          </div>

          {!tracking && stops.length > 0 && (
            <button onClick={startTracking} className="btn btn-accent w-full mt-4 !py-3">
              <Navigation size={15} />Start route & share location
            </button>
          )}
        </div>

        {stops.length === 0 && (
          <div className="surface p-10 text-center fade-up">
            <div className="text-3xl mb-3">📋</div>
            <div className="text-[14px] mb-1" style={{ color: 'var(--ink-2)' }}>No route assigned yet</div>
            <div className="text-[12px]" style={{ color: 'var(--ink-3)' }}>Check back later or contact dispatcher.</div>
          </div>
        )}

        <div className="space-y-3">
          {stops.map((s) => {
            const o = s.orders;
            const isDone = s.status === 'completed';
            const isFailed = s.status === 'failed';
            const dim = isDone || isFailed;
            return (
              <div key={s.id} className={`surface p-4 fade-up ${dim ? 'opacity-60' : ''}`}>
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white text-xs shrink-0"
                       style={{ background: isDone ? 'var(--good)' : isFailed ? 'var(--bad)' : driver.color }}>
                    {isDone ? <Check size={16} /> : isFailed ? <X size={16} /> : s.sequence}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-[14px]">{o.customer_name}</div>
                    <div className="text-[12px] mt-0.5" style={{ color: 'var(--ink-2)' }}>{o.address}</div>
                    <div className="text-[11px] mt-1" style={{ color: 'var(--ink-3)' }}>
                      ETA <span className="font-mono" style={{ color: 'var(--accent)' }}>{s.eta_clock}</span>
                    </div>
                  </div>
                </div>
                {!dim && (
                  <>
                    <div className="grid grid-cols-3 gap-2 mt-4">
                      {o.phone ? (
                        <a href={`tel:${o.phone}`} className="btn btn-ghost !text-[11px] !py-2">
                          <Phone size={12} />Call
                        </a>
                      ) : <div />}
                      <a href={`https://www.google.com/maps/dir/?api=1&destination=${o.lat},${o.lng}`}
                         target="_blank" rel="noreferrer" className="btn btn-ghost !text-[11px] !py-2">
                        <MapPin size={12} />Nav
                      </a>
                      <button onClick={() => markComplete(s.id)} className="btn btn-primary !text-[11px] !py-2">
                        <Check size={12} />Done
                      </button>
                    </div>
                    <button onClick={() => markFailed(s.id)} className="text-[11px] mt-2.5 w-full text-center"
                            style={{ color: 'color-mix(in srgb, var(--bad) 70%, transparent)' }}>
                      Mark as failed
                    </button>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </main>
  );
}
