import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  // Inline script runs before React hydrates, prevents theme flash
  const setInitialTheme = `
    (function() {
      try {
        var t = localStorage.getItem('theme');
        var isDark = t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches);
        if (isDark) document.documentElement.classList.add('dark');
      } catch(e) {}
    })();
  `;
  return (
    <Html lang="en">
      <Head />
      <body>
        <script dangerouslySetInnerHTML={{ __html: setInitialTheme }} />
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
