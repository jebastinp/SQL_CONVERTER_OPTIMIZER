import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowLeft, MapPin } from 'lucide-react';

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      const sb = supabase();
      const { data, error } = await sb.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName } },
      });
      if (error) throw error;

      if (data.user && companyName) {
        await sb.from('profiles').update({ company_name: companyName }).eq('id', data.user.id);
      }
      if (data.session) {
        router.push('/dashboard');
      } else {
        setInfo('Check your email to confirm, then sign in.');
      }
    } catch (e: any) {
      setError(e.message || 'Signup failed');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen relative paper-grain" style={{ background: 'var(--bg)' }}>
      <div className="ambient-bg" />
      <div className="absolute top-5 right-5 z-10"><ThemeToggle /></div>

      <main className="relative z-10 min-h-screen flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-[420px] fade-up">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-[12.5px] mb-8"
            style={{ color: 'var(--ink-3)' }}
          >
            <ArrowLeft size={13} /> Back
          </Link>

          <div className="flex items-center gap-2.5 mb-7">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: 'var(--ink)' }}>
              <MapPin size={16} style={{ color: 'var(--bg)' }} strokeWidth={2} />
            </div>
            <div className="serif text-[26px] tracking-tight">RouteFlow</div>
          </div>

          <h1 className="serif text-[40px] tracking-tight leading-[1.05] mb-2">
            Get <em style={{ color: 'var(--accent)' }}>started</em>
          </h1>
          <p className="text-[14px] mb-9" style={{ color: 'var(--ink-3)' }}>
            Create your account in under a minute.
          </p>

          <form onSubmit={signUp} className="space-y-4">
            <div>
              <label className="fld">Full name</label>
              <input value={fullName} onChange={(e) => setFullName(e.target.value)} required autoFocus className="input" placeholder="Alex Morgan" />
            </div>
            <div>
              <label className="fld">Company <span style={{ color: 'var(--ink-mute)' }}>· optional</span></label>
              <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="input" placeholder="Acme Logistics" />
            </div>
            <div>
              <label className="fld">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="input" placeholder="you@company.com" />
            </div>
            <div>
              <label className="fld">Password <span style={{ color: 'var(--ink-mute)' }}>· min 6 chars</span></label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="input" placeholder="••••••••" />
            </div>

            {error && (
              <div className="text-[12.5px] px-3.5 py-2.5 rounded-lg"
                style={{ color: 'var(--bad)', background: 'color-mix(in srgb, var(--bad) 7%, transparent)', border: '1px solid color-mix(in srgb, var(--bad) 22%, transparent)' }}>
                <span className="font-medium">Error:</span> {error}
              </div>
            )}
            {info && (
              <div className="text-[12.5px] px-3.5 py-2.5 rounded-lg"
                style={{ color: 'var(--good)', background: 'color-mix(in srgb, var(--good) 7%, transparent)', border: '1px solid color-mix(in srgb, var(--good) 22%, transparent)' }}>
                {info}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn btn-primary w-full !py-3 !text-[14px]">
              {loading ? 'Creating…' : 'Create account'}
            </button>
          </form>

          <div className="my-8 divider-label">or</div>

          <p className="text-center text-[13px]" style={{ color: 'var(--ink-3)' }}>
            Already have one?{' '}
            <Link href="/login" className="font-medium" style={{ color: 'var(--accent)' }}>
              Sign in →
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
