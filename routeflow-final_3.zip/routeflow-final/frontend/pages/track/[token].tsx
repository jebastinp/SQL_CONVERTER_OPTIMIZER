import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { MapPin, Clock, CheckCircle2, Package } from 'lucide-react';

const TrackMap = dynamic(() => import('@/components/TrackMap'), { ssr: false });

export default function CustomerTrack() {
  const router = useRouter();
  const token = router.query.token as string | undefined;

  const [stop, setStop] = useState<any>(null);
  const [order, setOrder] = useState<any>(null);
  const [route, setRoute] = useState<any>(null);
  const [driver, setDriver] = useState<any>(null);
  const [position, setPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!token) return;
    const sb = supabase();
    const { data: s, error: sErr } = await sb.from('delivery_stops').select('*')
      .eq('customer_token', token).single();
    if (sErr || !s) { setError('Invalid tracking link'); setLoading(false); return; }
    setStop(s);

    const [orderRes, routeRes] = await Promise.all([
      sb.from('orders').select('*').eq('id', s.order_id).single(),
      sb.from('routes').select('*').eq('id', s.route_id).single(),
    ]);
    setOrder(orderRes.data);
    setRoute(routeRes.data);

    if (routeRes.data) {
      const { data: d } = await sb.from('drivers').select('*').eq('id', routeRes.data.driver_id).single();
      setDriver(d);
      if (d?.current_lat && d?.current_lng) {
        setPosition({ lat: Number(d.current_lat), lng: Number(d.current_lng) });
      }
    }
    setLoading(false);
  }

  useEffect(() => { if (token) load(); }, [token]);

  useEffect(() => {
    if (!driver) return;
    const sb = supabase();
    const channel = sb.channel(`track_${driver.id}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'driver_positions', filter: `driver_id=eq.${driver.id}` },
        (payload: any) => {
          setPosition({ lat: Number(payload.new.lat), lng: Number(payload.new.lng) });
        })
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'delivery_stops', filter: `id=eq.${stop?.id}` },
        () => { load(); })
      .subscribe();
    return () => { sb.removeChannel(channel); };
  }, [driver, stop?.id]);

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg)' }}>
        <div className="text-sm" style={{ color: 'var(--ink-3)' }}>Loading…</div>
      </main>
    );
  }
  if (error) {
    return (
      <main className="min-h-screen flex items-center justify-center px-6" style={{ background: 'var(--bg)' }}>
        <div className="surface p-8 text-center max-w-sm">
          <div className="text-3xl mb-3">📦</div>
          <div className="text-[14px] font-medium mb-1" style={{ color: 'var(--bad)' }}>{error}</div>
        </div>
      </main>
    );
  }

  const isDone = stop?.status === 'completed';
  const isFailed = stop?.status === 'failed';

  return (
    <main className="min-h-screen pb-8" style={{ background: 'var(--bg)' }}>
      <div className="absolute top-4 right-4 z-10"><ThemeToggle /></div>

      <div className="max-w-md mx-auto px-4 pt-6">
        <div className="text-center mb-5 fade-up">
          <div className="font-serif text-3xl tracking-tight">Your delivery</div>
          <div className="text-[12px] mt-1" style={{ color: 'var(--ink-3)' }}>Live tracking</div>
        </div>

        <div className="surface p-5 mb-4 fade-up">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                 style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
              {isDone ? <CheckCircle2 size={20} /> : <Package size={20} />}
            </div>
            <div className="flex-1">
              <div className="font-semibold text-[14px]">{order?.customer_name}</div>
              <div className="text-[12px] mt-0.5" style={{ color: 'var(--ink-2)' }}>{order?.address}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="surface-soft p-3">
              <div className="text-[10px] uppercase tracking-wider mb-1" style={{ color: 'var(--ink-3)' }}>Status</div>
              <div>
                {isDone && <span className="pill pill-ok">delivered</span>}
                {isFailed && <span className="pill pill-bad">failed</span>}
                {!isDone && !isFailed && <span className="pill pill-info">en route</span>}
              </div>
            </div>
            <div className="surface-soft p-3">
              <div className="text-[10px] uppercase tracking-wider mb-1" style={{ color: 'var(--ink-3)' }}>ETA</div>
              <div className="font-mono text-[14px]" style={{ color: 'var(--accent)' }}>
                <Clock size={11} className="inline mr-1" />{stop?.eta_clock || '—'}
              </div>
            </div>
          </div>
        </div>

        {driver && (
          <div className="surface p-4 mb-4 fade-up">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center font-semibold text-white text-xs"
                   style={{ background: driver.color }}>
                {driver.name.split(' ').map((n: string) => n[0]).slice(0, 2).join('').toUpperCase()}
              </div>
              <div className="flex-1">
                <div className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--ink-3)' }}>Your driver</div>
                <div className="text-[14px] font-medium">{driver.name}</div>
              </div>
              {position && (
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full pulse-slow" style={{ background: 'var(--good)' }} />
                  <div className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'var(--good)' }}>Live</div>
                </div>
              )}
            </div>
          </div>
        )}

        {order?.lat && order?.lng && (
          <div className="surface overflow-hidden fade-up" style={{ height: 320 }}>
            <TrackMap
              stopLat={Number(order.lat)}
              stopLng={Number(order.lng)}
              driverPos={position}
              driverColor={driver?.color || 'var(--accent)'}
            />
          </div>
        )}

        {!position && !isDone && (
          <div className="mt-4 text-center text-[11.5px]" style={{ color: 'var(--ink-3)' }}>
            <MapPin size={12} className="inline mr-1" />
            Driver location will appear when they start the route
          </div>
        )}
      </div>
    </main>
  );
}
