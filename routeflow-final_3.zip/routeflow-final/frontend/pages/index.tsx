import Link from 'next/link';
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowRight, MapPin, Sparkles, Zap, Navigation, BarChart3 } from 'lucide-react';

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  return (
    <div className="min-h-screen relative paper-grain" style={{ background: 'var(--bg)' }}>
      <div className="ambient-bg" />

      {/* Nav */}
      <nav className="relative z-10 px-8 py-5 flex items-center justify-between max-w-[1180px] mx-auto">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--ink)' }}>
            <MapPin size={15} style={{ color: 'var(--bg)' }} strokeWidth={2} />
          </div>
          <div className="serif text-[22px] tracking-tight">RouteFlow</div>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/diagnostic" className="btn btn-bare text-[12px]">Diagnostic</Link>
          <ThemeToggle />
          <Link href="/login" className="btn btn-ghost">Sign in</Link>
          <Link href="/signup" className="btn btn-primary">Get started</Link>
        </div>
      </nav>

      {/* Hero */}
      <main className="relative z-10 max-w-[1180px] mx-auto px-8 pt-20 pb-24">
        <div className="max-w-3xl mx-auto text-center">
          <div
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-9 fade-up text-[11.5px]"
            style={{
              background: 'var(--bg-elev)',
              border: '1px solid var(--stroke-2)',
              color: 'var(--ink-3)',
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full pulse-dot" style={{ background: 'var(--good)' }} />
            <span className="font-medium">Live</span>
            <span style={{ color: 'var(--ink-mute)' }}>·</span>
            <span>AI route intelligence for delivery operations</span>
          </div>

          <h1
            className="serif tracking-tight leading-[1.02] mb-7 fade-up"
            style={{ fontSize: 'clamp(48px, 7vw, 84px)', color: 'var(--ink)' }}
          >
            Routes that{' '}
            <em style={{ color: 'var(--accent)' }}>think</em>
            <br />
            ahead of you.
          </h1>

          <p className="text-[17px] fade-up mb-12 max-w-xl mx-auto leading-relaxed" style={{ color: 'var(--ink-3)' }}>
            Upload your stops, assign your drivers, and let our VRP solver
            handle the rest. Less fuel, less time, fewer headaches.
          </p>

          <div className="flex gap-3 flex-wrap justify-center fade-up mb-20">
            <Link href="/signup" className="btn btn-primary !text-[14.5px] !px-5 !py-3">
              Start free <ArrowRight size={15} strokeWidth={2} />
            </Link>
            <Link href="/login" className="btn btn-ghost !text-[14.5px] !px-5 !py-3">
              Sign in
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 max-w-4xl mx-auto fade-up">
          {[
            {
              i: Zap,
              t: 'Upload & verify',
              d: 'Drop a CSV with name, address, phone. We geocode and validate every row.',
              num: '01',
            },
            {
              i: Sparkles,
              t: 'AI optimize',
              d: 'Google OR-Tools VRP solver assigns and sequences stops in under 5 seconds.',
              num: '02',
            },
            {
              i: Navigation,
              t: 'Track & deliver',
              d: 'Drivers share location live. Customers see real ETAs on their phones.',
              num: '03',
            },
          ].map((f, i) => {
            const Icon = f.i;
            return (
              <div key={i} className="surface-elev p-6 text-left transition-transform hover:-translate-y-0.5">
                <div className="flex items-start justify-between mb-5">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}
                  >
                    <Icon size={18} strokeWidth={1.75} />
                  </div>
                  <span className="text-[10.5px] uppercase tracking-[0.12em] font-medium" style={{ color: 'var(--ink-mute)' }}>
                    {f.num}
                  </span>
                </div>
                <div className="text-[15px] font-medium mb-1.5" style={{ color: 'var(--ink)' }}>
                  {f.t}
                </div>
                <div className="text-[12.5px] leading-relaxed" style={{ color: 'var(--ink-3)' }}>
                  {f.d}
                </div>
              </div>
            );
          })}
        </div>

        {/* Stats strip */}
        <div className="mt-20 max-w-4xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-px fade-up overflow-hidden rounded-2xl" style={{ background: 'var(--stroke)' }}>
            {[
              { v: '32%', l: 'Fuel savings' },
              { v: '2.4×', l: 'More stops/hour' },
              { v: '<5s', l: 'Optimization time' },
              { v: '99.9%', l: 'Delivery accuracy' },
            ].map((s, i) => (
              <div key={i} className="p-6 text-center" style={{ background: 'var(--bg-elev)' }}>
                <div className="serif text-[34px] leading-none mb-2" style={{ color: 'var(--ink)' }}>{s.v}</div>
                <div className="text-[10.5px] uppercase tracking-[0.12em] font-medium" style={{ color: 'var(--ink-3)' }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center text-[11.5px] fade-up" style={{ color: 'var(--ink-mute)' }}>
          First-time setup?{' '}
          <Link href="/diagnostic" className="font-medium" style={{ color: 'var(--accent)' }}>
            Run diagnostic →
          </Link>
        </div>
      </main>
    </div>
  );
}
