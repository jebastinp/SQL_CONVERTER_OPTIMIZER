import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { apiHealth } from '@/lib/api';
import ThemeToggle from '@/components/ThemeToggle';
import { ArrowLeft, RefreshCw, CheckCircle2, XCircle, Circle, Activity } from 'lucide-react';

type Check = { name: string; status: 'pending' | 'pass' | 'fail'; message?: string; fix?: string };

export default function Diagnostic() {
  const [checks, setChecks] = useState<Check[]>([]);

  useEffect(() => { runChecks(); }, []);

  async function runChecks() {
    const results: Check[] = [];
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    const apiUrl = process.env.NEXT_PUBLIC_API_URL;

    results.push({
      name: 'Supabase URL configured',
      status: url ? 'pass' : 'fail',
      message: url || 'missing',
      fix: !url ? 'Set NEXT_PUBLIC_SUPABASE_URL in frontend/.env.local and restart' : undefined,
    });
    results.push({
      name: 'Supabase anon key configured',
      status: key ? 'pass' : 'fail',
      message: key ? `${key.substring(0, 24)}…` : 'missing',
    });
    results.push({
      name: 'API URL configured',
      status: apiUrl ? 'pass' : 'fail',
      message: apiUrl || 'using default http://localhost:8000',
    });
    setChecks([...results]);

    if (url && key) {
      try {
        const r = await fetch(`${url}/rest/v1/`, { headers: { apikey: key } });
        results.push({
          name: 'Supabase REST reachable',
          status: r.status < 500 ? 'pass' : 'fail',
          message: `HTTP ${r.status}`,
        });
      } catch (e: any) {
        results.push({ name: 'Supabase REST reachable', status: 'fail', message: e.message });
      }
      try {
        const { error } = await supabase().from('profiles').select('id').limit(1);
        if (error) {
          results.push({
            name: 'Database schema installed',
            status: 'fail',
            message: error.message,
            fix: error.message.includes('does not exist')
              ? 'Run supabase/schema.sql in Supabase SQL Editor'
              : 'Check RLS policies',
          });
        } else {
          results.push({ name: 'Database schema installed', status: 'pass', message: 'profiles table OK' });
        }
      } catch (e: any) {
        results.push({ name: 'Database schema installed', status: 'fail', message: e.message });
      }
    }
    setChecks([...results]);

    try {
      const h = await apiHealth();
      results.push({
        name: 'Backend API reachable',
        status: 'pass',
        message: `ortools=${h.ortools}, ors=${h.ors_configured}`,
      });
    } catch (e: any) {
      const msg = e.message || '';
      if (msg.includes('401')) {
        results.push({ name: 'Backend API reachable', status: 'pass', message: 'Up · 401 expected without auth' });
      } else {
        results.push({
          name: 'Backend API reachable',
          status: 'fail',
          message: msg,
          fix: 'Start backend: cd backend && uvicorn main:app --reload --port 8000',
        });
      }
    }
    setChecks([...results]);
  }

  const allPassed = checks.length > 0 && checks.every((c) => c.status === 'pass');
  const anyFailed = checks.some((c) => c.status === 'fail');

  return (
    <div className="min-h-screen relative paper-grain" style={{ background: 'var(--bg)' }}>
      <div className="ambient-bg" />
      <div className="absolute top-5 right-5 z-10"><ThemeToggle /></div>

      <main className="relative z-10 max-w-2xl mx-auto px-6 py-12">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-[12.5px] mb-6"
          style={{ color: 'var(--ink-3)' }}
        >
          <ArrowLeft size={13} /> Back
        </Link>

        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}
          >
            <Activity size={18} strokeWidth={1.75} />
          </div>
          <h1 className="serif text-[40px] tracking-tight leading-none">Diagnostic</h1>
        </div>
        <p className="text-[14px] mb-9" style={{ color: 'var(--ink-3)' }}>
          Verifies your environment is connected correctly.
        </p>

        <div className="space-y-2.5">
          {checks.length === 0 && (
            <div className="text-[13px]" style={{ color: 'var(--ink-3)' }}>Running checks…</div>
          )}
          {checks.map((c, i) => (
            <div key={i} className="surface-elev p-4 flex items-start gap-3 fade-up">
              <div className="mt-0.5">
                {c.status === 'pass' && <CheckCircle2 size={17} strokeWidth={1.75} style={{ color: 'var(--good)' }} />}
                {c.status === 'fail' && <XCircle size={17} strokeWidth={1.75} style={{ color: 'var(--bad)' }} />}
                {c.status === 'pending' && <Circle size={17} strokeWidth={1.75} style={{ color: 'var(--ink-mute)' }} />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-[13.5px]" style={{ color: 'var(--ink)' }}>{c.name}</div>
                {c.message && (
                  <div className="text-[11.5px] mt-1 mono break-all" style={{ color: 'var(--ink-3)' }}>
                    {c.message}
                  </div>
                )}
                {c.fix && (
                  <div className="text-[11.5px] mt-2 px-3 py-2 rounded-md" style={{
                    color: 'var(--warn)',
                    background: 'color-mix(in srgb, var(--warn) 8%, transparent)',
                  }}>
                    → {c.fix}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {allPassed && (
          <div className="mt-6 surface-elev p-5 fade-up" style={{
            borderColor: 'color-mix(in srgb, var(--good) 30%, transparent)',
          }}>
            <div className="font-medium text-[13.5px] mb-1.5" style={{ color: 'var(--good)' }}>
              ✓ All checks passed
            </div>
            <div className="text-[12.5px]" style={{ color: 'var(--ink-3)' }}>
              You're ready.{' '}
              <Link href="/signup" className="font-medium" style={{ color: 'var(--accent)' }}>Sign up</Link>
              {' '}or{' '}
              <Link href="/login" className="font-medium" style={{ color: 'var(--accent)' }}>sign in</Link>.
            </div>
          </div>
        )}
        {anyFailed && (
          <div className="mt-6 surface-elev p-5 fade-up" style={{
            borderColor: 'color-mix(in srgb, var(--bad) 30%, transparent)',
          }}>
            <div className="font-medium text-[13.5px]" style={{ color: 'var(--bad)' }}>
              Some checks failed
            </div>
            <div className="text-[12.5px] mt-1" style={{ color: 'var(--ink-3)' }}>
              Follow the orange arrows to fix each issue, then re-run.
            </div>
          </div>
        )}

        <button onClick={() => { setChecks([]); runChecks(); }} className="btn btn-ghost mt-6">
          <RefreshCw size={13} /> Re-run checks
        </button>
      </main>
    </div>
  );
}
