import { useEffect, useState } from 'react';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { apiOptimize } from '@/lib/api';
import type { Order, Driver, Profile, OptimizeResponse } from '@/lib/types';
import { Zap, Download, AlertTriangle, ArrowRight, Route as RouteIcon } from 'lucide-react';

const RouteMap = dynamic(() => import('@/components/RouteMap'), { ssr: false });

export default function RoutesPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [optimization, setOptimization] = useState<OptimizeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [driverPositions, setDriverPositions] = useState<Record<string, { lat: number; lng: number }>>({});

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      const [o, d, p] = await Promise.all([
        sb.from('orders').select('*').eq('geocoded', true),
        sb.from('drivers').select('*'),
        sb.from('profiles').select('*').eq('id', user.id).single(),
      ]);
      setOrders((o.data as Order[]) || []);
      setDrivers((d.data as Driver[]) || []);
      setProfile(p.data as Profile);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const sb = supabase();
    const channel = sb.channel('driver_positions_live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'driver_positions' }, (payload: any) => {
        const p = payload.new;
        setDriverPositions((prev) => ({ ...prev, [p.driver_id]: { lat: Number(p.lat), lng: Number(p.lng) } }));
      })
      .subscribe();
    return () => { sb.removeChannel(channel); };
  }, []);

  async function optimize() {
    if (!profile) return;
    if (orders.length === 0) { setError('No geocoded orders. Import and geocode first.'); return; }
    if (drivers.length === 0) { setError('No drivers. Add at least one driver first.'); return; }
    setError(null);
    setOptimizing(true);
    try {
      const body = {
        depot: { lat: Number(profile.depot_lat), lng: Number(profile.depot_lng) },
        orders: orders.map((o) => ({
          id: o.id, customer_name: o.customer_name, address: o.address,
          lat: Number(o.lat), lng: Number(o.lng),
        })),
        drivers: drivers.map((d) => ({
          id: d.id, name: d.name, vehicle: d.vehicle || '',
          capacity: d.capacity, color: d.color,
        })),
        avg_speed_kmh: Number(profile.avg_speed_kmh),
        fuel_price_gbp: Number(profile.fuel_price_gbp),
        vehicle_kml: Number(profile.vehicle_kml),
      };
      const result: OptimizeResponse = await apiOptimize(body);
      setOptimization(result);

      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      for (const route of result.routes) {
        const { data: routeRow } = await sb.from('routes').insert({
          user_id: user.id,
          driver_id: route.driver_id,
          status: 'planned',
          depot_lat: profile.depot_lat,
          depot_lng: profile.depot_lng,
          distance_km: route.distance_km,
          duration_minutes: route.duration_minutes,
          fuel_saved_gbp: result.fuel_saved_gbp / Math.max(1, result.routes.length),
          baseline_km: result.baseline_distance_km / Math.max(1, result.routes.length),
        }).select().single();
        if (routeRow) {
          await sb.from('delivery_stops').insert(route.stops.map((s) => ({
            route_id: routeRow.id,
            order_id: s.order_id,
            user_id: user.id,
            sequence: s.sequence,
            eta_clock: s.eta_clock,
            status: 'pending',
          })));
          await sb.from('orders').update({ status: 'assigned' })
            .in('id', route.stops.map((s) => s.order_id).filter(Boolean));
        }
      }
    } catch (e: any) {
      setError(e.message);
    }
    setOptimizing(false);
  }

  function exportCSV() {
    if (!optimization) return;
    let csv = 'Driver,Sequence,Customer,Address,ETA,Lat,Lng\n';
    for (const r of optimization.routes) {
      for (const s of r.stops) {
        csv += `"${r.driver_name}",${s.sequence},"${s.customer_name}","${s.address}","${s.eta_clock}",${s.lat},${s.lng}\n`;
      }
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `routes-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  }

  const canOptimize = orders.length > 0 && drivers.length > 0 && !loading;

  return (
    <AppShell>
      <Topbar
        title="Routes"
        subtitle={optimization
          ? `${optimization.routes.length} routes · saved ${optimization.distance_saved_km.toFixed(1)}km · £${optimization.fuel_saved_gbp.toFixed(2)}`
          : 'Plan, optimize, and dispatch'}
        actions={
          <div className="flex gap-2">
            {optimization && (
              <button onClick={exportCSV} className="btn btn-ghost">
                <Download size={13} />Export CSV
              </button>
            )}
            <button onClick={optimize} disabled={optimizing || !canOptimize} className="btn btn-accent">
              <Zap size={13} strokeWidth={2} />{optimizing ? 'Optimizing…' : 'Optimize routes'}
            </button>
          </div>
        }
      />

      {error && (
        <div
          className="mx-8 mt-5 px-4 py-3 rounded-xl text-[13px] flex items-center gap-2"
          style={{
            color: 'var(--bad)',
            background: 'color-mix(in srgb, var(--bad) 7%, transparent)',
            border: '1px solid color-mix(in srgb, var(--bad) 22%, transparent)',
          }}
        >
          <AlertTriangle size={14} strokeWidth={1.75} />
          {error}
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[360px_1fr] overflow-hidden">
        {/* Sidebar with summary + driver routes */}
        <aside
          className="overflow-auto p-5 space-y-3"
          style={{ background: 'var(--bg-soft)', borderRight: '1px solid var(--stroke)' }}
        >
          {!optimization ? (
            <div className="text-center py-16 fade-up">
              {loading ? (
                <div className="text-[13px]" style={{ color: 'var(--ink-3)' }}>Loading…</div>
              ) : (
                <>
                  <div
                    className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: 'var(--bg-elev)', color: 'var(--ink-mute)', border: '1px solid var(--stroke)' }}
                  >
                    <RouteIcon size={22} strokeWidth={1.5} />
                  </div>
                  <div className="serif text-[20px] mb-1.5">
                    {canOptimize ? 'Ready to optimize' : 'Setup required'}
                  </div>
                  <div className="text-[12px] mb-5" style={{ color: 'var(--ink-3)' }}>
                    {orders.length} geocoded orders · {drivers.length} drivers
                  </div>
                  {!canOptimize && (
                    <div className="space-y-2 mt-4">
                      {orders.length === 0 && (
                        <Link href="/orders" className="btn btn-ghost text-[12px]">
                          Import orders <ArrowRight size={12} />
                        </Link>
                      )}
                      {drivers.length === 0 && (
                        <Link href="/drivers" className="btn btn-ghost text-[12px]">
                          Add drivers <ArrowRight size={12} />
                        </Link>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          ) : (
            <>
              {/* Summary card */}
              <div className="surface-elev p-4 fade-up">
                <div className="text-[10px] uppercase tracking-[0.1em] mb-3 font-medium" style={{ color: 'var(--ink-3)' }}>
                  Summary
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-[9.5px] uppercase tracking-[0.08em] font-medium" style={{ color: 'var(--ink-3)' }}>
                      Total km
                    </div>
                    <div className="serif text-[22px] leading-tight mt-1">{optimization.total_distance_km.toFixed(1)}</div>
                  </div>
                  <div>
                    <div className="text-[9.5px] uppercase tracking-[0.08em] font-medium" style={{ color: 'var(--ink-3)' }}>
                      Saved
                    </div>
                    <div className="serif text-[22px] leading-tight mt-1" style={{ color: 'var(--good)' }}>
                      {optimization.distance_saved_km.toFixed(1)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[9.5px] uppercase tracking-[0.08em] font-medium" style={{ color: 'var(--ink-3)' }}>
                      Fuel £
                    </div>
                    <div className="serif text-[22px] leading-tight mt-1" style={{ color: 'var(--good)' }}>
                      £{optimization.fuel_saved_gbp.toFixed(2)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[9.5px] uppercase tracking-[0.08em] font-medium" style={{ color: 'var(--ink-3)' }}>
                      Algorithm
                    </div>
                    <div className="mono text-[10px] mt-2.5" style={{ color: 'var(--ink-3)' }}>
                      {optimization.algorithm}
                    </div>
                  </div>
                </div>
              </div>

              {/* Each route */}
              {optimization.routes.map((route) => (
                <div key={route.driver_id} className="fade-up">
                  <div
                    className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl mb-2"
                    style={{
                      background: 'var(--bg-elev)',
                      border: '1px solid var(--stroke)',
                      borderLeft: `3px solid ${route.driver_color}`,
                    }}
                  >
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: route.driver_color }} />
                    <div className="text-[13px] font-medium flex-1" style={{ color: 'var(--ink)' }}>
                      {route.driver_name}
                    </div>
                    <div className="text-[10.5px] mono" style={{ color: 'var(--ink-3)' }}>
                      {route.stops.length} · {route.distance_km.toFixed(1)}km
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    {route.stops.map((s) => (
                      <div
                        key={s.sequence}
                        className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-[12px]"
                        style={{ background: 'var(--bg-elev)', border: '1px solid var(--stroke)' }}
                      >
                        <div
                          className="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-semibold text-white mono shrink-0"
                          style={{ background: route.driver_color }}
                        >
                          {s.sequence}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate" style={{ color: 'var(--ink)' }}>
                            {s.customer_name}
                          </div>
                          <div className="text-[10.5px] truncate mt-0.5" style={{ color: 'var(--ink-3)' }}>
                            {s.address}
                          </div>
                        </div>
                        <div className="text-[10.5px] mono font-medium" style={{ color: 'var(--accent)' }}>
                          {s.eta_clock}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}
        </aside>

        {/* Map */}
        <div className="relative">
          <RouteMap optimization={optimization} profile={profile} driverPositions={driverPositions} />
        </div>
      </div>
    </AppShell>
  );
}
