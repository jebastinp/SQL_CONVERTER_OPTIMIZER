import { useEffect, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { Zap, Upload, Users, Route as RouteIcon, TrendingUp, ArrowUpRight, ArrowRight } from 'lucide-react';

export default function DashboardPage() {
  const [stats, setStats] = useState({ orders: 0, drivers: 0, routes: [] as any[] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const [o, d, r] = await Promise.all([
        sb.from('orders').select('id', { count: 'exact', head: true }),
        sb.from('drivers').select('id', { count: 'exact', head: true }),
        sb.from('routes').select('*').order('created_at', { ascending: false }).limit(20),
      ]);
      setStats({ orders: o.count || 0, drivers: d.count || 0, routes: r.data || [] });
      setLoading(false);
    })();
  }, []);

  const completed = stats.routes.filter((r) => r.status === 'completed').length;
  const totalFuel = stats.routes.reduce((s, r: any) => s + Number(r.fuel_saved_gbp || 0), 0);
  const totalDistance = stats.routes.reduce((s, r: any) => s + Number(r.distance_km || 0), 0);

  return (
    <AppShell>
      <Topbar
        title="Overview"
        subtitle={`Welcome back · ${new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}`}
        actions={
          <Link href="/routes" className="btn btn-primary">
            <Zap size={13} strokeWidth={2} />Optimize now
          </Link>
        }
      />

      <div className="p-8 overflow-auto flex-1">
        {/* KPI cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-8 fade-up">
          <KPI label="Total orders" value={String(stats.orders)} icon={Upload} hint="All time" />
          <KPI label="Drivers" value={String(stats.drivers)} icon={Users} hint="In fleet" />
          <KPI label="Routes optimized" value={String(stats.routes.length)} icon={RouteIcon} hint={`${completed} completed`} />
          <KPI
            label="Fuel saved"
            value={`£${totalFuel.toFixed(0)}`}
            icon={TrendingUp}
            hint={`${totalDistance.toFixed(0)}km optimized`}
            highlight
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Recent routes */}
          <div className="lg:col-span-2 surface-elev p-6 fade-up">
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="serif text-[22px] tracking-tight">Recent routes</div>
                <div className="text-[12px] mt-1" style={{ color: 'var(--ink-3)' }}>
                  Last 20 optimizations
                </div>
              </div>
              <Link href="/analytics" className="btn btn-bare text-[12px]">
                View all <ArrowRight size={12} />
              </Link>
            </div>

            {loading ? (
              <div className="text-[13px] py-12 text-center" style={{ color: 'var(--ink-3)' }}>Loading…</div>
            ) : stats.routes.length === 0 ? (
              <div className="text-center py-16">
                <div
                  className="w-12 h-12 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                  style={{ background: 'var(--bg-soft)', color: 'var(--ink-mute)' }}
                >
                  <RouteIcon size={20} strokeWidth={1.5} />
                </div>
                <div className="text-[14px] font-medium mb-1.5" style={{ color: 'var(--ink-2)' }}>
                  No routes yet
                </div>
                <div className="text-[12.5px] mb-5" style={{ color: 'var(--ink-3)' }}>
                  Import orders and optimize to see results here.
                </div>
                <Link href="/orders" className="btn btn-ghost text-[12.5px]">
                  Import orders <ArrowRight size={13} />
                </Link>
              </div>
            ) : (
              <table className="data">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Distance</th>
                    <th>Duration</th>
                    <th>Saved</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.routes.slice(0, 10).map((r: any) => (
                    <tr key={r.id}>
                      <td style={{ color: 'var(--ink)' }}>
                        {new Date(r.created_at).toLocaleDateString('en-GB', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="mono">{Number(r.distance_km || 0).toFixed(1)} km</td>
                      <td className="mono">{Number(r.duration_minutes || 0).toFixed(0)}m</td>
                      <td className="mono" style={{ color: 'var(--good)' }}>
                        £{Number(r.fuel_saved_gbp || 0).toFixed(2)}
                      </td>
                      <td>
                        <span className={`pill ${r.status === 'completed' ? 'pill-ok' : r.status === 'in_progress' ? 'pill-info' : 'pill-neutral'}`}>
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Quick start */}
          <div className="surface-elev p-6 fade-up">
            <div className="serif text-[22px] tracking-tight mb-1">Quick start</div>
            <div className="text-[12px] mb-5" style={{ color: 'var(--ink-3)' }}>
              Four steps to your first optimized route
            </div>
            <div className="space-y-2">
              {[
                { n: 1, t: 'Add drivers', d: 'Set up your team', href: '/drivers', done: stats.drivers > 0 },
                { n: 2, t: 'Import orders', d: 'Upload CSV with customer info', href: '/orders', done: stats.orders > 0 },
                { n: 3, t: 'Optimize', d: 'AI assigns and sequences stops', href: '/routes', done: stats.routes.length > 0 },
                { n: 4, t: 'Track live', d: 'Share driver links', href: '/drivers' },
              ].map((s) => (
                <Link
                  key={s.n}
                  href={s.href}
                  className="surface-soft flex items-center gap-3 p-3.5 transition-all hover:translate-x-0.5 group"
                  style={{ background: s.done ? 'var(--accent-soft)' : 'var(--bg-soft)' }}
                >
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-[11.5px] font-semibold shrink-0"
                    style={{
                      background: s.done ? 'var(--accent)' : 'var(--bg-elev)',
                      color: s.done ? 'white' : 'var(--ink-2)',
                      border: s.done ? 'none' : '1px solid var(--stroke-2)',
                    }}
                  >
                    {s.done ? '✓' : s.n}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[13px] font-medium" style={{ color: 'var(--ink)' }}>{s.t}</div>
                    <div className="text-[11px] mt-0.5" style={{ color: 'var(--ink-3)' }}>{s.d}</div>
                  </div>
                  <ArrowUpRight
                    size={13}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ color: 'var(--ink-3)' }}
                  />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function KPI({ label, value, hint, icon: Icon, highlight }: {
  label: string; value: string; hint: string; icon: any; highlight?: boolean;
}) {
  return (
    <div className="surface-elev p-5 transition-all hover:-translate-y-0.5">
      <div className="flex items-start justify-between mb-4">
        <div
          className="text-[10.5px] uppercase tracking-[0.08em] font-medium"
          style={{ color: 'var(--ink-3)' }}
        >
          {label}
        </div>
        <Icon
          size={14}
          strokeWidth={1.75}
          style={{ color: highlight ? 'var(--accent)' : 'var(--ink-mute)' }}
        />
      </div>
      <div
        className="serif text-[38px] leading-none tracking-tight"
        style={{ color: highlight ? 'var(--accent)' : 'var(--ink)' }}
      >
        {value}
      </div>
      <div className="text-[11px] mt-2" style={{ color: 'var(--ink-3)' }}>
        {hint}
      </div>
    </div>
  );
}
