import { useEffect, useState } from 'react';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import type { Driver } from '@/lib/types';
import { Plus, Trash2, Copy, Smartphone, X, Check, Truck } from 'lucide-react';

const COLORS = ['#B5651D', '#2C5F3F', '#5B7BC2', '#8B4789', '#C2452E', '#3F7DA1', '#A87932', '#6B4D8F'];

export default function DriversPage() {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [adding, setAdding] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '', phone: '', vehicle: '', capacity: 30, color: COLORS[0],
  });

  async function refresh() {
    const { data } = await supabase().from('drivers').select('*').order('created_at', { ascending: false });
    setDrivers((data as Driver[]) || []);
    setLoading(false);
  }
  useEffect(() => { refresh(); }, []);

  async function addDriver(e: React.FormEvent) {
    e.preventDefault();
    setAdding(true);
    const sb = supabase();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) { setAdding(false); return; }
    await sb.from('drivers').insert({ ...form, user_id: user.id });
    setForm({
      name: '', phone: '', vehicle: '', capacity: 30,
      color: COLORS[(drivers.length + 1) % COLORS.length],
    });
    setShowAdd(false);
    await refresh();
    setAdding(false);
  }

  async function deleteDriver(id: string) {
    if (!confirm('Delete this driver?')) return;
    await supabase().from('drivers').delete().eq('id', id);
    await refresh();
  }

  function copyLink(token: string, id: string) {
    const url = `${location.origin}/driver/${token}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  return (
    <AppShell>
      <Topbar
        title="Drivers"
        subtitle={`${drivers.length} in fleet`}
        actions={
          <button onClick={() => setShowAdd(!showAdd)} className="btn btn-primary">
            <Plus size={13} />Add driver
          </button>
        }
      />

      <div className="p-8 overflow-auto flex-1 space-y-5">
        {showAdd && (
          <div className="surface-elev p-6 fade-up">
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="serif text-[20px] tracking-tight">New driver</div>
                <div className="text-[12px] mt-0.5" style={{ color: 'var(--ink-3)' }}>
                  Each driver gets a unique mobile app link
                </div>
              </div>
              <button onClick={() => setShowAdd(false)} className="btn btn-bare !p-1.5">
                <X size={14} />
              </button>
            </div>

            <form onSubmit={addDriver} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className="fld">Name</label>
                <input className="input" value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })} required
                  placeholder="Sarah Johnson" />
              </div>
              <div>
                <label className="fld">Phone</label>
                <input className="input" value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="07700 900123" />
              </div>
              <div>
                <label className="fld">Vehicle</label>
                <input className="input" value={form.vehicle}
                  onChange={(e) => setForm({ ...form, vehicle: e.target.value })}
                  placeholder="VW Crafter" />
              </div>
              <div>
                <label className="fld">Capacity</label>
                <input type="number" className="input" min={1} value={form.capacity}
                  onChange={(e) => setForm({ ...form, capacity: parseInt(e.target.value) || 30 })} />
              </div>
              <div className="md:col-span-2 lg:col-span-4">
                <label className="fld">Marker color</label>
                <div className="flex gap-2 flex-wrap">
                  {COLORS.map((c) => (
                    <button key={c} type="button" onClick={() => setForm({ ...form, color: c })}
                      className="w-9 h-9 rounded-xl transition-all"
                      style={{
                        background: c,
                        transform: form.color === c ? 'scale(1.1)' : 'scale(1)',
                        boxShadow: form.color === c
                          ? '0 0 0 2px var(--bg), 0 0 0 4px var(--ink), var(--shadow-sm)'
                          : 'var(--shadow-xs)',
                      }} />
                  ))}
                </div>
              </div>
              <div className="md:col-span-2 lg:col-span-4 flex justify-end gap-2">
                <button type="button" onClick={() => setShowAdd(false)} className="btn btn-ghost">
                  Cancel
                </button>
                <button type="submit" disabled={adding} className="btn btn-primary">
                  {adding ? 'Adding…' : 'Add driver'}
                </button>
              </div>
            </form>
          </div>
        )}

        {loading ? (
          <div className="text-[13px] py-12 text-center" style={{ color: 'var(--ink-3)' }}>Loading…</div>
        ) : drivers.length === 0 ? (
          <div className="surface-elev p-16 text-center fade-up">
            <div
              className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center"
              style={{ background: 'var(--bg-soft)', color: 'var(--ink-mute)' }}
            >
              <Truck size={22} strokeWidth={1.5} />
            </div>
            <div className="serif text-[22px] mb-1.5">No drivers yet</div>
            <div className="text-[12.5px] mb-5" style={{ color: 'var(--ink-3)' }}>
              Add your first driver to start optimizing routes.
            </div>
            <button onClick={() => setShowAdd(true)} className="btn btn-primary mx-auto">
              <Plus size={13} />Add your first driver
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {drivers.map((d) => {
              const initials = d.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase();
              return (
                <div key={d.id} className="surface-elev p-5 fade-up transition-transform hover:-translate-y-0.5">
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center font-semibold text-white text-[14px] shrink-0"
                      style={{ background: d.color }}
                    >
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-[14px] truncate" style={{ color: 'var(--ink)' }}>{d.name}</div>
                      <div className="text-[11.5px] truncate mt-0.5" style={{ color: 'var(--ink-3)' }}>
                        {d.vehicle || 'Vehicle not set'}
                      </div>
                    </div>
                    <button onClick={() => deleteDriver(d.id)} className="btn-danger-ghost p-1.5 rounded-md">
                      <Trash2 size={13} />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mb-4">
                    <div className="surface-soft p-3 text-center">
                      <div className="serif text-[22px] leading-none">{d.capacity}</div>
                      <div className="text-[9.5px] uppercase tracking-[0.1em] mt-1.5 font-medium" style={{ color: 'var(--ink-3)' }}>
                        Capacity
                      </div>
                    </div>
                    <div className="surface-soft p-3 text-center">
                      <div className="mono text-[13px] truncate" title={d.phone}>{d.phone || '—'}</div>
                      <div className="text-[9.5px] uppercase tracking-[0.1em] mt-1.5 font-medium" style={{ color: 'var(--ink-3)' }}>
                        Phone
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => copyLink(d.access_token, d.id)}
                    className="btn btn-ghost w-full !py-2 !text-[11.5px]"
                  >
                    {copiedId === d.id ? (
                      <>
                        <Check size={12} style={{ color: 'var(--good)' }} /> Copied to clipboard
                      </>
                    ) : (
                      <>
                        <Smartphone size={12} /> Copy driver app link <Copy size={11} />
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppShell>
  );
}
