"""
RouteFlow AI — FastAPI Backend
==============================
Run:
    pip install -r requirements.txt
    cp .env.example .env  # fill in values
    uvicorn main:app --reload --port 8000
"""
import os
import time
from typing import List, Optional
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

from optimizer import optimize_routes, OptimizeRequest, OptimizeResponse
from geocode import geocode_address, GeocodeResult
from db import get_supabase, verify_user_jwt

load_dotenv(dotenv_path=Path(__file__).with_name('.env'), override=True)

ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 RouteFlow backend starting")
    print(f"   CORS origins: {ALLOWED_ORIGINS}")
    print(f"   Supabase URL: {os.getenv('SUPABASE_URL', '(not set)')[:40]}…")
    print(f"   ORS API key:  {'set' if os.getenv('ORS_API_KEY') else 'NOT SET — geocoding will fail'}")
    yield


app = FastAPI(title="RouteFlow AI", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# AUTH DEPENDENCY
# ============================================================

async def current_user(authorization: Optional[str] = Header(None)) -> dict:
    """Extract user from Supabase JWT. Returns {id, email}."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing or invalid Authorization header")
    token = authorization.replace("Bearer ", "")
    user = verify_user_jwt(token)
    if not user:
        raise HTTPException(401, "Invalid token")
    return user


# ============================================================
# ENDPOINTS
# ============================================================

@app.get("/")
def root():
    return {
        "service": "RouteFlow AI",
        "version": "1.0.0",
        "endpoints": ["/optimize", "/geocode", "/health"],
        "docs": "/docs",
    }


@app.get("/health")
def health():
    from optimizer import HAS_ORTOOLS
    return {
        "status": "ok",
        "ortools": HAS_ORTOOLS,
        "ors_configured": bool(os.getenv("ORS_API_KEY")),
        "supabase_configured": bool(os.getenv("SUPABASE_URL")),
    }


# ---------- OPTIMIZE ----------

@app.post("/optimize", response_model=OptimizeResponse)
async def optimize(req: OptimizeRequest, user: dict = Depends(current_user)):
    """
    Solve VRP for given orders + drivers + depot.
    Authenticated. Does NOT persist — caller saves the result to Supabase.
    """
    t0 = time.time()
    if not req.orders:
        raise HTTPException(400, "No orders provided")
    if not req.drivers:
        raise HTTPException(400, "No drivers provided")

    result = optimize_routes(req)
    result.optimization_time_ms = round((time.time() - t0) * 1000, 1)
    return result


# ---------- GEOCODE ----------

class GeocodeRequest(BaseModel):
    address: str = Field(..., min_length=2)
    postcode: Optional[str] = None
    country: str = "GB"


class GeocodeBatchRequest(BaseModel):
    items: List[GeocodeRequest]


@app.post("/geocode", response_model=GeocodeResult)
async def geocode_one(req: GeocodeRequest, user: dict = Depends(current_user)):
    """Single-address geocode with database cache."""
    result = await geocode_address(req.address, req.postcode, req.country)
    if not result:
        raise HTTPException(404, "Could not geocode this address")
    return result


@app.post("/geocode/batch")
async def geocode_batch(req: GeocodeBatchRequest, user: dict = Depends(current_user)):
    """Batch geocode (used during CSV import)."""
    results = []
    for item in req.items:
        try:
            r = await geocode_address(item.address, item.postcode, item.country)
            results.append({"input": item.dict(), "result": r.dict() if r else None, "error": None})
        except Exception as e:
            results.append({"input": item.dict(), "result": None, "error": str(e)})
    return {"results": results, "count": len(results)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8000)), reload=True)
