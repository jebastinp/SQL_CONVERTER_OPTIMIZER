'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';
import Sidebar from '@/components/Sidebar';

export default function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [profile, setProfile] = useState<{ full_name?: string; email: string } | null>(null);

  useEffect(() => {
    let active = true;
    const sb = createClient();

    sb.auth.getUser().then(async ({ data: { user } }) => {
      if (!active) return;
      if (!user) {
        router.replace('/login');
        return;
      }

      const { data: profileRow } = await sb.from('profiles').select('*').eq('id', user.id).single();
      if (!active) return;
      setProfile(profileRow || { email: user.email || '' });
    });

    return () => {
      active = false;
    };
  }, [router]);

  if (!profile) {
    return <div className="min-h-screen" />;
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar profile={profile} />
      <main className="flex-1 flex flex-col overflow-hidden">
        {children}
      </main>
    </div>
  );
}
