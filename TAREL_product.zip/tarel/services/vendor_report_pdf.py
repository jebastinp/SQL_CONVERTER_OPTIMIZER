import os
import base64
from datetime import datetime
from flask import current_app, render_template_string

VENDOR_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4; margin: 18mm; }
  body { font-family: Arial, sans-serif; font-size: 12px; margin: 0; padding: 20px; color: #1d2821; background: #ffffff; }
  .header { text-align: center; border-bottom: 3px solid #d8ded3; padding-bottom: 15px; margin-bottom: 18px; }
  .header-logo { width: 160px; height: 160px; object-fit: contain; display: block; margin: 0 auto 8px; }
  .header-title { font-size: 24px; font-weight: 900; letter-spacing: 3px; color: #2e4236; margin: 0; }
  .header-subtitle { font-size: 12px; color: #6b746e; letter-spacing: 1px; text-transform: uppercase; }
  .meta { display: flex; justify-content: space-between; gap: 12px; margin: 16px 0 10px; font-size: 11px; color: #6b746e; }
  .section-title { font-size: 13px; font-weight: 800; color: #2e4236; text-transform: uppercase; letter-spacing: 1px; margin: 18px 0 8px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  th { background: #eaf0e5; color: #2e4236; padding: 8px; text-align: left; font-size: 11px; }
  td { padding: 7px 8px; border-bottom: 1px solid #d8ded3; vertical-align: top; }
  .total-row { background: #f5f7f1; font-weight: bold; }
  .total-row td { padding: 10px 8px; }
  .grand { margin-top: 14px; background: #2e4236; color: #fff; padding: 12px 14px; border-radius: 8px; font-size: 14px; font-weight: 700; }
  .muted { color: #6b746e; }
  .empty { color: #6b746e; font-style: italic; padding: 10px 0; }
  .footer { margin-top: 18px; text-align: center; color: #6b746e; font-size: 10px; border-top: 1px solid #d8ded3; padding-top: 10px; }
</style>
</head>
<body>
<div class="header">
  {% if logo_base64 %}<img class="header-logo" src="data:image/png;base64,{{ logo_base64 }}" alt="TAREL logo">{% endif %}
  <div class="header-title">VENDOR REPORT</div>
  <div class="header-subtitle">{{ report_label }}</div>
</div>

<div class="meta">
  <div><strong>Delivery date:</strong> {{ delivery_date }}</div>
  <div><strong>Generated:</strong> {{ generated_at }}</div>
</div>

<div class="section-title">{{ section_label }}</div>
{% if rows %}
<table>
  <thead>
    <tr><th>Product</th><th>Total kg</th><th>Orders</th>{% if include_customers %}<th>Customers</th>{% endif %}</tr>
  </thead>
  <tbody>
    {% for it in rows %}
    <tr>
      <td>{{ it.fish_name }}</td>
      <td>{{ "%.1f"|format(it.total_kg) }}kg</td>
      <td>{{ it.order_count }}</td>
      {% if include_customers %}<td class="muted">{{ it.customers[:4]|join(', ') }}{% if it.customers|length > 4 %} +{{ it.customers|length - 4 }} more{% endif %}</td>{% endif %}
    </tr>
    {% endfor %}
    <tr class="total-row">
      <td>Total</td>
      <td>{{ "%.1f"|format(total_kg) }}kg</td>
      <td>{{ total_orders }}</td>
      {% if include_customers %}<td></td>{% endif %}
    </tr>
  </tbody>
</table>
{% else %}
<div class="empty">No items for this section.</div>
{% endif %}

<div class="grand">Grand Total: {{ "%.1f"|format(total_kg) }}kg</div>
<div class="footer">TAREL Fish &amp; Meat Delivery | Vendor report</div>
</body>
</html>
"""


def _logo_base64():
    logo_path = os.path.join(current_app.root_path, 'images', 'logo.png')
    if not os.path.exists(logo_path):
        return ''
    with open(logo_path, 'rb') as logo_file:
        return base64.b64encode(logo_file.read()).decode('ascii')


def _render_rows(report_type, fish_totals, meat_totals):
  if report_type == 'fish':
    return fish_totals, 'Fish Orders', False
  if report_type == 'meat':
    return meat_totals, 'Meat Orders', False
  rows = list(fish_totals) + list(meat_totals)
  return rows, 'Fish and Meat Orders', False


def generate_vendor_pdf(fish_totals, meat_totals, delivery_date, generated_at, week_id, report_type='both'):
  try:
    from weasyprint import HTML
  except Exception as exc:
    return None, f'WeasyPrint unavailable: {exc}'

  rows, section_label, include_customers = _render_rows(report_type, fish_totals, meat_totals)
  total_kg = sum(float(item.get('total_kg') or 0) for item in rows)
  total_orders = sum(int(item.get('order_count') or 0) for item in rows)
  report_label = {
    'fish': 'Fish Only',
    'meat': 'Meat Only',
    'both': 'Fish + Meat',
  }.get(report_type, 'Fish + Meat')

  html = render_template_string(
    VENDOR_HTML,
    rows=rows,
    section_label=section_label,
    include_customers=include_customers,
    total_kg=total_kg,
    total_orders=total_orders,
    delivery_date=delivery_date,
    generated_at=generated_at,
    logo_base64=_logo_base64(),
    report_label=report_label,
  )

  pdf_dir = os.path.join(current_app.root_path, 'static', 'vendor_reports')
  os.makedirs(pdf_dir, exist_ok=True)
  filename = f"vendor_report_{report_type}_{week_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
  path = os.path.join(pdf_dir, filename)
  try:
    HTML(string=html).write_pdf(path)
    return path, None
  except Exception as e:
    return None, str(e)
