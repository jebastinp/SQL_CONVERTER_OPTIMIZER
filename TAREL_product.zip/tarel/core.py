"""
TAREL core business logic — framework-free so it can be unit-tested offline.

Covers the money-critical and access-critical decisions:
  - line totals (half/one-kg two-price rule)
  - freight: per-fish price if set, else global rate  (your decision)
  - delivery charge rules (Inverness / small-order / free)
  - invoice total assembly
  - order edit recalculation
  - refund vs extra-charge determination on edits
  - refund state machine
  - per-user page permissions
These functions take plain values/dicts so app.py can call them with ORM objects
mapped to simple attributes, and tests can call them with dicts.
"""
from decimal import Decimal, ROUND_HALF_UP

# ----------------------------------------------------------------------
# Money helpers
# ----------------------------------------------------------------------
def money(x):
    """Round to 2dp using banker-safe half-up, return float."""
    return float(Decimal(str(x or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


# ----------------------------------------------------------------------
# Line total — the half-kg / one-kg two-price rule
# ----------------------------------------------------------------------
def line_total(one_kg_price, half_kg_price, selling_price, qty_kg):
    """
    Mirror of the app's _calc_line_total but explicit and testable.
    - whole kilos charged at one_kg_price
    - a remainder of >= 0.5 adds one half_kg_price
    - remainder < 0.5 adds nothing (matches existing behaviour)
    Falls back: one_kg from selling_price; half_kg from one_kg/2.
    """
    one_price = float(one_kg_price or 0)
    half_price = float(half_kg_price or 0)
    if not one_price:
        one_price = float(selling_price or 0)
    if not half_price:
        half_price = round(one_price / 2, 2) if one_price else 0
    qty = float(qty_kg or 0)
    whole = int(qty)
    remainder = qty - whole
    total = (whole * one_price) + (half_price if remainder >= 0.5 else 0)
    return money(total)


# ----------------------------------------------------------------------
# Freight — per-fish if set, else global   (your chosen rule)
# ----------------------------------------------------------------------
def item_freight(is_fish, quantity_kg, per_fish_freight, global_rate):
    """
    Freight for ONE line item.
    - meat (is_fish False) -> 0
    - if the product has its own freight_price set (>0) -> use it per kg
    - else -> use the global freight rate per kg
    """
    if not is_fish:
        return 0.0
    qty = float(quantity_kg or 0)
    pf = per_fish_freight
    if pf is not None and float(pf or 0) > 0:
        rate = float(pf)
    else:
        rate = float(global_rate or 0)
    return money(qty * rate)


def order_freight(items, global_rate):
    """
    items: list of dicts with keys: is_fish, quantity_kg, per_fish_freight
    Sums per-item freight using the per-fish-else-global rule.
    """
    return money(sum(
        item_freight(it.get("is_fish", True),
                     it.get("quantity_kg", 0),
                     it.get("per_fish_freight"),
                     global_rate)
        for it in items
    ))


# ----------------------------------------------------------------------
# Delivery charge
# ----------------------------------------------------------------------
def delivery_charge(route, subtotal, rules):
    """
    rules: dict with small_order_threshold, small_order_charge, inverness_charge
    Inverness -> flat inverness_charge
    else subtotal < threshold -> small_order_charge
    else -> 0
    """
    if route == "Inverness":
        return money(rules.get("inverness_charge", 0.0))
    if float(subtotal) < float(rules.get("small_order_threshold", 0)):
        return money(rules.get("small_order_charge", 0.0))
    return 0.0


# ----------------------------------------------------------------------
# Invoice assembly
# ----------------------------------------------------------------------
def invoice_totals(items, route, rules, global_freight_rate):
    """
    items: list of dicts: one_kg_price, half_kg_price, selling_price,
                          quantity_kg, is_fish, per_fish_freight
    Returns dict: subtotal, freight, delivery, total (all 2dp floats).
    """
    subtotal = 0.0
    for it in items:
        # if a line_total is supplied use it, else compute
        if it.get("line_total") is not None:
            subtotal += float(it["line_total"])
        else:
            subtotal += line_total(it.get("one_kg_price"), it.get("half_kg_price"),
                                   it.get("selling_price"), it.get("quantity_kg"))
    subtotal = money(subtotal)
    freight = order_freight(items, global_freight_rate)
    delivery = delivery_charge(route, subtotal, rules)
    total = money(subtotal + freight + delivery)
    return {"subtotal": subtotal, "freight": freight,
            "delivery": delivery, "total": total}


# ----------------------------------------------------------------------
# Edit recalculation -> extra charge or refund
# ----------------------------------------------------------------------
def settlement_after_edit(old_total, new_total, already_paid):
    """
    Determine what happens after an order is edited.
    already_paid: total money actually received & verified so far.
    Returns dict:
        new_total, difference, action in {none, collect_extra, refund},
        amount (positive magnitude for the action)
    Rules:
      - If nothing paid yet -> just update invoice, action none
      - If new_total > already_paid -> collect_extra (new_total - already_paid)
      - If new_total < already_paid -> refund (already_paid - new_total)
      - equal -> none
    """
    old_total = money(old_total)
    new_total = money(new_total)
    paid = money(already_paid)
    diff = money(new_total - old_total)
    if paid <= 0:
        return {"new_total": new_total, "difference": diff,
                "action": "none", "amount": 0.0}
    if new_total > paid:
        return {"new_total": new_total, "difference": diff,
                "action": "collect_extra", "amount": money(new_total - paid)}
    if new_total < paid:
        return {"new_total": new_total, "difference": diff,
                "action": "refund", "amount": money(paid - new_total)}
    return {"new_total": new_total, "difference": diff,
            "action": "none", "amount": 0.0}


# ----------------------------------------------------------------------
# Refund state machine
# ----------------------------------------------------------------------
REFUND_STATES = ["pending", "sent", "confirmed"]

def refund_advance(current_state):
    """
    pending -> sent (admin marks refund sent)
    sent -> confirmed (customer confirms receipt)
    confirmed -> confirmed (terminal)
    """
    if current_state == "pending":
        return "sent"
    if current_state == "sent":
        return "confirmed"
    if current_state == "confirmed":
        return "confirmed"
    raise ValueError(f"unknown refund state: {current_state}")

def refund_is_settled(state):
    """Order is only settled/closed once the customer confirms receipt."""
    return state == "confirmed"


# ----------------------------------------------------------------------
# Per-user page permissions
# ----------------------------------------------------------------------
ALL_SECTIONS = ["orders", "availability", "customers", "reports",
                "finance", "fish", "drivers", "inbox", "settings", "audit"]
DEFAULT_TEAM_SECTIONS = ["orders", "availability", "customers"]

def parse_permissions(raw):
    """raw stored as comma string or list -> normalized list."""
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return [s.strip() for s in raw if s and s.strip()]
    return [s.strip() for s in str(raw).split(",") if s.strip()]

def can_access(user_role, user_permissions, section):
    """
    Admin can access everything.
    Others only if section in their permission list.
    """
    if user_role == "admin":
        return True
    return section in parse_permissions(user_permissions)

def serialize_permissions(sections):
    """list -> stored comma string, de-duped, only valid sections."""
    seen, out = set(), []
    for s in sections:
        s = s.strip()
        if s in ALL_SECTIONS and s not in seen:
            seen.add(s); out.append(s)
    return ",".join(out)


# ----------------------------------------------------------------------
# Unpaid invoice classification (for reminders)
# ----------------------------------------------------------------------
UNPAID_STATUSES = {"invoice_sent", "payment_pending"}
PAID_OR_INPROGRESS = {"payment_received", "payment_verified"}

def is_unpaid(order_status):
    """An order counts as unpaid (remind-able) only in these statuses."""
    return order_status in UNPAID_STATUSES
