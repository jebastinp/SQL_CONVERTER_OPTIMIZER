-- Migration 003: new features (permissions, fish fields, drivers, refunds, audit log)
-- Safe to run on Postgres (Supabase) or SQLite. Run once.

-- 1. Per-user page permissions
ALTER TABLE users ADD COLUMN permissions TEXT DEFAULT '';

-- 2. Fish Master: per-product freight, additional cost, vendor name
ALTER TABLE fish_master ADD COLUMN freight_price NUMERIC(10,2);
ALTER TABLE fish_master ADD COLUMN additional_cost NUMERIC(10,2);
ALTER TABLE fish_master ADD COLUMN vendor_name VARCHAR(150);

-- 3. Drivers
CREATE TABLE IF NOT EXISTS drivers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(30),
    vehicle_number VARCHAR(30),
    start_location VARCHAR(250),
    end_location VARCHAR(250),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Refunds
CREATE TABLE IF NOT EXISTS refunds (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id),
    customer_id INTEGER REFERENCES customers(id),
    amount NUMERIC(10,2),
    reason VARCHAR(250),
    bank_details TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    approved_by INTEGER REFERENCES users(id),
    sent_by INTEGER REFERENCES users(id),
    sent_at TIMESTAMP,
    customer_confirmed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Audit log
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    username VARCHAR(50),
    action VARCHAR(100),
    entity VARCHAR(50),
    entity_id VARCHAR(30),
    detail TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Note: on SQLite use INTEGER PRIMARY KEY AUTOINCREMENT instead of SERIAL.
-- If you let SQLAlchemy create tables (db.create_all()), tables 3-5 are made
-- automatically; you then only need the ALTER statements (1-2) for existing DBs.
