#!/usr/bin/env python3
"""
Run the full TAREL test suite (core logic + integration/services).
Usage:  python run_tests.py
On your own machine, first:  pip install -r requirements.txt
(so SQLAlchemy is present and the DB/model tests also run).
"""
import subprocess, sys

suites = ["test_core.py", "test_integration.py"]
failed = 0
for s in suites:
    print("\n" + "#"*64)
    print("# RUNNING", s)
    print("#"*64)
    rc = subprocess.call([sys.executable, s])
    if rc != 0:
        failed += 1
print("\n" + "="*64)
print("OVERALL:", "ALL SUITES PASSED" if failed == 0 else f"{failed} SUITE(S) HAD FAILURES")
print("="*64)
sys.exit(1 if failed else 0)
