#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 /path/to/backup.dump" >&2
  exit 1
fi

: "${DATABASE_URL:?DATABASE_URL must be set}"
pg_restore --clean --if-exists --no-owner --dbname="$DATABASE_URL" "$1"
