#!/usr/bin/env bash
set -euo pipefail

BACKUP_DIR="$(cd "$(dirname "$0")/../../db" && pwd)/backups"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

: "${DATABASE_URL:?DATABASE_URL must be set}"
pg_dump "$DATABASE_URL" -Fc -f "$BACKUP_DIR/tarel_${TIMESTAMP}.dump"
