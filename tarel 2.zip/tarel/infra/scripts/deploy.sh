#!/usr/bin/env bash
# =============================================================================
# TAREL — Production Deploy Script
# =============================================================================
# Called by the GitHub Actions deploy workflow (infra/.github/workflows/deploy.yml).
# Run from the repo root on the production server.
# =============================================================================
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

echo "==> Pulling latest changes..."
git pull --rebase

echo "==> Building production images..."
docker compose -f docker-compose.yml -f docker-compose.prod.yml build --pull

echo "==> Applying rolling update (zero-downtime where possible)..."
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --remove-orphans

echo "==> Waiting for backend health check..."
RETRIES=30
until docker compose exec backend python -c \
    "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" \
    > /dev/null 2>&1; do
    RETRIES=$((RETRIES - 1))
    if [ "$RETRIES" -le 0 ]; then
        echo "ERROR: Backend did not become healthy in time."
        docker compose logs --tail=50 backend
        exit 1
    fi
    echo "   Waiting for backend... ($RETRIES retries left)"
    sleep 3
done

echo "==> Deploy complete. All services healthy."
docker compose ps
