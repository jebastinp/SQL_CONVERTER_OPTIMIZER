import Link from 'next/link'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="py-8 text-sm text-brand-dark">
      <div className="mx-auto flex max-w-6xl items-center justify-center gap-3 px-4">
        <p>© {year} Tarel |</p>
        <span className="text-brand-dark/30" aria-hidden>
          
        </span>
        <Link
          href="/legal"
          className="font-medium text-brand-dark/70 underline-offset-4 hover:text-brand-dark hover:underline"
        >
          Legal
        </Link>
      </div>
    </footer>
  )
}
