'use client'

import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Suspense, useMemo } from 'react'
import type { ReactNode } from 'react'

import Footer from '@/components/Footer'
import MarqueeBanner from '@/components/MarqueeBanner'
import Navbar from '@/components/Navbar'
import UserGuard from '@/components/UserGuard'
import { CartProvider } from '@/providers/CartProvider'
import { useAuth } from '@/providers/AuthProvider'
import logoImage from '@/images/logo.png'

type AppShellProps = {
  children: ReactNode
  guard?: boolean
  mode?: 'public' | 'user'
}

export default function AppShell({ children, guard = false, mode = 'public' }: AppShellProps) {
  const content = guard ? <UserGuard>{children}</UserGuard> : children

  return (
    <CartProvider>
      {mode === 'user' ? <AccountScaffold>{content}</AccountScaffold> : <PublicScaffold>{content}</PublicScaffold>}
    </CartProvider>
  )
}

type AccountNavItem = {
  href: string
  label: string
  description?: string
}

const ACCOUNT_NAV: AccountNavItem[] = [
  {
    href: '/user',
    label: 'Overview',
    description: 'Stay on top of deliveries and recent activity.',
  },
  {
    href: '/user',
    label: 'Profile',
    description: 'Manage your personal info and password.',
  },
  {
    href: '/user/orders',
    label: 'Orders',
    description: 'Track purchases, totals, and delivery slots.',
  },
]

function PublicScaffold({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const isHomePage = pathname === '/'

  return (
    <div className="flex min-h-screen flex-col">
      {!isHomePage && (
        <Suspense fallback={<div className="h-24 bg-brand-beige/50" />}>
          <Navbar />
        </Suspense>
      )}
      <MarqueeBanner />
      <main className={isHomePage ? 'flex-1' : 'mx-auto w-full max-w-6xl flex-1 p-4'}>{children}</main>
      <Footer />
    </div>
  )
}

function AccountScaffold({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const currentPath = pathname ?? ''
  const { user, logout } = useAuth()
  const isOverviewPage = currentPath === '/user'

  const initials = useMemo(() => {
    if (!user) return ''
    const parts = user.name.trim().split(' ')
    const letters = parts.slice(0, 2).map((part) => part.charAt(0).toUpperCase())
    return letters.join('') || user.email.charAt(0).toUpperCase()
  }, [user])

  return (
    <div className="min-h-screen bg-brand-beige/60">
      {/* Header matching main Navbar style */}
      <header className="sticky top-0 z-50 border-b border-black/5 bg-gradient-to-b from-brand-beige via-white to-white shadow-[0_6px_18px_rgba(0,0,0,0.08)] backdrop-blur supports-[backdrop-filter]:bg-white/90">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4">
          {/* Logo and title */}
          <div className="flex items-center gap-3 min-w-fit">
            <Link href="/categories" className="hover:opacity-80 transition">
              <Image 
                src={logoImage} 
                alt="Tarel Logo" 
                width={220} 
                height={72}
                className="h-11 sm:h-12 w-auto object-contain"
              />
            </Link>
            <div className="hidden sm:block">
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-brand-dark/60">Customer Hub</p>
              <h1 className="text-base font-semibold text-brand-dark">Your Tarel account</h1>
            </div>
          </div>

          {/* User menu and buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {user && (
              <div className="hidden sm:inline-flex items-center gap-2 rounded-full border border-brand-dark/15 bg-white px-3 py-1.5 text-xs">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-dark text-xs font-semibold uppercase text-white">
                  {initials}
                </span>
                <div className="text-left">
                  <p className="text-xs font-medium text-brand-dark">{user.name}</p>
                  <p className="text-xs text-brand-dark/60 truncate">{user.email}</p>
                </div>
              </div>
            )}
            <button
              type="button"
              onClick={logout}
              className="rounded-full border border-brand-dark/15 bg-white px-3 sm:px-4 py-1.5 text-xs font-medium text-brand-dark transition hover:border-brand-dark hover:bg-brand-dark hover:text-white whitespace-nowrap"
            >
              Sign out
            </button>
            <Link
              href="/categories"
              className="rounded-full border border-brand-dark/15 bg-brand-dark text-white px-3 sm:px-4 py-1.5 text-xs font-medium transition hover:opacity-90 whitespace-nowrap"
            >
              ← Browse
            </Link>
          </div>
        </div>
      </header>

      {/* Horizontal tab navigation with curved pill effect */}
      <div className="border-b border-brand-dark/10 bg-white">
        <div className="mx-auto flex max-w-6xl px-4 py-3">
          <nav className="flex gap-2">
            {ACCOUNT_NAV.map((item) => {
              let isActive = false
              if (item.href === '/user') {
                isActive = currentPath === '/user'
              } else {
                isActive = currentPath.startsWith(item.href)
              }
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`px-5 py-2.5 rounded-lg text-sm font-semibold transition ${
                    isActive
                      ? 'bg-brand-dark text-white shadow-md'
                      : 'bg-brand-beige/40 text-brand-dark hover:bg-brand-beige/60'
                  }`}
                  title={item.description}
                >
                  {item.label}
                </Link>
              )
            })}
          </nav>
        </div>
      </div>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <div className="space-y-6">{children}</div>
      </main>

      {/* Footer only on overview */}
      {isOverviewPage && <Footer />}
    </div>
  )
}
