'use client'

import { useState, useRef, useEffect } from 'react'

type AddressFeature = {
  properties: {
    formatted: string
    housenumber?: string
    street?: string
    city?: string
    town?: string
    village?: string
    postcode?: string
    country?: string
  }
}

type AddressAutocompleteProps = {
  value: string
  onChange: (value: string) => void
  onAddressSelect: (address: {
    line1: string
    city: string
    postcode: string
    country: string
  }) => void
  placeholder?: string
  className?: string
  apiKey: string
}

export default function AddressAutocomplete({
  value,
  onChange,
  onAddressSelect,
  placeholder = 'Start typing your address...',
  className = '',
  apiKey,
}: AddressAutocompleteProps) {
  const [suggestions, setSuggestions] = useState<AddressFeature[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const suggestionsRef = useRef<HTMLDivElement>(null)
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null)

  // Fetch suggestions from Geoapify
  const fetchSuggestions = async (query: string) => {
    if (query.length < 3) {
      setSuggestions([])
      setShowSuggestions(false)
      return
    }

    setIsLoading(true)
    try {
      const url = new URL('https://api.geoapify.com/v1/geocode/autocomplete')
      url.searchParams.append('text', query)
      url.searchParams.append('filter', 'countrycode:gb')
      url.searchParams.append('limit', '5')
      url.searchParams.append('apiKey', apiKey)

      const res = await fetch(url.toString())
      const data = await res.json()

      if (data.features && Array.isArray(data.features)) {
        setSuggestions(data.features)
        setShowSuggestions(data.features.length > 0)
      } else {
        setSuggestions([])
        setShowSuggestions(false)
      }
    } catch (error) {
      console.error('Geoapify autocomplete error:', error)
      setSuggestions([])
      setShowSuggestions(false)
    } finally {
      setIsLoading(false)
    }
  }

  // Debounced input handler
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    onChange(newValue)

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }

    debounceTimerRef.current = setTimeout(() => {
      fetchSuggestions(newValue)
    }, 300)
  }

  // Handle suggestion selection
  const handleSelectSuggestion = (feature: AddressFeature) => {
    const p = feature.properties
    const formattedAddress = p.formatted || ''
    const street = `${p.housenumber || ''} ${p.street || ''}`.trim()
    const city = p.city || p.town || p.village || ''
    const postcode = p.postcode || ''
    const country = p.country || ''

    onChange(formattedAddress)
    onAddressSelect({ line1: street, city, postcode, country })
    setShowSuggestions(false)
  }

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        inputRef.current &&
        !inputRef.current.contains(e.target as Node) &&
        suggestionsRef.current &&
        !suggestionsRef.current.contains(e.target as Node)
      ) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  return (
    <div className="relative w-full">
      <input
        ref={inputRef}
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={handleInputChange}
        autoComplete="off"
        className={className}
      />

      {/* Suggestions dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div
          ref={suggestionsRef}
          className="absolute top-full left-0 right-0 z-50 mt-1 max-h-48 overflow-y-auto rounded-lg border border-white/20 bg-white/10 shadow-lg backdrop-blur-sm"
        >
          {suggestions.map((feature, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSelectSuggestion(feature)}
              className="w-full border-b border-white/10 px-4 py-3 text-left text-sm text-white transition hover:bg-white/20"
            >
              <div className="font-medium">{feature.properties.formatted}</div>
            </button>
          ))}
        </div>
      )}

      {isLoading && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/20 border-t-white" />
        </div>
      )}
    </div>
  )
}
