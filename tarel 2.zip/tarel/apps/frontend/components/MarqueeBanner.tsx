const MARQUEE_ITEMS = [
  'Fresh catch delivered in Edinburgh',
  'Order today, enjoy this week',
  'Tarel seafood and dry fish',
]

export default function MarqueeBanner() {
  const items = [...MARQUEE_ITEMS, ...MARQUEE_ITEMS]

  return (
    <div className="bg-brand-dark text-brand-beige">
      <div className="relative overflow-hidden">
        <div className="flex w-max gap-10 py-2 text-[0.65rem] font-semibold uppercase tracking-[0.35em] animate-marquee">
          {items.map((item, index) => (
            <span key={`${item}-${index}`} className="whitespace-nowrap">
              {item}
            </span>
          ))}
        </div>
      </div>
      <style jsx>{`
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-marquee {
          animation: marquee 20s linear infinite;
        }
      `}</style>
    </div>
  )
}
