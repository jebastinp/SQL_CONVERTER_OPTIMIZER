'use client'

import { useState } from 'react'
import Image from 'next/image'
import logoImage from '@/images/logo.png'
import AddressAutocomplete from '@/components/AddressAutocomplete'
import { buildApiUrl } from '@/lib/api'
import { parseErrorMessage } from '@/lib/errors'

const GEOAPIFY_API_KEY = '7a6a8f0943914da3b07d38f1c7f56be6'

type AuthMode = 'login' | 'signup'

type FormData = {
  name?: string
  phone?: string
  email: string
  password: string
  address?: {
    line1: string
    locality: string
    city: string
    postcode: string
  }
}

type AuthHeroProps = {
  mode: AuthMode
  onSubmit: (values: FormData) => Promise<void>
  googleAuthUrl?: string
}

export default function AuthHero({ mode: initialMode, onSubmit, googleAuthUrl }: AuthHeroProps) {
  const [mode, setMode] = useState<AuthMode>(initialMode)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>('')
  const [sendingCode, setSendingCode] = useState(false)
  const [codeSent, setCodeSent] = useState(false)
  const [code, setCode] = useState('')
  const [resendIn, setResendIn] = useState(0)
  const [otpStatus, setOtpStatus] = useState<'success' | 'error' | ''>('')
  const [otpMessage, setOtpMessage] = useState('')
  const [resetOpen, setResetOpen] = useState(false)
  const [resetCodeSent, setResetCodeSent] = useState(false)
  const [resetCode, setResetCode] = useState('')
  const [resetResendIn, setResetResendIn] = useState(0)
  const [resetSendingCode, setResetSendingCode] = useState(false)
  const [resettingPassword, setResettingPassword] = useState(false)
  const [resetStatus, setResetStatus] = useState<'success' | 'error' | ''>('')
  const [resetMessage, setResetMessage] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [formData, setFormData] = useState<FormData>({
    name: mode === 'signup' ? '' : undefined,
    phone: mode === 'signup' ? '' : undefined,
    email: '',
    password: '',
    address: mode === 'signup' ? {
      line1: '',
      locality: '',
      city: 'Edinburgh',
      postcode: '',
    } : undefined,
  })

  const handleFieldChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleAddressChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      address: prev.address ? { ...prev.address, [field]: value } : undefined,
    }))
  }

  const handleAddressSelect = (address: {
    line1: string
    city: string
    postcode: string
    country: string
  }) => {
    setFormData((prev) => ({
      ...prev,
      address: prev.address
        ? {
            ...prev.address,
            line1: address.line1,
            city: address.city,
            postcode: address.postcode,
            locality: address.country,
          }
        : undefined,
    }))
  }

  const handleModeSwitch = (newMode: AuthMode) => {
    setMode(newMode)
    setError('')
    setSendingCode(false)
    setCodeSent(false)
    setCode('')
    setResendIn(0)
    setOtpStatus('')
    setOtpMessage('')
    setResetOpen(false)
    setResetCodeSent(false)
    setResetCode('')
    setResetResendIn(0)
    setResetSendingCode(false)
    setResettingPassword(false)
    setResetStatus('')
    setResetMessage('')
    setNewPassword('')
    if (newMode === 'signup') {
      setFormData((prev) => ({
        ...prev,
        name: '',
        phone: '',
        address: {
          line1: '',
          locality: '',
          city: 'Edinburgh',
          postcode: '',
        },
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        name: undefined,
        phone: undefined,
        address: undefined,
      }))
    }
  }

  const startResendCountdown = () => {
    setResendIn(30)
    const timer = window.setInterval(() => {
      setResendIn((value) => {
        if (value <= 1) {
          window.clearInterval(timer)
          return 0
        }
        return value - 1
      })
    }, 1000)
  }

  const startResetResendCountdown = () => {
    setResetResendIn(30)
    const timer = window.setInterval(() => {
      setResetResendIn((value) => {
        if (value <= 1) {
          window.clearInterval(timer)
          return 0
        }
        return value - 1
      })
    }, 1000)
  }

  const handleSendSignupCode = async () => {
    const email = formData.email.trim()
    if (!email) {
      setError('Please enter your email first.')
      return
    }

    setError('')
    setOtpStatus('')
    setOtpMessage('')
    setSendingCode(true)
    try {
      const response = await fetch(buildApiUrl('/auth/send-otp'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      if (!response.ok) {
        throw new Error(parseErrorMessage(await response.text()))
      }
      setCodeSent(true)
      setResendIn(30)
      startResendCountdown()
      setOtpStatus('success')
      setOtpMessage('Code sent. Check your email.')
    } catch (err) {
      setOtpStatus('error')
      const message = err instanceof Error ? err.message : 'Unable to send code'
      setOtpMessage(message)
      setError(message)
    } finally {
      setSendingCode(false)
    }
  }

  const handleResendSignupCode = async () => {
    if (resendIn > 0) return
    await handleSendSignupCode()
  }

  const handleSendResetCode = async () => {
    const email = formData.email.trim()
    if (!email) {
      setResetStatus('error')
      setResetMessage('Please enter your email first.')
      return
    }

    setResetStatus('')
    setResetMessage('')
    setResetSendingCode(true)
    try {
      const response = await fetch(buildApiUrl('/auth/send-otp'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })
      if (!response.ok) {
        throw new Error(parseErrorMessage(await response.text()))
      }
      setResetCodeSent(true)
      setResetResendIn(30)
      startResetResendCountdown()
      setResetStatus('success')
      setResetMessage('Code sent to your email.')
    } catch (err) {
      setResetStatus('error')
      const message = err instanceof Error ? err.message : 'Unable to send code'
      setResetMessage(message)
    } finally {
      setResetSendingCode(false)
    }
  }

  const handleResendResetCode = async () => {
    if (resetResendIn > 0) return
    await handleSendResetCode()
  }

  const handleResetPassword = async () => {
    const email = formData.email.trim()
    const enteredCode = resetCode.trim()
    const password = newPassword.trim()
    if (!email) {
      setResetStatus('error')
      setResetMessage('Please enter your email first.')
      return
    }
    if (!/^\d{6}$/.test(enteredCode)) {
      setResetStatus('error')
      setResetMessage('Code must be 6 digits.')
      return
    }
    if (password.length < 8) {
      setResetStatus('error')
      setResetMessage('Password must be at least 8 characters.')
      return
    }

    setResetStatus('')
    setResetMessage('')
    setResettingPassword(true)
    try {
      const response = await fetch(buildApiUrl('/auth/reset-password'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code: enteredCode, new_password: password }),
      })

      if (!response.ok) {
        throw new Error(parseErrorMessage(await response.text()))
      }

      setResetStatus('success')
      setResetMessage('Password updated. Please login.')
      setNewPassword('')
      setResetCode('')
      setResetCodeSent(false)
    } catch (err) {
      setResetStatus('error')
      const message = err instanceof Error ? err.message : 'Unable to update password'
      setResetMessage(message)
    } finally {
      setResettingPassword(false)
    }
  }

  const handleVerifySignupCode = async () => {
    const email = formData.email.trim()
    const enteredCode = code.trim()
    if (!email) {
      setError('Please enter your email first.')
      setOtpStatus('error')
      setOtpMessage('Email is required to verify the code.')
      return
    }
    if (!/^\d{6}$/.test(enteredCode)) {
      setError('Please enter the 6-digit code.')
      setOtpStatus('error')
      setOtpMessage('Code must be 6 digits.')
      return
    }

    setError('')
    setOtpStatus('')
    setOtpMessage('')
    setLoading(true)
    try {
      const response = await fetch(buildApiUrl('/auth/verify-otp'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code: enteredCode }),
      })

      if (!response.ok) {
        throw new Error(parseErrorMessage(await response.text()))
      }

      setCodeSent(true)
      setOtpStatus('success')
      setOtpMessage('Email verified successfully.')
    } catch (err) {
      setOtpStatus('error')
      const message = err instanceof Error ? err.message : 'Unable to verify code'
      setOtpMessage(message)
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  const GoogleButton = googleAuthUrl ? (
    <a
      href={googleAuthUrl}
      className="inline-flex w-full items-center justify-center gap-3 rounded-lg border border-white/30 bg-white px-4 py-3 text-sm font-semibold text-brand-dark transition hover:bg-white/90"
    >
      <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
        <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.2-1.4 3.6-5.5 3.6-3.3 0-6.1-2.8-6.1-6.3s2.8-6.3 6.1-6.3c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 2.6 14.6 1.7 12 1.7 6.9 1.7 2.8 5.9 2.8 11s4.1 9.3 9.2 9.3c5.3 0 8.8-3.7 8.8-8.9 0-.6-.1-1-.1-1.2H12z"/>
      </svg>
      Continue with Google
    </a>
  ) : null

  const Divider = googleAuthUrl ? (
    <div className="my-3 flex items-center gap-3 text-white/70">
      <div className="h-px flex-1 bg-white/25" />
      <span className="text-xs uppercase tracking-wide">or</span>
      <div className="h-px flex-1 bg-white/25" />
    </div>
  ) : null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      await onSubmit(formData)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
      setLoading(false)
    }
  }

  return (
    <div className="relative mx-auto flex w-full max-w-5xl flex-col overflow-hidden rounded-[36px] bg-gradient-to-br from-brand-dark via-brand-dark/90 to-brand-olive/40 text-white shadow-2xl md:flex-row md:items-stretch min-h-[100dvh] sm:min-h-0">
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute -top-32 -left-32 h-64 w-64 rounded-full bg-brand-olive/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-brand-olive/30 blur-3xl" />

      {/* (logo will be rendered inside the left panel) */}

      {/* Left side: branding */}
      <div className="relative hidden flex-1 flex-col justify-start px-8 py-8 md:flex md:px-12 md:py-12 items-start text-left">
        <div className="space-y-6 md:space-y-8 max-w-lg">
          <div className="flex justify-center">
            <div className="inline-flex items-center justify-center rounded-2xl bg-white px-6 py-4 shadow-xl">
              <Image
                src={logoImage}
                alt="Tarel logo"
                width={280}
                height={100}
                className="h-20 w-auto object-contain"
                priority
              />
            </div>
          </div>
          <div className="space-y-3">
            <h1 className="text-3xl md:text-4xl font-bold leading-tight">
              Edinburgh&apos;s freshest seafood & meat, delivered
            </h1>
            <p className="text-base md:text-lg text-white/80">
              Fresh catches from Newhaven pier and quality meat cuts, prepared to your order and delivered to your door in chilled boxes.
            </p>
            <p className="mt-2 text-sm text-white/90">Need help? Email <a href="mailto:sales@tarel.co.uk" className="font-semibold underline text-white/90 hover:text-white">sales@tarel.co.uk</a></p>
          </div>
        </div>
      </div>

      {/* Right side: form */}
      <div className="relative flex flex-1 flex-col justify-start px-6 py-8 sm:px-8 sm:py-12 md:bg-brand-dark/40 md:backdrop-blur-sm">
        <div className="mx-auto w-full max-w-sm space-y-6">
          {/* Mobile branding */}
          <div className="space-y-4 md:hidden">
            <div className="inline-flex items-center justify-center rounded-2xl bg-white px-4 py-3 shadow-xl">
              <Image
                src={logoImage}
                alt="Tarel logo"
                width={160}
                height={60}
                className="h-16 w-auto object-contain"
                priority
              />
            </div>
            <div className="space-y-2 text-left">
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/60">Welcome to Tarel</p>
              <h1 className="text-2xl font-bold leading-tight text-white">
                Edinburgh&apos;s freshest seafood & meat, delivered
              </h1>
              <p className="text-sm leading-6 text-white/80">
                Fresh catches from Newhaven pier and quality meat cuts, prepared to your order and delivered to your door in chilled boxes.
              </p>
              <p className="text-sm text-white/90">
                Need help? Email{' '}
                <a href="mailto:sales@tarel.co.uk" className="font-semibold underline text-white/90 hover:text-white">
                  sales@tarel.co.uk
                </a>
              </p>
            </div>
          </div>

          {/* Heading */}
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-bold text-white md:text-3xl">
              {mode === 'login' ? 'Login' : 'Create your account'}
            </h2>
            <p className="mt-2 text-sm text-white/70">
              {mode === 'login'
                ? 'Premium access to Edinburgh\'s freshest catch. Track orders, save favourites, and manage delivery slots effortlessly.'
                : 'Join Tarel to place orders and get fresh seafood & meat delivered to your doorstep.'}
            </p>
          </div>

          {/* Mode tabs */}
          <div className="flex gap-3 border-b border-white/20">
            <button
              onClick={() => handleModeSwitch('login')}
              className={`flex-1 border-b-2 pb-3 text-sm font-medium transition ${
                mode === 'login'
                  ? 'border-white text-white'
                  : 'border-transparent text-white/60 hover:text-white/80'
              }`}
            >
              Login
            </button>
            <button
              onClick={() => handleModeSwitch('signup')}
              className={`flex-1 border-b-2 pb-3 text-sm font-medium transition ${
                mode === 'signup'
                  ? 'border-white text-white'
                  : 'border-transparent text-white/60 hover:text-white/80'
              }`}
            >
              Sign Up
            </button>
          </div>

          {GoogleButton}
          {Divider}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <>
                <div>
                  <label className="text-sm font-medium text-white">Name</label>
                  <input
                    type="text"
                    placeholder="Your full name"
                    value={formData.name || ''}
                    onChange={(e) => handleFieldChange('name', e.target.value)}
                    className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-white">Phone</label>
                  <input
                    type="tel"
                    placeholder="+44 7700 900000"
                    value={formData.phone || ''}
                    onChange={(e) => handleFieldChange('phone', e.target.value)}
                    className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                  />
                </div>
              </>
            )}

            <div>
              <label className="text-sm font-medium text-white">Email</label>
              <input
                type="email"
                inputMode="email"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => handleFieldChange('email', e.target.value)}
                onInput={(e) => handleFieldChange('email', e.currentTarget.value)}
                onBlur={(e) => handleFieldChange('email', e.currentTarget.value.trim())}
                className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                required
              />
            </div>

            {mode === 'signup' && (
              <div className="space-y-3 rounded-xl border border-white/15 bg-white/5 p-4">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-white">Email code</p>
                  <button
                    type="button"
                    onClick={handleSendSignupCode}
                    disabled={sendingCode || !formData.email.trim()}
                    className="w-full rounded-[10px] bg-[#2D4A35] px-4 py-[13px] text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {sendingCode ? 'Sending code...' : 'Send code'}
                  </button>
                </div>

                {codeSent && (
                  <div className="space-y-3">
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      placeholder="Enter 6-digit code"
                      value={code}
                      onChange={(event) => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))}
                      className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                    />
                    <div className="flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={handleVerifySignupCode}
                        className="flex-1 rounded-[10px] bg-white px-4 py-[13px] text-sm font-semibold text-brand-dark"
                      >
                        Verify code
                      </button>
                      <button
                        type="button"
                        onClick={handleResendSignupCode}
                        disabled={resendIn > 0}
                        className="flex-1 rounded-[10px] border border-white/25 px-4 py-[13px] text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
                      >
                        {resendIn > 0 ? `Resend in ${resendIn}s` : 'Resend code'}
                      </button>
                    </div>
                    {otpStatus && (
                      <div
                        className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold sm:text-sm ${
                          otpStatus === 'success'
                            ? 'border-emerald-300/60 bg-emerald-500/15 text-emerald-100'
                            : 'border-red-300/60 bg-red-500/15 text-red-100'
                        }`}
                      >
                        <span
                          className={`inline-flex h-5 w-5 items-center justify-center rounded-full border ${
                            otpStatus === 'success'
                              ? 'border-emerald-200/80 text-emerald-100'
                              : 'border-red-200/80 text-red-100'
                          }`}
                          aria-hidden="true"
                        >
                          {otpStatus === 'success' ? 'OK' : 'X'}
                        </span>
                        <span>{otpMessage}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            <div>
              <label className="text-sm font-medium text-white">Password</label>
              <input
                type="password"
                placeholder="Minimum 8 characters"
                value={formData.password}
                onChange={(e) => handleFieldChange('password', e.target.value)}
                className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                required
              />
            </div>

            {mode === 'login' && (
              <div className="space-y-3 rounded-xl border border-white/15 bg-white/5 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-white">Reset password</p>
                  <button
                    type="button"
                    onClick={() => setResetOpen((open) => !open)}
                    className="text-xs font-semibold text-white/80 underline underline-offset-4"
                  >
                    {resetOpen ? 'Hide' : 'Use OTP'}
                  </button>
                </div>

                {resetOpen && (
                  <div className="space-y-3">
                    <button
                      type="button"
                      onClick={handleSendResetCode}
                      disabled={resetSendingCode || !formData.email.trim()}
                      className="w-full rounded-[10px] bg-[#2D4A35] px-4 py-[13px] text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {resetSendingCode ? 'Sending code...' : 'Send code'}
                    </button>

                    {resetStatus && (
                      <div
                        className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold sm:text-sm ${
                          resetStatus === 'success'
                            ? 'border-emerald-300/60 bg-emerald-500/15 text-emerald-100'
                            : 'border-red-300/60 bg-red-500/15 text-red-100'
                        }`}
                      >
                        <span
                          className={`inline-flex h-5 w-5 items-center justify-center rounded-full border ${
                            resetStatus === 'success'
                              ? 'border-emerald-200/80 text-emerald-100'
                              : 'border-red-200/80 text-red-100'
                          }`}
                          aria-hidden="true"
                        >
                          {resetStatus === 'success' ? 'OK' : 'X'}
                        </span>
                        <span>{resetMessage}</span>
                      </div>
                    )}

                    {resetCodeSent && (
                      <div className="space-y-3">
                        <input
                          type="text"
                          inputMode="numeric"
                          maxLength={6}
                          placeholder="Enter 6-digit code"
                          value={resetCode}
                          onChange={(event) => setResetCode(event.target.value.replace(/\D/g, '').slice(0, 6))}
                          className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                        />
                        <input
                          type="password"
                          placeholder="New password"
                          value={newPassword}
                          onChange={(event) => setNewPassword(event.target.value)}
                          className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                        />
                        <div className="flex items-center justify-between gap-3">
                          <button
                            type="button"
                            onClick={handleResetPassword}
                            disabled={resettingPassword}
                            className="flex-1 rounded-[10px] bg-white px-4 py-[13px] text-sm font-semibold text-brand-dark disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            {resettingPassword ? 'Updating...' : 'Update password'}
                          </button>
                          <button
                            type="button"
                            onClick={handleResendResetCode}
                            disabled={resetResendIn > 0}
                            className="flex-1 rounded-[10px] border border-white/25 px-4 py-[13px] text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            {resetResendIn > 0 ? `Resend in ${resetResendIn}s` : 'Resend code'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {mode === 'signup' && formData.address && (
              <>
                <div>
                  <label className="text-sm font-medium text-white">Address</label>
                  <AddressAutocomplete
                    value={formData.address.line1}
                    onChange={(value) => handleAddressChange('line1', value)}
                    onAddressSelect={handleAddressSelect}
                    placeholder="Start typing your address..."
                    className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                    apiKey={GEOAPIFY_API_KEY}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium text-white">City</label>
                    <input
                      type="text"
                      placeholder="e.g. Edinburgh"
                      value={formData.address.city}
                      onChange={(e) => handleAddressChange('city', e.target.value)}
                      className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-white">Postcode</label>
                    <input
                      type="text"
                      placeholder="EH6 7DX"
                      value={formData.address.postcode}
                      onChange={(e) => handleAddressChange('postcode', e.target.value)}
                      className="mt-1 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-2 text-white placeholder:text-white/50 focus:border-white/40 focus:outline-none focus:ring-2 focus:ring-white/20"
                      required
                    />
                  </div>
                </div>
              </>
            )}

            {error && (
              <div className="rounded-lg border border-red-400/50 bg-red-500/20 p-3 text-sm text-red-200">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-white py-3 font-semibold text-brand-dark transition hover:bg-white/90 disabled:opacity-50"
            >
              {loading ? 'Processing...' : mode === 'login' ? 'Login / Sign Up' : 'Create Account'}
            </button>
          </form>
          {/* Help + Legal */}
          <div className="space-y-2 text-center">
            <p className="text-center text-xs leading-5 text-white/75">
              By continuing, you agree to our{' '}
              <a href="/legal/terms-and-conditions" className="font-semibold text-white underline decoration-white/70 underline-offset-4 hover:text-white hover:decoration-white">
                Terms
              </a>
              {' '}and acknowledge the{' '}
              <a href="/legal/privacy-policy" className="font-semibold text-white underline decoration-white/70 underline-offset-4 hover:text-white hover:decoration-white">
                Privacy Policy
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
