// Convenience hook wrapper for the frontend auth provider
export { useAuth } from '@/providers/AuthProvider'
