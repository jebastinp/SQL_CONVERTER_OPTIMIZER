// Convenience hook wrapper for the frontend cart provider
export { useCart } from '@/providers/CartProvider'
