import AppShell from '@/components/AppShell'
import Home from './(public)/page'

export default function RootHomePage() {
	return (
		<AppShell>
			<Home />
		</AppShell>
	)
}
