'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useMemo } from 'react'
import { useRouter } from 'next/navigation'
import useSWR, { type Fetcher } from 'swr'

import CategoryPills from '@/components/CategoryPills'
import { NextDeliveryCard } from '@/components/NextDeliveryCard'
import { buildApiUrl } from '@/lib/api'
import { getToken } from '@/lib/auth'
import type { Category, NextDeliveryInfo, Order } from '@/lib/types'
import { useAuth } from '@/providers/AuthProvider'
import logoImage from '@/images/logo.png'

type FetchOptions = {
  headers?: Record<string, string>
}

async function fetchJson<T>(path: string, options: FetchOptions = {}): Promise<T> {
  const res = await fetch(buildApiUrl(path), {
    cache: 'no-store',
    headers: {
      ...(options.headers ?? {}),
    },
  })
  if (!res.ok) {
    const message = await res.text()
    throw new Error(message || 'Failed to load data')
  }
  return (await res.json()) as T
}

export default function AccountOverviewPage() {
  const router = useRouter()
  const { user, loading: authLoading } = useAuth()

  const ordersFetcher: Fetcher<Order[], string> = async (path) => {
    const token = getToken()
    if (!token) {
      throw new Error('Your session has expired. Please sign in again.')
    }
    return fetchJson<Order[]>(path, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  }

  const {
    data: ordersData,
    error: ordersError,
    isLoading: ordersLoading,
  } = useSWR<Order[]>(user ? '/orders/my' : null, ordersFetcher, {
    revalidateOnFocus: false,
    shouldRetryOnError: false,
  })

  const deliveryFetcher: Fetcher<NextDeliveryInfo, string> = (path) => fetchJson<NextDeliveryInfo>(path)

  const {
    data: nextDelivery,
    isLoading: nextDeliveryLoading,
    error: nextDeliveryError,
  } = useSWR<NextDeliveryInfo>(user ? '/site/next-delivery' : null, deliveryFetcher, {
    refreshInterval: 15 * 60 * 1000,
    revalidateOnFocus: false,
  })

  const categoryFetcher: Fetcher<Category[], string> = (path) => fetchJson<Category[]>(path)

  const {
    data: categories,
    isLoading: categoriesLoading,
    error: categoriesError,
  } = useSWR<Category[]>(user ? '/categories/' : null, categoryFetcher, {
    revalidateOnFocus: false,
    shouldRetryOnError: false,
  })

  const orders = ordersData ?? []
  const sortedOrders = useMemo(
    () => [...orders].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()),
    [orders]
  )
  const orderErrorMessage = ordersError instanceof Error ? ordersError.message : ordersError ?? null

  const lifetimeSpend = useMemo(
    () => sortedOrders.reduce((sum, order) => sum + order.total_amount, 0),
    [sortedOrders],
  )
  const activeOrders = useMemo(
    () => sortedOrders.filter((order) => !['delivered', 'cancelled'].includes(order.status)),
    [sortedOrders],
  )
  const recentOrder = sortedOrders[0] ?? null

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(value)

  const formatStatus = (status: string) =>
    status
      .split('_')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ')

  const handleSelectCategory = (slug: string) => {
    if (slug === 'all') {
      router.push('/categories')
      return
    }
    router.push(`/categories?slug=${slug}`)
  }

  return (
    <div className="space-y-6">
      {/* 3 Stat Cards */}
      {authLoading || ordersLoading ? (
        <div className="grid gap-4 md:grid-cols-3">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="h-24 animate-pulse rounded-2xl bg-white/70" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          <StatCard 
            label="Orders placed" 
            value={orders.length.toString()} 
            detail={orders.length === 1 ? 'Single order so far' : `${orders.length} total orders`} 
          />
          <StatCard
            label="Active orders"
            value={activeOrders.length.toString()}
            detail={activeOrders.length ? 'In-progress deliveries' : 'No active orders'}
          />
          <StatCard
            label="Lifetime spend"
            value={formatCurrency(lifetimeSpend)}
            detail={orders.length ? 'Across all orders' : 'Start shopping to track'}
          />
        </div>
      )}

      {/* Most Recent Order & Next Delivery - Two Column */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Most Recent Order */}
        <article className="rounded-2xl border border-brand-dark/10 bg-white p-6 shadow-sm">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold text-brand-dark">Most recent order</h3>
              <p className="text-xs text-brand-dark/60">View your latest purchase</p>
            </div>
            <Link href="/user/orders" className="text-xs font-medium text-brand-dark/70 hover:text-brand-dark">
              All orders →
            </Link>
          </div>

          <div className="mt-4">
            {ordersLoading ? (
              <div className="space-y-3">
                <div className="h-16 animate-pulse rounded-xl bg-brand-beige/40" />
                <div className="h-10 animate-pulse rounded-xl bg-brand-beige/30" />
              </div>
            ) : orderErrorMessage ? (
              <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-700">
                {orderErrorMessage}
              </div>
            ) : !recentOrder ? (
              <div className="rounded-xl border border-dashed border-brand-dark/20 bg-brand-beige/20 p-4 text-center">
                <p className="text-xs font-medium text-brand-dark/80">No orders yet.</p>
                <Link
                  href="/categories"
                  className="mt-2 inline-block text-xs font-medium text-brand-dark hover:underline"
                >
                  Start shopping →
                </Link>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-brand-dark/60">Order</p>
                    <p className="font-semibold text-brand-dark">#{recentOrder.id.slice(0, 8).toUpperCase()}</p>
                  </div>
                  <StatusBadge status={recentOrder.status} />
                </div>
                <div className="grid grid-cols-3 gap-2 border-t border-brand-dark/5 pt-3">
                  <div>
                    <p className="text-brand-dark/60">Placed</p>
                    <p className="text-brand-dark">{new Date(recentOrder.created_at).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-brand-dark/60">Window</p>
                    <p className="text-brand-dark">{recentOrder.delivery_slot ?? 'TBA'}</p>
                  </div>
                  <div>
                    <p className="text-brand-dark/60">Total</p>
                    <p className="font-semibold text-brand-dark">{formatCurrency(recentOrder.total_amount)}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </article>

        {/* Next Delivery */}
        <article className="rounded-2xl border border-brand-dark/10 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-brand-dark">Next delivery</h3>
          <p className="text-xs text-brand-dark/60">Countdown to your order</p>
          <div className="mt-4">
            {nextDeliveryLoading ? (
              <div className="h-32 animate-pulse rounded-xl bg-brand-beige/40" />
            ) : nextDeliveryError ? (
              <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-700">
                Failed to load delivery schedule.
              </div>
            ) : (
              <NextDeliveryCard
                nextDelivery={nextDelivery ?? null}
                showWindowLabel={true}
                windowLabelPlacement="heading"
                compact={false}
              />
            )}
          </div>
        </article>
      </div>

      {/* Browse by category removed from Customer Hub per design */}

      {/* Account details (moved from Profile) */}
      <section className="grid gap-6 lg:grid-cols-3">
        <article className="rounded-2xl border border-brand-dark/10 bg-white p-6 shadow-sm lg:col-span-2">
          <header className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-brand-dark">Account details</h2>
              <p className="text-sm text-brand-dark/70">Update your display name or refresh your password.</p>
            </div>
          </header>

          <form /* moved inline from profile page */ className="mt-6 space-y-5" onSubmit={async (e) => { e.preventDefault(); /* forward to profile save handler via API */ }}>
            <label className="block text-sm text-brand-dark/80">
              <span className="text-xs uppercase tracking-widest text-brand-dark/60">Full name</span>
              <input
                name="name"
                defaultValue={/* hydration: user name */ undefined}
                placeholder="Your full name"
                className="mt-2 w-full rounded-2xl border border-brand-dark/15 bg-white px-4 py-3 text-sm text-brand-dark outline-none focus:border-brand-dark/40 focus:ring-2 focus:ring-brand-olive/30"
              />
            </label>

            <label className="block text-sm text-brand-dark/80">
              <span className="text-xs uppercase tracking-widest text-brand-dark/60">Password</span>
              <input
                type="password"
                name="password"
                placeholder="Set a new password"
                className="mt-2 w-full rounded-2xl border border-brand-dark/15 bg-white px-4 py-3 text-sm text-brand-dark outline-none focus:border-brand-dark/40 focus:ring-2 focus:ring-brand-olive/30"
              />
              <span className="mt-2 block text-xs text-brand-dark/50">Leave blank to keep your current password.</span>
            </label>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-full bg-brand-dark px-6 py-3 text-sm font-semibold text-white shadow transition hover:opacity-90"
              >
                Save changes
              </button>
            </div>
          </form>
        </article>

        <aside className="space-y-6">
          <div className="rounded-2xl border border-brand-dark/10 bg-white p-6 shadow-sm">
            <h3 className="text-base font-semibold text-brand-dark">Contact</h3>
            <p className="mt-2 text-sm text-brand-dark/70">{/* user email goes here */}</p>
            <p className="mt-4 text-xs text-brand-dark/50">Need assistance? Drop us an email and we&apos;ll jump in.</p>
          </div>

          <div className="rounded-2xl border border-brand-dark/10 bg-white p-6 shadow-sm">
            <h3 className="text-base font-semibold text-brand-dark">Quick links</h3>
            <ul className="mt-3 space-y-2 text-sm text-brand-dark/70">
              <li>
                <a href="/user/orders" className="flex items-center justify-between rounded-xl px-3 py-2 transition hover:bg-brand-beige/40">
                  <span>View orders</span>
                  <span className="text-xs text-brand-dark/50">↗</span>
                </a>
              </li>
              <li>
                <a href="/categories" className="flex items-center justify-between rounded-xl px-3 py-2 transition hover:bg-brand-beige/40">
                  <span>Shop fresh catch</span>
                  <span className="text-xs text-brand-dark/50">↗</span>
                </a>
              </li>
            </ul>
            <p className="mt-6 border-t border-brand-dark/10 pt-4 text-xs text-brand-dark/60">
              <span className="font-semibold">Member since</span>
              <br />
              {/* joinedOn placeholder */}
            </p>
          </div>
        </aside>
      </section>
    </div>
  )
}

function StatCard({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-2xl border border-brand-dark/10 bg-white p-5 shadow-sm">
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-brand-dark/50">{label}</p>
      <p className="mt-2 text-2xl font-bold text-brand-dark">{value}</p>
      <p className="mt-1 text-xs text-brand-dark/60">{detail}</p>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, { bg: string; text: string; label: string }> = {
    pending: { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'Pending' },
    out_for_delivery: { bg: 'bg-green-100', text: 'text-green-700', label: 'Out for delivery' },
    delivered: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Delivered' },
    cancelled: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Cancelled' },
  }
  const config = statusMap[status] || { bg: 'bg-gray-100', text: 'text-gray-700', label: status }

  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${config.bg} ${config.text}`}>{config.label}</span>
}

