'use client'

import { useCallback, useEffect, useState } from 'react'

import { buildApiUrl } from '@/lib/api'
import type { Order } from '@/lib/types'
import { useAuth } from '@/providers/AuthProvider'

const formatStatus = (status: string) =>
  status
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase())

export default function MyOrders() {
  const { user, loading: authLoading } = useAuth()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [banner, setBanner] = useState<{ type: 'success' | 'error'; message: string } | null>(null)
  const [cancellingId, setCancellingId] = useState<string | null>(null)
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null)

  useEffect(() => {
    if (authLoading) {
      return
    }

    let cancelled = false

    const loadOrders = async () => {
      try {
        if (!cancelled) {
          setIsLoading(true)
          setError(null)
          setBanner(null)
        }

        const { getToken } = await import('@/lib/auth')
        const token = getToken()

        if (!token || !user) {
          if (!cancelled) {
            setOrders([])
            setIsLoading(false)
          }
          return
        }

        const res = await fetch(buildApiUrl('/orders/my'), {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          cache: 'no-store',
        })

        if (!res.ok) {
          const message = await res.text()
          throw new Error(message || 'Failed to fetch orders')
        }

        const payload: Order[] = await res.json()
        if (!cancelled) {
          // ensure newest orders appear first
          payload.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          setOrders(payload)
        }
      } catch (err) {
        if (cancelled) {
          return
        }
        console.error('Failed to load orders', err)
        setError(err instanceof Error ? err.message : 'Unexpected error')
      } finally {
        if (!cancelled) {
          setIsLoading(false)
        }
      }
    }

    void loadOrders()

    return () => {
      cancelled = true
    }
  }, [authLoading, user])

  const formatCurrency = (value: number) => `£${value.toFixed(2)}`

  const canCancel = useCallback((status: string) => {
    const normalized = status.toLowerCase()
    return normalized === 'pending'
  }, [])

  const handleCancelOrder = useCallback(
    async (orderId: string) => {
      const confirmCancel = window.confirm('Cancel this order? This cannot be undone.')
      if (!confirmCancel) return

      setCancellingId(orderId)
      setBanner(null)

      try {
        const { getToken } = await import('@/lib/auth')
        const token = getToken()

        if (!token) {
          throw new Error('Please sign in again to cancel this order.')
        }

        const res = await fetch(buildApiUrl(`/orders/${orderId}/cancel`), {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`
          }
        })

        if (!res.ok) {
          const message = await res.text()
          throw new Error(message || 'Failed to cancel order')
        }

        const updatedOrder: Order = await res.json()
        setOrders((previous) => {
          const next = previous.map((order) => (order.id === updatedOrder.id ? updatedOrder : order))
          next.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          return next
        })
        setBanner({ type: 'success', message: 'Order cancelled successfully.' })
      } catch (err) {
        console.error('Failed to cancel order', err)
        const message = err instanceof Error ? err.message : 'Unable to cancel order'
        setBanner({ type: 'error', message })
      } finally {
        setCancellingId(null)
      }
    },
    []
  )

  return (
    <div className="space-y-6">
      {banner && (
        <div
          className={`rounded-xl border px-4 py-3 text-xs sm:px-4 sm:py-3 ${
            banner.type === 'success'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
              : 'border-red-200 bg-red-50 text-red-700'
          }`}
        >
          {banner.message}
        </div>
      )}

      {authLoading || isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="h-12 animate-pulse rounded-lg bg-white/60" />
          ))}
        </div>
      ) : error ? (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-xs text-red-700">
          <p className="font-semibold">We couldn't fetch your orders</p>
          <p className="mt-1">{error}</p>
        </div>
      ) : orders.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-brand-dark/20 bg-white p-8 text-center text-brand-dark/70">
          <p className="font-semibold">No orders just yet</p>
          <p className="mt-1 text-xs">
            Once you place an order, it will appear here with full tracking information.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order: Order) => (
            <div
              key={order.id}
              className="rounded-2xl border border-brand-dark/10 bg-white shadow-sm overflow-hidden"
            >
              {/* Order Header Row */}
              <button
                onClick={() =>
                  setExpandedOrderId(expandedOrderId === order.id ? null : order.id)
                }
                className="w-full px-6 py-4 hover:bg-brand-beige/20 transition text-left"
              >
                <div className="grid grid-cols-2 md:grid-cols-7 gap-3 md:gap-4 items-center">
                  <div>
                    <p className="text-xs text-brand-dark/60 uppercase tracking-widest">Order</p>
                    <p className="font-semibold text-brand-dark">#{order.id.slice(0, 8).toUpperCase()}</p>
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs text-brand-dark/60 uppercase tracking-widest">Placed</p>
                    <p className="text-sm text-brand-dark">{new Date(order.created_at).toLocaleDateString()}</p>
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs text-brand-dark/60 uppercase tracking-widest">Window</p>
                    <p className="text-sm text-brand-dark">{order.delivery_slot ?? 'TBA'}</p>
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs text-brand-dark/60 uppercase tracking-widest">Destination</p>
                    <p className="text-xs text-brand-dark">{order.city}</p>
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs text-brand-dark/60 uppercase tracking-widest">Total</p>
                    <p className="font-semibold text-brand-dark">{formatCurrency(order.total_amount)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-brand-dark/60 uppercase tracking-widest">Status</p>
                    <StatusBadge status={order.status} />
                  </div>
                  <div className="text-right">
                    <span className="text-lg text-brand-dark">
                      {expandedOrderId === order.id ? '↑' : '↓'}
                    </span>
                  </div>
                </div>

                {/* Mobile: Show key info */}
                <div className="md:hidden mt-3 pt-3 border-t border-brand-dark/5 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <p className="text-brand-dark/60">Placed: {new Date(order.created_at).toLocaleDateString()}</p>
                    <p className="text-brand-dark/60 mt-1">Window: {order.delivery_slot ?? 'TBA'}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-brand-dark">{formatCurrency(order.total_amount)}</p>
                    <p className="text-brand-dark/60 mt-1">{order.city}, {order.postcode}</p>
                  </div>
                </div>
              </button>

              {/* Expanded Details */}
              {expandedOrderId === order.id && (
                <div className="border-t border-brand-dark/10 bg-brand-beige/20 px-6 py-4 space-y-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-widest text-brand-dark/70 mb-3">Line items</p>
                    <ul className="space-y-2">
                      {order.items.map((item, index) => {
                        const lineTotal = item.qty_kg * item.price_per_kg
                        return (
                          <li
                            key={`${order.id}-${item.product_id}-${index}`}
                            className="flex items-center justify-between text-xs bg-white px-3 py-2 rounded-lg"
                          >
                            <div>
                              <p className="font-semibold text-brand-dark">{item.product.name}</p>
                              <p className="text-brand-dark/60">{item.qty_kg.toFixed(2)} kg × {formatCurrency(item.price_per_kg)}</p>
                            </div>
                            <span className="font-semibold text-brand-dark">{formatCurrency(lineTotal)}</span>
                          </li>
                        )
                      })}
                    </ul>
                    <div className="mt-3 bg-white px-3 py-2 rounded-lg flex items-center justify-between text-xs font-semibold border border-brand-dark/10">
                      <span className="text-brand-dark/70">Total paid</span>
                      <span className="text-brand-dark">{formatCurrency(order.total_amount)}</span>
                    </div>
                  </div>

                  {canCancel(order.status) && (
                    <button
                      type="button"
                      onClick={() => handleCancelOrder(order.id)}
                      disabled={cancellingId === order.id}
                      className="w-full rounded-lg border border-red-300 bg-red-50 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {cancellingId === order.id ? 'Cancelling…' : 'Cancel order'}
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, { bg: string; text: string; label: string }> = {
    pending: { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'Pending' },
    out_for_delivery: { bg: 'bg-green-100', text: 'text-green-700', label: 'Out for delivery' },
    delivered: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Delivered' },
    cancelled: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Cancelled' },
  }
  const config = statusMap[status] || { bg: 'bg-gray-100', text: 'text-gray-700', label: status }

  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${config.bg} ${config.text}`}>{config.label}</span>
}
