'use client'

import { useEffect, useState } from 'react'

import { useCart } from '@/providers/CartProvider'
import { buildApiUrl, buildMediaUrl } from '@/lib/api'
import { calculatePrice } from '@/lib/pricing'

export default function ProductPage({ params }: { params: { id: string } }) {
  const slug = params.id
  const [product, setProduct] = useState<any>(null)
  const [quantity, setQuantity] = useState(1)
  const { add } = useCart()

  useEffect(() => {
    ;(async () => {
  const res = await fetch(buildApiUrl(`/products/${slug}`))
      setProduct(await res.json())
    })()
  }, [slug])

  if (!product) return <div>Loading...</div>
  const oneKgPrice = product.one_kg_price ?? product.price_per_kg
  const halfKgPrice = product.half_kg_price ?? oneKgPrice / 2
  const totalPrice = calculatePrice(quantity, oneKgPrice, halfKgPrice)
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <img src={buildMediaUrl(product.image_url)} className="rounded-2xl" alt={product.name} />
      <div className="space-y-3 card">
        <h1 className="text-2xl font-bold">{product.name}</h1>
        <p className="text-gray-600">{product.description || '—'}</p>
        <p className="text-sm font-medium text-gray-700">½ kg — £{halfKgPrice.toFixed(2)}</p>
        <p className="text-sm font-medium text-gray-700">1 kg — £{oneKgPrice.toFixed(2)}</p>
        <label className="block space-y-2">
          <span className="text-sm font-medium text-gray-700">Weight (kg)</span>
          <input
            type="number"
            min="0.5"
            step="0.5"
            value={quantity}
            onChange={(event) => setQuantity(Math.max(0.5, Number(event.target.value) || 0.5))}
            className="w-32 rounded-lg border border-gray-300 px-3 py-2"
          />
        </label>
        <p className="text-lg font-semibold">Total: £{totalPrice.toFixed(2)}</p>
        <button className="btn" onClick={() => add(product, quantity)}>
          Add to cart
        </button>
      </div>
    </div>
  )
}
