'use client'

import { useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

import AuthHero from '@/components/AuthHero'
import { buildApiUrl } from '@/lib/api'
import { parseErrorMessage } from '@/lib/errors'
import { useAuth } from '@/providers/AuthProvider'
import { useToast } from '@/providers/ToastProvider'

export const dynamic = 'force-dynamic'

type AuthFormValues = {
  name?: string
  phone?: string
  email: string
  password: string
  address?: {
    line1: string
    locality: string
    city: string
    postcode: string
  }
}

export default function AuthPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { setSession } = useAuth()
  const { showSuccess, showError } = useToast()
  const nextPath = searchParams?.get('next') || '/'

  useEffect(() => {
    const oauthToken = searchParams?.get('token')
    if (!oauthToken) return

    const completeOAuthLogin = async () => {
      try {
        const res = await fetch(buildApiUrl('/auth/me'), {
          headers: { Authorization: `Bearer ${oauthToken}` },
          cache: 'no-store',
        })

        if (!res.ok) {
          throw new Error(await res.text())
        }

        const user = await res.json()
        setSession(oauthToken, user)
        showSuccess('Login successful! Welcome back.')
        router.replace(nextPath)
      } catch {
        showError('Unable to complete Google sign-in. Please try again.')
      }
    }

    void completeOAuthLogin()
  }, [nextPath, router, searchParams, setSession, showError, showSuccess])

  const handleAuth = async ({ name, phone, email, password, address }: AuthFormValues) => {
    const isSignup = Boolean(name)
    const endpoint = isSignup ? '/auth/register' : '/auth/login'

    const res = await fetch(buildApiUrl(endpoint), {
      method: 'POST',
      headers: isSignup ? { 'Content-Type': 'application/json' } : undefined,
      body: isSignup
        ? JSON.stringify({
            name,
            email,
            password,
            phone,
            address_line1: address?.line1,
            locality: address?.locality || undefined,
            city: address?.city,
            postcode: address?.postcode,
          })
        : new URLSearchParams({ username: email, password }),
    })

    if (!res.ok) {
      const errorText = await res.text()
      const errorMessage = parseErrorMessage(errorText)
      throw new Error(errorMessage)
    }

    const data = await res.json()
    if (isSignup) {
      showSuccess('Account created successfully! Please login.')
      router.push(`/login?next=${encodeURIComponent(nextPath)}`)
      return
    }

    setSession(data.access_token, data.user)
    showSuccess('Login successful! Welcome back.')
    router.push(nextPath)
  }

  return <AuthHero mode="login" onSubmit={handleAuth} googleAuthUrl={`${buildApiUrl('/auth/google')}?next=${encodeURIComponent(nextPath)}`} />
}
