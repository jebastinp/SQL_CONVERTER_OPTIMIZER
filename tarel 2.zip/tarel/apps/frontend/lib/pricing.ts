export function calculatePrice(weightKg: number, oneKgPrice: number, halfKgPrice: number) {
  const fullKgs = Math.floor(weightKg)
  const hasHalf = Math.round((weightKg % 1) * 10) / 10 === 0.5
  return (fullKgs * oneKgPrice) + (hasHalf ? halfKgPrice : 0)
}
