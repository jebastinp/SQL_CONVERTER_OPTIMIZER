function stripTrailingSlashes(value: string) {
  return value.replace(/\/+$/, '')
}

function normaliseOrigin(origin: string) {
  const trimmed = stripTrailingSlashes(origin)
  return trimmed.endsWith('/api') ? trimmed.replace(/\/api$/, '') : trimmed
}

function getBrowserHostname(): string | null {
  if (typeof window === 'undefined') return null
  return window.location?.hostname || null
}

export function resolveApiOrigin() {
  const envOriginRaw = process.env.NEXT_PUBLIC_API_BASE
  const envOrigin = envOriginRaw ? normaliseOrigin(envOriginRaw) : null

  const hostname = getBrowserHostname()
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    return 'http://localhost:8000'
  }

  if (hostname) {
    // In the browser, always call the backend on the same host as the page.
    // This keeps LAN/mobile testing working even if env vars are set to localhost.
    return `http://${hostname}:8000`
  }

  return envOrigin || 'http://localhost:8000'
}

export const API_ORIGIN = resolveApiOrigin()
export const API_BASE = `${API_ORIGIN}/api`

export function buildApiUrl(path: string) {
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path
  }
  const normalisedPath = path.startsWith('/') ? path : `/${path}`
  return `${API_BASE}${normalisedPath}`
}

export function buildServiceUrl(path: string) {
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path
  }
  const normalisedPath = path.startsWith('/') ? path : `/${path}`
  return `${API_ORIGIN}${normalisedPath}`
}

export function buildMediaUrl(imagePath: string | null | undefined): string {
  if (!imagePath) {
    return 'https://placehold.co/600x420?text=Tarel'
  }
  
  // If already absolute URL, return as is
  if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
    return imagePath
  }
  
  // Convert relative path to absolute URL using backend origin
  const normalisedPath = imagePath.startsWith('/') ? imagePath : `/${imagePath}`
  return `${API_ORIGIN}${normalisedPath}`
}

export async function api(path: string, opts: RequestInit = {}) {
  const target = buildApiUrl(path)
  const res = await fetch(target, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  if (!res.ok) {
    throw new Error(await res.text())
  }
  return res.json()
}
