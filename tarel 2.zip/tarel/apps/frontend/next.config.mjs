/** @type {import('next').NextConfig} */
const nextConfig = {
  // Standalone output: produces a minimal self-contained server bundle
  // used by the production Dockerfile (apps/frontend/Dockerfile).
  output: 'standalone',

  // Silence ESLint during builds (CI handles linting separately).
  eslint: { ignoreDuringBuilds: true },

  // Allow images served from the backend media endpoint.
  images: {
    remotePatterns: [
      {
        protocol: 'http',
        hostname: 'localhost',
        port: '8000',
        pathname: '/media/**',
      },
    ],
  },
}

export default nextConfig
