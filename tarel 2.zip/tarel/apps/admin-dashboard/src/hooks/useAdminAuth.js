// Admin auth convenience hook
import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'

import { useAuth } from '../context/AuthContext'

export function useAdminAuth() {
  const auth = useAuth()
  const navigate = useNavigate()

  const isAdmin = useMemo(() => auth.user?.role === 'admin', [auth.user?.role])

  const requireAdmin = () => {
    if (!auth.token || !isAdmin) {
      navigate('/admin/login', { replace: true })
      return false
    }
    return true
  }

  return {
    ...auth,
    isAdmin,
    requireAdmin,
  }
}
