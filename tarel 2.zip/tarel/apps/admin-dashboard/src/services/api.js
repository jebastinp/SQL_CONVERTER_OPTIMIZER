// Admin dashboard API helpers
function resolveApiBase() {
  const envBase = import.meta.env.VITE_API_BASE

  if (typeof window !== 'undefined') {
    const hostname = window.location?.hostname
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      return 'http://localhost:8000/api'
    }
    if (hostname) {
      const origin = window.location?.origin
      if (origin) {
        return `${origin.replace(/\/+$/, '')}/api`
      }
      const protocol = window.location?.protocol || 'http:'
      return `${protocol}//${hostname}/api`
    }
  }

  return envBase || 'http://localhost:8000/api'
}

function getApiBaseValue() {
  return resolveApiBase().replace(/\/+$/, '')
}

function joinUrl(base, path) {
  const safePath = path.startsWith('/') ? path : `/${path}`
  return `${base}${safePath}`
}

function buildHeaders(token, extraHeaders = {}) {
  const headers = { ...extraHeaders }
  if (!(headers instanceof Headers)) {
    headers['Accept'] = headers['Accept'] || 'application/json'
  }
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }
  return headers
}

export async function api(path, { method = 'GET', body, token, headers = {} } = {}) {
  const init = {
    method,
    headers: buildHeaders(token, headers)
  }

  if (body instanceof FormData) {
    init.body = body
  } else if (body instanceof URLSearchParams) {
    init.body = body
    init.headers['Content-Type'] = 'application/x-www-form-urlencoded'
  } else if (body !== undefined) {
    init.body = JSON.stringify(body)
    init.headers['Content-Type'] = 'application/json'
  }

  try {
    const response = await fetch(joinUrl(getApiBaseValue(), path), init)

    if (!response.ok) {
      let message = response.statusText
      try {
        const text = await response.text()
        message = text || message
      } catch (e) {
        // ignore
      }
      throw new Error(message)
    }

    if (response.status === 204) {
      return null
    }

    return response.json()
  } catch (error) {
    console.error('API Error:', error)
    throw error
  }
}

export function getApiBase() {
  return getApiBaseValue()
}
