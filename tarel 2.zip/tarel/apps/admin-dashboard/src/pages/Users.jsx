import { useEffect, useState } from 'react'

import Header from '../components/Header'
import Loading from '../components/Loading'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'
import { exportToCsv } from '../utils/exportCsv'

export default function Users () {
  const { token, loading: authLoading, error: authError } = useAuth()
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!token) return

    let cancelled = false
    setLoading(true)
    setError('')

    const load = async () => {
      try {
        const data = await api('/admin/users', { token })
        if (cancelled) return
        const normalized = Array.isArray(data) ? data : []
        normalized.sort((a, b) => {
          const left = new Date(b.created_at || 0).getTime()
          const right = new Date(a.created_at || 0).getTime()
          return left - right
        })
        setUsers(normalized)
      } catch (err) {
        if (cancelled) return
        console.error('Failed to load users', err)
        const message = err instanceof Error ? err.message : 'Unable to load users.'
        setError(message)
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    void load()

    return () => {
      cancelled = true
    }
  }, [token])

  if (authLoading) {
    return <Loading message="Checking session…" />
  }

  if (authError) {
    return <Loading message={authError} />
  }

  if (!token) {
    return <Loading message="Please sign in." />
  }

  if (loading) {
    return <Loading message="Loading customers…" />
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header title="Customers" />
      <section className="flex-1 space-y-6 bg-background px-4 py-6 sm:px-6">
        {error && (
          <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-secondary">View registered customers and admins.</p>
          <button
            onClick={() => exportToCsv('users.csv', users)}
            className="inline-flex items-center justify-center rounded-full border border-secondary px-4 py-2 text-xs font-semibold text-secondary transition hover:bg-secondary hover:text-background"
          >
            Export CSV
          </button>
        </div>
        <div className="overflow-x-auto rounded-3xl border border-background bg-white shadow">
          <table className="min-w-[640px] divide-y divide-background/60">
            <thead className="bg-secondary text-background">
              <tr>
                <th className="px-4 py-3 text-left text-xs uppercase tracking-wider">Name</th>
                <th className="px-4 py-3 text-left text-xs uppercase tracking-wider">Email</th>
                <th className="px-4 py-3 text-left text-xs uppercase tracking-wider">Role</th>
                <th className="px-4 py-3 text-left text-xs uppercase tracking-wider">Joined</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-background/60 text-sm text-primary">
              {users.map((user) => (
                <tr key={user.id}>
                  <td className="px-4 py-3 font-medium">{user.name}</td>
                  <td className="px-4 py-3">{user.email}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${user.role === 'admin' ? 'bg-primary/20 text-primary' : 'bg-secondary/20 text-secondary'}`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-4 py-3">{new Date(user.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {users.length === 0 && <p className="p-6 text-center text-sm text-secondary">No customers yet.</p>}
        </div>
      </section>
    </div>
  )
}
