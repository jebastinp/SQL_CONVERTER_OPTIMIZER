import { useEffect, useMemo, useState } from 'react'

import Header from '../components/Header'
import Loading from '../components/Loading'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'

const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

const getDayLabel = (value) => {
  if (!Number.isFinite(value)) return 'Unknown'
  return DAY_NAMES[value] || 'Unknown'
}

const formatDate = (value) => {
  if (!value) return ''
  try {
    return new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium' }).format(new Date(value))
  } catch (err) {
    console.error('Failed to format date', err)
    return value
  }
}

const formatDateTime = (value) => {
  if (!value) return ''
  try {
    return new Intl.DateTimeFormat('en-GB', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(new Date(value))
  } catch (err) {
    console.error('Failed to format date/time', err)
    return value
  }
}

const buildVendorCsv = (dateLabel, fishRows, meatRows) => {
  const rows = []
  rows.push([`VENDOR REPORT - ${dateLabel}`])
  rows.push([])

  rows.push(['FISH VENDOR'])
  rows.push(['FISH_NAME', 'TOTAL_QTY', 'HALF_KG', 'ONE_KG'])
  if (fishRows.length) {
    fishRows.forEach((row) => {
      rows.push([row.item_name, row.total_qty_kg, row.half_kg_bags, row.one_kg_bags])
    })
  } else {
    rows.push(['No fish orders', '', '', ''])
  }

  rows.push([])
  rows.push(['MEAT VENDOR'])
  rows.push(['MEAT_NAME', 'TOTAL_QTY', 'HALF_KG', 'ONE_KG'])
  if (meatRows.length) {
    meatRows.forEach((row) => {
      rows.push([row.item_name, row.total_qty_kg, row.half_kg_bags, row.one_kg_bags])
    })
  } else {
    rows.push(['No meat orders', '', '', ''])
  }

  return rows
    .map((line) =>
      line
        .map((cell) => {
          const text = cell == null ? '' : String(cell)
          if (/[",\n]/.test(text)) {
            return `"${text.replace(/"/g, '""')}"`
          }
          return text
        })
        .join(',')
    )
    .join('\n')
}

export default function DeliveryReport() {
  const { token, loading: authLoading, error: authError } = useAuth()
  const [initialising, setInitialising] = useState(true)
  const [loadingReport, setLoadingReport] = useState(false)
  const [error, setError] = useState('')
  const [report, setReport] = useState(null)
  const [orders, setOrders] = useState([])
  const [deliveryDates, setDeliveryDates] = useState([])
  const [selectedDate, setSelectedDate] = useState(() => {
    if (typeof window === 'undefined') return ''
    return window.localStorage.getItem('tarel.vendorReportDate') || ''
  })
  const [deliveryDay, setDeliveryDay] = useState(null)
  const [cutoffDay, setCutoffDay] = useState(null)

  useEffect(() => {
    if (!token) return

    let cancelled = false

    const load = async () => {
      setInitialising(true)
      setError('')

      try {
        const [data, ordersData] = await Promise.all([
          api('/admin/delivery-report', { token }),
          api('/admin/orders', { token })
        ])
        if (cancelled) return

        const dates = Array.isArray(data?.delivery_dates) ? data.delivery_dates : []
        setDeliveryDates(dates)
        setDeliveryDay(Number.isFinite(data?.delivery_day) ? Number(data.delivery_day) : null)
        setCutoffDay(Number.isFinite(data?.cutoff_day) ? Number(data.cutoff_day) : null)
        setOrders(Array.isArray(ordersData) ? ordersData : [])

        if (dates.length > 0) {
          setSelectedDate((previous) => {
            if (previous && dates.includes(previous)) {
              return previous
            }
            const defaultIndex = Math.min(4, dates.length - 1)
            return dates[defaultIndex]
          })
        }
      } catch (err) {
        if (cancelled) return
        console.error('Failed to load delivery report dates', err)
        setError(err instanceof Error ? err.message : 'Unable to load delivery report dates.')
      } finally {
        if (!cancelled) {
          setInitialising(false)
        }
      }
    }

    load()

    return () => {
      cancelled = true
    }
  }, [token])

  useEffect(() => {
    if (!token || !selectedDate) return

    if (typeof window !== 'undefined') {
      window.localStorage.setItem('tarel.vendorReportDate', selectedDate)
    }

    let cancelled = false

    const loadReport = async () => {
      setLoadingReport(true)
      setError('')

      try {
        const data = await api(`/admin/delivery-report/${selectedDate}`, { token })
        if (cancelled) return
        setReport(data)
      } catch (err) {
        if (cancelled) return
        console.error('Failed to load delivery report', err)
        setError(err instanceof Error ? err.message : 'Unable to load delivery report.')
      } finally {
        if (!cancelled) {
          setLoadingReport(false)
        }
      }
    }

    loadReport()

    return () => {
      cancelled = true
    }
  }, [token, selectedDate])

  const weekRange = useMemo(() => {
    if (!report?.week_start || !report?.week_end) return null
    return `${formatDate(report.week_start)} - ${formatDate(report.week_end)}`
  }, [report?.week_start, report?.week_end])

  const filteredOrders = useMemo(() => {
    if (!report?.week_start || !report?.week_end) return []
    const start = new Date(`${report.week_start}T00:00:00`)
    const end = new Date(`${report.week_end}T23:59:59.999`)
    if (Number.isNaN(start.valueOf()) || Number.isNaN(end.valueOf())) return []
    return orders.filter((order) => {
      if (!order?.created_at) return false
      const created = new Date(order.created_at)
      if (Number.isNaN(created.valueOf())) return false
      return created >= start && created <= end
    })
  }, [orders, report?.week_start, report?.week_end])

  const buildItemReport = (targetType) => {
    if (targetType === 'meat') {
      return []
    }
    const totals = new Map()
    filteredOrders.forEach((order) => {
      ;(order.items || []).forEach((item) => {
        const product = item.product || {}
        const name = product.name || 'Unknown item'
        const current = totals.get(name) || 0
        totals.set(name, current + Number(item.qty_kg || 0))
      })
    })

    const computeBags = (quantity) => {
      const total = Math.round(quantity * 2) / 2
      const oneKg = Math.floor(total)
      const halfKg = total - oneKg >= 0.5 ? 1 : 0
      return { oneKg, halfKg }
    }

    return Array.from(totals.entries()).map(([item_name, total_qty_kg]) => {
      const { oneKg, halfKg } = computeBags(total_qty_kg)
      return {
        item_name,
        total_qty_kg: Number(total_qty_kg.toFixed(2)),
        one_kg_bags: oneKg,
        half_kg_bags: halfKg
      }
    })
  }

  const fishReport = useMemo(() => buildItemReport('fish'), [filteredOrders])
  const meatReport = useMemo(() => buildItemReport('meat'), [filteredOrders])

  const handleDownloadReport = () => {
    if (!selectedDate) return
    const label = formatDate(selectedDate) || selectedDate
    const csv = buildVendorCsv(label, fishReport, meatReport)
    const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `vendor-report-${selectedDate}.csv`
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(url)
  }

  if (authLoading || initialising) {
    return <Loading message="Loading delivery report…" />
  }

  if (!token) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-primary">
        <div className="max-w-md rounded-3xl bg-white p-8 text-center shadow-xl">
          <h1 className="text-xl font-semibold">Admin session required</h1>
          <p className="mt-3 text-sm text-primary/70">
            {authError || 'Set VITE_ADMIN_EMAIL and VITE_ADMIN_PASSWORD in your environment to enable automatic dashboard access.'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header title="Vendor Report" subtitle="Weekly delivery order summary" />
      <section className="flex-1 space-y-6 bg-background px-4 py-6 sm:px-6">
        <div className="rounded-3xl border border-secondary/15 bg-white p-6 shadow-sm">
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-1 flex-col gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary/60">
              Delivery date
              <select
                value={selectedDate}
                onChange={(event) => setSelectedDate(event.target.value)}
                className="rounded-2xl border border-secondary/30 bg-white px-4 py-3 text-sm font-normal text-primary shadow-sm outline-none transition focus:border-secondary focus:ring-2 focus:ring-secondary/30"
              >
                {deliveryDates.map((date) => (
                  <option key={date} value={date}>
                    {formatDate(date)}
                  </option>
                ))}
              </select>
            </label>
            <div className="flex flex-wrap items-center justify-end gap-3">
              <button
                type="button"
                onClick={handleDownloadReport}
                disabled={!selectedDate}
                className="rounded-2xl border border-secondary/40 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-secondary transition hover:border-secondary hover:text-primary disabled:cursor-not-allowed disabled:opacity-50"
              >
                Download report
              </button>
            </div>
            <div className="flex-1 text-sm text-primary/60">
              <p>Delivery day: {getDayLabel(deliveryDay)}</p>
              <p>Cutoff day: {getDayLabel(cutoffDay)}</p>
            </div>
          </div>
        </div>

        {error && (
          <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        {loadingReport ? (
          <div className="rounded-3xl bg-white p-10 text-center text-sm text-primary/70 shadow-sm">
            Loading report...
          </div>
        ) : report ? (
          <>
            <div className="grid gap-4 lg:grid-cols-3">
              <div className="rounded-3xl border border-secondary/20 bg-white p-5 shadow-sm">
                <p className="text-xs uppercase tracking-[0.3em] text-secondary">Delivery date</p>
                <p className="mt-3 text-lg font-semibold text-primary">
                  {formatDate(report.delivery_date)}
                </p>
              </div>
              <div className="rounded-3xl border border-secondary/20 bg-white p-5 shadow-sm">
                <p className="text-xs uppercase tracking-[0.3em] text-secondary">Order window</p>
                <p className="mt-3 text-sm font-semibold text-primary">{weekRange || 'Not available'}</p>
              </div>
              <div className="rounded-3xl border border-secondary/20 bg-white p-5 shadow-sm">
                <p className="text-xs uppercase tracking-[0.3em] text-secondary">Cutoff day</p>
                <p className="mt-3 text-lg font-semibold text-primary">
                  {report.cutoff_day || getDayLabel(cutoffDay)}
                </p>
              </div>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-3xl border border-secondary/20 bg-white p-5 shadow-sm">
                <h3 className="text-sm font-semibold uppercase tracking-[0.3em] text-secondary">Fish report</h3>
                {fishReport.length ? (
                  <div className="mt-4 overflow-x-auto">
                    <table className="min-w-full text-sm text-primary/80">
                      <thead className="border-b border-secondary/20 text-xs uppercase tracking-[0.3em] text-secondary">
                        <tr>
                          <th className="px-3 py-2 text-left">Item</th>
                          <th className="px-3 py-2 text-right">Total kg</th>
                          <th className="px-3 py-2 text-right">1kg bags</th>
                          <th className="px-3 py-2 text-right">0.5kg bags</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fishReport.map((row) => (
                          <tr key={row.item_name} className="border-b border-secondary/10">
                            <td className="px-3 py-3 font-medium text-primary">{row.item_name}</td>
                            <td className="px-3 py-3 text-right">{row.total_qty_kg}</td>
                            <td className="px-3 py-3 text-right">{row.one_kg_bags}</td>
                            <td className="px-3 py-3 text-right">{row.half_kg_bags}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="mt-4 rounded-2xl border border-dashed border-secondary/30 bg-background px-4 py-8 text-center text-sm text-secondary">
                    No fish orders for this delivery date.
                  </p>
                )}
              </div>

              <div className="rounded-3xl border border-secondary/20 bg-white p-5 shadow-sm">
                <h3 className="text-sm font-semibold uppercase tracking-[0.3em] text-secondary">Meat report</h3>
                {meatReport.length ? (
                  <div className="mt-4 overflow-x-auto">
                    <table className="min-w-full text-sm text-primary/80">
                      <thead className="border-b border-secondary/20 text-xs uppercase tracking-[0.3em] text-secondary">
                        <tr>
                          <th className="px-3 py-2 text-left">Item</th>
                          <th className="px-3 py-2 text-right">Total kg</th>
                          <th className="px-3 py-2 text-right">1kg bags</th>
                          <th className="px-3 py-2 text-right">0.5kg bags</th>
                        </tr>
                      </thead>
                      <tbody>
                        {meatReport.map((row) => (
                          <tr key={row.item_name} className="border-b border-secondary/10">
                            <td className="px-3 py-3 font-medium text-primary">{row.item_name}</td>
                            <td className="px-3 py-3 text-right">{row.total_qty_kg}</td>
                            <td className="px-3 py-3 text-right">{row.one_kg_bags}</td>
                            <td className="px-3 py-3 text-right">{row.half_kg_bags}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="mt-4 rounded-2xl border border-dashed border-secondary/30 bg-background px-4 py-8 text-center text-sm text-secondary">
                    No meat orders for this delivery date.
                  </p>
                )}
              </div>
            </div>

            <div className="rounded-3xl border border-secondary/20 bg-white p-5 shadow-sm">
              <h3 className="text-sm font-semibold uppercase tracking-[0.3em] text-secondary">Orders</h3>
              {filteredOrders.length ? (
                <div className="mt-4 overflow-x-auto">
                  <table className="min-w-full text-sm text-primary/80">
                    <thead className="border-b border-secondary/20 text-xs uppercase tracking-[0.3em] text-secondary">
                      <tr>
                        <th className="px-3 py-2 text-left">Customer</th>
                        <th className="px-3 py-2 text-left">Order</th>
                        <th className="px-3 py-2 text-left">Placed</th>
                        <th className="px-3 py-2 text-left">Delivery</th>
                        <th className="px-3 py-2 text-right">Total</th>
                        <th className="px-3 py-2 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map((order) => (
                        <tr key={order.id} className="border-b border-secondary/10">
                          <td className="px-3 py-3 font-medium text-primary">
                            {order.user?.name || 'Unknown'}
                            <span className="block text-xs text-secondary">{order.user?.email || ''}</span>
                          </td>
                          <td className="px-3 py-3">#{order.id?.slice(0, 8)}</td>
                          <td className="px-3 py-3">
                            {order.created_at ? formatDateTime(order.created_at) : '—'}
                          </td>
                          <td className="px-3 py-3">{order.delivery_slot || '—'}</td>
                          <td className="px-3 py-3 text-right">£{Number(order.total_amount || 0).toFixed(2)}</td>
                          <td className="px-3 py-3 text-right">
                            <span className="rounded-full bg-secondary/10 px-3 py-1 text-xs text-secondary">
                              {String(order.status || '').replaceAll('_', ' ')}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="mt-4 rounded-2xl border border-dashed border-secondary/30 bg-background px-4 py-8 text-center text-sm text-secondary">
                  No orders found for this delivery window.
                </p>
              )}
            </div>
          </>
        ) : (
          <div className="rounded-3xl bg-white p-10 text-center text-sm text-primary/70 shadow-sm">
            Select a delivery date to view the report.
          </div>
        )}
      </section>
    </div>
  )
}
