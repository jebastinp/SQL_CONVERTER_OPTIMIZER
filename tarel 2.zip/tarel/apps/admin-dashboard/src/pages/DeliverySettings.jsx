import { useEffect, useMemo, useState } from 'react'

import Header from '../components/Header'
import Loading from '../components/Loading'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'

const DAY_OPTIONS = [
  { value: 0, label: 'Monday' },
  { value: 1, label: 'Tuesday' },
  { value: 2, label: 'Wednesday' },
  { value: 3, label: 'Thursday' },
  { value: 4, label: 'Friday' },
  { value: 5, label: 'Saturday' },
  { value: 6, label: 'Sunday' }
]

const getDayLabel = (value) => {
  const match = DAY_OPTIONS.find((option) => option.value === value)
  return match ? match.label : 'Unknown'
}

export default function DeliverySettings() {
  const { token, loading: authLoading, error: authError } = useAuth()
  const [initialising, setInitialising] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [feedback, setFeedback] = useState('')
  const [settings, setSettings] = useState(null)
  const [cutoffDay, setCutoffDay] = useState(4)
  const [deliveryDay, setDeliveryDay] = useState(2)

  useEffect(() => {
    if (!token) return

    let cancelled = false

    const load = async () => {
      setInitialising(true)
      setError('')

      try {
        const data = await api('/admin/delivery-settings', { token })
        if (cancelled) return
        setSettings(data)
        if (Number.isFinite(data?.cutoff_day)) {
          setCutoffDay(Number(data.cutoff_day))
        }
        if (Number.isFinite(data?.delivery_day)) {
          setDeliveryDay(Number(data.delivery_day))
        }
      } catch (err) {
        if (cancelled) return
        console.error('Failed to load delivery settings', err)
        setError(err instanceof Error ? err.message : 'Unable to load delivery settings.')
      } finally {
        if (!cancelled) {
          setInitialising(false)
        }
      }
    }

    load()

    return () => {
      cancelled = true
    }
  }, [token])

  useEffect(() => {
    if (!feedback) return
    const timer = setTimeout(() => setFeedback(''), 3500)
    return () => clearTimeout(timer)
  }, [feedback])

  const updatedDisplay = useMemo(() => {
    if (!settings?.updated_at) return null
    try {
      return new Intl.DateTimeFormat('en-GB', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }).format(new Date(settings.updated_at))
    } catch (err) {
      console.error('Failed to format delivery settings timestamp', err)
      return settings.updated_at
    }
  }, [settings?.updated_at])

  const handleSave = async (event) => {
    event.preventDefault()
    if (!token) return

    setSaving(true)
    setError('')
    setFeedback('')

    try {
      const payload = {
        cutoff_day: Number(cutoffDay),
        delivery_day: Number(deliveryDay)
      }
      const data = await api('/admin/delivery-settings', {
        method: 'POST',
        token,
        body: payload
      })
      setSettings(data)
      setFeedback('Delivery settings updated.')
    } catch (err) {
      console.error('Failed to update delivery settings', err)
      setError(err instanceof Error ? err.message : 'Unable to update delivery settings.')
    } finally {
      setSaving(false)
    }
  }

  if (authLoading || initialising) {
    return <Loading message="Loading delivery settings…" />
  }

  if (!token) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-primary">
        <div className="max-w-md rounded-3xl bg-white p-8 text-center shadow-xl">
          <h1 className="text-xl font-semibold">Admin session required</h1>
          <p className="mt-3 text-sm text-primary/70">
            {authError || 'Set VITE_ADMIN_EMAIL and VITE_ADMIN_PASSWORD in your environment to enable automatic dashboard access.'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header title="Delivery Settings" subtitle="Weekly delivery configuration" />
      <section className="flex-1 space-y-6 bg-background px-4 py-6 sm:px-6">
        <div className="rounded-3xl border border-secondary/15 bg-white p-6 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-secondary">Current schedule</p>
              <h2 className="mt-2 text-2xl font-semibold text-primary">
                {getDayLabel(deliveryDay)} deliveries
              </h2>
              <p className="mt-2 text-sm text-primary/60">
                Orders can be cancelled until {getDayLabel(cutoffDay)} of the order week.
              </p>
              {updatedDisplay && (
                <p className="mt-1 text-xs uppercase tracking-[0.2em] text-primary/40">
                  Updated {updatedDisplay}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-secondary/15 bg-white p-6 shadow-sm">
          <h3 className="text-sm font-semibold uppercase tracking-[0.3em] text-secondary">
            Update settings
          </h3>
          <form onSubmit={handleSave} className="mt-5 grid gap-4 md:grid-cols-2">
            <label className="flex flex-col gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary/60">
              Cutoff day
              <select
                value={cutoffDay}
                onChange={(event) => setCutoffDay(Number(event.target.value))}
                className="rounded-2xl border border-secondary/30 bg-white px-4 py-3 text-sm font-normal text-primary shadow-sm outline-none transition focus:border-secondary focus:ring-2 focus:ring-secondary/30"
              >
                {DAY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary/60">
              Delivery day
              <select
                value={deliveryDay}
                onChange={(event) => setDeliveryDay(Number(event.target.value))}
                className="rounded-2xl border border-secondary/30 bg-white px-4 py-3 text-sm font-normal text-primary shadow-sm outline-none transition focus:border-secondary focus:ring-2 focus:ring-secondary/30"
              >
                {DAY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </label>
            <div className="flex flex-wrap items-center gap-3 md:col-span-2 md:justify-end">
              <button
                type="submit"
                disabled={saving}
                className="rounded-2xl bg-secondary px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-primary disabled:cursor-not-allowed disabled:opacity-60"
              >
                {saving ? 'Saving…' : 'Save changes'}
              </button>
            </div>
          </form>
        </div>

        {feedback && (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            {feedback}
          </div>
        )}
        {error && (
          <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}
      </section>
    </div>
  )
}
