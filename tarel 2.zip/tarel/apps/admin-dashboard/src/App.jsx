import { Navigate, Route, Routes } from 'react-router-dom'

import ProtectedOutlet from './components/ProtectedOutlet'
import AdminLayout from './layouts/AdminLayout'
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import Products from './pages/Products'
import OrderDetails from './pages/OrderDetails'
import Customers from './pages/Customers'
import Reports from './pages/Reports'
import Categories from './pages/Categories'
import DeliverySettings from './pages/DeliverySettings'
import DeliveryReport from './pages/DeliveryReport'

export default function App() {
  return (
    <Routes>
      <Route path="/admin/login" element={<Login />} />
      <Route path="/login" element={<Navigate to="/admin/login" replace />} />

      <Route element={<ProtectedOutlet />}>
        <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
        <Route
          path="/admin/dashboard"
          element={
            <AdminLayout>
              <Dashboard />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/orders"
          element={
            <AdminLayout>
              <OrderDetails />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/products"
          element={
            <AdminLayout>
              <Products />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/categories"
          element={
            <AdminLayout>
              <Categories />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/customers"
          element={
            <AdminLayout>
              <Customers />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/delivery-settings"
          element={
            <AdminLayout>
              <DeliverySettings />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/delivery-report"
          element={
            <AdminLayout>
              <DeliveryReport />
            </AdminLayout>
          }
        />
        <Route
          path="/admin/reports"
          element={
            <AdminLayout>
              <Reports />
            </AdminLayout>
          }
        />
      </Route>

      <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
    </Routes>
  )
}
