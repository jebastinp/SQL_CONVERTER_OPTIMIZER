import React from 'react'

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { error: null, info: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    this.setState({ error, info })
    if (typeof console !== 'undefined') {
      console.error('Unhandled error caught by ErrorBoundary:', error, info)
    }
  }

  render() {
    const { error, info } = this.state
    if (error) {
      return (
        <div style={{ padding: 24, fontFamily: 'sans-serif' }}>
          <h1 style={{ color: '#b91c1c' }}>Something went wrong</h1>
          <p style={{ color: '#374151' }}>{String(error && error.message)}</p>
          {info && info.componentStack ? (
            <pre style={{ whiteSpace: 'pre-wrap', background: '#f8fafc', padding: 12, borderRadius: 6 }}>{info.componentStack}</pre>
          ) : null}
          <div style={{ marginTop: 12 }}>
            <button onClick={() => window.location.reload()} style={{ padding: '8px 12px' }}>
              Reload
            </button>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}
