CREATE TABLE IF NOT EXISTS delivery_settings (
    id UUID PRIMARY KEY,
    cutoff_day INTEGER NOT NULL DEFAULT 4,
    delivery_day INTEGER NOT NULL DEFAULT 2,
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS delivery_orders (
    id UUID PRIMARY KEY,
    customer_name VARCHAR(120) NOT NULL,
    customer_phone VARCHAR(30) NOT NULL,
    item_type VARCHAR(10) NOT NULL,
    item_name VARCHAR(160) NOT NULL,
    quantity_kg NUMERIC(6, 2) NOT NULL,
    order_date DATE NOT NULL,
    delivery_date DATE NOT NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'active',
    cancelled_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_delivery_orders_delivery_date ON delivery_orders (delivery_date);
CREATE INDEX IF NOT EXISTS idx_delivery_orders_status ON delivery_orders (status);
