BEGIN;

ALTER TABLE products
  ADD COLUMN IF NOT EXISTS half_kg_price NUMERIC(10, 2),
  ADD COLUMN IF NOT EXISTS one_kg_price NUMERIC(10, 2);

UPDATE products
SET
  one_kg_price = COALESCE(one_kg_price, price_per_kg),
  half_kg_price = COALESCE(half_kg_price, ROUND(price_per_kg / 2.0, 2));

-- Keep price_per_kg as a deprecated compatibility field for older clients.
-- New code should read one_kg_price and half_kg_price.

COMMIT;
