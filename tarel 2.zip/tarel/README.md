# Tarel — Edinburgh Seafood Marketplace

A full-stack e-commerce platform for a seafood delivery service targeting Edinburgh
postcodes (EH1–EH17).

```
┌─────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER                          │
│                                                             │
│   Next.js 14 Storefront        React + Vite Admin Panel     │
│   apps/frontend/  :3000        apps/admin-dashboard/  :5173 │
└────────────────────────┬───────────────────────────────────┘
                         │ HTTP / REST
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                        API LAYER                             │
│   FastAPI  backend/  :8000  (JWT · RBAC · OAuth · OTP)      │
└────────────────────────┬───────────────────────────────────┘
                         │ SQLAlchemy / psycopg3
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                      DATABASE LAYER                          │
│   PostgreSQL 15 (local)                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## Repository Layout

```
tarel/
├── apps/
│   ├── frontend/               # Next.js 14 customer storefront (TypeScript)
│   └── admin-dashboard/        # Vite + React admin panel (JavaScript)
├── backend/                    # FastAPI backend (Python 3.11)
│   ├── app/
│   │   ├── main.py             # ASGI entry-point
│   │   ├── config.py           # pydantic-settings configuration
│   │   ├── database.py         # SQLAlchemy engine + session
│   │   ├── models/             # ORM models
│   │   ├── schemas/            # Pydantic request/response schemas
│   │   ├── routers/            # FastAPI routers (auth, products, orders …)
│   │   └── services/           # Business logic layer
│   ├── tests/                  # Pytest test suite
│   └── requirements.txt
├── db/
│   └── postgres-schema.sql     # Baseline DDL
├── docs/
│   ├── migrations/             # SQL migration scripts (chronological)
│   └── postgres-schema.sql     # Latest schema reference
├── infra/
│   └── scripts/
│       ├── backup_db.sh        # pg_dump to db/backups/
│       └── restore_db.sh       # Restore from dump
├── dev.sh                      # One-command local dev (starts all 3 services)
├── Makefile                    # Convenience commands
├── .env.example                # Canonical variable reference (all services)
└── .gitignore
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Customer storefront | Next.js 14 (App Router), React 18, Tailwind CSS, SWR, Framer Motion |
| Admin dashboard | Vite 5, React 18, React Router 6, Tailwind CSS, Lucide React |
| Backend API | FastAPI 0.114, Uvicorn, SQLAlchemy 2, psycopg3, Pydantic 2, pydantic-settings |
| Auth | JWT (python-jose), bcrypt (passlib), Google OAuth (authlib), Email OTP |
| Database | PostgreSQL 15 (local) |
| Testing | pytest, httpx, Jest, Vitest, @testing-library/react |

---

## Quick Start

### Prerequisites

- **Python 3.11+** with pip
- **Node.js 20+** with npm
- **PostgreSQL 15+** running locally

### 1. Backend Setup

```bash
cd backend

# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env — set DATABASE_URL to your local Postgres instance at minimum
```

Create your local database and apply the schema:

```bash
psql -U postgres -c "CREATE DATABASE tarel;"
psql -U postgres -d tarel -f ../db/postgres-schema.sql
```

Seed the database with sample data + admin user:

```bash
python -m app.seed
```

Run the backend:

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API docs: http://localhost:8000/docs  
Health check: http://localhost:8000/health

### 2. Frontend Setup

```bash
cd apps/frontend

npm install

cp .env.local.example .env.local
# Default: NEXT_PUBLIC_API_BASE=http://localhost:8000

npm run dev
```

Storefront: http://localhost:3000

### 3. Admin Dashboard Setup

```bash
cd apps/admin-dashboard

npm install

cp .env.example .env
# Default: VITE_API_BASE=http://localhost:8000/api

npm run dev
```

Admin panel: http://localhost:5173

---

## One-Command Dev

After completing setup once, start all three services from the repo root:

```bash
./dev.sh
```

This launches:
- Backend API → http://localhost:8000
- Next.js storefront → http://localhost:3000
- Admin dashboard → http://localhost:5173

Press `Ctrl+C` once to stop all three.

To test from a phone or another device on the same network:

```bash
TAREL_NETWORK=1 ./dev.sh
# Uses your machine's LAN IP instead of localhost
```

---

## Environment Variables

Each service has its own `.env` file. See the comments inside each `.env.example`
for descriptions.

| File | Service | Key Variables |
|---|---|---|
| `backend/.env` | FastAPI | `DATABASE_URL`, `JWT_SECRET`, `FRONTEND_ORIGINS`, `MAIL_*`, `GOOGLE_*` |
| `apps/frontend/.env.local` | Next.js | `NEXT_PUBLIC_API_BASE` |
| `apps/admin-dashboard/.env` | Vite/React | `VITE_API_BASE` |

> **Why separate files?**
> Vite and Next.js inline `VITE_*` / `NEXT_PUBLIC_*` vars **at build time** — they
> cannot read runtime env files. The backend reads vars at startup. Each service
> owns only what it needs.
>
> The root `.env.example` is a **reference document** — it lists every variable
> used by any service so you have one place to look them up.

---

## API Reference

Base URL: `http://localhost:8000/api`

Interactive docs: `GET /docs` (Swagger UI) · `GET /redoc` (ReDoc)

| Group | Endpoints | Auth |
|---|---|---|
| Auth | `POST /auth/register`, `/auth/login`, `GET /auth/me`, `/auth/google/*`, `/auth/send-otp`, `/auth/verify-otp`, `/auth/reset-password` | Public / User |
| Products | `GET /products`, `/products/{slug}`, `/products/category/{slug}` | Public |
| Categories | `GET /categories`, `/categories/{slug}` | Public |
| Orders | `POST /orders`, `GET /orders`, `/orders/{id}` | User |
| Support | `POST /support/messages`, `GET /support/messages` | User |
| Site | `GET /site/delivery` | Public |
| Admin | `GET/POST/PUT/DELETE /admin/products`, `categories`, `orders`, `customers`, `support/messages`, `site-settings` | Admin |
| Health | `GET /health` | Public |

Admin login after seeding: `admin@tarel.local` / `admin123`

---

## Testing

```bash
# Backend
cd backend
source .venv/bin/activate
pytest tests/ -v

# Frontend
cd apps/frontend
npm test

# Admin dashboard
cd apps/admin-dashboard
npm test
```

---

## Database

The backend runs `Base.metadata.create_all()` at startup (auto-creates tables based
on ORM models).

**Manual schema application:**

```bash
psql -U postgres -d tarel -f db/postgres-schema.sql
```

**Backup / Restore:**

```bash
make backup    # dumps to db/backups/tarel_TIMESTAMP.dump
make restore   # restores from most recent dump
```

---

## Features

### Customer Storefront
- Product catalogue with category filtering
- Edinburgh postcode service area check (EH1–EH17)
- Shopping cart & checkout
- Order history & status tracking
- Google OAuth + Email OTP sign-in
- Password reset via email

### Admin Dashboard
- KPI dashboard (revenue, orders, customers)
- Product CRUD with image upload (local or Cloudinary)
- Category management
- Order status workflow (pending → paid → processing → out\_for\_delivery → delivered)
- Customer list
- Sales reports & analytics
- Support ticket management
- CSV export for all data views

### Backend API
- JWT authentication with role-based access control (user / admin)
- Google OAuth callback
- Email OTP for signup verification and password reset
- Edinburgh postcode validation + address autocomplete (GetAddress.io)
- Stripe integration placeholder (test key wired, live checkout pending)
- Cloudinary image storage (optional — set `USE_CLOUDINARY=true`)

---

## Roadmap

- [ ] Stripe checkout sessions + webhooks
- [ ] Refresh tokens + HttpOnly cookie auth
- [ ] SSR product/category pages with filters
- [ ] Low-stock inventory alerts
- [ ] Customer email notifications (order confirmation, dispatch)
