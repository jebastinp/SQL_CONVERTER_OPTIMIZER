#!/usr/bin/env bash
set -euo pipefail

BACKEND_VENV="backend/.venv"

if [ -f "${BACKEND_VENV}/bin/activate" ]; then
  source "${BACKEND_VENV}/bin/activate"
  if ! python -c "import cloudinary" >/dev/null 2>&1; then
    echo "Backend virtualenv is missing required packages. Run 'cd backend && source .venv/bin/activate && pip install -r requirements.txt'." >&2
    exit 1
  fi
else
  echo "Backend virtualenv not found. Run 'cd backend && python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt' first." >&2
  exit 1
fi

LOCAL_IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "localhost")

# By default, use localhost for API base URLs (more reliable on laptops/VPNs).
# Opt into LAN-IP mode (for testing from phones/other devices) with: TAREL_NETWORK=1 ./dev.sh
API_HOST="localhost"
if [ "${TAREL_NETWORK:-0}" = "1" ] && [ "${LOCAL_IP}" != "localhost" ]; then
  API_HOST="${LOCAL_IP}"
fi

echo "========================================"
echo "🚀 Starting TAREL Development Services"
echo "========================================"
echo ""
echo "📱 Access from mobile/other devices:"
echo "   Backend API:  http://${LOCAL_IP}:8000"
echo "   Frontend:     http://${LOCAL_IP}:3000"
echo "   Admin Panel:  http://${LOCAL_IP}:5173"
echo ""
echo "💻 Access from this machine:"
echo "   Backend API:  http://localhost:8000"
echo "   Frontend:     http://localhost:3000"
echo "   Admin Panel:  http://localhost:5173"
echo ""
echo "API base mode: ${API_HOST}  (set TAREL_NETWORK=1 for LAN IP mode)"
echo ""
echo "Press Ctrl+C to stop all services"
echo "========================================"
echo ""

cleanup() {
  echo ""
  echo "========================================"
  echo "🛑 Stopping all services..."
  echo "========================================"
  pkill -P $$ || true
  echo "✅ All services stopped"
}

trap cleanup EXIT

(
  cd backend
  # Keep using the active venv selected above
  export GETADDRESS_API_KEY="UF1ey2evy0iTrxKXrVcLbA48669"
  # Allow CORS from localhost and local network IP for mobile access
  export FRONTEND_ORIGINS="http://localhost:5173,http://localhost:3000,http://${LOCAL_IP}:5173,http://${LOCAL_IP}:3000"
  echo "[backend] Starting uvicorn on http://0.0.0.0:8000"
  echo "[backend] CORS enabled for: ${FRONTEND_ORIGINS}"
  uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
) &

(
  cd apps/frontend
  export NEXT_PUBLIC_API_BASE="http://${API_HOST}:8000"
  echo "[frontend] Starting Next.js dev server on http://0.0.0.0:3000"
  echo "[frontend] API Base: ${NEXT_PUBLIC_API_BASE}"
  npm run dev -- --hostname 0.0.0.0
) &

(
  cd apps/admin-dashboard
  export VITE_API_BASE="http://${API_HOST}:8000/api"
  echo "[admin] Starting Vite dev server on http://0.0.0.0:5173"
  echo "[admin] API Base: ${VITE_API_BASE}"
  npm run dev -- --host
) &

wait
