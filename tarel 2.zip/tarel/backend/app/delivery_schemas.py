from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


class DeliverySettingsOut(BaseModel):
    id: UUID
    cutoff_day: int
    delivery_day: int
    updated_at: datetime

    class Config:
        from_attributes = True


class DeliverySettingsUpdate(BaseModel):
    cutoff_day: int = Field(ge=0, le=6)
    delivery_day: int = Field(ge=0, le=6)


class DeliveryOrderCreate(BaseModel):
    customer_name: str
    customer_phone: str
    item_type: str
    item_name: str
    quantity_kg: Decimal

    @field_validator("item_type")
    @classmethod
    def validate_item_type(cls, value: str) -> str:
        item_type = value.strip().lower()
        if item_type not in {"fish", "meat"}:
            raise ValueError("item_type must be fish or meat")
        return item_type

    @field_validator("quantity_kg")
    @classmethod
    def validate_quantity(cls, value: Decimal) -> Decimal:
        if value <= 0:
            raise ValueError("quantity_kg must be greater than 0")
        if (value * 2) % 1 != 0:
            raise ValueError("quantity_kg must be in 0.5 kg steps")
        return value


class DeliveryOrderOut(BaseModel):
    id: UUID
    customer_name: str
    customer_phone: str
    item_type: str
    item_name: str
    quantity_kg: Decimal
    order_date: date
    delivery_date: date
    status: str
    cancelled_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True
