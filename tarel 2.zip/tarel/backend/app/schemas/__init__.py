"""Schema re-exports for app-wide imports."""

from app._schemas_legacy import *  # type: ignore  # noqa: F401,F403
from app.schemas.common import MessageResponse, PagedResponse