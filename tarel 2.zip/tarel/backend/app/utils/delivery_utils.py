"""Delivery utility helpers."""

from datetime import date, timedelta
from decimal import Decimal
from typing import Optional, Tuple, Union

from sqlalchemy.orm import Session

from app.models.delivery import DeliverySetting

DAY_NAMES = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
]


def get_delivery_settings(db: Session) -> DeliverySetting:
    settings = db.query(DeliverySetting).order_by(DeliverySetting.updated_at.desc()).first()
    if settings:
        return settings

    settings = DeliverySetting(cutoff_day=4, delivery_day=2)
    db.add(settings)
    db.commit()
    db.refresh(settings)
    return settings


def _sunday_start(target: date) -> date:
    offset = (target.weekday() + 1) % 7
    return target - timedelta(days=offset)


def get_delivery_date(order_date: date, delivery_day: int = 2) -> date:
    delivery_day = int(delivery_day)
    week_start = _sunday_start(order_date)
    offset = delivery_day + 1
    return week_start + timedelta(days=7 + offset)


def get_week_range(delivery_date: date) -> Tuple[date, date]:
    delivery_week_start = _sunday_start(delivery_date)
    order_week_start = delivery_week_start - timedelta(days=7)
    order_week_end = order_week_start + timedelta(days=6)
    return order_week_start, order_week_end


def is_cancellation_allowed(
    order_date: date,
    cutoff_day: int = 4,
    delivery_day: int = 2,
    today: Optional[date] = None,
) -> bool:
    today = today or date.today()
    delivery_date = get_delivery_date(order_date, delivery_day)
    order_week_start, _ = get_week_range(delivery_date)
    cutoff_date = order_week_start + timedelta(days=cutoff_day + 1)
    return today <= cutoff_date


def calculate_bags(total_kg: Union[Decimal, float, int]) -> Tuple[int, int]:
    total = Decimal(str(total_kg)).quantize(Decimal("0.5"))
    one_kg = int(total // 1)
    remainder = total - Decimal(one_kg)
    half_kg = 1 if remainder == Decimal("0.5") else 0
    return one_kg, half_kg


def next_delivery_date(today: date, delivery_day: int) -> date:
    weekday = today.weekday()
    if weekday <= delivery_day:
        return today + timedelta(days=delivery_day - weekday)
    return today + timedelta(days=7 + (delivery_day - weekday))
