from __future__ import annotations


def calculate_price(weight_kg, one_kg_price, half_kg_price):
    full_kgs = int(weight_kg)
    has_half = round(weight_kg % 1, 1) == 0.5
    return (full_kgs * one_kg_price) + (half_kg_price if has_half else 0)
