from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core.constants import (
    API_PREFIX,
    DEFAULT_ACCESS_TOKEN_EXPIRE_MINUTES,
    DEFAULT_DATABASE_URL,
    DEFAULT_FRONTEND_APP_URL,
    DEFAULT_FRONTEND_ORIGINS,
    DEFAULT_GETADDRESS_BASE_URL,
    DEFAULT_JWT_ALG,
    DEFAULT_JWT_SECRET,
    DEFAULT_MAIL_PORT,
    DEFAULT_MEDIA_ROOT,
    DEFAULT_MEDIA_URL,
    DEFAULT_REPORT_EMAIL,
    DEFAULT_STRIPE_SECRET_KEY,
    PROJECT_NAME as DEFAULT_PROJECT_NAME,
)


class Settings(BaseSettings):
    """Application settings loaded from environment variables and .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    # Project metadata
    PROJECT_NAME: str = DEFAULT_PROJECT_NAME
    API_PREFIX: str = API_PREFIX

    # Database
    DATABASE_URL: str = Field(default=DEFAULT_DATABASE_URL)

    # Security
    JWT_SECRET: str = Field(default=DEFAULT_JWT_SECRET)
    JWT_ALG: str = DEFAULT_JWT_ALG
    ACCESS_TOKEN_EXPIRE_MINUTES: int = DEFAULT_ACCESS_TOKEN_EXPIRE_MINUTES

    # CORS
    FRONTEND_ORIGINS: str = DEFAULT_FRONTEND_ORIGINS

    @field_validator("FRONTEND_ORIGINS", mode="before")
    @classmethod
    def _parse_origins(cls, v: str) -> str:
        # Accept both comma-separated string and a list (e.g. from JSON env)
        if isinstance(v, list):
            return ",".join(v)
        return v

    @property
    def BACKEND_CORS_ORIGINS(self) -> list[str]:
        return [o.strip() for o in self.FRONTEND_ORIGINS.split(",") if o.strip()]

    FRONTEND_APP_URL: str = DEFAULT_FRONTEND_APP_URL

    # Media storage
    MEDIA_ROOT: str = DEFAULT_MEDIA_ROOT
    MEDIA_URL: str = DEFAULT_MEDIA_URL

    # Stripe
    STRIPE_SECRET_KEY: str = Field(default=DEFAULT_STRIPE_SECRET_KEY)

    # Reporting
    REPORT_EMAIL: str = DEFAULT_REPORT_EMAIL

    # Address lookup
    GETADDRESS_API_KEY: Optional[str] = None
    GETADDRESS_BASE_URL: str = DEFAULT_GETADDRESS_BASE_URL

    # Cloudinary (optional)
    USE_CLOUDINARY: bool = False
    CLOUDINARY_CLOUD_NAME: Optional[str] = None
    CLOUDINARY_API_KEY: Optional[str] = None
    CLOUDINARY_API_SECRET: Optional[str] = None

    # Google OAuth (optional)
    GOOGLE_CLIENT_ID: Optional[str] = None
    GOOGLE_CLIENT_SECRET: Optional[str] = None
    GOOGLE_REDIRECT_URI: Optional[str] = None

    # Mail (required for OTP / password reset)
    MAIL_SERVER: Optional[str] = None
    MAIL_PORT: int = DEFAULT_MAIL_PORT
    MAIL_USE_TLS: bool = True
    MAIL_USERNAME: Optional[str] = None
    MAIL_PASSWORD: Optional[str] = None
    MAIL_DEFAULT_SENDER: Optional[str] = None


settings = Settings()
