from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.category import Category
from app.models.product import CutCleanOption, Product
from app.schemas import CutCleanOptionOut, ProductCreate, ProductOut

router = APIRouter(prefix="/products", tags=["products"])


def _serialize_product(product: Product) -> dict:
    one_kg_price = product.one_kg_price if product.one_kg_price is not None else product.price_per_kg
    half_kg_price = product.half_kg_price if product.half_kg_price is not None else round(one_kg_price / 2, 2)
    return {
        "id": product.id,
        "name": product.name,
        "slug": product.slug,
        "description": product.description,
        "price_per_kg": one_kg_price,
        "half_kg_price": half_kg_price,
        "one_kg_price": one_kg_price,
        "image_url": product.image_url,
        "stock_kg": product.stock_kg,
        "is_dry": product.is_dry,
        "is_active": product.is_active,
        "category": {
            "id": product.category.id,
            "name": product.category.name,
            "slug": product.category.slug,
            "description": product.category.description,
            "is_active": product.category.is_active,
        }
        if product.category
        else None,
    }


@router.get("/", response_model=List[ProductOut])
def list_products(db: Session = Depends(get_db)):
    products = db.query(Product).filter(Product.is_active.is_(True)).all()
    return [_serialize_product(product) for product in products]


@router.get("/{slug}", response_model=ProductOut)
def get_product(slug: str, db: Session = Depends(get_db)):
    prod = (
        db.query(Product)
        .filter(Product.slug == slug, Product.is_active.is_(True))
        .first()
    )
    if not prod:
        raise HTTPException(status_code=404, detail="Product not found")
    return _serialize_product(prod)


@router.post("/", response_model=ProductOut)
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    if not db.query(Category).filter(Category.id == payload.category_id).first():
        raise HTTPException(status_code=400, detail="Invalid category")

    one_kg_price = payload.one_kg_price if payload.one_kg_price is not None else payload.price_per_kg
    half_kg_price = payload.half_kg_price
    if half_kg_price is None and payload.price_per_kg is not None:
        half_kg_price = round(payload.price_per_kg / 2, 2)
    if one_kg_price is None or half_kg_price is None:
        raise HTTPException(status_code=400, detail="Both half_kg_price and one_kg_price are required")

    prod = Product(
        name=payload.name,
        slug=payload.slug,
        description=payload.description,
        price_per_kg=one_kg_price,
        half_kg_price=half_kg_price,
        one_kg_price=one_kg_price,
        image_url=payload.image_url,
        stock_kg=payload.stock_kg,
        is_dry=payload.is_dry,
        category_id=payload.category_id,
    )
    db.add(prod)
    db.commit()
    db.refresh(prod)
    return _serialize_product(prod)


@router.get("/cut-clean-options", response_model=List[CutCleanOptionOut])
def get_active_cut_clean_options(db: Session = Depends(get_db)):
    """Get all active cut & clean options for users."""
    options = (
        db.query(CutCleanOption)
        .filter(CutCleanOption.is_active.is_(True))
        .order_by(CutCleanOption.sort_order, CutCleanOption.label)
        .all()
    )
    return options
