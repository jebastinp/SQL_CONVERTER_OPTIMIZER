from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..delivery_models import DeliveryOrder
from ..delivery_schemas import DeliveryOrderCreate, DeliveryOrderOut
from ..delivery_utils import DAY_NAMES, get_delivery_date, get_delivery_settings, is_cancellation_allowed

router = APIRouter(prefix="/order", tags=["delivery-orders"])


@router.post("/place", response_model=DeliveryOrderOut)
def place_delivery_order(payload: DeliveryOrderCreate, db: Session = Depends(get_db)):
    settings = get_delivery_settings(db)
    order_date = datetime.utcnow().date()
    delivery_date = get_delivery_date(order_date, settings.delivery_day)

    order = DeliveryOrder(
        customer_name=payload.customer_name.strip(),
        customer_phone=payload.customer_phone.strip(),
        item_type=payload.item_type,
        item_name=payload.item_name.strip(),
        quantity_kg=payload.quantity_kg,
        order_date=order_date,
        delivery_date=delivery_date,
        status="active",
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    return order


@router.post("/cancel/{order_id}", response_model=DeliveryOrderOut)
def cancel_delivery_order(order_id: str, db: Session = Depends(get_db)):
    order = db.query(DeliveryOrder).filter(DeliveryOrder.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    settings = get_delivery_settings(db)
    if not is_cancellation_allowed(order.order_date, settings.cutoff_day, settings.delivery_day):
        cutoff_name = DAY_NAMES[settings.cutoff_day]
        raise HTTPException(
            status_code=400,
            detail=f"Cancellation not allowed after {cutoff_name}",
        )

    if order.status != "cancelled":
        order.status = "cancelled"
        order.cancelled_at = datetime.utcnow()
        db.add(order)
        db.commit()
        db.refresh(order)

    return order
