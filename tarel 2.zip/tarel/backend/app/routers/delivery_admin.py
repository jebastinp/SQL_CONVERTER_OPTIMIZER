from datetime import date
from decimal import Decimal
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin
from ..delivery_models import DeliveryOrder, DeliverySetting
from ..delivery_schemas import DeliverySettingsOut, DeliverySettingsUpdate
from ..delivery_utils import (
    DAY_NAMES,
    calculate_bags,
    get_delivery_settings,
    get_week_range,
    next_delivery_date,
)

router = APIRouter(prefix="/admin", tags=["delivery-admin"])


@router.get("/delivery-settings", response_model=DeliverySettingsOut)
def get_delivery_settings_route(
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    del admin
    return get_delivery_settings(db)


@router.post("/delivery-settings", response_model=DeliverySettingsOut)
def update_delivery_settings(
    payload: DeliverySettingsUpdate,
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    del admin
    settings = get_delivery_settings(db)
    settings.cutoff_day = payload.cutoff_day
    settings.delivery_day = payload.delivery_day
    db.add(settings)
    db.commit()
    db.refresh(settings)
    return settings


@router.get("/delivery-report")
def list_delivery_reports(
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    del admin
    settings = get_delivery_settings(db)
    base_date = next_delivery_date(date.today(), settings.delivery_day)
    delivery_dates = [
        (base_date.fromordinal(base_date.toordinal() + (weeks * 7))).isoformat()
        for weeks in range(-4, 5)
    ]

    return {
        "delivery_dates": delivery_dates,
        "delivery_day": settings.delivery_day,
        "cutoff_day": settings.cutoff_day,
    }


@router.get("/delivery-report/{delivery_date}")
def delivery_report_detail(
    delivery_date: date,
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    del admin

    settings = get_delivery_settings(db)
    orders: List[DeliveryOrder] = (
        db.query(DeliveryOrder)
        .filter(DeliveryOrder.delivery_date == delivery_date)
        .order_by(DeliveryOrder.created_at.asc())
        .all()
    )

    active_orders = [order for order in orders if order.status == "active"]

    def build_report(item_type: str) -> List[dict]:
        grouped: dict[str, Decimal] = {}
        for order in active_orders:
            if order.item_type != item_type:
                continue
            grouped[order.item_name] = grouped.get(order.item_name, Decimal("0")) + Decimal(
                str(order.quantity_kg)
            )

        report = []
        for item_name, total_qty in sorted(grouped.items()):
            one_kg, half_kg = calculate_bags(total_qty)
            report.append(
                {
                    "item_name": item_name,
                    "total_qty_kg": float(total_qty),
                    "one_kg_bags": one_kg,
                    "half_kg_bags": half_kg,
                }
            )
        return report

    week_start, week_end = get_week_range(delivery_date)

    return {
        "delivery_date": delivery_date.isoformat(),
        "week_start": week_start.isoformat(),
        "week_end": week_end.isoformat(),
        "delivery_day": DAY_NAMES[settings.delivery_day],
        "cutoff_day": DAY_NAMES[settings.cutoff_day],
        "fish_report": build_report("fish"),
        "meat_report": build_report("meat"),
        "orders": [
            {
                "id": str(order.id),
                "customer_name": order.customer_name,
                "customer_phone": order.customer_phone,
                "item_type": order.item_type,
                "item_name": order.item_name,
                "quantity_kg": float(order.quantity_kg),
                "status": order.status,
                "order_date": order.order_date.isoformat(),
                "delivery_date": order.delivery_date.isoformat(),
                "cancelled_at": order.cancelled_at.isoformat() if order.cancelled_at else None,
                "created_at": order.created_at.isoformat(),
            }
            for order in orders
        ],
    }
