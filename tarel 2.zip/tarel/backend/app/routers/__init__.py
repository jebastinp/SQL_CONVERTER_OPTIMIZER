from . import (
    admin,
    auth,
    categories,
    delivery_admin,
    delivery_orders,
    getaddress,
    orders,
    products,
    site,
    support,
)

__all__ = [
    "admin",
    "auth",
    "categories",
    "delivery_admin",
    "delivery_orders",
    "getaddress",
    "orders",
    "products",
    "site",
    "support",
]
