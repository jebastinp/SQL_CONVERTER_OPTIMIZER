from datetime import datetime, timedelta
from email.message import EmailMessage
import secrets
import smtplib
from urllib.parse import quote

from authlib.integrations.starlette_client import OAuth, OAuthError
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.auth import create_access_token, hash_password, verify_password
from app.config import settings
from app.database import get_db
from app.deps import get_current_user
from app.models.user import OTPCode, User
from app.schemas import (
    OTPRequest,
    OTPVerify,
    PasswordReset,
    TokenOut,
    UserCreate,
    UserOut,
    UserUpdate,
)
from app.utils import generate_user_code

router = APIRouter(prefix="/auth", tags=["auth"])

oauth = OAuth()
if settings.GOOGLE_CLIENT_ID and settings.GOOGLE_CLIENT_SECRET:
    oauth.register(
        name="google",
        client_id=settings.GOOGLE_CLIENT_ID,
        client_secret=settings.GOOGLE_CLIENT_SECRET,
        server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
        client_kwargs={"scope": "openid email profile"},
    )


def _ensure_google_oauth():
    if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
        raise HTTPException(status_code=500, detail="Google OAuth is not configured")
    if not settings.GOOGLE_REDIRECT_URI:
        raise HTTPException(status_code=500, detail="Google redirect URI is not configured")
    if not getattr(oauth, "google", None):
        raise HTTPException(status_code=500, detail="Google OAuth client not initialized")
    return oauth.google


def _send_otp_email(recipient: str, code: str):
    if not settings.MAIL_SERVER or not settings.MAIL_USERNAME or not settings.MAIL_PASSWORD:
        raise HTTPException(status_code=500, detail="Email service is not configured")

    msg = EmailMessage()
    msg["Subject"] = "Your Tarel verification code"
    msg["From"] = settings.MAIL_DEFAULT_SENDER or settings.MAIL_USERNAME
    msg["To"] = recipient
    msg.set_content(f"Your verification code is {code}. It expires in 10 minutes.")

    with smtplib.SMTP(settings.MAIL_SERVER, settings.MAIL_PORT) as server:
        server.ehlo()
        if settings.MAIL_USE_TLS:
            server.starttls()
            server.ehlo()
        server.login(settings.MAIL_USERNAME, settings.MAIL_PASSWORD)
        server.send_message(msg)


@router.post("/register", response_model=UserOut)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    exists = db.query(User).filter(User.email == payload.email).first()
    if exists:
        raise HTTPException(status_code=400, detail="Email already registered")

    try:
        user_code = generate_user_code(db, payload.postcode)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error

    user = User(
        name=payload.name,
        email=payload.email,
        password_hash=hash_password(payload.password),
        phone=payload.phone,
        address_line1=payload.address_line1,
        locality=payload.locality.strip() if payload.locality else None,
        city=payload.city,
        postcode=payload.postcode,
        user_code=user_code,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenOut)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    token = create_access_token({"sub": str(user.id), "role": user.role})
    return TokenOut(access_token=token, user=user)


@router.get("/me", response_model=UserOut)
def read_current_user(current_user: User = Depends(get_current_user)) -> User:
    return current_user


@router.patch("/me", response_model=UserOut)
def update_current_user(
    payload: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> User:
    updated = False

    if payload.name is not None and payload.name != current_user.name:
        current_user.name = payload.name
        updated = True

    if payload.password:
        current_user.password_hash = hash_password(payload.password)
        updated = True

    if updated:
        db.add(current_user)
        db.commit()
        db.refresh(current_user)

    return current_user


@router.post("/send-otp")
def send_otp(payload: OTPRequest, db: Session = Depends(get_db)):
    email = payload.email
    code = f"{secrets.randbelow(1000000):06d}"
    expires_at = datetime.utcnow() + timedelta(minutes=10)

    otp = OTPCode(email=email, code=code, expires_at=expires_at, used=False)
    db.add(otp)
    db.commit()

    _send_otp_email(email, code)
    return {"status": "sent"}


@router.post("/verify-otp")
def verify_otp(payload: OTPVerify, db: Session = Depends(get_db)):
    now = datetime.utcnow()
    record = (
        db.query(OTPCode)
        .filter(OTPCode.email == payload.email)
        .filter(OTPCode.used.is_(False))
        .filter(OTPCode.expires_at > now)
        .order_by(OTPCode.created_at.desc())
        .first()
    )

    if not record or record.code != payload.code:
        raise HTTPException(status_code=400, detail="Invalid or expired code")

    record.used = True
    db.add(record)
    db.commit()

    return {"status": "verified"}


@router.post("/reset-password")
def reset_password(payload: PasswordReset, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    now = datetime.utcnow()
    record = (
        db.query(OTPCode)
        .filter(OTPCode.email == payload.email)
        .filter(OTPCode.used.is_(False))
        .filter(OTPCode.expires_at > now)
        .order_by(OTPCode.created_at.desc())
        .first()
    )

    if not record or record.code != payload.code:
        raise HTTPException(status_code=400, detail="Invalid or expired code")

    user.password_hash = hash_password(payload.new_password)
    record.used = True
    db.add(record)
    db.add(user)
    db.commit()

    return {"status": "password_updated"}


@router.get("/google")
async def google_login(request: Request, next: str = "/"):
    client = _ensure_google_oauth()
    return await client.authorize_redirect(
        request,
        settings.GOOGLE_REDIRECT_URI,
        state=next,
    )


@router.get("/google/callback")
async def google_callback(request: Request, db: Session = Depends(get_db)):
    client = _ensure_google_oauth()

    try:
        token = await client.authorize_access_token(request)
    except OAuthError:
        raise HTTPException(status_code=400, detail="Google authentication failed")

    userinfo = token.get("userinfo")
    if not userinfo:
        userinfo = await client.userinfo(token=token)

    email = (userinfo.get("email") or "").strip().lower()
    if not email:
        raise HTTPException(status_code=400, detail="Google account missing email")

    google_id = userinfo.get("sub")
    name = userinfo.get("name") or email.split("@")[0]
    picture = userinfo.get("picture")

    user = db.query(User).filter(User.email == email).first()
    if not user and google_id:
        user = db.query(User).filter(User.google_id == google_id).first()

    if not user:
        random_password = secrets.token_urlsafe(32)
        user = User(
            name=name,
            email=email,
            password_hash=hash_password(random_password),
            google_id=google_id,
            profile_photo=picture,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    else:
        updated = False
        if google_id and user.google_id != google_id:
            user.google_id = google_id
            updated = True
        if picture and not user.profile_photo:
            user.profile_photo = picture
            updated = True
        if user.name != name and name:
            user.name = name
            updated = True
        if updated:
            db.add(user)
            db.commit()
            db.refresh(user)

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    next_path = request.query_params.get("state") or "/"
    frontend_url = settings.FRONTEND_APP_URL.rstrip("/")
    redirect_url = f"{frontend_url}/login?token={access_token}&next={quote(next_path)}"
    return RedirectResponse(url=redirect_url)
