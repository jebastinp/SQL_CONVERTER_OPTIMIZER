"""Request-scoped context helpers."""

from contextvars import ContextVar
from typing import Optional

request_id_context: ContextVar[Optional[str]] = ContextVar("request_id", default=None)


def get_request_id(default: Optional[str] = None) -> Optional[str]:
    value = request_id_context.get()
    return value if value is not None else default
