"""Request logging helpers and per-request file writer."""

import json
import logging
from pathlib import Path
from time import perf_counter
from uuid import uuid4

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.core.constants import (
    REQUEST_ID_HEADER,
    REQUEST_LOG_DIRECTORY,
    REQUEST_LOG_ENCODING,
)
from app.core.request_context import get_request_id, request_id_context

logger = logging.getLogger("tarel.request")


def configure_logging() -> None:
    """Create the request log directory and keep the root logger usable."""
    Path(REQUEST_LOG_DIRECTORY).mkdir(parents=True, exist_ok=True)
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s %(message)s",
        )


def _write_request_log(request_id: str, payload: dict) -> None:
    log_dir = Path(REQUEST_LOG_DIRECTORY)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{request_id}.log"
    with log_file.open("a", encoding=REQUEST_LOG_ENCODING) as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")


class RequestIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get(REQUEST_ID_HEADER) or str(uuid4())
        token = request_id_context.set(request_id)
        started_at = perf_counter()
        response = None
        error_message = None

        try:
            response = await call_next(request)
            response.headers[REQUEST_ID_HEADER] = request_id
            return response
        except Exception as exc:
            error_message = str(exc)
            logger.exception("Request failed", extra={"request_id": request_id})
            raise
        finally:
            duration_ms = round((perf_counter() - started_at) * 1000, 2)
            payload = {
                "request_id": request_id,
                "method": request.method,
                "path": str(request.url.path),
                "query": str(request.url.query),
                "status_code": getattr(response, "status_code", 500 if error_message else 200),
                "duration_ms": duration_ms,
                "client": request.client.host if request.client else None,
                "error": error_message,
                "request_id_context": get_request_id(),
            }
            _write_request_log(request_id, payload)
            request_id_context.reset(token)
