"""Core application constants kept in one place."""

PROJECT_NAME = "Tarel API"
API_PREFIX = "/api"

DEFAULT_DATABASE_URL = "postgresql+psycopg://postgres:password@localhost:5432/tarel"
DEFAULT_JWT_SECRET = "devsecret-change-in-production"
DEFAULT_JWT_ALG = "HS256"
DEFAULT_ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7

DEFAULT_FRONTEND_ORIGINS = "http://localhost:5173,http://localhost:3000"
DEFAULT_FRONTEND_APP_URL = "http://localhost:3000"

DEFAULT_MEDIA_ROOT = "media"
DEFAULT_MEDIA_URL = "/media"

DEFAULT_REPORT_EMAIL = "admin@tarel.local"
DEFAULT_STRIPE_SECRET_KEY = "sk_test_placeholder"
DEFAULT_GETADDRESS_BASE_URL = "https://api.getAddress.io"

DEFAULT_MAIL_PORT = 587

REQUEST_ID_HEADER = "X-Request-ID"
REQUEST_LOG_DIRECTORY = "logs/requests"
REQUEST_LOG_ENCODING = "utf-8"
