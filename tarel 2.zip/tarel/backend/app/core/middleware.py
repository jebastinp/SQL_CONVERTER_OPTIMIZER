"""Middleware setup helpers."""

from app.core.request_logging import RequestIdMiddleware


def setup_middleware(app):
    """Attach shared middleware to a FastAPI app."""
    app.add_middleware(RequestIdMiddleware)
    return app