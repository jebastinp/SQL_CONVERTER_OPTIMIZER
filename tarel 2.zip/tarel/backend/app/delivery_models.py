"""Legacy delivery model re-export."""

from app.models.delivery import DeliveryOrder, DeliverySetting

__all__ = ["DeliveryOrder", "DeliverySetting"]
