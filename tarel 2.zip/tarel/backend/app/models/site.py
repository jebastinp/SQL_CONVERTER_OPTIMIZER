"""Site settings model."""

from datetime import datetime

from sqlalchemy import Column, DateTime, String

from app.database import Base


class SiteSetting(Base):
    __tablename__ = "site_settings"

    key = Column(String(120), primary_key=True)
    value = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
