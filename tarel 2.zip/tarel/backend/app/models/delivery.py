"""Weekly delivery settings and orders."""

from datetime import datetime
import uuid

from sqlalchemy import Column, Date, DateTime, Integer, Numeric, String

from app.database import Base, GUID


class DeliverySetting(Base):
    __tablename__ = "delivery_settings"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    cutoff_day = Column(Integer, default=4, nullable=False)
    delivery_day = Column(Integer, default=2, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class DeliveryOrder(Base):
    __tablename__ = "delivery_orders"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    customer_name = Column(String(120), nullable=False)
    customer_phone = Column(String(30), nullable=False)
    item_type = Column(String(10), nullable=False)
    item_name = Column(String(160), nullable=False)
    quantity_kg = Column(Numeric(6, 2), nullable=False)
    order_date = Column(Date, nullable=False)
    delivery_date = Column(Date, nullable=False)
    status = Column(String(10), default="active", nullable=False)
    cancelled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
