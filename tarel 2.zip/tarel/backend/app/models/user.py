"""User, role, support, and OTP models."""

from datetime import datetime
import enum
import uuid

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, String, Text
from sqlalchemy.orm import relationship

from app.database import Base, GUID


class RoleEnum(str, enum.Enum):
    user = "user"
    admin = "admin"


class User(Base):
    __tablename__ = "users"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    name = Column(String(120), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(RoleEnum), default=RoleEnum.user, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    google_id = Column(String(255), unique=True, nullable=True)
    profile_photo = Column(String(500), nullable=True)
    phone = Column(String(30), nullable=True)
    address_line1 = Column(String(255), nullable=True)
    locality = Column(String(120), nullable=True)
    city = Column(String(120), nullable=True)
    postcode = Column(String(12), nullable=True)
    user_code = Column(String(16), unique=True, nullable=True)

    orders = relationship("Order", back_populates="user")


class SupportStatusEnum(str, enum.Enum):
    open = "open"
    pending = "pending"
    closed = "closed"


class SupportMessage(Base):
    __tablename__ = "support_messages"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    user_id = Column(GUID, ForeignKey("users.id"), nullable=False)
    subject = Column(String(160), nullable=False)
    message = Column(Text, nullable=False)
    response = Column(Text, nullable=True)
    status = Column(Enum(SupportStatusEnum), default=SupportStatusEnum.open, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User")


class OTPCode(Base):
    __tablename__ = "otp_codes"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    email = Column(String(255), index=True, nullable=False)
    code = Column(String(6), nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
