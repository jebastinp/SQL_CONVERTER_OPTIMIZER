"""Cart models (placeholder for future expansion)."""

# No cart models defined yet.
