"""Order models and status enums."""

from datetime import datetime
import enum
import uuid

from sqlalchemy import Column, DateTime, Enum, Float, ForeignKey, String
from sqlalchemy.orm import relationship

from app.database import Base, GUID


class OrderStatusEnum(str, enum.Enum):
    pending = "pending"
    paid = "paid"
    processing = "processing"
    out_for_delivery = "out_for_delivery"
    delivered = "delivered"
    cancelled = "cancelled"


class Order(Base):
    __tablename__ = "orders"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    user_id = Column(GUID, ForeignKey("users.id"), nullable=False)
    total_amount = Column(Float, nullable=False)
    status = Column(Enum(OrderStatusEnum), default=OrderStatusEnum.pending)
    delivery_slot = Column(String(50), nullable=True)
    address_line = Column(String(255), nullable=False)
    city = Column(String(120), default="Edinburgh")
    postcode = Column(String(12), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="orders")
    items = relationship("OrderItem", back_populates="order")


class OrderItem(Base):
    __tablename__ = "order_items"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    order_id = Column(GUID, ForeignKey("orders.id"), nullable=False)
    product_id = Column(GUID, ForeignKey("products.id"), nullable=False)
    qty_kg = Column(Float, nullable=False)
    price_per_kg = Column(Float, nullable=False)

    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")
