"""Category model."""

import uuid

from sqlalchemy import Boolean, Column, String, Text
from sqlalchemy.orm import relationship

from app.database import Base, GUID


class Category(Base):
    __tablename__ = "categories"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    name = Column(String(120), unique=True, nullable=False)
    slug = Column(String(140), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)

    products = relationship("Product", back_populates="category")
