"""Product and cut/clean option models."""

from datetime import datetime
import uuid

from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, String, Text
from sqlalchemy.orm import relationship

from app.database import Base, GUID


class Product(Base):
    __tablename__ = "products"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    name = Column(String(160), nullable=False)
    slug = Column(String(180), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    price_per_kg = Column(Float, nullable=False)
    half_kg_price = Column(Float, nullable=True)
    one_kg_price = Column(Float, nullable=True)
    image_url = Column(String(500), nullable=True)
    stock_kg = Column(Float, default=0)
    is_dry = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    category_id = Column(GUID, ForeignKey("categories.id"), nullable=False)

    category = relationship("Category", back_populates="products")
    order_items = relationship("OrderItem", back_populates="product")


class CutCleanOption(Base):
    __tablename__ = "cut_clean_options"

    id = Column(GUID, primary_key=True, index=True, default=uuid.uuid4)
    label = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    sort_order = Column(Float, default=0, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
