from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from .config import settings
from .database import Base, engine
from . import delivery_models
from .core.middleware import setup_middleware
from .core.request_logging import configure_logging
from .routers import (
    admin,
    auth,
    categories,
    delivery_admin,
    delivery_orders,
    getaddress,
    orders,
    products,
    site,
    support,
)
from .seed import seed_database


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: create tables and seed on startup."""
    Base.metadata.create_all(bind=engine)
    try:
        seed_database()
    except Exception as e:
        import logging
        logging.getLogger("tarel.main").warning("Could not seed database: %s", e)
    yield


configure_logging()
app = FastAPI(title=settings.PROJECT_NAME, lifespan=lifespan)

# ── Middleware ────────────────────────────────────────────────────────────────
# CORS must be added before other middleware that reads the request body.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

setup_middleware(app)
app.add_middleware(SessionMiddleware, secret_key=settings.JWT_SECRET)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth.router, prefix=settings.API_PREFIX)
app.include_router(categories.router, prefix=settings.API_PREFIX)
app.include_router(products.router, prefix=settings.API_PREFIX)
app.include_router(orders.router, prefix=settings.API_PREFIX)
app.include_router(admin.router, prefix=settings.API_PREFIX)
app.include_router(delivery_admin.router, prefix=settings.API_PREFIX)
app.include_router(site.router, prefix=settings.API_PREFIX)
app.include_router(support.router, prefix=settings.API_PREFIX)
app.include_router(getaddress.router)
app.include_router(delivery_orders.router)

# ── Static media ──────────────────────────────────────────────────────────────
media_path = Path(settings.MEDIA_ROOT)
media_path.mkdir(parents=True, exist_ok=True)
media_mount = (
    settings.MEDIA_URL
    if settings.MEDIA_URL.startswith("/")
    else f"/{settings.MEDIA_URL}"
)
app.mount(media_mount, StaticFiles(directory=media_path), name="media")


# ── Utility endpoints ─────────────────────────────────────────────────────────
@app.get("/health", tags=["ops"])
def health_check():
    """Liveness probe — used by Docker and load balancers."""
    return {"status": "ok"}


@app.get("/")
def root():
    return {"status": "ok", "name": settings.PROJECT_NAME}
