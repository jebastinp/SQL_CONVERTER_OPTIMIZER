# Tarel — Security Audit

This document records the access-control model and how every
endpoint is scoped. Use it as a checklist when adding new endpoints
or auditing the app.

---

## Threat model

Three actor types:

| Actor | What they can do |
|---|---|
| Anonymous (no token) | Browse the storefront (products, categories). Sign up. Sign in. |
| Authenticated user (Supabase JWT, `role=user`) | Anything anonymous can do, **plus** see/manage **their own** orders, cart, profile, payments. **Never** other users' data. |
| Admin (Supabase JWT, `role=admin`) | Everything. Sees all orders, all customers, all payments. Can issue refunds, change order status, manage catalog. |

A user's role lives in `public.users.role` and is mirrored into the
Supabase token's `app_metadata.role` claim. The role is checked on
every request in the backend — never trusted from the browser.

---

## Defense layers (3, in order)

### Layer 1 — Service layer ownership checks (primary defense)

Every customer endpoint that takes a UUID looks the row up **scoped
to the current user**. If a customer tries to fetch order `ORD-9999`
that belongs to someone else, they get a **404 Not Found** — never a
403 (which would leak that the row exists).

Implementation: `OrderService.get_for_user(uuid, user)`:

```python
order = await self._orders.get_by_uuid(uuid)
if order is None or order.user_id != user.id:
    raise NotFoundError("Order not found")   # ← deliberately ambiguous
return order
```

### Layer 2 — Router-level auth dependency

Every route declares its required identity at the function signature:

```python
async def get_my_orders(user: CurrentUserDep, ...):   # requires JWT
async def admin_list_orders(_admin: CurrentAdminDep, ...):  # requires admin
```

`CurrentUserDep` and `CurrentAdminDep` are FastAPI dependencies that
verify the Supabase token, look up the local user, and raise 401/403
*before* the handler runs.

### Layer 3 — Database Row-Level Security (defense in depth)

Defined in `db/03_rls.sql`. Even if every Layer-1/2 check were bypassed,
the database itself denies access to any non-`postgres` role on every
sensitive table.

Only these tables permit anonymous reads (storefront catalog):
- `categories` (active only)
- `products` (active only)
- `cut_clean_options` (active only)
- `delivery_settings`
- `site_settings`

Every other table has no policy → default deny.

---

## Endpoint inventory & ownership

### Public (anonymous-allowed)

| Method | Path | Notes |
|---|---|---|
| `GET`  | `/api/v1/products` | Storefront catalog |
| `GET`  | `/api/v1/products/{slug}` | Single product |
| `GET`  | `/api/v1/products/cut-clean-options` | Filter options |
| `GET`  | `/api/v1/categories` | Catalog navigation |
| `POST` | `/api/v1/payments/webhook/handypay` | Gateway → us. Verified by HMAC signature, not auth. |
| `GET`  | `/health` | Liveness check |

### Authenticated user (token required, scoped to `user.id`)

| Method | Path | Scoping |
|---|---|---|
| `GET`    | `/api/v1/auth/me` | Returns the caller's profile |
| `POST`   | `/api/v1/auth/register` | Creates/updates the caller's local profile |
| `GET`    | `/api/v1/users/me` | Returns the caller's profile |
| `PATCH`  | `/api/v1/users/me` | Updates the caller's profile only |
| `GET`    | `/api/v1/orders/me` | Lists `user_id = current_user.id` only |
| `POST`   | `/api/v1/orders` | Creates with `user_id = current_user.id` |
| `GET`    | `/api/v1/orders/{uuid}` | `get_for_user` — 404 if not the caller's |
| `POST`   | `/api/v1/orders/{uuid}/cancel` | `get_for_user` — same scoping |
| `POST`   | `/api/v1/orders/{uuid}/checkout` | `get_for_user` — same scoping |
| `GET`    | `/api/v1/orders/{uuid}/payment` | `get_for_user` — same scoping |

### Admin only (`role = admin` required)

| Method | Path |
|---|---|
| `GET`    | `/api/v1/admin/customers` |
| `GET`    | `/api/v1/admin/categories` |
| `POST`   | `/api/v1/admin/categories` |
| `PATCH`  | `/api/v1/admin/categories/{uuid}` |
| `DELETE` | `/api/v1/admin/categories/{uuid}` |
| `GET`    | `/api/v1/admin/orders` |
| `GET`    | `/api/v1/admin/orders/{uuid}` |
| `PATCH`  | `/api/v1/admin/orders/{uuid}/status` |
| `POST`   | `/api/v1/admin/orders/{uuid}/refund` |
| `GET`    | `/api/v1/admin/payments` |
| `POST`   | `/api/v1/admin/payments/{uuid}/refund` |
| `GET`    | `/api/v1/admin/reports/vendor.xlsx` |

---

## Frontend route guards

### Admin pages — `/[adminSlug]/...`

Three layers stack on top of each other:

1. **URL obscurity** — admin lives at `/<NEXT_PUBLIC_ADMIN_PATH>/...`. Default is `tarel-control` but you can set it to anything. Customers see no link to it anywhere.
2. **Middleware** (`web/middleware.ts`) — for any request whose first segment is the admin slug, decodes the JWT cookie and:
   - No token → real 404 (so the path looks non-existent)
   - Token without `role=admin` → real 404
   - Token expired → real 404
   - Wrong slug entirely → real 404
3. **Layout-level guard** (`(admin)/[adminSlug]/layout.tsx`) — client-side re-check on render. If the role somehow flips (token refreshed with new claims), the admin shell unmounts.

### User pages — `/account/...`

`(user)/layout.tsx` is a client component that:
- Renders a loading state while the auth session resolves
- Redirects to `/login` if no user
- Mounts the page only once a user is confirmed

Backend endpoints don't trust this guard alone — they still verify
the JWT every request.

---

## Payment & webhook security

### Checkout flow

```
Customer → POST /orders/{uuid}/checkout
        ↓ (backend creates Payment row, calls gateway)
Customer → 302 redirect → gateway hosted checkout
Customer → completes payment on gateway
        ↓
[Two parallel paths reconciled by webhook]
   Path A: gateway redirects customer back to /checkout/success
   Path B: gateway POSTs webhook → us mark Payment as 'succeeded'
        ↓
/checkout/success → polls /orders/{uuid}/payment until status updates
```

Path A and Path B are **idempotent and asynchronous**. Either can
arrive first. The customer page polls until the backend confirms
(driven by the webhook).

### Webhook signature verification

`HandyPayGateway.verify_webhook()` checks the `X-HandyPay-Signature`
header (HMAC-SHA256 of the raw body using `HANDYPAY_WEBHOOK_SECRET`).
If signature is missing or invalid, the request is rejected before
any DB write.

The Mock gateway accepts unsigned payloads (development only — never
use `PAYMENT_GATEWAY=mock` in production).

### Refund authorization

- A **customer** can trigger a refund **only indirectly**, by
  cancelling their own order *before* the cutoff day. The
  cancellation rule is preserved verbatim from the legacy app
  (`is_cancellation_allowed`).
- An **admin** can refund any successful payment at any time via
  Admin → Payments → Refund. Partial refunds are supported.
- Refund amount is server-validated against the payment's remaining
  refundable balance.

---

## Data exposure audit (Pydantic schemas)

User-facing responses are restricted to safe fields. Verified:

- `UserOut` — exposes `uuid` (renamed to `id`), email, name, role,
  profile fields, addresses, postcode, phone. **Does not** expose
  `supabase_id` (internal join key) or any hash.
- `OrderSummary` — minimal projection for lists; no PII beyond what
  the owner is meant to see.
- `OrderDetail` — full info, but only returned by `get_for_user` so
  scoping is enforced.
- `PaymentOut` — provider name & ID, amount, status. Provider keys
  are never exposed.
- `AdminPaymentRow` (admin only) — joins customer email/name. Admin
  endpoint, admin-required.

---

## What I deliberately did NOT do (and why)

- **No CSRF tokens.** The API is JWT-based (no cookies for auth
  beyond the optional mirror cookie for middleware). All API calls
  go through `fetch` with the Authorization header, which browsers
  do not auto-include from another origin.
- **No rate limiting.** Out of scope for this milestone. For
  production, add `slowapi` or put Cloudflare in front.
- **No request body size limit beyond defaults.** FastAPI's default
  is generally safe; tighten if you accept file uploads at this layer.

---

## How to verify yourself

1. **Try to fetch someone else's order**:
   - Sign in as user A.
   - Note one of your order UUIDs.
   - Sign in as user B (different account).
   - Hit `GET /api/v1/orders/<A's uuid>` → expect **404**, not 200.
2. **Try to call an admin endpoint as a regular user**:
   - Sign in as `role=user`.
   - Hit `GET /api/v1/admin/orders` → expect **403 Forbidden**.
3. **Try the admin URL as a regular user**:
   - Sign in as `role=user`.
   - Visit `/tarel-control` → expect **404 page**, not the admin shell.
4. **Inspect a customer JWT**:
   - Sign in, copy your token from `tarel.supabase.auth` in localStorage.
   - Decode it on <https://jwt.io>.
   - Should contain `sub`, `email`, `role: authenticated`, `exp`.
   - Should NOT contain a database id, password hash, or any
     internal field.
