# How to run Tarel

One command starts everything. This guide tells you which command, what
URLs to open, and what to test.

---

## 1. One-time setup

### Prerequisites
- **Python 3.11+** (`python3 --version`)
- **Node 20+** (`node --version`)
- **macOS / Linux / WSL** (the dev script uses bash)

### Run the SQL queries in Supabase (once)

Open **Supabase dashboard → SQL Editor**. Run these three files in order:

1. `db/01_schema.sql` — base tables (users, products, orders, etc.)
2. `db/02_payments.sql` — payment, refund, and payment_event tables
3. `db/03_rls.sql` — row-level security policies (defense in depth)

> Already done step 1? Run only steps 2 and 3 now. Just open each
> file, copy the contents into Supabase SQL Editor, click Run.

### Install dependencies (once)

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd ..

cd web
npm install
cd ..
```

### Promote your account to admin (once, after first signup)

After you first sign up in the running app, open Supabase SQL Editor:

```sql
update public.users set role = 'admin' where email = 'YOUR_EMAIL_HERE';
```

Sign out and back in to refresh your token.

---

## 2. Start everything — ONE command

From the project root:

```bash
./dev.sh
```

This:
- Starts the backend on `0.0.0.0:8000` (visible to your phone over WiFi)
- Starts the web app on `0.0.0.0:3000` (visible to your phone over WiFi)
- Detects your LAN IP and prints clickable URLs
- Stops both with Ctrl-C

You'll see something like this when it boots:

```
Tarel — development
────────────────────────────────────────────────────────
Backend
  Local           http://localhost:8000
  LAN (phone)     http://192.168.1.42:8000
  Docs            http://localhost:8000/docs
  Health          http://localhost:8000/health

Web app
  Local           http://localhost:3000
  LAN (phone)     http://192.168.1.42:3000
  Admin           http://localhost:3000/tarel-control
  Admin (LAN)     http://192.168.1.42:3000/tarel-control
────────────────────────────────────────────────────────
```

> First time on macOS: when you visit a LAN URL from your phone, the
> Mac may pop up a firewall prompt — **click "Allow"** so other devices
> can connect.

---

## 3. URL cheat sheet

### Customer (use a phone or laptop)

| What | URL |
|---|---|
| Homepage | `http://<LAN-IP>:3000/` |
| Shop | `http://<LAN-IP>:3000/products` |
| Sign up | `http://<LAN-IP>:3000/register` |
| Sign in | `http://<LAN-IP>:3000/login` |
| Cart | `http://<LAN-IP>:3000/cart` |
| Checkout | `http://<LAN-IP>:3000/checkout` |
| Account | `http://<LAN-IP>:3000/account` |
| My orders | `http://<LAN-IP>:3000/account/orders` |
| My profile | `http://<LAN-IP>:3000/account/profile` |

### Admin (your phone or a desktop)

> The admin slug is set in `web/.env.local` as `NEXT_PUBLIC_ADMIN_PATH`.
> Default is `tarel-control`. Non-admins (and wrong slugs) see a real 404.

| What | URL |
|---|---|
| Admin login | `http://<LAN-IP>:3000/tarel-control/login` |
| Dashboard | `http://<LAN-IP>:3000/tarel-control/dashboard` |
| Orders (priority-sorted) | `http://<LAN-IP>:3000/tarel-control/orders` |
| Payments + refunds | `http://<LAN-IP>:3000/tarel-control/payments` |
| Products | `http://<LAN-IP>:3000/tarel-control/products` |
| Categories | `http://<LAN-IP>:3000/tarel-control/categories` |
| Customers (search by email) | `http://<LAN-IP>:3000/tarel-control/customers` |
| Reports (vendor XLSX) | `http://<LAN-IP>:3000/tarel-control/reports` |

### Backend

| What | URL |
|---|---|
| Health | `http://localhost:8000/health` |
| Auto-generated docs | `http://localhost:8000/docs` |
| HandyPay webhook receiver | `http://<LAN-IP>:8000/api/v1/webhook/handypay` |

---

## 4. Payment flow (mock & HandyPay)

### Default: mock gateway

Out of the box `PAYMENT_GATEWAY=mock` in `backend/.env`. This means:

1. Customer fills cart → goes to `/checkout`
2. App creates an order in the DB and a payment session via the mock gateway
3. Customer is redirected to `/checkout/mock` — a simulator page that says
   "Pay" or "Simulate failure"
4. Click "Pay" → page calls the webhook → backend marks payment + order as paid
5. Customer is redirected to `/checkout/success` → order is confirmed
6. **Admin → Payments** shows the row with the **"Refund"** button

This gives you the entire flow working end-to-end without any real money or HandyPay account.

### When HandyPay is ready

1. Get your 4 keys from HandyPay's merchant dashboard
2. Fill in `backend/.env`:
   ```
   PAYMENT_GATEWAY=handypay
   HANDYPAY_API_KEY=...
   HANDYPAY_SECRET=...
   HANDYPAY_MERCHANT_ID=...
   HANDYPAY_WEBHOOK_SECRET=...
   ```
3. In HandyPay's dashboard, set the webhook URL to your public backend URL
   (use [ngrok](https://ngrok.com/) for local dev):
   ```
   https://<your-ngrok-url>/api/v1/webhook/handypay
   ```
4. Restart `./dev.sh`. The same checkout flow now uses real HandyPay.

> The HandyPay adapter (`backend/app/modules/payments/handypay.py`) uses
> the standard REST + HMAC-signed webhook pattern. You'll need to verify
> three endpoint paths against your actual HandyPay docs:
> - "Create checkout" endpoint path
> - "Refund" endpoint path
> - Webhook signature header name
>
> They're marked with `# TODO: verify against HandyPay docs` comments
> in the file. Fix those three constants and the rest works.

---

## 5. Cancellation & refund

Cancellation rules are **preserved verbatim** from the legacy system
(see `DELIVERY_LOGIC_PRESERVED.md`):

- A customer can cancel an order **up to the cutoff day** of the
  order's delivery week
- After the cutoff, cancellation is refused (admin can still cancel)
- When an order is cancelled and a payment exists, a refund is
  automatically issued through the same gateway that took payment

Where it's exposed in the UI:

- **Customer**: `Account → My orders → [order]` → "Cancel order"
  button (visible only if cancellation is allowed)
- **Admin**: `Admin → Orders → [order]` → status controls including
  Cancel + manual refund
- **Admin**: `Admin → Payments` → per-row Refund button (partial
  refunds supported)

---

## 6. Testing on your phone

1. Make sure your phone and Mac are on the **same WiFi network**
2. Run `./dev.sh` on your Mac
3. Look at the "LAN (phone)" URL in the printed output
4. Open it in Safari/Chrome on your phone
5. Add to home screen for the native-app feel (uses the PWA manifest)

If it doesn't load:
- Mac firewall is blocking the port → System Settings → Network → Firewall → allow
- Phone is on a different network (cellular instead of WiFi) → switch to WiFi
- `LAN_IP` printed as `localhost` → tell me and I'll add detection for your network adapter

---

## 7. Per-request logs

Every API request gets a UUID and a dedicated log file:

```
backend/logs/requests/<request-id>.log
```

The UUID is returned to the browser in the `X-Request-ID` header, so
when a customer reports an error you can grep that exact request:

```bash
grep -l "ORD-000123" backend/logs/requests/*.log
```

---

## 8. Common issues

| Symptom | Fix |
|---|---|
| `dev.sh: Permission denied` | `chmod +x dev.sh` |
| Backend won't start, "DATABASE_URL not set" | `backend/.env` missing — copy from earlier message |
| `npm: command not found` | Install Node 20+ from <https://nodejs.org/> |
| Phone says "can't connect to server" | Firewall is blocking — see section 6 above |
| Admin 404s even with admin slug | You're not signed in as an admin — run the `update users set role='admin'` SQL |
| Webhook never arrives in dev | HandyPay can't reach your laptop — use ngrok |
| `STORAGE_BACKEND='supabase' but bucket missing` | Create the `tarel-products` bucket in Supabase Storage |
