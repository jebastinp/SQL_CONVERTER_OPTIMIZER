from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_file, send_from_directory, abort
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from datetime import datetime, date, timedelta
from decimal import Decimal
import csv
import bcrypt
import json
import os
from flask_cors import CORS

from config import Config
from models import db, User, Customer, FishMaster, DeliveryWeek, Order, OrderItem, Invoice, Payment, Expense, Income, VendorReport, WhatsAppMessage, Settings

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    CORS(
        app,
        resources={r"/api/*": {"origins": os.environ.get('FRONTEND_ORIGIN', '*')}},
        supports_credentials=True,
    )

    db.init_app(app)

    login_manager = LoginManager(app)
    login_manager.login_view = 'login'
    login_manager.login_message = 'Please log in to access TAREL.'

    def _get_setting(key, default=''):
        record = Settings.query.filter_by(key=key).first()
        if record and record.value is not None:
            return record.value
        return default

    def _get_setting_float(key, default):
        try:
            return float(_get_setting(key, default))
        except (TypeError, ValueError):
            return float(default)

    def _set_setting(key, value):
        record = Settings.query.filter_by(key=key).first()
        if not record:
            record = Settings(key=key)
        record.value = str(value).strip()
        db.session.add(record)

    def _get_rules_settings():
        return {
            'freight_rate': _get_setting_float('freight_rate', app.config['FREIGHT_RATE']),
            'small_order_threshold': _get_setting_float('small_order_threshold', app.config['SMALL_ORDER_THRESHOLD']),
            'small_order_charge': _get_setting_float('small_order_charge', app.config['SMALL_ORDER_CHARGE']),
            'inverness_charge': _get_setting_float('inverness_charge', app.config['INVERNESS_CHARGE']),
        }

    def _get_bank_settings():
        return {
            'account_name': _get_setting('bank_account_name', 'Daniel Maria Lazar'),
            'sort_code': _get_setting('bank_sort_code', '80-48-88'),
            'account_number': _get_setting('bank_account_number', '13616562'),
        }
    def _calc_line_total(fish, qty):
        one_price = float(fish.one_kg_price or 0)
        half_price = float(fish.half_kg_price or 0)
        if not one_price:
            one_price = float(fish.selling_price or 0)
        if not half_price:
            half_price = round(one_price / 2, 2) if one_price else 0
        whole = int(qty)
        remainder = qty - whole
        total = (whole * one_price) + (half_price if remainder >= 0.5 else 0)
        return round(total, 2)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # ─── AUTH ───────────────────────────────────────────────────────────────

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            user = User.query.filter_by(username=username).first()
            if user and bcrypt.checkpw(password.encode(), user.password_hash.encode()):
                login_user(user, remember=True)
                session.permanent = True
                if request.is_json or request.accept_mimetypes.best == 'application/json':
                    return jsonify({'success': True, 'user': {'id': user.id, 'name': user.name, 'username': user.username, 'role': user.role}})
                return redirect(url_for('dashboard'))
            flash('Invalid username or password', 'error')
            if request.is_json or request.accept_mimetypes.best == 'application/json':
                return jsonify({'success': False, 'error': 'Invalid username or password'}), 401
        return render_template('login.html')

    @app.route('/api/health')
    def api_health():
        return jsonify({'ok': True, 'service': 'tarel-backend'})

    @app.route('/api/me')
    @login_required
    def api_me():
        return jsonify({'id': current_user.id, 'name': current_user.name, 'username': current_user.username, 'role': current_user.role})

    @app.route('/api/login', methods=['POST'])
    def api_login():
        payload = request.get_json(silent=True) or {}
        username = (payload.get('username') or '').strip()
        password = payload.get('password') or ''
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.checkpw(password.encode(), user.password_hash.encode()):
            login_user(user, remember=True)
            session.permanent = True
            return jsonify({'success': True, 'user': {'id': user.id, 'name': user.name, 'username': user.username, 'role': user.role}})
        return jsonify({'success': False, 'error': 'Invalid username or password'}), 401

    @app.route('/api/logout', methods=['POST'])
    @login_required
    def api_logout():
        logout_user()
        return jsonify({'success': True})

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('login'))

    @app.route('/brand-logo.png')
    def brand_logo():
        return send_from_directory(os.path.join(app.root_path, 'images'), 'logo.png')

    # ─── DASHBOARD ──────────────────────────────────────────────────────────

    @app.route('/')
    @login_required
    def dashboard():
        current_week = DeliveryWeek.query.filter_by(status='open').order_by(DeliveryWeek.delivery_date).first()
        latest_week = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).first()
        dashboard_week = current_week or latest_week
        week_orders = Order.query.filter_by(delivery_week_id=dashboard_week.id).all() if dashboard_week else []
        pending_availability = sum(1 for o in week_orders for i in o.items if i.availability_status == 'pending')
        unpaid_invoices = Order.query.filter(Order.status.in_(['invoice_sent', 'payment_pending'])).count()
        recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
        unread_messages = WhatsAppMessage.query.filter_by(direction='in', is_read=False).count()
        vendor_report = VendorReport.query.filter_by(delivery_week_id=dashboard_week.id).first() if dashboard_week else None
        pending_payments = Order.query.filter(Order.status.in_(['payment_pending', 'payment_received'])).all()
        return render_template('dashboard.html',
            current_week=dashboard_week,
            week_orders_count=len(week_orders),
            pending_availability=pending_availability,
            unpaid_invoices=unpaid_invoices,
            recent_orders=recent_orders,
            unread_messages=unread_messages,
            vendor_report=vendor_report,
            pending_payments=pending_payments)

    # ─── ORDERS ─────────────────────────────────────────────────────────────

    @app.route('/orders')
    @login_required
    def orders_list():
        week_id = request.args.get('week_id', type=int)
        status = request.args.get('status')
        payment_status = request.args.get('payment_status')

        q = Order.query
        if week_id:
            q = q.filter_by(delivery_week_id=week_id)
        if status:
            q = q.filter_by(status=status)
        orders = q.order_by(Order.created_at.desc()).all()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        return render_template('orders/list.html', orders=orders, weeks=weeks, current_week=current_week,
                               selected_week=week_id, selected_status=status)

    @app.route('/orders/export')
    @login_required
    def export_orders_csv():
        week_id = request.args.get('week_id', type=int)
        week = DeliveryWeek.query.get(week_id) if week_id else DeliveryWeek.query.filter_by(status='open').first()
        if not week:
            flash('Select a delivery week to export orders.', 'warning')
            return redirect(url_for('orders_list'))
        orders = Order.query.filter_by(delivery_week_id=week.id).order_by(Order.id.asc()).all()
        import io, csv
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'order_id', 'customer_id', 'customer_name', 'phone', 'address', 'area', 'postcode',
            'delivery_week_id', 'delivery_date', 'payment_reference', 'status',
            'item_name', 'quantity_kg', 'unit_price', 'line_total'
        ])
        for order in orders:
            customer = order.customer
            for item in order.items:
                writer.writerow([
                    order.id,
                    customer.customer_id if customer else '',
                    customer.name if customer else '',
                    customer.phone if customer else '',
                    customer.address if customer else '',
                    customer.area if customer else '',
                    customer.postcode if customer else '',
                    order.delivery_week_id or '',
                    order.delivery_date.strftime('%Y-%m-%d') if order.delivery_date else '',
                    order.payment_reference or '',
                    order.status or '',
                    item.fish_name,
                    float(item.quantity_kg or 0),
                    float(item.unit_price or 0),
                    float(item.line_total or 0),
                ])
        output.seek(0)
        from flask import Response
        filename = f'orders_week_{week.id}.csv'
        return Response(output.getvalue().encode('utf-8'), mimetype='text/csv', headers={
            'Content-Disposition': f'attachment; filename={filename}'
        })

    @app.route('/orders/routes-csv')
    @login_required
    def export_routes_csv():
        week_id = request.args.get('week_id', type=int)
        week = DeliveryWeek.query.get(week_id) if week_id else None
        if not week:
            flash('Select a delivery week to export route data.', 'warning')
            return redirect(url_for('orders_list'))
        orders = Order.query.filter_by(delivery_week_id=week.id).order_by(Order.id.asc()).all()
        import io, csv
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['order_id', 'customer_name', 'phone', 'address', 'area', 'postcode', 'delivery_date', 'payment_reference'])
        for order in orders:
            customer = order.customer
            writer.writerow([
                order.id,
                customer.name if customer else '',
                customer.phone if customer else '',
                customer.address if customer else '',
                customer.area if customer else '',
                customer.postcode if customer else '',
                order.delivery_date.strftime('%Y-%m-%d') if order.delivery_date else '',
                order.payment_reference or '',
            ])
        output.seek(0)
        from flask import Response
        filename = f'route_optimization_week_{week.id}.csv'
        return Response(output.getvalue().encode('utf-8'), mimetype='text/csv', headers={
            'Content-Disposition': f'attachment; filename={filename}'
        })

    @app.route('/orders/new', methods=['GET', 'POST'])
    @login_required
    def new_order():
        if request.method == 'POST':
            data = request.form
            customer_id = data.get('customer_id', type=int)
            new_customer_name = data.get('new_customer_name', '').strip()

            if not customer_id and new_customer_name:
                # Create new customer
                area = data.get('new_customer_area', 'Edinburgh')
                customer = Customer(
                    name=new_customer_name,
                    phone=data.get('new_customer_phone', '').strip(),
                    address=data.get('new_customer_address', '').strip(),
                    area=area,
                    postcode=data.get('new_customer_postcode', '').strip(),
                    customer_id=generate_customer_id(area)
                )
                db.session.add(customer)
                db.session.flush()
                customer_id = customer.id

            if not customer_id:
                flash('Please select or add a customer', 'error')
                return redirect(url_for('new_order'))

            customer = Customer.query.get(customer_id)
            week_id = data.get('delivery_week_id', type=int)
            week = DeliveryWeek.query.get(week_id) if week_id else DeliveryWeek.query.filter_by(status='open').first()
            if not week:
                week = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).first()

            area_code = app.config['AREA_CODES'].get(customer.area, 'XX')
            year = datetime.now().strftime('%y')
            pay_ref = generate_payment_ref(area_code, year)

            order = Order(
                customer_id=customer_id,
                delivery_week_id=week.id if week else None,
                payment_reference=pay_ref,
                order_date=date.today(),
                delivery_date=week.delivery_date if week else None,
                status='received',
                raw_whatsapp_text=data.get('raw_whatsapp_text', ''),
                delivery_instructions=data.get('delivery_instructions', ''),
                created_by=current_user.id
            )
            db.session.add(order)
            db.session.flush()

            fish_ids = request.form.getlist('fish_master_id[]')
            quantities = request.form.getlist('quantity_kg[]')
            cut_instructions = request.form.getlist('cut_instructions[]')

            for i, fid in enumerate(fish_ids):
                if not fid:
                    continue
                fish = FishMaster.query.get(int(fid))
                if not fish:
                    continue
                qty = float(quantities[i]) if i < len(quantities) else 1.0
                # Calculate line total using two-price rule (1kg and 0.5kg prices)
                line_total = _calc_line_total(fish, qty)
                unit_price = round(line_total / qty, 2) if qty else 0
                item = OrderItem(
                    order_id=order.id,
                    fish_master_id=fish.id,
                    fish_name=fish.fish_name,
                    quantity_kg=qty,
                    unit_price=unit_price,
                    line_total=line_total,
                    cut_instructions=cut_instructions[i] if i < len(cut_instructions) else 'Clean and Cut',
                )
                db.session.add(item)

            db.session.commit()

            # Send WhatsApp acknowledgement
            if customer.phone:
                from services.whatsapp import send_order_acknowledgement
                send_order_acknowledgement(customer.name, customer.phone)

            flash(f'Order #{order.id} created successfully!', 'success')
            return redirect(url_for('order_detail', order_id=order.id))

        weeks = DeliveryWeek.query.filter_by(status='open').all()
        fish_list = FishMaster.query.filter_by(is_active=True).order_by(FishMaster.fish_name).all()
        customers = Customer.query.order_by(Customer.name).all()
        areas = list(app.config['AREA_CODES'].keys())
        return render_template('orders/new.html', weeks=weeks, fish_list=fish_list, customers=customers, areas=areas, config=app.config, rules=_get_rules_settings())

    @app.route('/orders/<int:order_id>')
    @login_required
    def order_detail(order_id):
        order = Order.query.get_or_404(order_id)
        return render_template('orders/detail.html', order=order)

    @app.route('/orders/<int:order_id>/status', methods=['POST'])
    @login_required
    def update_order_status(order_id):
        order = Order.query.get_or_404(order_id)
        new_status = request.form.get('status')
        if new_status:
            order.status = new_status
            db.session.commit()
            flash(f'Order status updated to {new_status}', 'success')
        return redirect(url_for('order_detail', order_id=order_id))

    @app.route('/api/parse-order', methods=['POST'])
    @login_required
    def api_parse_order():
        from services.ai_parser import parse_whatsapp_order
        raw_text = request.json.get('text', '')
        if not raw_text:
            return jsonify({'success': False, 'error': 'No text provided'})
        result = parse_whatsapp_order(raw_text)
        return jsonify(result)

    # ─── QUICK WHATSAPP ORDER (paste → review → create → invoice) ───────────
    @app.route('/orders/quick')
    @login_required
    def quick_order():
        weeks = DeliveryWeek.query.filter_by(status='open').all()
        areas = list(app.config['AREA_CODES'].keys())
        return render_template('orders/quick.html', weeks=weeks, areas=areas)

    @app.route('/api/quick-parse', methods=['POST'])
    @login_required
    def api_quick_parse():
        """Parse pasted WhatsApp text AND resolve each item to a real product."""
        from services.ai_parser import parse_whatsapp_order
        from services.fish_match import resolve_items
        raw_text = (request.json or {}).get('text', '').strip()
        if not raw_text:
            return jsonify({'success': False, 'error': 'Please paste a message first.'})
        parsed = parse_whatsapp_order(raw_text)
        data = parsed.get('data', {})
        fish_rows = FishMaster.query.filter_by(is_active=True).order_by(FishMaster.fish_name).all()
        resolved = resolve_items(data.get('items', []), fish_rows)
        # Try to match an existing customer by phone or name
        matched_customer = None
        phone = (data.get('phone') or '').strip()
        name = (data.get('customer_name') or '').strip()
        if phone:
            c = Customer.query.filter(Customer.phone.ilike(f'%{phone[-9:]}%')).first()
            if c:
                matched_customer = c
        if not matched_customer and name:
            c = Customer.query.filter(Customer.name.ilike(f'%{name}%')).first()
            if c:
                matched_customer = c
        fish_options = [{'id': f.id, 'name': f.fish_name} for f in fish_rows]
        return jsonify({
            'success': True,
            'customer_name': name,
            'phone': phone,
            'matched_customer': ({'id': matched_customer.id, 'name': matched_customer.name,
                                  'phone': matched_customer.phone, 'area': matched_customer.area}
                                 if matched_customer else None),
            'delivery_instructions': data.get('delivery_instructions', ''),
            'items': resolved,
            'fish_options': fish_options,
        })

    @app.route('/orders/quick/create', methods=['POST'])
    @login_required
    def quick_order_create():
        """Create an order from the reviewed quick-order form, then go to its detail
        page (with a one-click Generate Invoice there)."""
        data = request.form
        customer_id = data.get('customer_id', type=int)
        new_customer_name = (data.get('new_customer_name') or '').strip()

        if not customer_id and new_customer_name:
            area = data.get('new_customer_area', 'Edinburgh')
            customer = Customer(
                name=new_customer_name,
                phone=(data.get('new_customer_phone') or '').strip(),
                address=(data.get('new_customer_address') or '').strip(),
                area=area,
                postcode=(data.get('new_customer_postcode') or '').strip(),
                customer_id=generate_customer_id(area),
            )
            db.session.add(customer)
            db.session.flush()
            customer_id = customer.id

        if not customer_id:
            flash('Please select an existing customer or enter a new customer name.', 'error')
            return redirect(url_for('quick_order'))

        customer = Customer.query.get(customer_id)
        week_id = data.get('delivery_week_id', type=int)
        week = DeliveryWeek.query.get(week_id) if week_id else DeliveryWeek.query.filter_by(status='open').first()
        if not week:
            week = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).first()

        area_code = app.config['AREA_CODES'].get(customer.area, 'XX')
        year = datetime.now().strftime('%y')
        pay_ref = generate_payment_ref(area_code, year)

        order = Order(
            customer_id=customer_id,
            delivery_week_id=week.id if week else None,
            payment_reference=pay_ref,
            order_date=date.today(),
            delivery_date=week.delivery_date if week else None,
            status='received',
            raw_whatsapp_text=(data.get('raw_whatsapp_text') or ''),
            delivery_instructions=(data.get('delivery_instructions') or ''),
            created_by=current_user.id,
        )
        db.session.add(order)
        db.session.flush()

        fish_ids = request.form.getlist('fish_master_id[]')
        quantities = request.form.getlist('quantity_kg[]')
        cuts = request.form.getlist('cut_instructions[]')
        added = 0
        for i, fid in enumerate(fish_ids):
            if not fid:
                continue
            fish = FishMaster.query.get(int(fid))
            if not fish:
                continue
            try:
                qty = float(quantities[i]) if i < len(quantities) and quantities[i] else 1.0
            except ValueError:
                qty = 1.0
            if qty <= 0:
                continue
            line_total = _calc_line_total(fish, qty)
            unit_price = round(line_total / qty, 2) if qty else 0
            db.session.add(OrderItem(
                order_id=order.id,
                fish_master_id=fish.id,
                fish_name=fish.fish_name,
                quantity_kg=qty,
                unit_price=unit_price,
                line_total=line_total,
                cut_instructions=cuts[i] if i < len(cuts) else 'Clean and Cut',
            ))
            added += 1

        if added == 0:
            db.session.rollback()
            flash('No valid products to add. Please match at least one item to a product.', 'error')
            return redirect(url_for('quick_order'))

        db.session.commit()

        if customer.phone:
            try:
                from services.whatsapp import send_order_acknowledgement
                send_order_acknowledgement(customer.name, customer.phone)
            except Exception as e:
                app.logger.warning('WhatsApp ack failed: %s', e)

        flash(f'Order #{order.id} created with {added} item(s). Review and generate the invoice below.', 'success')
        return redirect(url_for('order_detail', order_id=order.id))

    @app.route('/api/customers/search')
    @login_required
    def api_customer_search():
        q = request.args.get('q', '')
        customers = Customer.query.filter(
            (Customer.name.ilike(f'%{q}%')) | (Customer.phone.ilike(f'%{q}%'))
        ).limit(10).all()
        return jsonify([{'id': c.id, 'name': c.name, 'phone': c.phone, 'area': c.area, 'address': c.address} for c in customers])

    # ─── AVAILABILITY ────────────────────────────────────────────────────────

    @app.route('/availability')
    @login_required
    def availability():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        if not current_week:
            flash('No open delivery week found', 'warning')
            return redirect(url_for('dashboard'))
        orders = Order.query.filter_by(delivery_week_id=current_week.id).all()
        # Group by fish
        fish_groups = {}
        for order in orders:
            for item in order.items:
                key = item.fish_name
                if key not in fish_groups:
                    fish_groups[key] = {'fish_name': key, 'rows': [], 'total_kg': 0}
                fish_groups[key]['rows'].append({'item': item, 'order': order, 'customer': order.customer})
                fish_groups[key]['total_kg'] += float(item.quantity_kg or 0)
        return render_template('availability.html', fish_groups=fish_groups.values(), current_week=current_week)

    @app.route('/availability/update', methods=['POST'])
    @login_required
    def update_availability():
        item_id = request.form.get('item_id', type=int)
        status = request.form.get('status')
        item = OrderItem.query.get_or_404(item_id)
        item.availability_status = status
        item.availability_checked_by = current_user.id
        item.availability_checked_at = datetime.utcnow()
        db.session.commit()

        order = item.order
        customer = order.customer
        if customer.phone:
            from services.whatsapp import send_availability_confirmed, send_not_available
            if status == 'available':
                send_availability_confirmed(customer.name, customer.phone, item.fish_name,
                                           str(order.delivery_date or 'TBC'))
            elif status == 'not_available':
                send_not_available(customer.name, customer.phone, item.fish_name)

        return jsonify({'success': True})

    # ─── INVOICES ────────────────────────────────────────────────────────────

    @app.route('/orders/<int:order_id>/invoice', methods=['POST'])
    @login_required
    def generate_invoice(order_id):
        try:
            order = Order.query.get_or_404(order_id)
            rules = _get_rules_settings()
            bank_settings = _get_bank_settings()
            # Ensure order has at least one item
            if not order.items or len(order.items) == 0:
                flash('Add at least one product before saving the order.', 'error')
                return redirect(url_for('new_order'))

            # Calculate invoice components
            subtotal = sum(float(i.line_total or 0) for i in order.items)
            fish_kg = sum(float(i.quantity_kg or 0) for i in order.items if i.fish and i.fish.is_fish)
            freight = fish_kg * rules['freight_rate']

            if order.route == 'Inverness':
                delivery_charge = rules.get('inverness_charge', 0.0)
            elif subtotal < rules.get('small_order_threshold', 0):
                delivery_charge = rules.get('small_order_charge', 0.0)
            else:
                delivery_charge = 0.0

            total = subtotal + freight + delivery_charge

            # Create or update invoice record
            if order.invoice:
                inv = order.invoice
            else:
                inv = Invoice(order_id=order.id)
                db.session.add(inv)

            inv.invoice_number = f"INV-{order.id}-{datetime.now().strftime('%Y%m%d')}"
            inv.subtotal = subtotal
            inv.freight_surcharge = freight
            inv.delivery_charge = delivery_charge
            inv.total = total
            inv.generated_at = datetime.utcnow()
            inv.sent_by = current_user.id

            db.session.flush()

            from services.invoice_pdf import generate_invoice_pdf, render_invoice_html
            pdf_path, error = generate_invoice_pdf(order, inv, bank_settings=bank_settings, freight_rate=rules['freight_rate'])
            if pdf_path:
                inv.pdf_path = pdf_path
                order.status = 'invoice_sent'
                db.session.commit()
                flash('Invoice generated successfully!', 'success')
                return redirect(url_for('order_detail', order_id=order_id))
            # PDF failed — produce HTML fallback and offer as download
            html_content = render_invoice_html(order, inv, bank_settings=bank_settings, freight_rate=rules['freight_rate'])
            order.status = 'invoice_sent'
            db.session.commit()
            # Return HTML file for download so the browser can save as PDF
            from flask import Response
            filename = f"invoice_{order.id}.html"
            headers = {
                'Content-Disposition': f'attachment; filename={filename}'
            }
            flash(f'Invoice generated but PDF failed: {error}. An HTML copy is provided for download.', 'warning')
            return Response(html_content, mimetype='text/html', headers=headers)
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            app.logger.error('Invoice generation error:\n%s', tb)
            flash(f'Error generating invoice: {e}', 'error')
            return redirect(url_for('order_detail', order_id=order_id))

    @app.route('/invoices/<int:invoice_id>/pdf')
    @login_required
    def download_invoice(invoice_id):
        inv = Invoice.query.get_or_404(invoice_id)
        if inv.pdf_path and os.path.exists(inv.pdf_path):
            return send_file(inv.pdf_path, as_attachment=True, download_name=f"invoice_{inv.invoice_number}.pdf")
        flash('PDF not found. Please regenerate the invoice.', 'error')
        return redirect(url_for('order_detail', order_id=inv.order_id))

    # ─── PAYMENTS ────────────────────────────────────────────────────────────

    @app.route('/orders/<int:order_id>/payment', methods=['POST'])
    @login_required
    def record_payment(order_id):
        order = Order.query.get_or_404(order_id)
        bank_reference = (request.form.get('bank_reference') or '').strip()
        payment_date = (request.form.get('payment_date') or '').strip()
        if not bank_reference:
            flash('Bank transfer number is required to record a payment.', 'error')
            return redirect(url_for('order_detail', order_id=order.id))
        if not payment_date:
            flash('Payment date is required to record a payment.', 'error')
            return redirect(url_for('order_detail', order_id=order.id))
        amount = request.form.get('amount', type=float)
        if amount is None or amount <= 0:
            flash('A valid payment amount (greater than 0) is required.', 'error')
            return redirect(url_for('order_detail', order_id=order.id))
        try:
            received_date = datetime.strptime(payment_date, '%Y-%m-%d').date()
        except ValueError:
            flash('Payment date must be a valid date (YYYY-MM-DD).', 'error')
            return redirect(url_for('order_detail', order_id=order.id))
        payment = Payment(
            order_id=order.id,
            invoice_id=order.invoice.id if order.invoice else None,
            amount=amount,
            payment_mode=request.form.get('payment_mode'),
            payment_name=request.form.get('payment_name'),
            bank_reference=bank_reference,
            payment_received_date=received_date,
            status='received'
        )
        db.session.add(payment)
        order.status = 'payment_received'
        db.session.commit()
        flash('Payment recorded!', 'success')
        return redirect(url_for('order_detail', order_id=order_id))

    @app.route('/orders/<int:order_id>/delete', methods=['POST'])
    @login_required
    def delete_order(order_id):
        if current_user.role != 'admin':
            abort(403)
        order = Order.query.get_or_404(order_id)
        # delete related payments and invoice explicitly
        for p in list(order.payments):
            db.session.delete(p)
        if order.invoice:
            db.session.delete(order.invoice)
        db.session.delete(order)
        db.session.commit()
        flash(f'Order #{order_id} deleted', 'success')
        return redirect(url_for('orders_list'))

    @app.route('/payments/<int:payment_id>/verify', methods=['POST'])
    @login_required
    def verify_payment(payment_id):
        if current_user.role != 'admin':
            abort(403)
        payment = Payment.query.get_or_404(payment_id)
        payment.status = 'verified'
        payment.payment_verified_by = current_user.id
        payment.payment_verified_at = datetime.utcnow()
        order = payment.order
        order.status = 'payment_verified'
        db.session.commit()
        customer = order.customer
        if customer.phone:
            from services.whatsapp import send_payment_confirmation
            send_payment_confirmation(customer.name, customer.phone, float(payment.amount))
        flash('Payment verified!', 'success')
        return redirect(url_for('order_detail', order_id=order.id))

    @app.route('/payments/<int:payment_id>/edit', methods=['GET', 'POST'])
    @login_required
    def edit_payment(payment_id):
        payment = Payment.query.get_or_404(payment_id)
        order = payment.order
        # Only allow admin or the user who created the order to edit payments
        if current_user.role != 'admin' and current_user.id != (order.created_by or 0):
            abort(403)
        if request.method == 'POST':
            # Validate and update fields
            amt = request.form.get('amount')
            pdate = request.form.get('payment_date')
            try:
                payment.amount = float(amt) if amt else payment.amount
            except ValueError:
                flash('Invalid amount', 'error')
                return redirect(url_for('edit_payment', payment_id=payment.id))
            payment.payment_mode = request.form.get('payment_mode') or payment.payment_mode
            payment.payment_name = request.form.get('payment_name') or payment.payment_name
            payment.bank_reference = request.form.get('bank_reference') or payment.bank_reference
            if pdate:
                try:
                    payment.payment_received_date = datetime.strptime(pdate, '%Y-%m-%d').date()
                except Exception:
                    flash('Invalid date format', 'error')
                    return redirect(url_for('edit_payment', payment_id=payment.id))
            payment.status = request.form.get('status') or payment.status
            db.session.commit()
            flash('Payment updated!', 'success')
            return redirect(url_for('order_detail', order_id=order.id))
        # GET
        return render_template('payment_edit.html', payment=payment, order=order)

    @app.route('/payments/<int:payment_id>/delete', methods=['POST'])
    @login_required
    def delete_payment(payment_id):
        payment = Payment.query.get_or_404(payment_id)
        order = payment.order
        # Only admin or order creator can delete
        if current_user.role != 'admin' and current_user.id != (order.created_by or 0):
            abort(403)
        db.session.delete(payment)
        db.session.commit()
        flash('Payment deleted', 'success')
        return redirect(url_for('order_detail', order_id=order.id))

    # ─── CUSTOMERS ───────────────────────────────────────────────────────────

    @app.route('/customers')
    @login_required
    def customers_list():
        q = request.args.get('q', '')
        area = request.args.get('area', '')
        query = Customer.query
        if q:
            query = query.filter((Customer.name.ilike(f'%{q}%')) | (Customer.phone.ilike(f'%{q}%')) | (Customer.customer_id.ilike(f'%{q}%')))
        if area:
            query = query.filter_by(area=area)
        customers = query.order_by(Customer.name).all()
        areas = db.session.query(Customer.area).distinct().filter(Customer.area.isnot(None)).all()
        return render_template('customers/list.html', customers=customers, areas=[a[0] for a in areas], q=q, selected_area=area)

    @app.route('/customers/export')
    @login_required
    def export_customers_csv():
        customers = Customer.query.order_by(Customer.name).all()
        import io, csv
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['name', 'customer_id', 'phone', 'address', 'area', 'postcode'])
        for customer in customers:
            writer.writerow([
                customer.name,
                customer.customer_id or '',
                customer.phone or '',
                customer.address or '',
                customer.area or '',
                customer.postcode or '',
            ])
        output.seek(0)
        from flask import Response
        return Response(output.getvalue().encode('utf-8'), mimetype='text/csv', headers={
            'Content-Disposition': 'attachment; filename=customers.csv'
        })

    @app.route('/customers/import', methods=['GET', 'POST'])
    @login_required
    def import_customers():
        if current_user.role != 'admin':
            abort(403)
        if request.method == 'POST':
            csv_file = request.files.get('csv_file')
            if not csv_file or not csv_file.filename.lower().endswith('.csv'):
                flash('Please upload a CSV file', 'error')
                return redirect(url_for('import_customers'))

            area_counters = {}
            imported = 0
            skipped = 0
            updated = 0

            rows = csv.DictReader(csv_file.stream.read().decode('utf-8-sig').splitlines())
            for row in rows:
                name = (row.get('name') or '').strip()
                if not name:
                    continue

                phone = (row.get('phone') or '').strip()
                # skip exact name+phone duplicates
                if Customer.query.filter_by(name=name, phone=phone).first():
                    skipped += 1
                    continue

                # prefer provided customer_id from CSV when present
                provided_id = (row.get('customer_id') or '').strip()
                if provided_id:
                    existing = Customer.query.filter_by(customer_id=provided_id).first()
                    if existing:
                        # update existing customer
                        existing.name = name
                        existing.phone = phone
                        existing.address = (row.get('address') or '').strip()
                        existing.area = (row.get('area') or 'Edinburgh').strip()
                        existing.postcode = (row.get('postcode') or '').strip()
                        existing.notes = (row.get('notes') or '').strip()
                        db.session.add(existing)
                        updated += 1
                        continue
                    customer_id = provided_id
                else:
                    area = (row.get('area') or 'Edinburgh').strip() or 'Edinburgh'
                    area_code = app.config['AREA_CODES'].get(area, 'XX')
                    year = datetime.now().strftime('%y')
                    prefix = f'{area_code}{year}'
                    existing_count = Customer.query.filter(Customer.customer_id.like(f'{prefix}%')).count()
                    area_counters[area] = area_counters.get(area, 0) + 1
                    customer_id = f"{prefix}{existing_count + area_counters[area]:03d}"

                db.session.add(Customer(
                    customer_id=customer_id,
                    name=name,
                    phone=phone,
                    address=(row.get('address') or '').strip(),
                    area=(row.get('area') or 'Edinburgh').strip(),
                    postcode=(row.get('postcode') or '').strip(),
                    notes=(row.get('notes') or '').strip(),
                ))
                imported += 1

            db.session.commit()
            msg = f'Imported {imported} customers'
            if updated:
                msg += f', updated {updated} customers'
            if skipped:
                msg += f', skipped {skipped} duplicates'
            flash(msg, 'success')
            return redirect(url_for('customers_list'))

        return render_template('customers/import.html')

    @app.route('/customers/new', methods=['GET', 'POST'])
    @login_required
    def new_customer():
        if request.method == 'POST':
            area = request.form.get('area', 'Edinburgh')
            customer = Customer(
                name=request.form.get('name').strip(),
                phone=request.form.get('phone', '').strip(),
                address=request.form.get('address', '').strip(),
                area=area,
                postcode=request.form.get('postcode', '').strip(),
                notes=request.form.get('notes', '').strip(),
                customer_id=generate_customer_id(area)
            )
            db.session.add(customer)
            db.session.commit()
            flash(f'Customer {customer.name} added!', 'success')
            return redirect(url_for('customer_profile', customer_id=customer.id))
        areas = list(app.config['AREA_CODES'].keys())
        return render_template('customers/profile.html', customer=None, areas=areas, mode='new')

    @app.route('/customers/<int:customer_id>')
    @login_required
    def customer_profile(customer_id):
        customer = Customer.query.get_or_404(customer_id)
        orders = Order.query.filter_by(customer_id=customer_id).order_by(Order.order_date.desc()).all()
        total_spent = sum(float(o.invoice.total or 0) for o in orders if o.invoice)
        areas = list(app.config['AREA_CODES'].keys())
        recent_orders = orders[:5]
        older_orders = orders[5:]
        return render_template(
            'customers/profile.html',
            customer=customer,
            orders=orders,
            recent_orders=recent_orders,
            older_orders=older_orders,
            total_spent=total_spent,
            areas=areas,
            mode='view'
        )

    @app.route('/customers/<int:customer_id>/edit', methods=['POST'])
    @login_required
    def edit_customer(customer_id):
        customer = Customer.query.get_or_404(customer_id)
        customer.name = request.form.get('name', customer.name).strip()
        customer.phone = request.form.get('phone', customer.phone).strip()
        customer.address = request.form.get('address', customer.address).strip()
        customer.area = request.form.get('area', customer.area)
        customer.postcode = request.form.get('postcode', customer.postcode).strip()
        customer.notes = request.form.get('notes', customer.notes)
        db.session.commit()
        flash('Customer updated!', 'success')
        return redirect(url_for('customer_profile', customer_id=customer_id))

    @app.route('/customers/<int:customer_id>/delete', methods=['POST'])
    @login_required
    def delete_customer(customer_id):
        if current_user.role != 'admin':
            abort(403)
        customer = Customer.query.get_or_404(customer_id)
        order_ids = [order.id for order in customer.orders]
        if order_ids:
            invoice_ids = [invoice.id for invoice in Invoice.query.filter(Invoice.order_id.in_(order_ids)).all()]
            payment_ids = [payment.id for payment in Payment.query.filter(Payment.order_id.in_(order_ids)).all()]
            db.session.query(WhatsAppMessage).filter_by(customer_id=customer.id).delete(synchronize_session=False)
            if payment_ids:
                db.session.query(Payment).filter(Payment.id.in_(payment_ids)).delete(synchronize_session=False)
            if invoice_ids:
                db.session.query(Invoice).filter(Invoice.id.in_(invoice_ids)).delete(synchronize_session=False)
            db.session.query(OrderItem).filter(OrderItem.order_id.in_(order_ids)).delete(synchronize_session=False)
            db.session.query(Order).filter(Order.id.in_(order_ids)).delete(synchronize_session=False)
        else:
            db.session.query(WhatsAppMessage).filter_by(customer_id=customer.id).delete(synchronize_session=False)
        db.session.delete(customer)
        db.session.commit()
        flash('Customer deleted permanently.', 'success')
        return redirect(url_for('customers_list'))

    # ─── FISH MASTER ─────────────────────────────────────────────────────────

    @app.route('/fish-master')
    @login_required
    def fish_master():
        fish = FishMaster.query.order_by(FishMaster.fish_name).all()
        return render_template('fish_master.html', fish=fish)

    @app.route('/fish-master/new', methods=['POST'])
    @login_required
    def new_fish():
        fish = FishMaster(
            fish_name=request.form.get('fish_name'),
            english_name=request.form.get('english_name'),
            tamil_name=request.form.get('tamil_name'),
            malayalam_name=request.form.get('malayalam_name'),
            size=request.form.get('size', '1kg'),
            avra_impex_price=request.form.get('avra_price') or None,
            global_food_price=request.form.get('global_price') or None,
            half_kg_price=request.form.get('half_kg_price') or None,
            one_kg_price=request.form.get('one_kg_price') or None,
            selling_price=request.form.get('selling_price') or None,
            is_fish=request.form.get('is_fish') == 'true',
            is_active=True
        )
        db.session.add(fish)
        db.session.commit()
        flash('Fish added!', 'success')
        return redirect(url_for('fish_master'))

    @app.route('/fish-master/<int:fish_id>/toggle', methods=['POST'])
    @login_required
    def toggle_fish(fish_id):
        fish = FishMaster.query.get_or_404(fish_id)
        fish.is_active = not fish.is_active
        db.session.commit()
        return jsonify({'active': fish.is_active})

    @app.route('/fish-master/<int:fish_id>/edit', methods=['POST'])
    @login_required
    def edit_fish(fish_id):
        fish = FishMaster.query.get_or_404(fish_id)
        fish.fish_name = request.form.get('fish_name', fish.fish_name)
        fish.avra_impex_price = request.form.get('avra_price') or fish.avra_impex_price
        fish.global_food_price = request.form.get('global_price') or fish.global_food_price
        fish.selling_price = request.form.get('selling_price') or fish.selling_price
        fish.half_kg_price = request.form.get('half_kg_price') or fish.half_kg_price
        fish.one_kg_price = request.form.get('one_kg_price') or fish.one_kg_price
        db.session.commit()
        flash('Fish updated!', 'success')
        return redirect(url_for('fish_master'))

    # ─── VENDOR REPORT ───────────────────────────────────────────────────────

    @app.route('/vendor-report')
    @login_required
    def vendor_report():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        week_id = request.args.get('week_id', type=int)
        if week_id:
            current_week = DeliveryWeek.query.get(week_id)
        if not current_week:
            current_week = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).first()
        if not current_week:
            return render_template('vendor_report.html', fish_totals=[], meat_totals=[], current_week=None, weeks=weeks)
        orders = Order.query.filter_by(delivery_week_id=current_week.id).all()
        if not orders:
            orphan_orders = Order.query.filter_by(delivery_week_id=None).all()
            if orphan_orders and not week_id:
                for order in orphan_orders:
                    order.delivery_week_id = current_week.id
                    order.delivery_date = current_week.delivery_date
                db.session.commit()
                orders = orphan_orders
        fish_totals = {}
        meat_totals = {}
        for order in orders:
            for item in order.items:
                name = item.fish_name
                is_fish = item.fish.is_fish if item.fish else True
                target = fish_totals if is_fish else meat_totals
                if name not in target:
                    target[name] = {'fish_name': name, 'total_kg': 0, 'order_count': 0, 'customers': []}
                target[name]['total_kg'] += float(item.quantity_kg or 0)
                target[name]['order_count'] += 1
                target[name]['customers'].append(order.customer.name)
        existing_report = VendorReport.query.filter_by(delivery_week_id=current_week.id).first()
        topup_count = 0
        topups = []
        if existing_report and existing_report.report_data and isinstance(existing_report.report_data, dict):
            top_ups = existing_report.report_data.get('top_ups', [])
            topup_count = len(top_ups)
            topups = top_ups
            for t in top_ups:
                target = fish_totals if t.get('is_fish', True) else meat_totals
                name = t.get('fish_name')
                kg = float(t.get('kg') or 0)
                if not name:
                    continue
                if name not in target:
                    target[name] = {'fish_name': name, 'total_kg': 0, 'order_count': 0, 'customers': []}
                target[name]['total_kg'] += kg
        for data in (fish_totals, meat_totals):
            for row in data.values():
                row['customers'] = sorted(set(row.get('customers') or []))
        return render_template('vendor_report.html',
            fish_totals=sorted(fish_totals.values(), key=lambda x: x['total_kg'], reverse=True),
            meat_totals=sorted(meat_totals.values(), key=lambda x: x['total_kg'], reverse=True),
            current_week=current_week, weeks=weeks, existing_report=existing_report, topup_count=topup_count, topups=topups)

    def _vendor_report_totals(week_id, report_type):
        week = DeliveryWeek.query.get_or_404(week_id)
        orders = Order.query.filter_by(delivery_week_id=week.id).all()
        fish_totals = {}
        meat_totals = {}
        for order in orders:
            for item in order.items:
                name = item.fish_name
                is_fish = item.fish.is_fish if item.fish else True
                target = fish_totals if is_fish else meat_totals
                if name not in target:
                    target[name] = {'fish_name': name, 'total_kg': 0, 'order_count': 0, 'customers': []}
                target[name]['total_kg'] += float(item.quantity_kg or 0)
                target[name]['order_count'] += 1
                target[name]['customers'].append(order.customer.name)

        # Include top-ups from existing VendorReport.report_data if present
        vr = VendorReport.query.filter_by(delivery_week_id=week.id).first()
        if vr and vr.report_data and isinstance(vr.report_data, dict):
            for t in vr.report_data.get('top_ups', []):
                target = fish_totals if t.get('is_fish', True) else meat_totals
                nm = t.get('fish_name')
                kg = float(t.get('kg') or 0)
                if nm not in target:
                    target[nm] = {'fish_name': nm, 'total_kg': 0, 'order_count': 0, 'customers': []}
                target[nm]['total_kg'] += kg

        for data in (fish_totals, meat_totals):
            for row in data.values():
                row['customers'] = sorted(set(row.get('customers') or []))

        if report_type == 'fish':
            rows = sorted(fish_totals.values(), key=lambda x: x['total_kg'], reverse=True)
        elif report_type == 'meat':
            rows = sorted(meat_totals.values(), key=lambda x: x['total_kg'], reverse=True)
        else:
            rows = sorted(fish_totals.values(), key=lambda x: x['total_kg'], reverse=True) + sorted(meat_totals.values(), key=lambda x: x['total_kg'], reverse=True)

        delivery_date = week.delivery_date.strftime('%d %B %Y') if week.delivery_date else 'TBC'
        generated_at = vr.generated_at.strftime('%d %b %Y %H:%M') if vr and vr.generated_at else datetime.utcnow().strftime('%d %b %Y %H:%M')
        return week, rows, fish_totals, meat_totals, delivery_date, generated_at, vr

    def _download_vendor_report(week_id, report_type):
        week, rows, fish_totals, meat_totals, delivery_date, generated_at, vr = _vendor_report_totals(week_id, report_type)
        if vr and vr.report_data:
            confirmed = bool(vr.report_data.get('confirmed'))
        else:
            confirmed = False
        if not (confirmed or current_user.role == 'admin'):
            flash('Vendor report not yet confirmed by admin. Ask an admin to confirm.', 'warning')
            return redirect(url_for('vendor_report', week_id=week.id))
        from services.vendor_report_pdf import generate_vendor_pdf
        pdf_path, error = generate_vendor_pdf(
            sorted(fish_totals.values(), key=lambda x: x['total_kg'], reverse=True),
            sorted(meat_totals.values(), key=lambda x: x['total_kg'], reverse=True),
            delivery_date,
            generated_at,
            week.id,
            report_type=report_type,
        )
        if pdf_path:
            return send_file(pdf_path, as_attachment=True)
        flash(f'Failed to generate PDF: {error}', 'error')
        return redirect(url_for('vendor_report', week_id=week.id))

    @app.route('/vendor-report/<int:week_id>/download/fish')
    @login_required
    def download_vendor_report_fish(week_id):
        return _download_vendor_report(week_id, 'fish')

    @app.route('/vendor-report/<int:week_id>/download/meat')
    @login_required
    def download_vendor_report_meat(week_id):
        return _download_vendor_report(week_id, 'meat')

    @app.route('/vendor-report/<int:week_id>/csv')
    @login_required
    def download_vendor_csv(week_id):
        week = DeliveryWeek.query.get_or_404(week_id)
        orders = Order.query.filter_by(delivery_week_id=week.id).all()
        import io, csv
        output = io.StringIO()
        writer = csv.writer(output)
        # Header
        writer.writerow(['order_id','customer_id','customer_name','phone','delivery_date','payment_reference','status','item_name','quantity_kg','unit_price','line_total'])
        for order in orders:
            for item in order.items:
                writer.writerow([
                    order.id,
                    order.customer.customer_id if order.customer else '',
                    order.customer.name if order.customer else '',
                    order.customer.phone if order.customer else '',
                    order.delivery_date.strftime('%Y-%m-%d') if order.delivery_date else '',
                    order.payment_reference or '',
                    order.status or '',
                    item.fish_name,
                    float(item.quantity_kg or 0),
                    float(item.unit_price or 0),
                    float(item.line_total or 0)
                ])
        output.seek(0)
        from flask import Response
        csv_bytes = output.getvalue().encode('utf-8')
        return Response(csv_bytes, mimetype='text/csv', headers={
            'Content-Disposition': f'attachment; filename=vendor_report_{week.id}.csv'
        })

    @app.route('/vendor-report/topup', methods=['POST'])
    @login_required
    def vendor_report_topup():
        if current_user.role != 'admin':
            abort(403)
        week_id = request.form.get('week_id', type=int)
        fish_name = request.form.get('fish_name')
        kg = request.form.get('kg', type=float)
        is_fish = request.form.get('is_fish', '1') == '1'
        if not week_id or not fish_name or not kg:
            flash('Invalid top-up data', 'error')
            return redirect(url_for('vendor_report'))
        vr = VendorReport.query.filter_by(delivery_week_id=week_id).first()
        if not vr:
            vr = VendorReport(delivery_week_id=week_id, generated_by=current_user.id, generated_at=datetime.utcnow(), report_data={})
            db.session.add(vr)
        data = vr.report_data or {}
        top_ups = data.get('top_ups', [])
        top_ups.append({'fish_name': fish_name, 'kg': kg, 'is_fish': is_fish, 'admin_id': current_user.id, 'timestamp': datetime.utcnow().isoformat()})
        data['top_ups'] = top_ups
        vr.report_data = data
        db.session.commit()
        flash(f'Added top-up {kg}kg to {fish_name}', 'success')
        return redirect(url_for('vendor_report', week_id=week_id))

    @app.route('/vendor-report/<int:week_id>/topups')
    @login_required
    def view_vendor_topups(week_id):
        if current_user.role != 'admin':
            abort(403)
        vr = VendorReport.query.filter_by(delivery_week_id=week_id).first()
        top_ups = []
        if vr and vr.report_data:
            top_ups = vr.report_data.get('top_ups', [])
            confirmed = bool(vr.report_data.get('confirmed'))
        else:
            confirmed = False
        return render_template('vendor_topups.html', week_id=week_id, top_ups=top_ups, confirmed=confirmed)

    @app.route('/vendor-report/topup/remove', methods=['POST'])
    @login_required
    def remove_vendor_topup():
        if current_user.role != 'admin':
            abort(403)
        week_id = request.form.get('week_id', type=int)
        idx = request.form.get('index', type=int)
        vr = VendorReport.query.filter_by(delivery_week_id=week_id).first()
        if not vr or not vr.report_data:
            flash('No top-ups to remove', 'error')
            return redirect(url_for('view_vendor_topups', week_id=week_id))
        top_ups = vr.report_data.get('top_ups', [])
        if 0 <= idx < len(top_ups):
            removed = top_ups.pop(idx)
            vr.report_data['top_ups'] = top_ups
            db.session.commit()
            flash(f"Removed top-up {removed.get('kg')}kg {removed.get('fish_name')}", 'success')
        else:
            flash('Invalid top-up index', 'error')
        return redirect(url_for('view_vendor_topups', week_id=week_id))

    @app.route('/vendor-report/topup/confirm', methods=['POST'])
    @login_required
    def confirm_vendor_topups():
        if current_user.role != 'admin':
            abort(403)
        week_id = request.form.get('week_id', type=int)
        vr = VendorReport.query.filter_by(delivery_week_id=week_id).first()
        if not vr:
            vr = VendorReport(delivery_week_id=week_id, generated_by=current_user.id, generated_at=datetime.utcnow(), report_data={})
            db.session.add(vr)
        data = vr.report_data or {}
        data['confirmed'] = True
        vr.report_data = data
        vr.sent_at = datetime.utcnow()
        db.session.commit()
        flash('Top-ups confirmed and vendor report marked as sent!', 'success')
        return redirect(url_for('vendor_report', week_id=week_id))

    @app.route('/vendor-report/mark-sent', methods=['POST'])
    @login_required
    def mark_vendor_report_sent():
        week_id = request.form.get('week_id', type=int)
        report = VendorReport.query.filter_by(delivery_week_id=week_id).first()
        if not report:
            report = VendorReport(delivery_week_id=week_id, generated_by=current_user.id, generated_at=datetime.utcnow())
            db.session.add(report)
        report.sent_at = datetime.utcnow()
        week = DeliveryWeek.query.get(week_id)
        if week:
            week.status = 'vendor_report_sent'
        db.session.commit()
        flash('Vendor report marked as sent!', 'success')
        return redirect(url_for('vendor_report'))

    # ─── FINANCE ─────────────────────────────────────────────────────────────

    @app.route('/finance')
    @login_required
    def finance():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        week_id = request.args.get('week_id', type=int)
        if week_id:
            current_week = DeliveryWeek.query.get(week_id)
        expenses = income_records = []
        total_income = total_expenses = fish_profit = 0
        if current_week:
            expenses = Expense.query.filter_by(delivery_week_id=current_week.id).order_by(Expense.expense_date.desc()).all()
            total_expenses = sum(float(e.amount or 0) for e in expenses)
            verified_payments = Payment.query.join(Order).filter(
                Order.delivery_week_id == current_week.id,
                Payment.status == 'verified'
            ).all()
            total_income = sum(float(p.amount or 0) for p in verified_payments)
            fish_profit = total_income - total_expenses
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        return render_template('finance.html', expenses=expenses, current_week=current_week, weeks=weeks,
            total_income=total_income, total_expenses=total_expenses, fish_profit=fish_profit)

    @app.route('/finance/export')
    @login_required
    def export_finance_csv():
        week_id = request.args.get('week_id', type=int)
        week = DeliveryWeek.query.get(week_id) if week_id else DeliveryWeek.query.filter_by(status='open').first()
        if not week:
            flash('Select a delivery week to export finance data.', 'warning')
            return redirect(url_for('finance'))
        expenses = Expense.query.filter_by(delivery_week_id=week.id).order_by(Expense.expense_date.desc()).all()
        payments = Payment.query.join(Order).filter(
            Order.delivery_week_id == week.id,
            Payment.status == 'verified'
        ).all()
        import io, csv
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'type', 'date', 'description', 'category', 'amount', 'payment_status',
            'order_id', 'customer_name', 'payment_mode', 'payment_name', 'bank_reference'
        ])
        for expense in expenses:
            writer.writerow([
                'expense',
                expense.expense_date.strftime('%Y-%m-%d') if expense.expense_date else '',
                expense.description or '',
                expense.category or '',
                float(expense.amount or 0),
                expense.payment_status or '',
                '', '', '', '', ''
            ])
        for payment in payments:
            order = payment.order
            customer_name = order.customer.name if order and order.customer else ''
            writer.writerow([
                'payment',
                payment.payment_received_date.strftime('%Y-%m-%d') if payment.payment_received_date else '',
                'Verified payment',
                '',
                float(payment.amount or 0),
                payment.status or '',
                order.id if order else '',
                customer_name,
                payment.payment_mode or '',
                payment.payment_name or '',
                payment.bank_reference or '',
            ])
        output.seek(0)
        from flask import Response
        filename = f'finance_week_{week.id}.csv'
        return Response(output.getvalue().encode('utf-8'), mimetype='text/csv', headers={
            'Content-Disposition': f'attachment; filename={filename}'
        })

    @app.route('/finance/expense/add', methods=['POST'])
    @login_required
    def add_expense():
        expense = Expense(
            expense_date=datetime.strptime(request.form.get('expense_date'), '%Y-%m-%d').date(),
            description=request.form.get('description'),
            category=request.form.get('category', 'Other'),
            amount=request.form.get('amount', type=float),
            payment_status=request.form.get('payment_status', 'paid'),
            delivery_week_id=request.form.get('week_id', type=int),
            created_by=current_user.id
        )
        db.session.add(expense)
        db.session.commit()
        flash('Expense added!', 'success')
        return redirect(url_for('finance', week_id=expense.delivery_week_id))

    @app.route('/finance/expense/<int:expense_id>/delete', methods=['POST'])
    @login_required
    def delete_expense(expense_id):
        if current_user.role != 'admin':
            abort(403)
        expense = Expense.query.get_or_404(expense_id)
        week_id = expense.delivery_week_id
        db.session.delete(expense)
        db.session.commit()
        flash('Expense deleted', 'success')
        return redirect(url_for('finance', week_id=week_id))

    # ─── SETTINGS ────────────────────────────────────────────────────────────

    @app.route('/settings')
    @login_required
    def settings():
        if current_user.role != 'admin':
            flash('Admin access required', 'error')
            return redirect(url_for('dashboard'))
        users = User.query.all()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        return render_template('settings.html', users=users, weeks=weeks, config=app.config,
                               rules=_get_rules_settings(), bank=_get_bank_settings())

    @app.route('/settings/rules/update', methods=['POST'])
    @login_required
    def update_business_rules():
        if current_user.role != 'admin':
            abort(403)
        _set_setting('freight_rate', request.form.get('freight_rate', '').strip())
        _set_setting('small_order_threshold', request.form.get('small_order_threshold', '').strip())
        _set_setting('small_order_charge', request.form.get('small_order_charge', '').strip())
        _set_setting('inverness_charge', request.form.get('inverness_charge', '').strip())
        db.session.commit()
        flash('Business rules updated.', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/bank/update', methods=['POST'])
    @login_required
    def update_bank_details():
        if current_user.role != 'admin':
            abort(403)
        _set_setting('bank_account_name', request.form.get('bank_account_name', '').strip())
        _set_setting('bank_sort_code', request.form.get('bank_sort_code', '').strip())
        _set_setting('bank_account_number', request.form.get('bank_account_number', '').strip())
        db.session.commit()
        flash('Bank details updated.', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/user/add', methods=['POST'])
    @login_required
    def add_user():
        if current_user.role != 'admin':
            abort(403)
        password = request.form.get('password')
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        role = request.form.get('role', 'team')
        if role not in {'admin', 'team'}:
            role = 'team'
        user = User(
            name=request.form.get('name'),
            username=request.form.get('username'),
            password_hash=hashed,
            role=role
        )
        db.session.add(user)
        db.session.commit()
        flash('User added!', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/user/<int:user_id>/delete', methods=['POST'])
    @login_required
    def delete_user(user_id):
        if current_user.role != 'admin':
            abort(403)
        user = User.query.get_or_404(user_id)
        if user.id == current_user.id:
            flash("Can't delete yourself", 'error')
            return redirect(url_for('settings'))
        db.session.delete(user)
        db.session.commit()
        flash('User deleted', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/week/add', methods=['POST'])
    @login_required
    def add_delivery_week():
        if current_user.role != 'admin':
            abort(403)
        week = DeliveryWeek(
            week_start=datetime.strptime(request.form.get('week_start'), '%Y-%m-%d').date(),
            week_end=datetime.strptime(request.form.get('week_end'), '%Y-%m-%d').date(),
            delivery_date=datetime.strptime(request.form.get('delivery_date'), '%Y-%m-%d').date(),
            status='open'
        )
        db.session.add(week)
        db.session.commit()
        flash('Delivery week added!', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/week/<int:week_id>/close', methods=['POST'])
    @login_required
    def close_week(week_id):
        if current_user.role != 'admin':
            abort(403)
        week = DeliveryWeek.query.get_or_404(week_id)
        week.status = 'closed'
        db.session.commit()
        flash('Week closed', 'success')
        return redirect(url_for('settings'))

    # ─── WHATSAPP WEBHOOK ────────────────────────────────────────────────────

    @app.route('/webhook/whatsapp', methods=['GET', 'POST'])
    def whatsapp_webhook():
        if request.method == 'GET':
            token = request.args.get('hub.verify_token')
            if token == app.config.get('WHATSAPP_VERIFY_TOKEN'):
                return request.args.get('hub.challenge', ''), 200
            return 'Forbidden', 403
        try:
            data = request.json
            entry = data.get('entry', [{}])[0]
            changes = entry.get('changes', [{}])[0]
            value = changes.get('value', {})
            messages = value.get('messages', [])
            for msg in messages:
                phone = msg.get('from', '')
                text = msg.get('text', {}).get('body', '')
                wa_msg = WhatsAppMessage(direction='in', phone=phone, message=text, is_read=False)
                customer = Customer.query.filter_by(phone=phone).first()
                if customer:
                    wa_msg.customer_id = customer.id
                db.session.add(wa_msg)
            db.session.commit()
        except Exception:
            pass
        return 'OK', 200

    # ─── HELPERS ─────────────────────────────────────────────────────────────

    def generate_customer_id(area):
        code = app.config['AREA_CODES'].get(area, 'XX')
        year = datetime.now().strftime('%y')
        count = Customer.query.filter(Customer.customer_id.like(f'{code}{year}%')).count()
        return f"{code}{year}{count + 1:03d}"

    def generate_payment_ref(area_code, year):
        count = Order.query.filter(Order.payment_reference.like(f'{area_code}{year}%')).count()
        return f"{area_code}{year}{count + 1:03d}"

    @app.template_filter('currency')
    def currency_filter(value):
        try:
            return f"£{float(value):.2f}"
        except:
            return '£0.00'

    # status_badge is now a Jinja2 macro in base.html

    @app.template_filter('currency')
    def currency_filter(value):
        try:
            return f"£{float(value):.2f}"
        except (TypeError, ValueError):
            return '£0.00' 

    # ─── ERROR HANDLERS (no stack traces leak to users in prod) ──────────────
    @app.errorhandler(403)
    def err_403(e):
        try:
            return render_template('error.html', code=403,
                                   message="You don't have permission to access this."), 403
        except Exception:
            return "403 — Forbidden", 403

    @app.errorhandler(404)
    def err_404(e):
        try:
            return render_template('error.html', code=404,
                                   message="That page was not found."), 404
        except Exception:
            return "404 — Not Found", 404

    @app.errorhandler(500)
    def err_500(e):
        try:
            db.session.rollback()
        except Exception:
            pass
        app.logger.exception('Unhandled 500 error')
        try:
            return render_template('error.html', code=500,
                                   message="Something went wrong on our end. Please try again."), 500
        except Exception:
            return "500 — Server Error", 500

    return app


if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        try:
            db.create_all()
        except Exception as e:
            print(f"DB warning: {e}")
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port, use_reloader=False)
