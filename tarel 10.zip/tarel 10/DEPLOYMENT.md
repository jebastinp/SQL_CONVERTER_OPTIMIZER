Deployment notes — Render (backend) + Netlify (optional static assets)

Render (recommended for full app)
- Use the Dockerfile included to run the app with system deps for WeasyPrint.
- Create a new Web Service on Render and connect your Git repo.
- If using the Dockerfile, Render will build and deploy automatically.
- Set these Environment Variables in the Render dashboard (Environment → Environment Variables):
  - `DATABASE_URL` — your Supabase **shared pooler** connection string from Supabase Connect (session mode on IPv4). Do **not** use the direct `db.<project-ref>.supabase.co` URL on Render because it is IPv6-only and causes the login/dashboard 500.
  - `SECRET_KEY` — flask secret
  - `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_ID`, `WHATSAPP_VERIFY_TOKEN` (optional)
- Start Command (if not using Dockerfile): `gunicorn wsgi:application --bind 0.0.0.0:$PORT --workers 4`
- The app now preserves Render environment variables, so the dashboard `DATABASE_URL` will override the repo `.env` file.

Notes about WeasyPrint:
- WeasyPrint requires native libraries (cairo, pango, gdk-pixbuf). The provided Dockerfile installs them on Debian slim.

Netlify (optional)
- Netlify is for static sites only. The Flask Jinja templates require a server — you cannot host the full app on Netlify unless you convert the frontend to a static SPA that talks to the backend API.
- You can still deploy the `static/` assets (CSS/JS) to Netlify and point the frontend to your Render backend.

Quick local test commands
```bash
# build and run docker locally
docker build -t tarel-app .
docker run -e DATABASE_URL="<your-supabase-url>" -e SECRET_KEY="secret" -p 10000:10000 tarel-app
# then open http://localhost:10000
```
