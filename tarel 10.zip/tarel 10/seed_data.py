import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def seed():
    from app import create_app
    from models import db, User, FishMaster, DeliveryWeek
    import bcrypt
    from datetime import date, timedelta

    app = create_app()
    with app.app_context():
        print("Creating tables...")
        db.create_all()

        # Users
        if not User.query.filter_by(username='admin').first():
            users = [
                User(name='Admin', username='admin',
                     password_hash=bcrypt.hashpw(b'tarel2026', bcrypt.gensalt()).decode(), role='admin'),
                User(name='Martin', username='martin',
                     password_hash=bcrypt.hashpw(b'martin2026', bcrypt.gensalt()).decode(), role='team'),
                User(name='Danny', username='danny',
                     password_hash=bcrypt.hashpw(b'danny2026', bcrypt.gensalt()).decode(), role='team'),
            ]
            for u in users:
                db.session.add(u)
            print("✅ Users created (admin/tarel2026, martin/martin2026, danny/danny2026)")
        else:
            print("⏭  Users already exist")

        # Fish
        if FishMaster.query.count() == 0:
            fish_data = [
                {"fish_name":"(1kg) Blue Swimmer Crab","tamil_name":"நீலக்கண் நண்டு","size":"1kg","avra_price":27,"global_price":12,"selling_price":37.80,"is_fish":True},
                {"fish_name":"(1/2kg) Blue Swimmer Crab","tamil_name":"நீலக்கண் நண்டு","size":"0.5kg","avra_price":15,"global_price":12,"selling_price":21.00,"is_fish":True},
                {"fish_name":"(1kg) Indian Mackerel (Ayila)","tamil_name":"அயிலை","size":"1kg","avra_price":15,"selling_price":18.00,"is_fish":True},
                {"fish_name":"(1/2kg) Indian Mackerel (Ayila)","size":"0.5kg","avra_price":9,"selling_price":10.80,"is_fish":True},
                {"fish_name":"(1kg) Sardine (Mathi)","tamil_name":"சாளை","size":"1kg","avra_price":15,"selling_price":15.00,"is_fish":True},
                {"fish_name":"(1/2kg) Sardine (Mathi)","size":"0.5kg","avra_price":9,"selling_price":9.00,"is_fish":True},
                {"fish_name":"(1kg) Anchovy (Netholi)","tamil_name":"நெத்திலி மீன்","size":"1kg","avra_price":17,"global_price":11,"selling_price":22.10,"is_fish":True},
                {"fish_name":"(1/2kg) Anchovy (Netholi)","size":"0.5kg","avra_price":10,"global_price":11,"selling_price":13.00,"is_fish":True},
                {"fish_name":"(1kg) Bonito","tamil_name":"தூனை","size":"1kg","avra_price":17,"global_price":10.75,"selling_price":22.10,"is_fish":True},
                {"fish_name":"(1kg) Threadfin Bream (Kilimeen)","tamil_name":"சங்கரா மீன்","size":"1kg","avra_price":17,"selling_price":22.10,"is_fish":True},
                {"fish_name":"(1kg) Ponny Fish","tamil_name":"காரா","size":"1kg","avra_price":17,"selling_price":22.10,"is_fish":True},
                {"fish_name":"(1kg) Yellow Scads","size":"1kg","avra_price":17,"selling_price":23.80,"is_fish":True},
                {"fish_name":"(1kg) Yellow Travelly/Manjal Paarai","size":"1kg","avra_price":18,"selling_price":23.40,"is_fish":True},
                {"fish_name":"(1kg) Goat Fish (Red Mullet)","tamil_name":"நகரை","size":"1kg","avra_price":18,"selling_price":23.40,"is_fish":True},
                {"fish_name":"(1kg) Ribbon Fish (Vaala Meen)","size":"1kg","avra_price":18,"selling_price":23.40,"is_fish":True},
                {"fish_name":"(1kg) Rabbit Fish","tamil_name":"ஒரா மீன்","size":"1kg","avra_price":18,"selling_price":23.40,"is_fish":True},
                {"fish_name":"(1kg) Emperor Fish (Vilameen)","tamil_name":"விளவன்","size":"1kg","avra_price":19,"selling_price":24.70,"is_fish":True},
                {"fish_name":"(1kg) Yellowfin Tuna (Choora)","tamil_name":"சூரை மீன்","size":"1kg","avra_price":19,"selling_price":24.70,"is_fish":True},
                {"fish_name":"(1kg) King Fish (Slice)","tamil_name":"அருக்குவா மீன்","size":"1kg","avra_price":21,"selling_price":21.00,"is_fish":True},
                {"fish_name":"(1kg) Barramundi (Kalanchi)","tamil_name":"கொளவான்","size":"1kg","avra_price":20,"global_price":12.60,"selling_price":26.00,"is_fish":True},
                {"fish_name":"(1kg) Travelly / Vatta","tamil_name":"பாரை","size":"1kg","avra_price":20,"selling_price":26.00,"is_fish":True},
                {"fish_name":"(1kg) Milkshark","tamil_name":"பால் சுறா","size":"1kg","avra_price":20,"selling_price":26.00,"is_fish":True},
                {"fish_name":"(1kg) Indian Salmon","tamil_name":"காலான்","size":"1kg","avra_price":20,"selling_price":26.00,"is_fish":True},
                {"fish_name":"(1kg) Barracuda (Seelav)","tamil_name":"சீலா","size":"1kg","avra_price":20,"global_price":12.45,"selling_price":26.00,"is_fish":True},
                {"fish_name":"(1kg) Black Pomfret (B. Avoli)","tamil_name":"வாவால்","size":"1kg","avra_price":22,"global_price":13.90,"selling_price":28.60,"is_fish":True},
                {"fish_name":"(1kg) Ladyfish","tamil_name":"கிழங்கான்","size":"1kg","avra_price":22,"selling_price":28.60,"is_fish":True},
                {"fish_name":"(1kg) Sail Fish","tamil_name":"மயில் மீன்","size":"1kg","avra_price":22,"selling_price":30.80,"is_fish":True},
                {"fish_name":"(1kg) Silver Pomfret (S. Avoli)","tamil_name":"வெள்ளை வாவால்","size":"1kg","avra_price":39,"selling_price":50.70,"is_fish":True},
                {"fish_name":"(1kg) Cuttlefish (Kanava)","tamil_name":"கன்னவாய்","size":"1kg","avra_price":20,"selling_price":28.00,"is_fish":True},
                {"fish_name":"(1kg) Squid","tamil_name":"ஊருள் கன்னவாய்","size":"1kg","avra_price":24,"selling_price":28.80,"is_fish":True},
                {"fish_name":"(1kg) White Prawn","tamil_name":"வெள்ளை இறால்","size":"1kg","avra_price":33,"selling_price":39.60,"is_fish":True},
                {"fish_name":"(1/2kg) White Prawn","size":"0.5kg","avra_price":18,"selling_price":21.60,"is_fish":True},
                {"fish_name":"(1kg) Black Tiger Prawn","tamil_name":"டைகர் இறால்","size":"1kg","avra_price":36,"selling_price":46.80,"is_fish":True},
                {"fish_name":"(1/2kg) Black Tiger Prawn","size":"0.5kg","avra_price":19,"selling_price":24.70,"is_fish":True},
                {"fish_name":"(1kg) Kid Goat Meat","tamil_name":"இளம் ஆட்டு இறைச்சி","size":"1kg","avra_price":18,"selling_price":23.40,"is_fish":False},
                {"fish_name":"(1kg) Goat Meat With Bone","tamil_name":"ஆட்டு இறைச்சி","size":"1kg","avra_price":15,"selling_price":19.50,"is_fish":False},
                {"fish_name":"(1kg) Goat Meat without Bone","size":"1kg","avra_price":21,"selling_price":27.30,"is_fish":False},
                {"fish_name":"(1/2kg) Goat Meat without Bone","size":"0.5kg","avra_price":12,"selling_price":15.60,"is_fish":False},
                {"fish_name":"(1kg) Goat Liver+Heart","size":"1kg","avra_price":6,"selling_price":8.40,"is_fish":False},
                {"fish_name":"Lamb Diced on Bone","size":"1kg","avra_price":16,"selling_price":None,"is_fish":False},
            ]
            for f in fish_data:
                db.session.add(FishMaster(
                    fish_name=f.get('fish_name'), tamil_name=f.get('tamil_name'),
                    size=f.get('size','1kg'), avra_impex_price=f.get('avra_price'),
                    global_food_price=f.get('global_price'), selling_price=f.get('selling_price'),
                    is_fish=f.get('is_fish',True), is_active=True
                ))
            print(f"✅ {len(fish_data)} fish/products added")
        else:
            print(f"⏭  Fish already seeded ({FishMaster.query.count()} items)")

        # Delivery week
        if DeliveryWeek.query.count() == 0:
            today = date.today()
            days = (2 - today.weekday()) % 7
            if days == 0: days = 7
            next_wed = today + timedelta(days=days)
            db.session.add(DeliveryWeek(
                week_start=next_wed - timedelta(days=7),
                week_end=next_wed - timedelta(days=3),
                delivery_date=next_wed, status='open'
            ))
            print(f"✅ Delivery week created — delivery on {next_wed}")
        else:
            print("⏭  Delivery weeks already exist")

        db.session.commit()
        print("\n🎉 Seed complete! Login at http://localhost:5000")
        print("   Username: admin | Password: tarel2026")
        print("   Username: martin | Password: martin2026")
        print("   Username: danny  | Password: danny2026")

if __name__ == '__main__':
    seed()
