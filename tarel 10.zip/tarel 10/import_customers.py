"""
Import customers from a CSV file.
CSV columns:
    customer_id (optional), name, phone, address, area, postcode, notes
All fields except customer_id are required.
Phone numbers may be UK or Indian mobile formats, but they must be present.
Existing customers are skipped by customer_id or phone, so large files can be re-run safely.
Run: python import_customers.py customers.csv
"""
import sys
import csv
import re
from datetime import datetime
from app import create_app
from models import db, Customer

AREA_CODES = {
    'Edinburgh': 'ED', 'Glasgow': 'GL', 'Livingston': 'LI',
    'Bathgate': 'BA', 'East Calder': 'EC', 'Broxburn': 'BR',
    'Inverness': 'IN', 'Winchburgh': 'WI', 'Ayr': 'AY',
}

def generate_customer_id(area, year, count):
    code = AREA_CODES.get(area, 'XX')
    return f"{code}{year}{count:03d}"

def normalize_phone(phone):
    phone = (phone or '').strip()
    if not phone:
        return ''
    phone = re.sub(r'[\s\-()\.]+', '', phone)
    if phone.startswith('00'):
        phone = '+' + phone[2:]
    if phone.startswith('+'):
        digits = phone[1:]
        if not digits.isdigit():
            return ''
        return '+' + digits
    digits = re.sub(r'\D', '', phone)
    if not digits:
        return ''
    return digits

def import_csv(filepath):
    app = create_app()
    with app.app_context():
        year = datetime.now().strftime('%y')
        area_counters = {}
        imported = skipped = failed = 0
        batch_size = 200
        pending = 0
        existing_customers = Customer.query.all()
        existing_by_id = {c.customer_id: c for c in existing_customers if c.customer_id}
        existing_by_phone = {}
        for customer in existing_customers:
            key = normalize_phone(customer.phone)
            if key and key not in existing_by_phone:
                existing_by_phone[key] = customer
        assigned_ids = set()
        assigned_phones = set()

        def get(row, key):
            for k in row:
                if k and k.strip().lower() == key:
                    return (row.get(k) or '').strip()
            return ''

        def validate_row(row):
            required = ['name', 'phone', 'address', 'area', 'postcode', 'notes']
            missing = [field for field in required if not get(row, field)]
            phone = get(row, 'phone')
            phone_key = normalize_phone(phone)
            if phone and not phone_key:
                missing.append('phone (invalid format)')
            if phone_key and len(phone_key.lstrip('+')) < 8:
                missing.append('phone (too short)')
            return missing, phone_key

        with open(filepath, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for idx, row in enumerate(reader, start=2):
                try:
                    name = get(row, 'name')
                    area = get(row, 'area')
                    provided_cid = get(row, 'customer_id')
                    missing, phone_key = validate_row(row)
                    if missing:
                        failed += 1
                        print(f"Row {idx} ({name or '?'}) missing/invalid: {', '.join(sorted(set(missing)))}")
                        continue
                    if provided_cid and provided_cid in assigned_ids:
                        skipped += 1
                        continue
                    if phone_key in assigned_phones:
                        skipped += 1
                        continue

                    address = get(row, 'address')
                    postcode = get(row, 'postcode')
                    notes = get(row, 'notes')
                    phone_val = get(row, 'phone')

                    existing = None
                    if provided_cid and provided_cid in existing_by_id:
                        existing = existing_by_id[provided_cid]
                    elif phone_key and phone_key in existing_by_phone:
                        existing = existing_by_phone[phone_key]

                    if existing:
                        skipped += 1
                        if provided_cid:
                            assigned_ids.add(provided_cid)
                        if phone_key:
                            assigned_phones.add(phone_key)
                        continue

                    if not area:
                        area = 'Edinburgh'
                    area_counters[area] = area_counters.get(area, 0) + 1
                    cid = provided_cid or generate_customer_id(area, year, area_counters[area])
                    while cid in assigned_ids or cid in existing_by_id:
                        area_counters[area] += 1
                        cid = generate_customer_id(area, year, area_counters[area])
                    customer = Customer(
                        customer_id=cid,
                        name=name,
                        phone=phone_val,
                        address=address,
                        area=area,
                        postcode=postcode,
                        notes=notes,
                    )
                    db.session.add(customer)
                    imported += 1
                    assigned_ids.add(cid)
                    existing_by_id[cid] = customer
                    if phone_key:
                        assigned_phones.add(phone_key)
                        existing_by_phone[phone_key] = customer

                    pending += 1
                    if pending >= batch_size:
                        db.session.commit()
                        pending = 0
                except Exception as exc:
                    db.session.rollback()
                    failed += 1
                    pending = 0
                    print(f"Row {idx} ({get(row, 'name') or '?'}): {exc}")
        if pending:
            db.session.commit()
        print(f"✅ Imported {imported} customers, updated {updated}, skipped {skipped}, failed {failed}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python import_customers.py customers.csv")
        sys.exit(1)
    import_csv(sys.argv[1])
