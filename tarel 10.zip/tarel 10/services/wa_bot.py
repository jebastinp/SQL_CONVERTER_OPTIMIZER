"""
WhatsApp conversation brain — framework-light and testable.
The actual sending function is injected, so tests pass a fake sender and assert
on what WOULD be sent, with no network.

Conversation states tracked per phone:
  idle -> awaiting_confirm -> awaiting_payment -> done
Intents detected: availability, order, confirm, decline, paid, refund_confirm, unknown
"""
import re

# ---- intent detection ----
AVAIL_PAT = re.compile(r"\b(available|availability|what.*(have|got)|stock|list|menu|price)\b", re.I)
CONFIRM_PAT = re.compile(r"^\s*(yes|yeah|yep|confirm|ok|okay|y|sure|go ahead)\b", re.I)
DECLINE_PAT = re.compile(r"^\s*(no|nope|cancel|stop|n)\b", re.I)
PAID_PAT = re.compile(r"\b(paid|payment done|sent.*payment|transferred|done payment|paid now)\b", re.I)
REFUND_CONFIRM_PAT = re.compile(r"\b(received.*refund|refund received|got.*refund|refund.*received)\b", re.I)

def detect_intent(text, has_image=False):
    if has_image:
        return "paid"               # an image in payment context is treated as a payment proof
    if not text:
        return "unknown"
    t = text.strip()
    if REFUND_CONFIRM_PAT.search(t):
        return "refund_confirm"
    if PAID_PAT.search(t):
        return "paid"
    if CONFIRM_PAT.match(t):
        return "confirm"
    if DECLINE_PAT.match(t):
        return "decline"
    if AVAIL_PAT.search(t):
        return "availability"
    # crude order detection: contains a quantity like "2kg" or "1 kg" or "500g"
    if re.search(r"\d+\s*(kg|g|kilo|gram)", t, re.I):
        return "order"
    return "unknown"


def format_availability(products):
    """products: list of dicts {name, one_kg_price, is_fish, available}.
    Returns the text the bot replies with."""
    avail = [p for p in products if p.get("available", True)]
    if not avail:
        return "Sorry, we have no items available this week. Please check back later. - TAREL"
    fish = [p for p in avail if p.get("is_fish", True)]
    meat = [p for p in avail if not p.get("is_fish", True)]
    lines = ["Here's what's available this week:"]
    if fish:
        lines.append("\nFISH:")
        for p in fish:
            lines.append(f"- {p['name']}: \u00a3{float(p['one_kg_price']):.2f}/kg")
    if meat:
        lines.append("\nMEAT:")
        for p in meat:
            lines.append(f"- {p['name']}: \u00a3{float(p['one_kg_price']):.2f}/kg")
    lines.append("\nReply with your order, e.g. '2kg king fish, 1kg prawns'. - TAREL")
    return "\n".join(lines)


def format_order_summary(items, total):
    """items: list of {name, qty_kg, line_total}."""
    lines = ["Here's your order:"]
    for it in items:
        lines.append(f"- {it['name']}: {it['qty_kg']}kg = \u00a3{float(it['line_total']):.2f}")
    lines.append(f"\nTotal (before delivery/freight): \u00a3{float(total):.2f}")
    lines.append("Reply YES to confirm and we'll send your invoice. - TAREL")
    return "\n".join(lines)


def handle_message(state, text, has_image, deps):
    """
    Pure decision function. Does NOT touch DB/network directly.
    state: current conversation state string for this phone
    deps: dict of callables/values the handler may use:
        - products: list for availability
        - parse_order(text) -> (items, total) or None
        - create_draft_order(items) -> order_ref
        - generate_invoice() -> invoice dict
        - record_pending_payment() 
        - confirm_refund()
    Returns dict: {reply, new_state, action}
      action in {none, drafted, invoiced, payment_logged, refund_confirmed, handoff}
    """
    intent = detect_intent(text, has_image)

    if intent == "availability":
        return {"reply": format_availability(deps.get("products", [])),
                "new_state": state, "action": "none"}

    if intent == "order":
        parsed = deps.get("parse_order", lambda t: None)(text)
        if not parsed or not parsed[0]:
            return {"reply": "Sorry, I couldn't read that order. A team member will help you shortly. - TAREL",
                    "new_state": state, "action": "handoff"}
        items, total = parsed
        deps.get("create_draft_order", lambda i: None)(items)
        return {"reply": format_order_summary(items, total),
                "new_state": "awaiting_confirm", "action": "drafted"}

    if intent == "confirm":
        if state == "awaiting_confirm":
            inv = deps.get("generate_invoice", lambda: {"total": 0})()
            return {"reply": f"Thank you! Your invoice total is \u00a3{float(inv['total']):.2f}. "
                             f"Please pay to the bank details provided and send a screenshot. - TAREL",
                    "new_state": "awaiting_payment", "action": "invoiced"}
        return {"reply": "Thanks! Could you tell me your order first? - TAREL",
                "new_state": state, "action": "none"}

    if intent == "decline":
        return {"reply": "No problem, your order has been cancelled. Message us anytime. - TAREL",
                "new_state": "idle", "action": "none"}

    if intent == "paid":
        deps.get("record_pending_payment", lambda: None)()
        return {"reply": "Thank you! We've received your payment proof. Our team will verify it shortly. - TAREL",
                "new_state": "done", "action": "payment_logged"}

    if intent == "refund_confirm":
        deps.get("confirm_refund", lambda: None)()
        return {"reply": "Thank you for confirming you received the refund. - TAREL",
                "new_state": state, "action": "refund_confirmed"}

    # unknown -> handoff
    return {"reply": "Thanks for your message! A team member will get back to you shortly. - TAREL",
            "new_state": state, "action": "handoff"}
