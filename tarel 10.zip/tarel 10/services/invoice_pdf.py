import os
import re
import base64
from datetime import datetime
from flask import current_app, render_template_string

os.environ.setdefault('LDFLAGS', '-L/opt/homebrew/lib')
os.environ.setdefault('CPPFLAGS', '-I/opt/homebrew/include')
os.environ.setdefault('PKG_CONFIG_PATH', '/opt/homebrew/lib/pkgconfig:/opt/homebrew/share/pkgconfig')
os.environ.setdefault('DYLD_LIBRARY_PATH', '/opt/homebrew/lib')

INVOICE_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4; margin: 18mm; }
  body { font-family: Arial, sans-serif; font-size: 12px; margin: 0; padding: 20px; color: #1d2821; background: #ffffff; }
  .header { text-align: center; border-bottom: 3px solid #d8ded3; padding-bottom: 15px; margin-bottom: 20px; }
  .header-logo { width: 190px; height: 190px; object-fit: contain; display: block; margin: 0 auto 8px; }
  .header-title { font-size: 24px; font-weight: 900; letter-spacing: 4px; color: #2e4236; margin: 0; }
  .header h1 { display: none; }
  .header h2 { display: none; }
  .stop-header { background: #2e4236; color: white; padding: 10px 15px; font-size: 16px; font-weight: bold; margin-bottom: 15px; }
  .section { margin-bottom: 15px; }
  .section-title { font-weight: bold; color: #2e4236; border-bottom: 1px solid #d8ded3; padding-bottom: 5px; margin-bottom: 8px; text-transform: uppercase; font-size: 11px; letter-spacing: 1px; }
  .detail-row { display: flex; margin-bottom: 4px; }
  .detail-label { width: 120px; font-weight: bold; color: #1d2821; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  th { background: #eaf0e5; color: #2e4236; padding: 8px; text-align: left; font-size: 11px; }
  td { padding: 7px 8px; border-bottom: 1px solid #d8ded3; }
  .total-row { background: #eaf0e5; font-weight: bold; font-size: 14px; }
  .total-row td { padding: 10px 8px; }
  .bank { background: #f8f7f2; padding: 12px; border-left: 4px solid #6f8e52; }
  .bank .bank-title { font-weight: bold; margin-bottom: 8px; color: #2e4236; }
  .text-right { text-align: right; }
  .footer { margin-top: 20px; text-align: center; color: #6b746e; font-size: 10px; border-top: 1px solid #d8ded3; padding-top: 10px; }
</style>
</head>
<body>
<div class="header">
  {% if logo_base64 %}<img class="header-logo" src="data:image/png;base64,{{ logo_base64 }}" alt="TAREL logo">{% endif %}
  <div class="header-title">INVOICE</div>
</div>

{% if stop_number %}
<div class="stop-header">STOP {{ stop_number }} — {{ customer_name }}</div>
{% else %}
<div class="stop-header">{{ customer_name }}</div>
{% endif %}

<div class="section">
  <div class="section-title">Customer Details</div>
  <div class="detail-row"><span class="detail-label">Name:</span> {{ customer_name }}</div>
  <div class="detail-row"><span class="detail-label">Payment Ref:</span> {{ payment_reference }}</div>
  <div class="detail-row"><span class="detail-label">Phone:</span> {{ phone }}</div>
  <div class="detail-row"><span class="detail-label">Address:</span> {{ address }}</div>
</div>

<div class="section">
  <div class="section-title">Order Details</div>
  <table>
    <thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th class="text-right">Total</th></tr></thead>
    <tbody>
      {% for item in items %}
      <tr>
        <td>{{ item.fish_name }}{% if item.cut_instructions %}<br><small style="color:#888">{{ item.cut_instructions }}</small>{% endif %}</td>
        <td>{{ item.quantity_kg }}kg</td>
        <td>£{{ "%.2f"|format(item.unit_price) }}</td>
        <td class="text-right">£{{ "%.2f"|format(item.line_total) }}</td>
      </tr>
      {% endfor %}
      {% if freight_surcharge > 0 %}
      <tr>
        <td>Freight Surcharge (£{{ "%.2f"|format(freight_rate) }}/kg)</td>
        <td>{{ fish_kg }}kg</td>
        <td>£{{ "%.2f"|format(freight_rate) }}</td>
        <td class="text-right">£{{ "%.2f"|format(freight_surcharge) }}</td>
      </tr>
      {% endif %}
      {% if delivery_charge > 0 %}
      <tr>
        <td>Delivery Charge</td>
        <td>1</td>
        <td>£{{ "%.2f"|format(delivery_charge) }}</td>
        <td class="text-right">£{{ "%.2f"|format(delivery_charge) }}</td>
      </tr>
      {% endif %}
      <tr class="total-row">
        <td colspan="3"><strong>TOTAL</strong></td>
        <td class="text-right"><strong>£{{ "%.2f"|format(total) }}</strong></td>
      </tr>
    </tbody>
  </table>
</div>

<div class="bank">
  <div class="bank-title">Bank Transfer Details</div>
  <div>Name: <strong>{{ bank_account_name }}</strong></div>
  <div>Sort Code: <strong>{{ bank_sort_code }}</strong></div>
  <div>Account: <strong>{{ bank_account_number }}</strong></div>
  <div>Reference: <strong>{{ payment_reference }}</strong></div>
</div>

<div class="footer">TAREL Fish & Meat Delivery | Thank you for your order!</div>
</body>
</html>
"""

def generate_invoice_pdf(order, invoice, bank_settings=None, freight_rate=1.50):
    """Generate a PDF invoice for an order."""
    try:
        from weasyprint import HTML
    except ImportError:
        return None, "WeasyPrint not installed"

    customer = order.customer
    items = order.items
    
    fish_kg = sum(float(i.quantity_kg) for i in items if i.fish and i.fish.is_fish)

    order_date_text = order.order_date.strftime('%Y%m%d') if order.order_date else datetime.now().strftime('%Y%m%d')
    safe_customer_name = re.sub(r'[^a-z0-9]+', ' ', (customer.name or 'customer').lower()).strip() or 'customer'
    logo_path = os.path.join(current_app.root_path, 'images', 'logo.png')
    logo_base64 = ''
    if os.path.exists(logo_path):
      with open(logo_path, 'rb') as logo_file:
        logo_base64 = base64.b64encode(logo_file.read()).decode('ascii')
    
    bank_settings = bank_settings or {}
    html_content = render_template_string(INVOICE_HTML,
      delivery_date=order.delivery_date.strftime('%d %B %Y') if order.delivery_date else '',
      stop_number=order.delivery_stop_number or '',
      customer_name=customer.name,
      payment_reference=order.payment_reference or '',
      phone=customer.phone or '',
      address=f"{customer.address}, {customer.postcode}" if customer.address else '',
      items=items,
      fish_kg=fish_kg,
      logo_base64=logo_base64,
      freight_surcharge=float(invoice.freight_surcharge or 0),
      delivery_charge=float(invoice.delivery_charge or 0),
      total=float(invoice.total or 0),
      freight_rate=float(freight_rate),
      bank_account_name=bank_settings.get('account_name', 'Daniel Maria Lazar'),
      bank_sort_code=bank_settings.get('sort_code', '80-48-88'),
      bank_account_number=bank_settings.get('account_number', '13616562'),
    )

    pdf_dir = os.path.join(current_app.root_path, 'static', 'invoices')
    os.makedirs(pdf_dir, exist_ok=True)
    filename = f"{safe_customer_name}_{order_date_text}_invoice.pdf"
    pdf_path = os.path.join(pdf_dir, filename)
    
    try:
        HTML(string=html_content).write_pdf(pdf_path)
        return pdf_path, None
    except Exception as e:
        return None, str(e)


def render_invoice_html(order, invoice, bank_settings=None, freight_rate=1.50):
    """Return the invoice HTML string (same template used for PDF)."""
    customer = order.customer
    items = order.items
    fish_kg = sum(float(i.quantity_kg) for i in items if i.fish and i.fish.is_fish)
    logo_path = os.path.join(current_app.root_path, 'images', 'logo.png')
    logo_base64 = ''
    if os.path.exists(logo_path):
      with open(logo_path, 'rb') as logo_file:
        logo_base64 = base64.b64encode(logo_file.read()).decode('ascii')
    bank_settings = bank_settings or {}
    html_content = render_template_string(INVOICE_HTML,
      delivery_date=order.delivery_date.strftime('%d %B %Y') if order.delivery_date else '',
      stop_number=order.delivery_stop_number or '',
        customer_name=customer.name,
        payment_reference=order.payment_reference or '',
        phone=customer.phone or '',
        address=f"{customer.address}, {customer.postcode}" if customer.address else '',
        items=items,
        fish_kg=fish_kg,
      logo_base64=logo_base64,
        freight_surcharge=float(invoice.freight_surcharge or 0),
        delivery_charge=float(invoice.delivery_charge or 0),
        total=float(invoice.total or 0),
        freight_rate=float(freight_rate),
        bank_account_name=bank_settings.get('account_name', 'Daniel Maria Lazar'),
        bank_sort_code=bank_settings.get('sort_code', '80-48-88'),
        bank_account_number=bank_settings.get('account_number', '13616562'),
    )
    return html_content
