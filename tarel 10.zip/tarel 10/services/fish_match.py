"""
Bridge parsed WhatsApp item names to real FishMaster rows.
The parser returns display names/aliases; we must resolve each to an actual
product in the database so the order can be created with valid prices.
"""
import re


def _norm(s):
    s = (s or "").lower()
    s = re.sub(r"\(.*?\)", " ", s)          # drop bracketed bits like (1kg)
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


# Generic words that must NOT, on their own, cause a match.
_STOPWORDS = {"fish", "meat", "with", "without", "bone", "the", "and", "of",
              "kg", "slice", "whole", "fresh", "big", "small", "medium"}


def _content_tokens(s):
    return {t for t in _norm(s).split() if t and t not in _STOPWORDS}


def match_fish(parsed_name, fish_rows):
    """
    parsed_name: string from the parser (e.g. '(1kg) King Fish (Slice)' or 'king fish')
    fish_rows: list of FishMaster ORM rows (active ones)
    Returns (fish_row_or_None, confidence) where confidence in {'exact','strong','weak','none'}.
    """
    if not parsed_name or not fish_rows:
        return None, "none"
    target = _norm(parsed_name)
    if not target:
        return None, "none"

    # 1) exact normalized match on fish_name
    for f in fish_rows:
        if _norm(f.fish_name) == target:
            return f, "exact"

    # 2) exact match against english/tamil/malayalam names
    for f in fish_rows:
        for alt in (f.english_name, f.tamil_name, f.malayalam_name):
            if alt and _norm(alt) == target:
                return f, "exact"

    # 3) token-overlap strong match using CONTENT tokens (ignore generic words)
    tgt_tokens = _content_tokens(parsed_name)
    if not tgt_tokens:
        return None, "none"
    best, best_score = None, 0
    for f in fish_rows:
        cand_tokens = _content_tokens(f.fish_name)
        if not cand_tokens:
            continue
        overlap = tgt_tokens & cand_tokens
        score = len(overlap)
        if score > best_score and overlap:
            best, best_score = f, score
    if best is not None:
        if tgt_tokens.issubset(_content_tokens(best.fish_name)):
            return best, "strong"
        return best, "weak"

    # 4) substring containment on content (avoids matching on generic words)
    for f in fish_rows:
        cand = _norm(f.fish_name)
        if target and len(target) >= 4 and (target in cand):
            return f, "weak"

    return None, "none"


def resolve_items(parsed_items, fish_rows):
    """
    Turn parser items into review rows with a matched product.
    Returns list of dicts:
      {parsed_name, quantity_kg, cut_instructions,
       fish_id, matched_name, confidence}
    fish_id is None when nothing matched (user must pick on the review screen).
    """
    out = []
    for it in parsed_items or []:
        name = it.get("fish_name", "")
        qty = float(it.get("quantity_kg") or 1.0)
        f, conf = match_fish(name, fish_rows)
        out.append({
            "parsed_name": name,
            "quantity_kg": qty,
            "cut_instructions": it.get("cut_instructions", "Clean and Cut"),
            "fish_id": f.id if f else None,
            "matched_name": f.fish_name if f else None,
            "confidence": conf,
        })
    return out
