"""
Driver routing via OpenRouteService.
The HTTP call is isolated in `_ors_optimize` so tests inject a fake.
Auto-split logic (by area then load) is pure and fully testable offline.
"""
import os
from collections import defaultdict

ORS_BASE = "https://api.openrouteservice.org"


def split_orders_by_area_load(orders, drivers):
    """
    orders: list of dicts {id, area, lat, lon}
    drivers: list of dicts {id, name}
    Auto-split: group by area, then distribute area-groups across drivers to
    balance load (number of stops). Returns {driver_id: [order, ...]}.
    """
    if not drivers:
        return {}
    # group by area
    by_area = defaultdict(list)
    for o in orders:
        by_area[o.get("area") or "Unknown"].append(o)
    # sort areas by size desc so big clusters are placed first
    areas = sorted(by_area.values(), key=len, reverse=True)
    assignment = {d["id"]: [] for d in drivers}
    driver_ids = [d["id"] for d in drivers]
    # greedy: put each area group with the currently-lightest driver
    for group in areas:
        lightest = min(driver_ids, key=lambda did: len(assignment[did]))
        assignment[lightest].extend(group)
    return assignment


def build_optimization_jobs(orders):
    """Turn orders into ORS 'jobs' (each delivery is a job)."""
    jobs = []
    for i, o in enumerate(orders, 1):
        if o.get("lat") is None or o.get("lon") is None:
            continue  # unroutable, skipped (flagged separately)
        jobs.append({"id": o["id"], "location": [o["lon"], o["lat"]]})
    return jobs


def unroutable(orders):
    """Orders lacking coordinates."""
    return [o for o in orders if o.get("lat") is None or o.get("lon") is None]


def build_vehicle(driver):
    """driver dict needs start [lon,lat]; end optional."""
    v = {"id": driver["id"],
         "start": [driver["start_lon"], driver["start_lat"]]}
    if driver.get("end_lon") is not None and driver.get("end_lat") is not None:
        v["end"] = [driver["end_lon"], driver["end_lat"]]
    return v


def _ors_optimize(payload, api_key, http_post=None):
    """Real network call (or injected http_post for tests)."""
    if http_post is None:
        import requests
        http_post = requests.post
    if not api_key:
        return {"ok": False, "error": "ORS_API_KEY not configured"}
    try:
        r = http_post(f"{ORS_BASE}/optimization",
                      json=payload,
                      headers={"Authorization": api_key},
                      timeout=20)
        if r.status_code == 429:
            return {"ok": False, "error": "ORS rate limit (429) — try again shortly"}
        r.raise_for_status()
        return {"ok": True, "data": r.json()}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def optimize_routes(orders, drivers, api_key=None, http_post=None):
    """
    Full pipeline: split -> build payload per driver -> call ORS -> return routes.
    Returns dict: {assignments, unroutable, results:{driver_id: ors_result}}
    """
    api_key = api_key or os.environ.get("ORS_API_KEY", "")
    skipped = unroutable(orders)
    routable = [o for o in orders if o not in skipped]
    assignment = split_orders_by_area_load(routable, drivers)
    results = {}
    driver_by_id = {d["id"]: d for d in drivers}
    for did, ords in assignment.items():
        if not ords:
            results[did] = {"ok": True, "data": {"routes": []}}
            continue
        payload = {"jobs": build_optimization_jobs(ords),
                   "vehicles": [build_vehicle(driver_by_id[did])]}
        results[did] = _ors_optimize(payload, api_key, http_post=http_post)
    return {"assignments": assignment, "unroutable": skipped, "results": results}
