# 🐟 TAREL — Admin Management System

## ▶️ ONE-CLICK START

### Windows
Double-click **`run.bat`**

### Mac / Linux
```bash
./run.sh
```

That's it. The script installs everything, sets up the database, and opens the app.

---

## 🔑 KEYS YOU NEED (only 2)

### 1. Supabase Database URL (free)
1. Go to **supabase.com** → sign up free
2. Create New Project (pick any name, set a password)
3. Wait ~2 mins for setup
4. Go to **Settings → Database → Connection string → URI**
5. Copy the URI — looks like:
   `postgresql://postgres:YOURPASSWORD@db.YOURREF.supabase.co:5432/postgres`

### 2. Secret Key
Just type any random text, e.g.: `tarel-admin-secure-2026`

---

## 🛠 FIRST TIME SETUP

1. Run `run.bat` (Windows) or `./run.sh` (Mac/Linux)
2. It will create `.env` and open it automatically
3. Paste your Supabase URL and secret key
4. Save and run again
5. Database tables created automatically
6. Open **http://localhost:5000** on your Mac, or use your Mac's local Wi-Fi IP from your phone/iPad as `http://YOUR-MAC-IP:5000`

### View on other devices on the same Wi-Fi
1. Start the app with `./run.sh`
2. Look for the `Phone/iPad:` URL printed in the terminal
3. Open that URL on your mobile device while it is connected to the same Wi-Fi network

If it does not load, check macOS Firewall and allow incoming connections for Python.

---

## 🔐 LOGIN — EVERY PAGE REQUIRES LOGIN

| User     | Password     | Can do |
|----------|-------------|--------|
| admin    | tarel2026   | Everything |
| martin   | martin2026  | Orders, routes, availability |
| danny    | danny2026   | Orders, routes, availability |

- **Every page is protected** — if you're not logged in, you're sent to login
- **Session expires after 8 hours** — must login again
- **Change passwords** in Settings → Team after first login

---

## 📱 IMPORT YOUR CUSTOMERS

Fill in `customers_template.csv` (you can include an optional `customer_id` column):
```
customer_id,name,phone,address,area,postcode,notes
CUSTOMER001,John Smith,+447911123456,12 High Street,Edinburgh,EH1 1AA,Regular customer
```

Areas: Edinburgh, Glasgow, Livingston, Bathgate, East Calder, Broxburn, Inverness, Winchburgh, Ayr

Then run:
```bash
python import_customers.py customers.csv
```

---

## 🌐 HOST ONLINE (after local testing)

**Railway (easiest — free)**
1. Push code to GitHub
2. Go to railway.app → Deploy from GitHub
3. Add your `.env` variables in Railway dashboard
4. Done — gets URL like `https://tarel-admin.railway.app`

Your whole team can then use it from any phone/laptop.
