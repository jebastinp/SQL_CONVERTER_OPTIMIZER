"""
Runnable unit tests for the TAREL core engine.
Each test references the test-plan ID(s) it covers.
Run: python -m pytest test_core.py -v    (or python test_core.py for a plain run)
"""
import core

PASS, FAIL = [], []

def check(test_id, desc, got, expected):
    ok = got == expected
    (PASS if ok else FAIL).append((test_id, desc, got, expected))
    mark = "PASS" if ok else "FAIL"
    print(f"[{mark}] {test_id}: {desc}" + ("" if ok else f"  got={got!r} expected={expected!r}"))

def check_true(test_id, desc, cond):
    check(test_id, desc, bool(cond), True)

# ---------------- Line totals: INV / ORD two-price rule ----------------
# ORD-06 0.5kg -> half price
check("ORD-06", "0.5kg charged half price",
      core.line_total(20, 11, None, 0.5), 11.0)
# ORD-07 whole kg
check("ORD-07", "2kg charged 2x one-kg",
      core.line_total(20, 11, None, 2), 40.0)
# ORD-05 1.5kg -> one + half
check("ORD-05", "1.5kg = one_kg + half_kg",
      core.line_total(20, 11, None, 1.5), 31.0)
# remainder < 0.5 adds nothing
check("ORD-05b", "1.4kg = one_kg only (remainder<0.5)",
      core.line_total(20, 11, None, 1.4), 20.0)
# fallback: no half price -> one_kg/2
check("ORD-05c", "half price falls back to one_kg/2",
      core.line_total(20, 0, None, 0.5), 10.0)
# fallback: no one_kg -> selling price
check("ORD-05d", "one_kg falls back to selling_price",
      core.line_total(0, 0, 18, 1), 18.0)

# ---------------- Freight: per-fish else global (FSH-11, INV-03) -------
# meat -> no freight (FSH-10)
check("FSH-10", "meat line has zero freight",
      core.item_freight(False, 3, None, 1.5), 0.0)
# fish, no per-fish price -> global rate
check("INV-03", "fish freight uses global when per-fish unset",
      core.item_freight(True, 2, None, 1.5), 3.0)
# fish, per-fish price set -> use it
check("FSH-11a", "fish freight uses per-fish price when set",
      core.item_freight(True, 2, 2.0, 1.5), 4.0)
# per-fish zero -> treated as unset -> global
check("FSH-11b", "per-fish freight of 0 falls back to global",
      core.item_freight(True, 2, 0, 1.5), 3.0)
# order freight mixes the rules
mix = [
    {"is_fish": True, "quantity_kg": 2, "per_fish_freight": 2.0},   # 4.00
    {"is_fish": True, "quantity_kg": 1, "per_fish_freight": None},  # 1.50
    {"is_fish": False, "quantity_kg": 5, "per_fish_freight": None}, # 0
]
check("FSH-11c", "order freight mixes per-fish and global",
      core.order_freight(mix, 1.5), 5.5)

# ---------------- Delivery charge (INV-04/05/06) ----------------------
rules = {"small_order_threshold": 30, "small_order_charge": 2, "inverness_charge": 13}
check("INV-04", "Inverness flat charge",
      core.delivery_charge("Inverness", 100, rules), 13.0)
check("INV-05", "small order charge under threshold",
      core.delivery_charge("Edinburgh", 25, rules), 2.0)
check("INV-06", "no charge at/over threshold",
      core.delivery_charge("Edinburgh", 30, rules), 0.0)
check("INV-04b", "Inverness charged even if big order",
      core.delivery_charge("Inverness", 500, rules), 13.0)

# ---------------- Invoice assembly (INV-07) ---------------------------
items = [
    {"one_kg_price": 20, "half_kg_price": 11, "selling_price": None,
     "quantity_kg": 1.5, "is_fish": True, "per_fish_freight": None},   # line 31.00, fish 1.5kg
    {"one_kg_price": 10, "half_kg_price": 6, "selling_price": None,
     "quantity_kg": 2, "is_fish": False, "per_fish_freight": None},    # line 20.00, meat
]
inv = core.invoice_totals(items, "Edinburgh", rules, 1.5)
# subtotal 31+20=51, freight 1.5*1.5=2.25, delivery 0 (>=30), total 53.25
check("INV-07a", "invoice subtotal", inv["subtotal"], 51.0)
check("INV-07b", "invoice freight (global on fish only)", inv["freight"], 2.25)
check("INV-07c", "invoice delivery", inv["delivery"], 0.0)
check("INV-07d", "invoice total", inv["total"], 53.25)

# small order triggers charge in full assembly (EDT-07)
items_small = [{"one_kg_price": 10, "half_kg_price": 6, "selling_price": None,
                "quantity_kg": 1, "is_fish": True, "per_fish_freight": None}]
inv2 = core.invoice_totals(items_small, "Glasgow", rules, 1.5)
# subtotal 10, freight 1.5, delivery 2 (under 30), total 13.5
check("EDT-07", "edit below threshold adds small-order charge",
      inv2["total"], 13.5)

# ---------------- Settlement after edit (RFD) -------------------------
# RFD-08 nothing paid -> none
check("RFD-08", "edit with no payment -> no money flow",
      core.settlement_after_edit(50, 40, 0)["action"], "none")
# RFD-01 edit up while paid -> collect extra
s_up = core.settlement_after_edit(50, 70, 50)
check("RFD-01a", "edit up -> collect_extra action", s_up["action"], "collect_extra")
check("RFD-01b", "edit up -> extra amount", s_up["amount"], 20.0)
# RFD-03/09 edit down while paid -> refund exact
s_dn = core.settlement_after_edit(50, 35, 50)
check("RFD-03", "edit down -> refund action", s_dn["action"], "refund")
check("RFD-09", "refund amount exact", s_dn["amount"], 15.0)
# equal -> none
check("RFD-11", "edit net zero -> none",
      core.settlement_after_edit(50, 50, 50)["action"], "none")

# ---------------- Refund state machine (RFD-05/06/12) -----------------
check("RFD-05", "admin marks refund sent: pending->sent",
      core.refund_advance("pending"), "sent")
check("RFD-06", "customer confirms: sent->confirmed",
      core.refund_advance("sent"), "confirmed")
check("RFD-12a", "not settled while pending",
      core.refund_is_settled("pending"), False)
check("RFD-12b", "not settled while sent",
      core.refund_is_settled("sent"), False)
check("RFD-06b", "settled only when confirmed",
      core.refund_is_settled("confirmed"), True)

# ---------------- Permissions (ACC) -----------------------------------
check("ACC-01", "admin can access anything",
      core.can_access("admin", "", "finance"), True)
check("ACC-02", "team without perm cannot access finance",
      core.can_access("team", "orders,availability", "finance"), False)
check("ACC-03", "team with perm can access",
      core.can_access("team", "orders,finance", "finance"), True)
check("ACC-06", "default team sections exclude finance",
      "finance" in core.DEFAULT_TEAM_SECTIONS, False)
check("ACC-06b", "default team includes orders",
      "orders" in core.DEFAULT_TEAM_SECTIONS, True)
check("SET-08", "serialize permissions dedups & validates",
      core.serialize_permissions(["orders","orders","nonsense","finance"]),
      "orders,finance")
check("ACC-02b", "parse handles list form",
      core.can_access("team", ["reports"], "reports"), True)

# ---------------- Unpaid classification (RMD) -------------------------
check("RMD-01", "invoice_sent counts unpaid",
      core.is_unpaid("invoice_sent"), True)
check("RMD-08", "verified payment NOT unpaid",
      core.is_unpaid("payment_verified"), False)
check("RMD-08b", "received payment NOT unpaid",
      core.is_unpaid("payment_received"), False)

# ---------------- Rounding edge (INV-13) ------------------------------
check("INV-13", "rounding half-up to 2dp",
      core.money(2.005), 2.01)
check("INV-13b", "money handles None",
      core.money(None), 0.0)

# ---------------- Vendor top-up consumption (TOP) --------------------
check("TOP-01", "topup not consumed when no later orders",
      core.topup_consumption(10, 0)["topup_remaining"], 10.0)
check("TOP-02", "topup partly consumed by later orders",
      core.topup_consumption(10, 4)["topup_remaining"], 6.0)
check("TOP-03", "topup fully consumed -> 0 when exceeded",
      core.topup_consumption(10, 12)["topup_remaining"], 0.0)
check("TOP-04", "consumed capped at topup",
      core.topup_consumption(10, 12)["consumed"], 10.0)
check("TOP-05", "final = received + remaining topup",
      core.vendor_line_final(20, 10, 4)["final"], 26.0)
check("TOP-06", "final when topup exhausted = received",
      core.vendor_line_final(32, 10, 12)["final"], 32.0)
check("TOP-07", "final with untouched topup",
      core.vendor_line_final(16, 10, 0)["final"], 26.0)

# ----------------------------- summary --------------------------------
print("\n" + "="*60)
print(f"RESULTS: {len(PASS)} passed, {len(FAIL)} failed, {len(PASS)+len(FAIL)} total")
if FAIL:
    print("FAILURES:")
    for t in FAIL:
        print("  ", t)
print("="*60)

if __name__ == "__main__":
    import sys
    sys.exit(1 if FAIL else 0)
