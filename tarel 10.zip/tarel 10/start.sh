#!/bin/bash
# TAREL one-click launcher (Mac/Linux).
# Requires DATABASE_URL (Supabase) set in .env before running.
set -e
cd "$(dirname "$0")"

echo ""
echo "=========================================="
echo "   TAREL — Fish Delivery Admin System"
echo "=========================================="

if [ ! -f .env ]; then
  cp .env.example .env 2>/dev/null || true
  echo "  [!] Created .env — open it, set DATABASE_URL and SECRET_KEY, then run ./start.sh again."
  exit 0
fi

# pick python
PY=""
for c in python3 python3.12 python3.11 python3.10 python; do
  command -v $c >/dev/null 2>&1 && { PY=$c; break; }
done
[ -z "$PY" ] && { echo "Python not found. Install from python.org"; exit 1; }

# venv
if [ ! -d ".venv" ]; then
  echo "  [setup] creating virtual environment..."
  $PY -m venv .venv
fi
PY=".venv/bin/python"; PIP=".venv/bin/pip"

echo "  [1/3] installing packages (first run only)..."
$PIP install -r requirements.txt --quiet 2>/dev/null || $PIP install -r requirements.txt

echo "  [2/3] preparing database + sample login..."
$PY seed_data.py 2>/dev/null || echo "  (seed skipped — tables will auto-create)"

# port
PORT=5000
if command -v lsof >/dev/null 2>&1 && lsof -iTCP:5000 -sTCP:LISTEN >/dev/null 2>&1; then PORT=5001; fi
export PORT

# LAN IP for phone access
LAN_IP=$($PY - <<'PYEOF'
import socket
try:
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect(("8.8.8.8",80))
    print(s.getsockname()[0]); s.close()
except Exception:
    print("")
PYEOF
)

echo "  [3/3] starting..."
echo ""
echo "=========================================="
echo "   On this computer : http://localhost:${PORT}"
if [ -n "$LAN_IP" ]; then
echo "   On your PHONE    : http://${LAN_IP}:${PORT}"
echo "   (phone must be on the same Wi-Fi)"
fi
echo "   Login            : admin / tarel2026"
echo "   Stop             : Ctrl+C"
echo "=========================================="
echo ""

( sleep 2 && (open "http://localhost:${PORT}" 2>/dev/null || xdg-open "http://localhost:${PORT}" 2>/dev/null) ) &
exec $PY app.py
