# TAREL — Build Status & Setup

## ⚡ One-click run

## 🆕 Quick WhatsApp Order (paste → review → create → invoice)

A new page at **Orders → Quick Order** (`/orders/quick`) that does what you asked:

1. **Paste** the customer's WhatsApp message into one box and click **Read message**.
2. The app parses it and **matches each item to a real product** in your Fish Master,
   shows a confidence badge (Matched / Check this / Pick product), and tries to
   **match the customer** by phone or name (or pre-fills a new customer).
3. You **review and fix** anything (change product, qty, cut; pick customer) — nothing
   is saved until you approve.
4. Click **Create order → go to invoice**. The order is created and you land on the
   order page where **Generate Invoice** produces the PDF using your freight/delivery rules.

No WhatsApp API keys are needed for this — staff paste the message manually.
(The fully-automatic bot that replies to customers by itself is a later step that needs
Meta API keys.)

Tested by: `test_fish_match.py` (the name→product matcher) + the existing engine tests.

---

**1. Set your database first.** Create `.env` (copy `.env.example`) and put your Supabase URL in it:
```
DATABASE_URL=postgresql://...your-supabase-uri...
SECRET_KEY=some-long-random-string
```
**2. Run the migration** (see "Database migration" below) once in Supabase.

**3. Launch:**
- **Mac / Linux:** `chmod +x start.sh` then `./start.sh`
- **Windows:** double-click `start.bat`

It prints two URLs:
- **On this computer:** http://localhost:5000
- **On your phone:** http://<your-computer-ip>:5000  (phone must be on the **same Wi-Fi**)

Login: **admin / tarel2026**

> 📱 **Mobile:** the app serves to your whole Wi-Fi network, so just open the phone URL it
> prints. If your firewall blocks it, allow Python through, or use a free tunnel (ngrok).

---

## Database migration (run once)
Open the Supabase SQL editor and run **`migrations/003_new_features.sql`**.
It adds the `permissions` column to users, the freight/cost/vendor columns to fish_master,
and the new `drivers`, `refunds`, and `audit_log` tables. It is idempotent (safe to re-run).

---

This package contains the existing TAREL app **plus** the new features we agreed,
with a runnable test suite. Read this first — it tells you honestly what is
tested and verified, and what still needs your keys to test live.

---

## Decisions locked in
1. **Freight** — per-fish `freight_price` if set on the product, else the global rate.
2. **Page access** — per individual user (each user has a `permissions` list).
3. **Multi-driver** — orders split automatically by area/load, then each route optimized.

---

## What is built and VERIFIED here (57 automated tests passing, 0 failing)

Run it yourself:
```bash
python run_tests.py
```

- `core.py` — money/permission engine. **43 tests** (`test_core.py`):
  line totals (two-price rule), freight (per-fish-else-global), delivery charges,
  full invoice totals, edit→extra-charge/refund settlement, refund state machine,
  per-user permissions, unpaid classification, rounding.
- `services/wa_bot.py` — WhatsApp conversation brain (intent detection, order→confirm
  →invoice→payment flow, refund-receipt confirm, human handoff). Tested with sample
  messages.
- `services/routing.py` — driver auto-split by area/load + ORS payload building +
  graceful handling of unroutable addresses / missing key / rate limits. Tested with
  **mocked** ORS responses and sample geo-data.
- `models.py` — extended with: `User.permissions`, `FishMaster.freight_price/
  additional_cost/vendor_name`, and new `Driver`, `Refund`, `AuditLog` tables.

## What is built but needs YOUR keys to test LIVE (cannot run in a no-internet build)
These have correct code + logic tests, but the real end-to-end pass happens on your
machine with credentials:
- WhatsApp send/receive (needs Meta `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_ID`).
- Route optimization real distances (needs free `ORS_API_KEY`).
- Postgres/Supabase behaviour (this sandbox had no SQLAlchemy; the DB/model tests in
  `test_integration.py` run automatically once you `pip install -r requirements.txt`).

## Still to wire into app.py (the web routes/pages) — next slices
The engine + services exist and are tested. The remaining work is calling them from
Flask routes and adding the pages/templates:
- order edit/cancel screen, refund admin screen, unpaid+reminders page,
  drivers page, WhatsApp inbox, audit-log view, settings permission checkboxes,
  and the live webhook wiring that calls `services/wa_bot.handle_message`.

---

## Setup on your machine
```bash
pip install -r requirements.txt
cp .env.example .env        # then fill in values
```
`.env` keys:
```
DATABASE_URL=...            # Supabase Postgres (or set SQLite for local dev)
SECRET_KEY=some-long-random-string
WHATSAPP_TOKEN=             # Meta -> App -> WhatsApp -> API Setup
WHATSAPP_PHONE_ID=          # same page (Phone number ID)
WHATSAPP_VERIFY_TOKEN=tarel_verify
ORS_API_KEY=               # free at openrouteservice.org
ANTHROPIC_API_KEY=         # optional, only for AI parsing
```

## Apply the DB migration (existing databases)
Run `migrations/003_new_features.sql` against your DB
(or let `db.create_all()` create the new tables, then run just the ALTER lines for the
new columns on `users` and `fish_master`).

## Test plan
`TAREL_Test_Cases.xlsx` (separately provided) holds all 220 cases. The automated
suite here covers the offline-testable subset; the live/integration cases are run on
your machine per the notes above.
