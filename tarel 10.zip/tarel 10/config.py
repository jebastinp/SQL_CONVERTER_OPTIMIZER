import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).resolve().parent / '.env', override=False)

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', '')
    if not SECRET_KEY:
        if os.environ.get('FLASK_ENV') == 'production' or os.environ.get('TAREL_ENV') == 'production':
            raise RuntimeError('SECRET_KEY must be set in production. Generate one with: python -c "import secrets; print(secrets.token_hex(32))"')
        # dev fallback only
        SECRET_KEY = 'tarel-dev-secret-change-me'
    DATABASE_URL = os.environ.get('DATABASE_URL', '').strip()
    if not DATABASE_URL or 'YOUR-PROJECT-REF' in DATABASE_URL:
        raise RuntimeError('DATABASE_URL must be set to a valid Supabase PostgreSQL URI.')
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY', '')
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')
    ORS_API_KEY = os.environ.get('ORS_API_KEY', '')
    WHATSAPP_TOKEN = os.environ.get('WHATSAPP_TOKEN', '')
    WHATSAPP_PHONE_ID = os.environ.get('WHATSAPP_PHONE_ID', '')
    WHATSAPP_VERIFY_TOKEN = os.environ.get('WHATSAPP_VERIFY_TOKEN', 'tarel_verify')
    PERMANENT_SESSION_LIFETIME = 28800  # 8 hours
    # For local HTTP (incl. phones on your WiFi) cookies must NOT require HTTPS.
    # Set SESSION_COOKIE_SECURE=true only when you deploy behind HTTPS.
    SESSION_COOKIE_SAMESITE = os.environ.get('SESSION_COOKIE_SAMESITE', 'Lax')
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True

    FREIGHT_RATE = 1.50
    SMALL_ORDER_THRESHOLD = 30.00
    SMALL_ORDER_CHARGE = 2.00
    INVERNESS_CHARGE = 13.00


    AREA_CODES = {
        'Edinburgh': 'ED', 'Glasgow': 'GL', 'Livingston': 'LI',
        'Bathgate': 'BA', 'East Calder': 'EC', 'Broxburn': 'BR',
        'Inverness': 'IN', 'Winchburgh': 'WI', 'Ayr': 'AY',
    }

