@echo off
title TAREL Admin System
color 0B
cd /d "%~dp0"
echo.
echo  ==========================================
echo    TAREL - Fish Delivery Admin System
echo  ==========================================
echo.

REM Requires DATABASE_URL (Supabase) set in .env before running.
if not exist .env (
  copy .env.example .env >nul 2>&1
  echo   [!] Created .env - open it, set DATABASE_URL and SECRET_KEY, then run start.bat again.
  notepad .env
  pause
  exit /b
)

REM pick python
set PY=python
where python >nul 2>&1 || set PY=python3

REM venv
if not exist ".venv" (
  echo   [setup] creating virtual environment...
  %PY% -m venv .venv
)
set PY=.venv\Scripts\python.exe
set PIP=.venv\Scripts\pip.exe

echo   [1/3] installing packages (first run only)...
%PIP% install -r requirements.txt --quiet

echo   [2/3] preparing database + sample login...
%PY% seed_data.py

REM find LAN IP for phone access
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do set LAN_IP=%%a
set LAN_IP=%LAN_IP: =%

set PORT=5000
echo   [3/3] starting...
echo.
echo  ==========================================
echo    On this computer : http://localhost:%PORT%
echo    On your PHONE    : http://%LAN_IP%:%PORT%
echo    (phone must be on the same Wi-Fi)
echo    Login            : admin / tarel2026
echo    Stop             : Ctrl+C
echo  ==========================================
echo.
start http://localhost:%PORT%
%PY% app.py
pause
