"""Tests for services/fish_match.py — the parsed-name → product resolver."""
from services.fish_match import match_fish, resolve_items

class F:
    def __init__(self, id, name, en=None, ta=None, ml=None):
        self.id=id; self.fish_name=name; self.english_name=en
        self.tamil_name=ta; self.malayalam_name=ml

ROWS = [
    F(1,"(1kg) King Fish (Slice)"),
    F(2,"(1kg) White Prawn"),
    F(3,"(1kg) Indian Mackerel (Ayila)", ta="Ayila"),
    F(4,"(1kg) Goat Meat With Bone"),
    F(5,"(1kg) Sardine (Mathi)", ml="Mathi"),
]

PASS=[]; FAIL=[]
def check(tid,desc,got,exp):
    ok=got==exp; (PASS if ok else FAIL).append(tid)
    print(f"[{'PASS' if ok else 'FAIL'}] {tid}: {desc}"+("" if ok else f" got={got} exp={exp}"))

def mid(name):
    f,_=match_fish(name,ROWS); return f.id if f else None
def mconf(name):
    _,c=match_fish(name,ROWS); return c

# exact + alias matches
check("FM-01","exact full name", mid("(1kg) King Fish (Slice)"), 1)
check("FM-02","loose 'king fish'", mid("king fish"), 1)
check("FM-03","'prawn' -> white prawn", mid("prawn"), 2)
check("FM-04","tamil name 'ayila'", mid("ayila"), 3)
check("FM-05","malayalam 'mathi'", mid("mathi"), 5)
check("FM-06","'goat with bone'", mid("goat with bone"), 4)
# must NOT false-match on generic words
check("FM-07","'unicorn fish' -> no match", mid("unicorn fish"), None)
check("FM-08","'just fish' -> no match", mid("just fish"), None)
check("FM-09","'meat' alone -> no match", mid("meat"), None)
# confidence levels
check("FM-10","unknown is 'none' confidence", mconf("xyzzy"), "none")

# resolve_items keeps unmatched as fish_id None
items=[{"fish_name":"king fish","quantity_kg":2,"cut_instructions":"Steak"},
       {"fish_name":"unicorn","quantity_kg":1}]
res=resolve_items(items, ROWS)
check("FM-11","resolve matched id", res[0]["fish_id"], 1)
check("FM-12","resolve keeps qty", res[0]["quantity_kg"], 2.0)
check("FM-13","resolve unmatched -> None", res[1]["fish_id"], None)

print("\n"+"="*50)
print(f"FISH MATCH: {len(PASS)} passed, {len(FAIL)} failed")
print("="*50)
import sys; sys.exit(1 if FAIL else 0)
