-- =====================================================================
-- TAREL — RESET: drop all TAREL tables so the full schema can be created clean.
-- ⚠️  DESTRUCTIVE: deletes ALL data in these tables. Only use on a dev/empty
--     database or when you intend to rebuild from scratch.
-- Run this FIRST, then run 000_full_schema.sql.
-- CASCADE removes dependent foreign keys automatically, so order doesn't matter.
-- =====================================================================
DROP TABLE IF EXISTS audit_log          CASCADE;
DROP TABLE IF EXISTS refunds            CASCADE;
DROP TABLE IF EXISTS whatsapp_messages  CASCADE;
DROP TABLE IF EXISTS vendor_reports     CASCADE;
DROP TABLE IF EXISTS income             CASCADE;
DROP TABLE IF EXISTS expenses           CASCADE;
DROP TABLE IF EXISTS payments           CASCADE;
DROP TABLE IF EXISTS order_items        CASCADE;
DROP TABLE IF EXISTS invoices           CASCADE;
DROP TABLE IF EXISTS orders             CASCADE;
DROP TABLE IF EXISTS drivers            CASCADE;
DROP TABLE IF EXISTS settings           CASCADE;
DROP TABLE IF EXISTS delivery_weeks     CASCADE;
DROP TABLE IF EXISTS fish_master        CASCADE;
DROP TABLE IF EXISTS customers          CASCADE;
DROP TABLE IF EXISTS users              CASCADE;
-- Now run 000_full_schema.sql
