-- Migration: add bank_reference to payments and half/one kg prices to fish_master
-- Run this on your Postgres DB (psql) or integrate into Alembic migrations.

ALTER TABLE payments ADD COLUMN IF NOT EXISTS bank_reference VARCHAR(100);
ALTER TABLE fish_master ADD COLUMN IF NOT EXISTS half_kg_price NUMERIC(10,2);
ALTER TABLE fish_master ADD COLUMN IF NOT EXISTS one_kg_price NUMERIC(10,2);

-- Optionally set default values for existing rows (uncomment and adjust if needed):
-- UPDATE fish_master SET half_kg_price = selling_price/2 WHERE half_kg_price IS NULL AND selling_price IS NOT NULL;

-- Commit is automatic in psql; for other DB tooling ensure the migration is applied within a transaction.
