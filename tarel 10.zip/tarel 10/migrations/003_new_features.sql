-- =====================================================================
-- TAREL migration 003 — all new-feature schema changes (Supabase/Postgres)
-- Run ONCE in the Supabase SQL editor. Safe to re-run (idempotent).
-- =====================================================================

-- 1) Per-user page permissions (comma-separated list of allowed sections)
ALTER TABLE users        ADD COLUMN IF NOT EXISTS permissions TEXT DEFAULT '';

-- 2) Fish Master: per-product freight, additional cost, vendor name
ALTER TABLE fish_master  ADD COLUMN IF NOT EXISTS freight_price   NUMERIC(10,2);
ALTER TABLE fish_master  ADD COLUMN IF NOT EXISTS additional_cost NUMERIC(10,2);
ALTER TABLE fish_master  ADD COLUMN IF NOT EXISTS vendor_name     VARCHAR(150);

-- 3) Drivers
CREATE TABLE IF NOT EXISTS drivers (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    phone           VARCHAR(30),
    vehicle_number  VARCHAR(30),
    start_location  VARCHAR(250),
    end_location    VARCHAR(250),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4) Refunds (mirror of payments, for money going back to customers)
CREATE TABLE IF NOT EXISTS refunds (
    id                    SERIAL PRIMARY KEY,
    order_id              INTEGER REFERENCES orders(id),
    customer_id           INTEGER REFERENCES customers(id),
    amount                NUMERIC(10,2),
    reason                VARCHAR(250),
    bank_details          TEXT,
    status                VARCHAR(20) DEFAULT 'pending',   -- pending -> sent -> confirmed
    approved_by           INTEGER REFERENCES users(id),
    sent_by               INTEGER REFERENCES users(id),
    sent_at               TIMESTAMP,
    customer_confirmed_at TIMESTAMP,
    created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5) Audit log (who did what)
CREATE TABLE IF NOT EXISTS audit_log (
    id          SERIAL PRIMARY KEY,
    user_id     INTEGER REFERENCES users(id),
    username    VARCHAR(50),
    action      VARCHAR(100),
    entity      VARCHAR(50),
    entity_id   VARCHAR(30),
    detail      TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6) Give existing admin users full access by leaving permissions blank
--    (code treats role='admin' as all-access regardless of this column).
--    Optionally grant a default set to existing non-admin users:
UPDATE users
   SET permissions = 'orders,availability,customers'
 WHERE role <> 'admin'
   AND (permissions IS NULL OR permissions = '');

-- Helpful indexes
CREATE INDEX IF NOT EXISTS idx_refunds_order   ON refunds(order_id);
CREATE INDEX IF NOT EXISTS idx_refunds_status  ON refunds(status);
CREATE INDEX IF NOT EXISTS idx_audit_created   ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_entity    ON audit_log(entity, entity_id);

-- Done.
