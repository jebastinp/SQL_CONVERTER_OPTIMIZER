-- =====================================================================
-- TAREL — FULL SCHEMA (from scratch) for Supabase / PostgreSQL
-- Run ONCE in the Supabase SQL editor on a fresh/empty database.
-- Creates every table (base + new features) in dependency order.
-- Idempotent: safe to re-run (uses IF NOT EXISTS).
-- =====================================================================

-- ---------- Parent tables (no FKs) ----------
CREATE TABLE IF NOT EXISTS users (
    id            SERIAL PRIMARY KEY,
    name          VARCHAR(100),
    username      VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(20) DEFAULT 'team',
    permissions   TEXT DEFAULT '',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS customers (
    id          SERIAL PRIMARY KEY,
    customer_id VARCHAR(20) UNIQUE,
    name        VARCHAR(150) NOT NULL,
    phone       VARCHAR(30),
    address     TEXT,
    area        VARCHAR(100),
    postcode    VARCHAR(15),
    notes       TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fish_master (
    id                SERIAL PRIMARY KEY,
    fish_name         VARCHAR(200) NOT NULL,
    english_name      VARCHAR(150),
    tamil_name        VARCHAR(150),
    malayalam_name    VARCHAR(150),
    size              VARCHAR(10),
    avra_impex_price  NUMERIC(10,2),
    global_food_price NUMERIC(10,2),
    half_kg_price     NUMERIC(10,2),
    one_kg_price      NUMERIC(10,2),
    selling_price     NUMERIC(10,2),
    freight_price     NUMERIC(10,2),
    additional_cost   NUMERIC(10,2),
    vendor_name       VARCHAR(150),
    cut_type          VARCHAR(100),
    is_fish           BOOLEAN DEFAULT TRUE,
    is_active         BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS delivery_weeks (
    id            SERIAL PRIMARY KEY,
    week_start    DATE,
    week_end      DATE,
    delivery_date DATE,
    status        VARCHAR(20) DEFAULT 'open',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
    id         SERIAL PRIMARY KEY,
    key        VARCHAR(100) UNIQUE,
    value      TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS drivers (
    id             SERIAL PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    phone          VARCHAR(30),
    vehicle_number VARCHAR(30),
    start_location VARCHAR(250),
    end_location   VARCHAR(250),
    is_active      BOOLEAN DEFAULT TRUE,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Child tables (with FKs) ----------
CREATE TABLE IF NOT EXISTS orders (
    id                   SERIAL PRIMARY KEY,
    customer_id          INTEGER NOT NULL REFERENCES customers(id),
    delivery_week_id     INTEGER REFERENCES delivery_weeks(id),
    payment_reference    VARCHAR(30),
    order_date           DATE,
    delivery_date        DATE,
    driver               VARCHAR(50),
    route                VARCHAR(50),
    delivery_stop_number INTEGER,
    status               VARCHAR(30) DEFAULT 'received',
    delivery_instructions TEXT,
    order_platform       VARCHAR(50) DEFAULT 'WhatsApp',
    raw_whatsapp_text    TEXT,
    created_by           INTEGER REFERENCES users(id),
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS invoices (
    id              SERIAL PRIMARY KEY,
    order_id        INTEGER REFERENCES orders(id),
    invoice_number  VARCHAR(30),
    subtotal        NUMERIC(10,2),
    freight_surcharge NUMERIC(10,2),
    delivery_charge NUMERIC(10,2),
    total           NUMERIC(10,2),
    pdf_path        VARCHAR(500),
    generated_at    TIMESTAMP,
    sent_at         TIMESTAMP,
    sent_by         INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id                    SERIAL PRIMARY KEY,
    order_id              INTEGER NOT NULL REFERENCES orders(id),
    fish_master_id        INTEGER REFERENCES fish_master(id),
    fish_name             VARCHAR(200),
    quantity_kg           NUMERIC(10,3),
    unit_price            NUMERIC(10,2),
    line_total            NUMERIC(10,2),
    cut_instructions      TEXT,
    availability_status   VARCHAR(20) DEFAULT 'pending',
    availability_checked_by INTEGER REFERENCES users(id),
    availability_checked_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payments (
    id                   SERIAL PRIMARY KEY,
    order_id             INTEGER REFERENCES orders(id),
    invoice_id           INTEGER REFERENCES invoices(id),
    amount               NUMERIC(10,2),
    payment_mode         VARCHAR(50),
    payment_name         VARCHAR(150),
    bank_reference       VARCHAR(100),
    payment_received_date DATE,
    payment_verified_by  INTEGER REFERENCES users(id),
    payment_verified_at  TIMESTAMP,
    status               VARCHAR(20) DEFAULT 'pending',
    screenshot_path      TEXT
);

CREATE TABLE IF NOT EXISTS expenses (
    id               SERIAL PRIMARY KEY,
    expense_date     DATE,
    description      VARCHAR(200),
    category         VARCHAR(100),
    amount           NUMERIC(10,2),
    payment_status   VARCHAR(20) DEFAULT 'paid',
    delivery_week_id INTEGER REFERENCES delivery_weeks(id),
    created_by       INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS income (
    id               SERIAL PRIMARY KEY,
    income_date      DATE,
    description      VARCHAR(200),
    amount           NUMERIC(10,2),
    fish_profit      NUMERIC(10,2),
    delivery_week_id INTEGER REFERENCES delivery_weeks(id)
);

CREATE TABLE IF NOT EXISTS vendor_reports (
    id               SERIAL PRIMARY KEY,
    delivery_week_id INTEGER REFERENCES delivery_weeks(id),
    generated_at     TIMESTAMP,
    generated_by     INTEGER REFERENCES users(id),
    sent_at          TIMESTAMP,
    report_data      JSON
);

CREATE TABLE IF NOT EXISTS whatsapp_messages (
    id          SERIAL PRIMARY KEY,
    direction   VARCHAR(10),
    phone       VARCHAR(30),
    message     TEXT,
    status      VARCHAR(20) DEFAULT 'received',
    customer_id INTEGER REFERENCES customers(id),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_read     BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS refunds (
    id                    SERIAL PRIMARY KEY,
    order_id              INTEGER REFERENCES orders(id),
    customer_id           INTEGER REFERENCES customers(id),
    amount                NUMERIC(10,2),
    reason                VARCHAR(250),
    bank_details          TEXT,
    status                VARCHAR(20) DEFAULT 'pending',
    approved_by           INTEGER REFERENCES users(id),
    sent_by               INTEGER REFERENCES users(id),
    sent_at               TIMESTAMP,
    customer_confirmed_at TIMESTAMP,
    created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_log (
    id         SERIAL PRIMARY KEY,
    user_id    INTEGER REFERENCES users(id),
    username   VARCHAR(50),
    action     VARCHAR(100),
    entity     VARCHAR(50),
    entity_id  VARCHAR(30),
    detail     TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Helpful indexes ----------
CREATE INDEX IF NOT EXISTS idx_orders_customer   ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_week        ON orders(delivery_week_id);
CREATE INDEX IF NOT EXISTS idx_orders_status      ON orders(status);
CREATE INDEX IF NOT EXISTS idx_items_order        ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_order     ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_refunds_order      ON refunds(order_id);
CREATE INDEX IF NOT EXISTS idx_refunds_status     ON refunds(status);
CREATE INDEX IF NOT EXISTS idx_audit_created      ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_wamsg_customer     ON whatsapp_messages(customer_id);

-- ---------- Admin login ----------
-- NOTE: passwords are bcrypt-hashed by the app, so we do NOT insert a user here
-- (a hand-written hash can't be verified safely). Create the admin login by running
-- ONE of these on your machine after the schema exists:
--
--   Option 1 (recommended):  python seed_data.py
--      -> creates admin/tarel2026, martin/martin2026, danny/danny2026 + sample fish
--
--   Option 2 (manual hash):  generate a bcrypt hash and insert it, e.g.
--      python -c "import bcrypt; print(bcrypt.hashpw(b'YOURPASSWORD', bcrypt.gensalt()).decode())"
--      then:
--      INSERT INTO users (name, username, password_hash, role, permissions)
--      VALUES ('Admin','admin','<paste-hash-here>','admin','');

-- Done. All tables created.
