-- Migration: drop avra_impex_price and global_food_price from fish_master
-- WARNING: this will permanently remove data in these columns. Ensure you have backups if needed.

BEGIN;

ALTER TABLE fish_master DROP COLUMN IF EXISTS avra_impex_price;
ALTER TABLE fish_master DROP COLUMN IF EXISTS global_food_price;

COMMIT;
