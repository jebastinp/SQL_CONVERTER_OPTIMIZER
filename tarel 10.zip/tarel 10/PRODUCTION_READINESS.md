# TAREL — Production Readiness Report

Date of analysis: pre-launch review of the full codebase (app.py, models, services, config, templates).
Scope: static analysis + offline logic tests. **Live browser/DB testing must be done by you** (see Part D) — this sandbox has no internet, so I could not boot against Supabase or click through pages in a browser.

---

## A. Summary verdict

**Not yet ready to launch to real customers, but close for an internal/soft launch** once Part D (your live checklist) passes. The core money logic is sound and tested; I found and **fixed 6 real issues** during this review. The main remaining gaps are (1) your own live testing, (2) CSRF protection, and (3) the new feature *pages* that aren't built yet (refunds, drivers, etc.).

**Automated tests:** 70 passing (43 core + 14 integration + 13 fish-match), 0 failing.

---

## B. Issues found and FIXED in this review

1. **🔴 CRITICAL — Payment verification had no admin check.** Any logged-in staff
   could verify payments, violating your "admin alone verifies" rule and risking
   money integrity. **Fixed:** now returns 403 for non-admins.

2. **🟠 Expense deletion had no admin check.** Any user could delete finance records.
   **Fixed:** admin-only now.

3. **🔴 `.env` was included in the package.** Secret-leak risk. **Fixed:** removed from
   the zip and added a `.gitignore` that excludes it permanently. → **Action for you:**
   if your `.env` ever held real values that were shared, rotate them (DB password,
   WhatsApp token).

4. **🟠 `SECRET_KEY` had a weak hardcoded default.** Forgeable sessions if run in prod
   without setting it. **Fixed:** now raises an error in production if unset (dev still
   has a fallback). → **Action for you:** set a strong `SECRET_KEY` in `.env`
   (`python -c "import secrets; print(secrets.token_hex(32))"`).

5. **🟠 Payment amount not validated.** Null/negative/garbage amounts could be saved.
   **Fixed:** amount must be present and > 0; date must be valid.

6. **🟠 No error pages.** 404/500 would show stack traces. **Fixed:** added friendly
   403/404/500 handlers + `error.html`; 500 also rolls back the DB session.

---

## C. Known gaps / decisions for you (NOT yet fixed)

1. **CSRF protection is not enabled.** Forms have no CSRF tokens. For an internal tool
   on a trusted network this is lower risk, but for public/prod you should add
   Flask-WTF CSRFProtect. *Recommended before public launch.* (Medium effort — needs a
   token in every form.)

2. **New feature pages not built yet.** The tested *logic* exists, but these have no UI:
   order edit/cancel, refunds, unpaid-reminders page, drivers/route page, WhatsApp inbox,
   audit-log view, per-user permission checkboxes. Quick WhatsApp Order **is** built.

3. **`/vendor-report/mark-sent` is login-only, not admin-only.** Decide if staff should
   be able to mark a report sent, or restrict to admin.

4. **Per-user permissions enforced in logic (core.py) but not yet wired to every route.**
   Currently role-based (`admin` vs others) is enforced; the granular per-page
   permissions need decorators added to routes when you build the permissions UI.

5. **WhatsApp & ORS live calls untested** — need your keys; see Part D.

6. **Rate limiting / brute-force protection on login** — none. Consider adding for public
   exposure (e.g. Flask-Limiter).

7. **Backups** — rely on Supabase's backup policy; confirm it's enabled.

---

## D. YOUR live launch checklist (must be done on your machine)

These are the things I cannot verify from here. Do them in order.

### Setup
- [ ] Set `DATABASE_URL`, a strong `SECRET_KEY`, and `TAREL_ENV=production` in `.env`
- [ ] Run `000_reset_and_create.sql` in Supabase (fresh DB) — confirm 16 tables created
- [ ] Run `python seed_data.py` — confirm admin login created
- [ ] `pip install -r requirements.txt` then launch; confirm it starts with no errors

### Smoke-test every page loads (login as admin)
- [ ] Dashboard, Orders list, Quick Order, Customers, Availability, Reports, Finance, Settings, Fish Prices all open without error
- [ ] Each opens on your **phone** via the printed LAN URL

### Core flows (end to end)
- [ ] Create a delivery week
- [ ] Add a few products in Fish Prices (incl. one with a per-fish freight price)
- [ ] **Quick Order:** paste a WhatsApp message → items match → create order → generate invoice (PDF downloads/opens) → totals look right (subtotal + freight + delivery)
- [ ] Record a payment → **verify as admin** → confirm a non-admin user gets 403 on verify
- [ ] Availability: mark items available/not
- [ ] Vendor report: generate, confirm, download fish + meat PDF/CSV
- [ ] Finance: add expense/income, export CSV
- [ ] Customers: add, edit, CSV import/export

### Permissions
- [ ] Create a non-admin user; confirm they CANNOT verify payments, delete orders, delete expenses, or open Settings (should 403)

### Integrations (if using)
- [ ] WhatsApp: webhook verify handshake succeeds; a test message logs to DB; ack sends
- [ ] ORS: route optimization returns stops for a test set of orders

### Error handling
- [ ] Visit a bad URL → friendly 404 (no stack trace)
- [ ] Confirm `debug=False` in production (it is, in app.py)

---

## E. What's solid (verified here)

- Money math: line totals, per-fish-else-global freight, delivery charges, invoice totals,
  refund/extra-charge settlement, refund state machine — **43 tests passing**.
- WhatsApp bot decision logic + driver auto-split + fish matcher — **27 tests passing**.
- App boots, all 61 routes register, new Quick Order page renders, no import/registration errors.
- Admin checks now present on: order/customer/payment/expense/user delete, payment verify,
  settings (rules/bank/user/week), vendor topup confirm.
- Passwords bcrypt-hashed; debug off; cookies HTTP-safe for LAN, switchable to Secure for HTTPS.

---

## F. Recommended pre-public-launch priorities (in order)
1. Run Part D and fix anything that fails live.
2. Add CSRF protection (Flask-WTF).
3. Add login rate-limiting (Flask-Limiter).
4. Build the remaining feature pages as needed.
5. Put it behind HTTPS and set `SESSION_COOKIE_SECURE=true`.
