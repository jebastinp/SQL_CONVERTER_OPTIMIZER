#!/bin/bash
echo ""
echo "=========================================="
echo "  TAREL Fish Delivery — Admin System"
echo "=========================================="
echo ""

if [ ! -f .env ]; then
    cp .env.example .env
    echo "  [!] .env created. Open it and fill in your DATABASE_URL and SECRET_KEY, then run ./run.sh again."
    open .env 2>/dev/null || nano .env 2>/dev/null || echo "  -> Please open .env in a text editor"
    exit 0
fi

# Detect python
PY=""
for cmd in python3 python3.11 python3.10 python3.9 python; do
    if command -v $cmd &>/dev/null; then
        PY=$cmd
        break
    fi
done
if [ -z "$PY" ]; then echo "Python not found. Install from python.org"; exit 1; fi

# Make Homebrew native libraries visible to WeasyPrint/Pango/GObject.
export LDFLAGS="${LDFLAGS:-}-L/opt/homebrew/lib"
export CPPFLAGS="${CPPFLAGS:-}-I/opt/homebrew/include"
export PKG_CONFIG_PATH="/opt/homebrew/lib/pkgconfig:/opt/homebrew/share/pkgconfig:${PKG_CONFIG_PATH:-}"
export DYLD_LIBRARY_PATH="/opt/homebrew/lib:${DYLD_LIBRARY_PATH:-}"

PIP=""
for cmd in pip3 pip; do
    if command -v $cmd &>/dev/null; then
        PIP=$cmd
        break
    fi
done

# Prefer project venv if present or create it automatically
VENV_DIR=".venv"
VENV_PY="$VENV_DIR/bin/python"
VENV_PIP="$VENV_DIR/bin/pip"
if [ ! -d "$VENV_DIR" ]; then
    echo "  [!] Creating virtual environment at $VENV_DIR"
    $PY -m venv $VENV_DIR
fi
if [ -x "$VENV_PY" ]; then
    PY="$VENV_PY"
fi
if [ -x "$VENV_PIP" ]; then
    PIP="$VENV_PIP"
fi

PORT=5000
if lsof -iTCP:5000 -sTCP:LISTEN >/dev/null 2>&1; then
    PORT=5001
fi
export PORT

LAN_IP=""
for iface in en0 en1 en2; do
    LAN_IP=$($PY -c "import subprocess,sys; iface=sys.argv[1]; result=subprocess.run(['ipconfig','getifaddr',iface], capture_output=True, text=True, check=False); print(result.stdout.strip()) if result.stdout.strip() else None" "$iface")
    if [ -n "$LAN_IP" ]; then
        break
    fi
done

echo "  [1/3] Installing packages..."
$PIP install -r requirements.txt --quiet 2>/dev/null || \
$PIP install -r requirements.txt --user --quiet 2>/dev/null || \
$PY -m pip install -r requirements.txt --user --quiet

echo "  [2/3] Setting up database..."
$PY seed_data.py

echo "  [3/3] Starting TAREL..."
echo ""
echo "=========================================="
echo "  Open: http://localhost:${PORT}"
if [ -n "$LAN_IP" ]; then
    echo "  Phone/iPad: http://${LAN_IP}:${PORT}"
else
    echo "  Phone/iPad: use your Mac's local IP address on the same Wi-Fi"
fi
echo "  Login: admin / tarel2026"
echo "  Stop: Ctrl+C"
echo "=========================================="
echo ""

# Open browser after 1.5 seconds
(sleep 1.5 && open http://localhost:${PORT} 2>/dev/null || xdg-open http://localhost:${PORT} 2>/dev/null) &

$PY app.py
