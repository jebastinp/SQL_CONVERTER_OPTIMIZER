@echo off
title TAREL Admin System
color 0B
echo.
echo  ==========================================
echo   TAREL Fish Delivery — Admin System
echo  ==========================================
echo.

REM Check if .env exists
if not exist .env (
    echo  [!] First time setup detected...
    echo.
    copy .env.example .env
    echo  [!] .env file created.
    echo  [!] Please open .env in Notepad and fill in:
    echo      - DATABASE_URL  (from Supabase)
    echo      - SECRET_KEY    (any random string)
    echo.
    notepad .env
    echo.
    echo  Press any key after saving .env to continue...
    pause >nul
)

REM Install dependencies
echo  [1/3] Installing Python packages...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo  [!] pip failed. Trying pip3...
    pip3 install -r requirements.txt --quiet
)

REM Setup database
echo  [2/3] Setting up database...
python seed_data.py
if errorlevel 1 (
    python3 seed_data.py
)

REM Start app
echo  [3/3] Starting TAREL...
echo.
echo  ==========================================
echo   App running at: http://localhost:5000
echo   Login: admin / tarel2026
echo   Press Ctrl+C to stop
echo  ==========================================
echo.
start http://localhost:5000
python app.py
if errorlevel 1 (
    python3 app.py
)
pause
