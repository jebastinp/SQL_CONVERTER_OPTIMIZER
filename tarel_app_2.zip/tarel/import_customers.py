"""
Import customers from a CSV file.
CSV format: name,phone,address,area,postcode,notes
Run: python import_customers.py customers.csv
"""
import sys
import csv
from datetime import datetime
from app import create_app
from models import db, Customer

AREA_CODES = {
    'Edinburgh': 'ED', 'Glasgow': 'GL', 'Livingston': 'LI',
    'Bathgate': 'BA', 'East Calder': 'EC', 'Broxburn': 'BR',
    'Inverness': 'IN', 'Winchburgh': 'WI', 'Ayr': 'AY',
}

def generate_customer_id(area, year, count):
    code = AREA_CODES.get(area, 'XX')
    return f"{code}{year}{count:03d}"

def import_csv(filepath):
    app = create_app()
    with app.app_context():
        year = datetime.now().strftime('%y')
        area_counters = {}
        count = 0
        with open(filepath, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                name = row.get('name', '').strip()
                if not name:
                    continue
                area = row.get('area', 'Edinburgh').strip()
                area_counters[area] = area_counters.get(area, 0) + 1
                # Check if already exists
                if Customer.query.filter_by(name=name, phone=row.get('phone','').strip()).first():
                    continue
                cid = generate_customer_id(area, year, area_counters[area])
                customer = Customer(
                    customer_id=cid,
                    name=name,
                    phone=row.get('phone', '').strip(),
                    address=row.get('address', '').strip(),
                    area=area,
                    postcode=row.get('postcode', '').strip(),
                    notes=row.get('notes', '').strip(),
                )
                db.session.add(customer)
                count += 1
        db.session.commit()
        print(f"✅ Imported {count} customers")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python import_customers.py customers.csv")
        sys.exit(1)
    import_csv(sys.argv[1])
