import os
from datetime import datetime
from flask import current_app, render_template_string

INVOICE_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { font-family: Arial, sans-serif; font-size: 12px; margin: 0; padding: 20px; color: #1a2744; }
  .header { text-align: center; border-bottom: 3px solid #f0a500; padding-bottom: 15px; margin-bottom: 20px; }
  .header h1 { font-size: 28px; color: #1a2744; margin: 0; letter-spacing: 4px; }
  .header h2 { font-size: 16px; color: #f0a500; margin: 5px 0 0; }
  .stop-header { background: #1a2744; color: white; padding: 10px 15px; font-size: 16px; font-weight: bold; margin-bottom: 15px; }
  .section { margin-bottom: 15px; }
  .section-title { font-weight: bold; color: #1a2744; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-bottom: 8px; text-transform: uppercase; font-size: 11px; letter-spacing: 1px; }
  .detail-row { display: flex; margin-bottom: 4px; }
  .detail-label { width: 120px; font-weight: bold; color: #555; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  th { background: #1a2744; color: white; padding: 8px; text-align: left; font-size: 11px; }
  td { padding: 7px 8px; border-bottom: 1px solid #eee; }
  .total-row { background: #f0a500; font-weight: bold; font-size: 14px; }
  .total-row td { padding: 10px 8px; }
  .bank { background: #f8f9fa; padding: 12px; border-left: 4px solid #f0a500; }
  .bank .bank-title { font-weight: bold; margin-bottom: 8px; color: #1a2744; }
  .text-right { text-align: right; }
  .footer { margin-top: 20px; text-align: center; color: #888; font-size: 10px; border-top: 1px solid #eee; padding-top: 10px; }
</style>
</head>
<body>
<div class="header">
  <h1>TAREL</h1>
  <h2>{{ delivery_date }} DELIVERY INVOICE</h2>
</div>

<div class="stop-header">STOP {{ stop_number }} — {{ customer_name }}</div>

<div class="section">
  <div class="section-title">Customer Details</div>
  <div class="detail-row"><span class="detail-label">Name:</span> {{ customer_name }}</div>
  <div class="detail-row"><span class="detail-label">Payment Ref:</span> {{ payment_reference }}</div>
  <div class="detail-row"><span class="detail-label">Phone:</span> {{ phone }}</div>
  <div class="detail-row"><span class="detail-label">Address:</span> {{ address }}</div>
</div>

<div class="section">
  <div class="section-title">Order Details</div>
  <table>
    <thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th class="text-right">Total</th></tr></thead>
    <tbody>
      {% for item in items %}
      <tr>
        <td>{{ item.fish_name }}{% if item.cut_instructions %}<br><small style="color:#888">{{ item.cut_instructions }}</small>{% endif %}</td>
        <td>{{ item.quantity_kg }}kg</td>
        <td>£{{ "%.2f"|format(item.unit_price) }}</td>
        <td class="text-right">£{{ "%.2f"|format(item.line_total) }}</td>
      </tr>
      {% endfor %}
      {% if freight_surcharge > 0 %}
      <tr>
        <td>Freight Surcharge (£1.50/kg)</td>
        <td>{{ fish_kg }}kg</td>
        <td>£1.50</td>
        <td class="text-right">£{{ "%.2f"|format(freight_surcharge) }}</td>
      </tr>
      {% endif %}
      {% if delivery_charge > 0 %}
      <tr>
        <td>Delivery Charge</td>
        <td>1</td>
        <td>£{{ "%.2f"|format(delivery_charge) }}</td>
        <td class="text-right">£{{ "%.2f"|format(delivery_charge) }}</td>
      </tr>
      {% endif %}
      <tr class="total-row">
        <td colspan="3"><strong>TOTAL</strong></td>
        <td class="text-right"><strong>£{{ "%.2f"|format(total) }}</strong></td>
      </tr>
    </tbody>
  </table>
</div>

<div class="bank">
  <div class="bank-title">Bank Transfer Details</div>
  <div>Name: <strong>Daniel Maria Lazar</strong></div>
  <div>Sort Code: <strong>80-48-88</strong></div>
  <div>Account: <strong>13616562</strong></div>
  <div>Reference: <strong>{{ payment_reference }}</strong></div>
</div>

<div class="footer">TAREL Fish & Meat Delivery | Thank you for your order!</div>
</body>
</html>
"""

def generate_invoice_pdf(order, invoice):
    """Generate a PDF invoice for an order."""
    try:
        from weasyprint import HTML
    except ImportError:
        return None, "WeasyPrint not installed"

    customer = order.customer
    items = order.items
    
    fish_kg = sum(float(i.quantity_kg) for i in items if i.fish and i.fish.is_fish)
    
    html_content = render_template_string(INVOICE_HTML,
        delivery_date=order.delivery_date.strftime('%d %B %Y') if order.delivery_date else 'TBC',
        stop_number=order.delivery_stop_number or 'N/A',
        customer_name=customer.name,
        payment_reference=order.payment_reference or '',
        phone=customer.phone or '',
        address=f"{customer.address}, {customer.postcode}" if customer.address else '',
        items=items,
        fish_kg=fish_kg,
        freight_surcharge=float(invoice.freight_surcharge or 0),
        delivery_charge=float(invoice.delivery_charge or 0),
        total=float(invoice.total or 0),
    )

    pdf_dir = os.path.join(current_app.root_path, 'static', 'invoices')
    os.makedirs(pdf_dir, exist_ok=True)
    filename = f"invoice_{order.id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
    pdf_path = os.path.join(pdf_dir, filename)
    
    try:
        HTML(string=html_content).write_pdf(pdf_path)
        return pdf_path, None
    except Exception as e:
        return None, str(e)
