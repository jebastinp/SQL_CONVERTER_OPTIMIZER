import requests
from flask import current_app

def send_whatsapp_message(phone, message):
    token = current_app.config.get('WHATSAPP_TOKEN')
    phone_id = current_app.config.get('WHATSAPP_PHONE_ID')
    if not token or not phone_id:
        return {'success': False, 'error': 'WhatsApp not configured', 'manual': True, 'message': message}
    phone = phone.replace(' ', '').replace('-', '').replace('+', '')
    if not phone.startswith('44') and phone.startswith('0'):
        phone = '44' + phone[1:]
    url = f"https://graph.facebook.com/v18.0/{phone_id}/messages"
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    data = {"messaging_product": "whatsapp", "to": phone, "type": "text", "text": {"body": message}}
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=10)
        resp.raise_for_status()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def send_order_acknowledgement(customer_name, phone):
    return send_whatsapp_message(phone, f"Hi {customer_name}, thank you for your order! We are checking availability and will confirm shortly. - TAREL Team")

def send_availability_confirmed(customer_name, phone, fish_name, delivery_date):
    return send_whatsapp_message(phone, f"Hi {customer_name}, great news! Your order of {fish_name} is confirmed. We will deliver on {delivery_date}. - TAREL")

def send_not_available(customer_name, phone, fish_name):
    return send_whatsapp_message(phone, f"Hi {customer_name}, unfortunately {fish_name} is not available this week. We apologise for the inconvenience. - TAREL")

def send_payment_confirmation(customer_name, phone, amount):
    return send_whatsapp_message(phone, f"Hi {customer_name}, your payment of £{amount:.2f} has been received. Thank you! - TAREL")
