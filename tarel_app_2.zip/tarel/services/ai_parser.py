"""
Smart WhatsApp order parser — no AI API needed.
Parses common formats used by customers ordering fish/meat via WhatsApp.
"""
import re

FISH_ALIASES = {
    'king fish': '(1kg) King Fish (Slice)',
    'kingfish': '(1kg) King Fish (Slice)',
    'king': '(1kg) King Fish (Slice)',
    'mackerel': '(1kg) Indian Mackerel (Ayila)',
    'ayila': '(1kg) Indian Mackerel (Ayila)',
    'sardine': '(1kg) Sardine (Mathi)',
    'mathi': '(1kg) Sardine (Mathi)',
    'anchovy': '(1kg) Anchovy (Netholi)',
    'netholi': '(1kg) Anchovy (Netholi)',
    'bonito': '(1kg) Bonito',
    'crab': '(1kg) Blue Swimmer Crab',
    'blue crab': '(1kg) Blue Swimmer Crab',
    'prawn': '(1kg) White Prawn',
    'white prawn': '(1kg) White Prawn',
    'tiger prawn': '(1kg) Black Tiger Prawn',
    'black tiger': '(1kg) Black Tiger Prawn',
    'pomfret': '(1kg) Black Pomfret (B. Avoli)',
    'black pomfret': '(1kg) Black Pomfret (B. Avoli)',
    'silver pomfret': '(1kg) Silver Pomfret (S. Avoli)',
    'avoli': '(1kg) Black Pomfret (B. Avoli)',
    'squid': '(1kg) Squid',
    'cuttlefish': '(1kg) Cuttlefish (Kanava)',
    'kanava': '(1kg) Cuttlefish (Kanava)',
    'tuna': '(1kg) Yellowfin Tuna (Choora)',
    'choora': '(1kg) Yellowfin Tuna (Choora)',
    'salmon': '(1kg) Indian Salmon',
    'barracuda': '(1kg) Barracuda (Seelav)',
    'seelav': '(1kg) Barracuda (Seelav)',
    'seela': '(1kg) Barracuda (Seelav)',
    'emperor': '(1kg) Emperor Fish (Vilameen)',
    'vilameen': '(1kg) Emperor Fish (Vilameen)',
    'travelly': '(1kg) Travelly / Vatta',
    'vatta': '(1kg) Travelly / Vatta',
    'milkshark': '(1kg) Milkshark',
    'milk shark': '(1kg) Milkshark',
    'ribbon fish': '(1kg) Ribbon Fish (Vaala Meen)',
    'vaala': '(1kg) Ribbon Fish (Vaala Meen)',
    'rabbit fish': '(1kg) Rabbit Fish',
    'barramundi': '(1kg) Barramundi (Kalanchi)',
    'kalanchi': '(1kg) Barramundi (Kalanchi)',
    'ladyfish': '(1kg) Ladyfish',
    'sail fish': '(1kg) Sail Fish',
    'sailfish': '(1kg) Sail Fish',
    'goat fish': '(1kg) Goat Fish (Red Mullet)',
    'red mullet': '(1kg) Goat Fish (Red Mullet)',
    'threadfin': '(1kg) Threadfin Bream (Kilimeen)',
    'kilimeen': '(1kg) Threadfin Bream (Kilimeen)',
    'ponny': '(1kg) Ponny Fish',
    'yellow scads': '(1kg) Yellow Scads',
    'scads': '(1kg) Yellow Scads',
    'yellow travelly': '(1kg) Yellow Travelly/Manjal Paarai',
    'manjal paarai': '(1kg) Yellow Travelly/Manjal Paarai',
    # Meat
    'goat': '(1kg) Goat Meat With Bone',
    'goat meat': '(1kg) Goat Meat With Bone',
    'goat with bone': '(1kg) Goat Meat With Bone',
    'goat without bone': '(1kg) Goat Meat without Bone',
    'goat boneless': '(1kg) Goat Meat without Bone',
    'kid goat': '(1kg) Kid Goat Meat',
    'lamb': 'Lamb Diced on Bone',
    'goat liver': '(1kg) Goat Liver+Heart',
    'liver': '(1kg) Goat Liver+Heart',
}

def parse_quantity(text):
    """Extract quantity in kg from text like '1kg', '500g', '1/2kg', '2', 'half kg'."""
    text = text.strip().lower()
    if 'half' in text or '1/2' in text or '0.5' in text:
        return 0.5
    # Match patterns like 1.5kg, 2kg, 500g
    m = re.search(r'(\d+\.?\d*)\s*kg', text)
    if m:
        return float(m.group(1))
    m = re.search(r'(\d+)\s*g', text)
    if m:
        return float(m.group(1)) / 1000
    m = re.search(r'(\d+\.?\d*)', text)
    if m:
        val = float(m.group(1))
        return val if val <= 20 else val / 1000
    return 1.0

def find_fish_name(text):
    """Match text against known fish aliases."""
    text_lower = text.lower().strip()
    # Direct match
    if text_lower in FISH_ALIASES:
        return FISH_ALIASES[text_lower]
    # Partial match
    for alias, name in sorted(FISH_ALIASES.items(), key=lambda x: -len(x[0])):
        if alias in text_lower:
            return FISH_ALIASES[alias]
    return text.title()

def parse_whatsapp_order(raw_text):
    """
    Parse a WhatsApp order message into structured data.
    Handles formats like:
      - "1kg king fish, 500g prawns"
      - "King Fish 1kg\nSardine 2kg"  
      - "I want 2kg mackerel and 1kg goat"
    """
    lines = raw_text.strip().split('\n')
    customer_name = ''
    phone = ''
    items = []
    delivery_instructions = ''
    notes = ''

    # Extract phone number
    phone_match = re.search(r'(\+?[\d\s\-]{10,15})', raw_text)
    if phone_match:
        candidate = re.sub(r'[\s\-]', '', phone_match.group(1))
        if len(candidate) >= 10:
            phone = candidate

    # Try to find name patterns like "Hi, I'm John" or first line if it looks like a name
    name_patterns = [
        r"(?:hi|hello|dear)[\s,]+(?:i[\'']?m\s+)?([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
        r"(?:name|from)[:\s]+([A-Z][a-z]+(?: [A-Z][a-z]+)?)",
        r"^([A-Z][a-z]+(?: [A-Z][a-z]+)?)[\s:,\-]",
    ]
    for pattern in name_patterns:
        m = re.search(pattern, raw_text)
        if m:
            customer_name = m.group(1).strip()
            break

    # Parse items — handle multiple formats
    # Format 1: "2kg king fish" or "king fish 2kg"
    # Format 2: "1 kg mackerel, 500g prawn"
    # Format 3: line by line

    # Combined regex to find fish + quantity pairs
    item_patterns = [
        # "2kg king fish" / "2 kg king fish"
        r'(\d+\.?\d*)\s*(?:kg|g|kgs)\s+([a-zA-Z\s/\(\)]+?)(?:,|$|\n|and\s)',
        # "king fish 2kg" / "king fish - 2kg"
        r'([a-zA-Z\s/\(\)]{3,30}?)\s*[\-:]\s*(\d+\.?\d*)\s*(?:kg|g|kgs)',
        # "king fish 2kg" no separator
        r'([a-zA-Z\s/\(\)]{3,25})\s+(\d+\.?\d*)\s*(?:kg|g|kgs)',
    ]

    text_lower = raw_text.lower()
    found_items = set()

    for pattern in item_patterns:
        for m in re.finditer(pattern, text_lower, re.IGNORECASE | re.MULTILINE):
            groups = m.groups()
            # Determine which group is qty and which is name
            try:
                float(groups[0].strip())
                qty_str, name_str = groups[0], groups[1]
            except ValueError:
                name_str, qty_str = groups[0], groups[1]

            name_str = name_str.strip().strip(',.-:')
            qty = parse_quantity(qty_str)
            fish_name = find_fish_name(name_str)

            # Skip if it looks like noise
            if len(name_str) < 3 or name_str.lower() in ('and', 'the', 'for', 'of'):
                continue

            key = f"{fish_name}_{qty}"
            if key not in found_items:
                found_items.add(key)
                # Check for cut instructions
                cut = 'Clean and Cut'
                if 'steak' in raw_text.lower():
                    cut = 'Steak'
                elif 'whole' in raw_text.lower():
                    cut = 'Whole'
                elif 'fillet' in raw_text.lower():
                    cut = 'Fillet'

                # Adjust name for half kg items
                if qty == 0.5 and fish_name.startswith('(1kg)'):
                    half_name = fish_name.replace('(1kg)', '(1/2kg)', 1)
                    fish_name = half_name

                items.append({
                    'fish_name': fish_name,
                    'quantity_kg': qty,
                    'cut_instructions': cut,
                    'packing_size': f'{qty}kg',
                })

    # If no items found via regex, try line-by-line
    if not items:
        for line in lines:
            line = line.strip()
            if not line or len(line) < 3:
                continue
            # Skip lines that are clearly not orders
            if any(word in line.lower() for word in ['hi ', 'hello', 'dear', 'thanks', 'thank you', 'please', 'delivery']):
                continue
            # Try to find any fish name in the line
            for alias in sorted(FISH_ALIASES.keys(), key=lambda x: -len(x)):
                if alias in line.lower():
                    qty = parse_quantity(line)
                    fish_name = FISH_ALIASES[alias]
                    if qty == 0.5 and fish_name.startswith('(1kg)'):
                        fish_name = fish_name.replace('(1kg)', '(1/2kg)', 1)
                    items.append({
                        'fish_name': fish_name,
                        'quantity_kg': qty,
                        'cut_instructions': 'Clean and Cut',
                        'packing_size': f'{qty}kg',
                    })
                    break

    # Look for delivery notes
    for line in lines:
        if any(word in line.lower() for word in ['deliver', 'address', 'note', 'instruction']):
            delivery_instructions = line.strip()

    return {
        'success': True,
        'data': {
            'customer_name': customer_name,
            'phone': phone,
            'items': items if items else [],
            'delivery_instructions': delivery_instructions,
            'notes': notes,
        },
        'method': 'rule_based'  # flags that this used local parsing, not AI
    }
