import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'tarel-dev-secret')
    DATABASE_URL = os.environ.get('DATABASE_URL', '')
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY', '')
    WHATSAPP_TOKEN = os.environ.get('WHATSAPP_TOKEN', '')
    WHATSAPP_PHONE_ID = os.environ.get('WHATSAPP_PHONE_ID', '')
    WHATSAPP_VERIFY_TOKEN = os.environ.get('WHATSAPP_VERIFY_TOKEN', 'tarel_verify')
    PERMANENT_SESSION_LIFETIME = 28800  # 8 hours

    FREIGHT_RATE = 1.50
    SMALL_ORDER_THRESHOLD = 30.00
    SMALL_ORDER_CHARGE = 2.00
    INVERNESS_CHARGE = 13.00


    AREA_CODES = {
        'Edinburgh': 'ED', 'Glasgow': 'GL', 'Livingston': 'LI',
        'Bathgate': 'BA', 'East Calder': 'EC', 'Broxburn': 'BR',
        'Inverness': 'IN', 'Winchburgh': 'WI', 'Ayr': 'AY',
    }

