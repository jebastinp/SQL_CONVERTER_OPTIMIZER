from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_file, abort
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from datetime import datetime, date, timedelta
from decimal import Decimal
import bcrypt
import json
import os

from config import Config
from models import db, User, Customer, FishMaster, DeliveryWeek, Order, OrderItem, Invoice, Payment, Expense, Income, VendorReport, WhatsAppMessage, Settings

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    login_manager = LoginManager(app)
    login_manager.login_view = 'login'
    login_manager.login_message = 'Please log in to access TAREL.'

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # ─── AUTH ───────────────────────────────────────────────────────────────

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            user = User.query.filter_by(username=username).first()
            if user and bcrypt.checkpw(password.encode(), user.password_hash.encode()):
                login_user(user, remember=True)
                session.permanent = True
                return redirect(url_for('dashboard'))
            flash('Invalid username or password', 'error')
        return render_template('login.html')

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('login'))

    # ─── DASHBOARD ──────────────────────────────────────────────────────────

    @app.route('/')
    @login_required
    def dashboard():
        current_week = DeliveryWeek.query.filter_by(status='open').order_by(DeliveryWeek.delivery_date).first()
        week_orders = Order.query.filter_by(delivery_week_id=current_week.id).all() if current_week else []
        pending_availability = sum(1 for o in week_orders for i in o.items if i.availability_status == 'pending')
        unpaid_invoices = Order.query.filter(Order.status.in_(['invoice_sent', 'payment_pending'])).count()
        recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
        unread_messages = WhatsAppMessage.query.filter_by(direction='in', is_read=False).count()
        vendor_report = VendorReport.query.filter_by(delivery_week_id=current_week.id).first() if current_week else None
        pending_payments = Order.query.filter(Order.status.in_(['payment_pending', 'payment_received'])).all()
        return render_template('dashboard.html',
            current_week=current_week,
            week_orders_count=len(week_orders),
            pending_availability=pending_availability,
            unpaid_invoices=unpaid_invoices,
            recent_orders=recent_orders,
            unread_messages=unread_messages,
            vendor_report=vendor_report,
            pending_payments=pending_payments)

    # ─── ORDERS ─────────────────────────────────────────────────────────────

    @app.route('/orders')
    @login_required
    def orders_list():
        week_id = request.args.get('week_id', type=int)
        driver = request.args.get('driver')
        route = request.args.get('route')
        status = request.args.get('status')
        payment_status = request.args.get('payment_status')

        q = Order.query
        if week_id:
            q = q.filter_by(delivery_week_id=week_id)
        if driver:
            q = q.filter_by(driver=driver)
        if route:
            q = q.filter_by(route=route)
        if status:
            q = q.filter_by(status=status)
        orders = q.order_by(Order.created_at.desc()).all()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        return render_template('orders/list.html', orders=orders, weeks=weeks, current_week=current_week,
                               selected_week=week_id, selected_driver=driver, selected_route=route,
                               selected_status=status)

    @app.route('/orders/new', methods=['GET', 'POST'])
    @login_required
    def new_order():
        if request.method == 'POST':
            data = request.form
            customer_id = data.get('customer_id', type=int)
            new_customer_name = data.get('new_customer_name', '').strip()

            if not customer_id and new_customer_name:
                # Create new customer
                area = data.get('new_customer_area', 'Edinburgh')
                customer = Customer(
                    name=new_customer_name,
                    phone=data.get('new_customer_phone', '').strip(),
                    address=data.get('new_customer_address', '').strip(),
                    area=area,
                    postcode=data.get('new_customer_postcode', '').strip(),
                    customer_id=generate_customer_id(area)
                )
                db.session.add(customer)
                db.session.flush()
                customer_id = customer.id

            if not customer_id:
                flash('Please select or add a customer', 'error')
                return redirect(url_for('new_order'))

            customer = Customer.query.get(customer_id)
            week_id = data.get('delivery_week_id', type=int)
            week = DeliveryWeek.query.get(week_id) if week_id else DeliveryWeek.query.filter_by(status='open').first()

            area_code = app.config['AREA_CODES'].get(customer.area, 'XX')
            year = datetime.now().strftime('%y')
            pay_ref = generate_payment_ref(area_code, year)

            order = Order(
                customer_id=customer_id,
                delivery_week_id=week.id if week else None,
                payment_reference=pay_ref,
                order_date=date.today(),
                delivery_date=week.delivery_date if week else None,
                driver=data.get('driver', 'Martin'),
                route=customer.area,
                status='received',
                raw_whatsapp_text=data.get('raw_whatsapp_text', ''),
                delivery_instructions=data.get('delivery_instructions', ''),
                created_by=current_user.id
            )
            db.session.add(order)
            db.session.flush()

            fish_ids = request.form.getlist('fish_master_id[]')
            quantities = request.form.getlist('quantity_kg[]')
            cut_instructions = request.form.getlist('cut_instructions[]')

            for i, fid in enumerate(fish_ids):
                if not fid:
                    continue
                fish = FishMaster.query.get(int(fid))
                if not fish:
                    continue
                qty = float(quantities[i]) if i < len(quantities) else 1.0
                price = float(fish.selling_price or 0)
                item = OrderItem(
                    order_id=order.id,
                    fish_master_id=fish.id,
                    fish_name=fish.fish_name,
                    quantity_kg=qty,
                    unit_price=price,
                    line_total=qty * price,
                    cut_instructions=cut_instructions[i] if i < len(cut_instructions) else 'Clean and Cut',
                )
                db.session.add(item)

            db.session.commit()

            # Send WhatsApp acknowledgement
            if customer.phone:
                from services.whatsapp import send_order_acknowledgement
                send_order_acknowledgement(customer.name, customer.phone)

            flash(f'Order #{order.id} created successfully!', 'success')
            return redirect(url_for('order_detail', order_id=order.id))

        weeks = DeliveryWeek.query.filter_by(status='open').all()
        fish_list = FishMaster.query.filter_by(is_active=True).order_by(FishMaster.fish_name).all()
        customers = Customer.query.order_by(Customer.name).all()
        areas = list(app.config['AREA_CODES'].keys())
        return render_template('orders/new.html', weeks=weeks, fish_list=fish_list, customers=customers, areas=areas, config=app.config)

    @app.route('/orders/<int:order_id>')
    @login_required
    def order_detail(order_id):
        order = Order.query.get_or_404(order_id)
        return render_template('orders/detail.html', order=order)

    @app.route('/orders/<int:order_id>/status', methods=['POST'])
    @login_required
    def update_order_status(order_id):
        order = Order.query.get_or_404(order_id)
        new_status = request.form.get('status')
        if new_status:
            order.status = new_status
            db.session.commit()
            flash(f'Order status updated to {new_status}', 'success')
        return redirect(url_for('order_detail', order_id=order_id))

    @app.route('/api/parse-order', methods=['POST'])
    @login_required
    def api_parse_order():
        from services.ai_parser import parse_whatsapp_order
        raw_text = request.json.get('text', '')
        if not raw_text:
            return jsonify({'success': False, 'error': 'No text provided'})
        result = parse_whatsapp_order(raw_text)
        return jsonify(result)

    @app.route('/api/customers/search')
    @login_required
    def api_customer_search():
        q = request.args.get('q', '')
        customers = Customer.query.filter(
            (Customer.name.ilike(f'%{q}%')) | (Customer.phone.ilike(f'%{q}%'))
        ).limit(10).all()
        return jsonify([{'id': c.id, 'name': c.name, 'phone': c.phone, 'area': c.area, 'address': c.address} for c in customers])

    # ─── AVAILABILITY ────────────────────────────────────────────────────────

    @app.route('/availability')
    @login_required
    def availability():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        if not current_week:
            flash('No open delivery week found', 'warning')
            return redirect(url_for('dashboard'))
        orders = Order.query.filter_by(delivery_week_id=current_week.id).all()
        # Group by fish
        fish_groups = {}
        for order in orders:
            for item in order.items:
                key = item.fish_name
                if key not in fish_groups:
                    fish_groups[key] = {'fish_name': key, 'items': [], 'total_kg': 0}
                fish_groups[key]['items'].append({'item': item, 'order': order, 'customer': order.customer})
                fish_groups[key]['total_kg'] += float(item.quantity_kg or 0)
        return render_template('availability.html', fish_groups=fish_groups.values(), current_week=current_week)

    @app.route('/availability/update', methods=['POST'])
    @login_required
    def update_availability():
        item_id = request.form.get('item_id', type=int)
        status = request.form.get('status')
        item = OrderItem.query.get_or_404(item_id)
        item.availability_status = status
        item.availability_checked_by = current_user.id
        item.availability_checked_at = datetime.utcnow()
        db.session.commit()

        order = item.order
        customer = order.customer
        if customer.phone:
            from services.whatsapp import send_availability_confirmed, send_not_available
            if status == 'available':
                send_availability_confirmed(customer.name, customer.phone, item.fish_name,
                                           str(order.delivery_date or 'TBC'))
            elif status == 'not_available':
                send_not_available(customer.name, customer.phone, item.fish_name)

        return jsonify({'success': True})

    # ─── INVOICES ────────────────────────────────────────────────────────────

    @app.route('/orders/<int:order_id>/invoice', methods=['POST'])
    @login_required
    def generate_invoice(order_id):
        order = Order.query.get_or_404(order_id)
        config = app.config

        subtotal = sum(float(i.line_total or 0) for i in order.items)
        fish_kg = sum(float(i.quantity_kg or 0) for i in order.items if i.fish and i.fish.is_fish)
        freight = fish_kg * config['FREIGHT_RATE']

        if order.route == 'Inverness':
            delivery_charge = config['INVERNESS_CHARGE']
        elif subtotal < config['SMALL_ORDER_THRESHOLD']:
            delivery_charge = config['SMALL_ORDER_CHARGE']
        else:
            delivery_charge = 0.0

        total = subtotal + freight + delivery_charge

        if order.invoice:
            inv = order.invoice
        else:
            inv = Invoice(order_id=order.id)
            db.session.add(inv)

        inv.invoice_number = f"INV-{order.id}-{datetime.now().strftime('%Y%m%d')}"
        inv.subtotal = subtotal
        inv.freight_surcharge = freight
        inv.delivery_charge = delivery_charge
        inv.total = total
        inv.generated_at = datetime.utcnow()
        inv.sent_by = current_user.id
        db.session.flush()

        from services.invoice_pdf import generate_invoice_pdf
        pdf_path, error = generate_invoice_pdf(order, inv)
        if pdf_path:
            inv.pdf_path = pdf_path
        order.status = 'invoice_sent'
        db.session.commit()

        if error:
            flash(f'Invoice generated but PDF failed: {error}', 'warning')
        else:
            flash('Invoice generated successfully!', 'success')
        return redirect(url_for('order_detail', order_id=order_id))

    @app.route('/invoices/<int:invoice_id>/pdf')
    @login_required
    def download_invoice(invoice_id):
        inv = Invoice.query.get_or_404(invoice_id)
        if inv.pdf_path and os.path.exists(inv.pdf_path):
            return send_file(inv.pdf_path, as_attachment=True, download_name=f"invoice_{inv.invoice_number}.pdf")
        flash('PDF not found. Please regenerate the invoice.', 'error')
        return redirect(url_for('order_detail', order_id=inv.order_id))

    # ─── PAYMENTS ────────────────────────────────────────────────────────────

    @app.route('/orders/<int:order_id>/payment', methods=['POST'])
    @login_required
    def record_payment(order_id):
        order = Order.query.get_or_404(order_id)
        payment = Payment(
            order_id=order.id,
            invoice_id=order.invoice.id if order.invoice else None,
            amount=request.form.get('amount', type=float),
            payment_mode=request.form.get('payment_mode'),
            payment_name=request.form.get('payment_name'),
            payment_received_date=datetime.strptime(request.form.get('payment_date'), '%Y-%m-%d').date(),
            status='received'
        )
        db.session.add(payment)
        order.status = 'payment_received'
        db.session.commit()
        flash('Payment recorded!', 'success')
        return redirect(url_for('order_detail', order_id=order_id))

    @app.route('/payments/<int:payment_id>/verify', methods=['POST'])
    @login_required
    def verify_payment(payment_id):
        payment = Payment.query.get_or_404(payment_id)
        payment.status = 'verified'
        payment.payment_verified_by = current_user.id
        payment.payment_verified_at = datetime.utcnow()
        order = payment.order
        order.status = 'payment_verified'
        db.session.commit()
        customer = order.customer
        if customer.phone:
            from services.whatsapp import send_payment_confirmation
            send_payment_confirmation(customer.name, customer.phone, float(payment.amount))
        flash('Payment verified!', 'success')
        return redirect(url_for('order_detail', order_id=order.id))

    # ─── CUSTOMERS ───────────────────────────────────────────────────────────

    @app.route('/customers')
    @login_required
    def customers_list():
        q = request.args.get('q', '')
        area = request.args.get('area', '')
        query = Customer.query
        if q:
            query = query.filter((Customer.name.ilike(f'%{q}%')) | (Customer.phone.ilike(f'%{q}%')) | (Customer.customer_id.ilike(f'%{q}%')))
        if area:
            query = query.filter_by(area=area)
        customers = query.order_by(Customer.name).all()
        areas = db.session.query(Customer.area).distinct().filter(Customer.area.isnot(None)).all()
        return render_template('customers/list.html', customers=customers, areas=[a[0] for a in areas], q=q, selected_area=area)

    @app.route('/customers/new', methods=['GET', 'POST'])
    @login_required
    def new_customer():
        if request.method == 'POST':
            area = request.form.get('area', 'Edinburgh')
            customer = Customer(
                name=request.form.get('name').strip(),
                phone=request.form.get('phone', '').strip(),
                address=request.form.get('address', '').strip(),
                area=area,
                postcode=request.form.get('postcode', '').strip(),
                notes=request.form.get('notes', '').strip(),
                customer_id=generate_customer_id(area)
            )
            db.session.add(customer)
            db.session.commit()
            flash(f'Customer {customer.name} added!', 'success')
            return redirect(url_for('customer_profile', customer_id=customer.id))
        areas = list(app.config['AREA_CODES'].keys())
        return render_template('customers/profile.html', customer=None, areas=areas, mode='new')

    @app.route('/customers/<int:customer_id>')
    @login_required
    def customer_profile(customer_id):
        customer = Customer.query.get_or_404(customer_id)
        orders = Order.query.filter_by(customer_id=customer_id).order_by(Order.order_date.desc()).all()
        total_spent = sum(float(o.invoice.total or 0) for o in orders if o.invoice)
        areas = list(app.config['AREA_CODES'].keys())
        return render_template('customers/profile.html', customer=customer, orders=orders, total_spent=total_spent, areas=areas, mode='view')

    @app.route('/customers/<int:customer_id>/edit', methods=['POST'])
    @login_required
    def edit_customer(customer_id):
        customer = Customer.query.get_or_404(customer_id)
        customer.name = request.form.get('name', customer.name).strip()
        customer.phone = request.form.get('phone', customer.phone).strip()
        customer.address = request.form.get('address', customer.address).strip()
        customer.area = request.form.get('area', customer.area)
        customer.postcode = request.form.get('postcode', customer.postcode).strip()
        customer.notes = request.form.get('notes', customer.notes)
        db.session.commit()
        flash('Customer updated!', 'success')
        return redirect(url_for('customer_profile', customer_id=customer_id))

    # ─── FISH MASTER ─────────────────────────────────────────────────────────

    @app.route('/fish-master')
    @login_required
    def fish_master():
        fish = FishMaster.query.order_by(FishMaster.fish_name).all()
        return render_template('fish_master.html', fish=fish)

    @app.route('/fish-master/new', methods=['POST'])
    @login_required
    def new_fish():
        fish = FishMaster(
            fish_name=request.form.get('fish_name'),
            english_name=request.form.get('english_name'),
            tamil_name=request.form.get('tamil_name'),
            malayalam_name=request.form.get('malayalam_name'),
            size=request.form.get('size', '1kg'),
            avra_impex_price=request.form.get('avra_price') or None,
            global_food_price=request.form.get('global_price') or None,
            selling_price=request.form.get('selling_price') or None,
            is_fish=request.form.get('is_fish') == 'true',
            is_active=True
        )
        db.session.add(fish)
        db.session.commit()
        flash('Fish added!', 'success')
        return redirect(url_for('fish_master'))

    @app.route('/fish-master/<int:fish_id>/toggle', methods=['POST'])
    @login_required
    def toggle_fish(fish_id):
        fish = FishMaster.query.get_or_404(fish_id)
        fish.is_active = not fish.is_active
        db.session.commit()
        return jsonify({'active': fish.is_active})

    @app.route('/fish-master/<int:fish_id>/edit', methods=['POST'])
    @login_required
    def edit_fish(fish_id):
        fish = FishMaster.query.get_or_404(fish_id)
        fish.fish_name = request.form.get('fish_name', fish.fish_name)
        fish.avra_impex_price = request.form.get('avra_price') or fish.avra_impex_price
        fish.global_food_price = request.form.get('global_price') or fish.global_food_price
        fish.selling_price = request.form.get('selling_price') or fish.selling_price
        db.session.commit()
        flash('Fish updated!', 'success')
        return redirect(url_for('fish_master'))

    # ─── VENDOR REPORT ───────────────────────────────────────────────────────

    @app.route('/vendor-report')
    @login_required
    def vendor_report():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        week_id = request.args.get('week_id', type=int)
        if week_id:
            current_week = DeliveryWeek.query.get(week_id)
        if not current_week:
            return render_template('vendor_report.html', fish_totals=[], meat_totals=[], current_week=None, weeks=weeks)
        orders = Order.query.filter_by(delivery_week_id=current_week.id).all()
        fish_totals = {}
        meat_totals = {}
        for order in orders:
            for item in order.items:
                name = item.fish_name
                is_fish = item.fish.is_fish if item.fish else True
                target = fish_totals if is_fish else meat_totals
                if name not in target:
                    target[name] = {'fish_name': name, 'total_kg': 0, 'order_count': 0, 'customers': []}
                target[name]['total_kg'] += float(item.quantity_kg or 0)
                target[name]['order_count'] += 1
                target[name]['customers'].append(order.customer.name)
        existing_report = VendorReport.query.filter_by(delivery_week_id=current_week.id).first()
        return render_template('vendor_report.html',
            fish_totals=sorted(fish_totals.values(), key=lambda x: x['total_kg'], reverse=True),
            meat_totals=sorted(meat_totals.values(), key=lambda x: x['total_kg'], reverse=True),
            current_week=current_week, weeks=weeks, existing_report=existing_report)

    @app.route('/vendor-report/mark-sent', methods=['POST'])
    @login_required
    def mark_vendor_report_sent():
        week_id = request.form.get('week_id', type=int)
        report = VendorReport.query.filter_by(delivery_week_id=week_id).first()
        if not report:
            report = VendorReport(delivery_week_id=week_id, generated_by=current_user.id, generated_at=datetime.utcnow())
            db.session.add(report)
        report.sent_at = datetime.utcnow()
        week = DeliveryWeek.query.get(week_id)
        if week:
            week.status = 'vendor_report_sent'
        db.session.commit()
        flash('Vendor report marked as sent!', 'success')
        return redirect(url_for('vendor_report'))

    # ─── DELIVERY ROUTES ─────────────────────────────────────────────────────

    @app.route('/delivery-routes')
    @login_required
    def delivery_routes():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        week_id = request.args.get('week_id', type=int)
        if week_id:
            current_week = DeliveryWeek.query.get(week_id)
        martin_orders = danny_orders = inverness_orders = []
        if current_week:
            martin_orders = Order.query.filter_by(delivery_week_id=current_week.id, driver='Martin').filter(Order.route != 'Inverness').order_by(Order.delivery_stop_number).all()
            danny_orders = Order.query.filter_by(delivery_week_id=current_week.id, driver='Danny').order_by(Order.delivery_stop_number).all()
            inverness_orders = Order.query.filter_by(delivery_week_id=current_week.id, route='Inverness').all()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        return render_template('delivery_routes.html',
            martin_orders=martin_orders, danny_orders=danny_orders, inverness_orders=inverness_orders,
            current_week=current_week, weeks=weeks)

    @app.route('/delivery-routes/reorder', methods=['POST'])
    @login_required
    def reorder_stops():
        order_ids = request.json.get('order_ids', [])
        for i, oid in enumerate(order_ids):
            order = Order.query.get(oid)
            if order:
                order.delivery_stop_number = i + 1
        db.session.commit()
        return jsonify({'success': True})

    @app.route('/delivery-routes/mark-delivered/<int:order_id>', methods=['POST'])
    @login_required
    def mark_delivered(order_id):
        order = Order.query.get_or_404(order_id)
        order.status = 'delivered'
        db.session.commit()
        return jsonify({'success': True})

    # ─── FINANCE ─────────────────────────────────────────────────────────────

    @app.route('/finance')
    @login_required
    def finance():
        current_week = DeliveryWeek.query.filter_by(status='open').first()
        week_id = request.args.get('week_id', type=int)
        if week_id:
            current_week = DeliveryWeek.query.get(week_id)
        expenses = income_records = []
        total_income = total_expenses = fish_profit = 0
        if current_week:
            expenses = Expense.query.filter_by(delivery_week_id=current_week.id).order_by(Expense.expense_date.desc()).all()
            total_expenses = sum(float(e.amount or 0) for e in expenses)
            verified_payments = Payment.query.join(Order).filter(
                Order.delivery_week_id == current_week.id,
                Payment.status == 'verified'
            ).all()
            total_income = sum(float(p.amount or 0) for p in verified_payments)
            fish_profit = total_income - total_expenses
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        return render_template('finance.html', expenses=expenses, current_week=current_week, weeks=weeks,
            total_income=total_income, total_expenses=total_expenses, fish_profit=fish_profit)

    @app.route('/finance/expense/add', methods=['POST'])
    @login_required
    def add_expense():
        expense = Expense(
            expense_date=datetime.strptime(request.form.get('expense_date'), '%Y-%m-%d').date(),
            description=request.form.get('description'),
            category=request.form.get('category', 'Other'),
            amount=request.form.get('amount', type=float),
            payment_status=request.form.get('payment_status', 'paid'),
            delivery_week_id=request.form.get('week_id', type=int),
            created_by=current_user.id
        )
        db.session.add(expense)
        db.session.commit()
        flash('Expense added!', 'success')
        return redirect(url_for('finance', week_id=expense.delivery_week_id))

    @app.route('/finance/expense/<int:expense_id>/delete', methods=['POST'])
    @login_required
    def delete_expense(expense_id):
        expense = Expense.query.get_or_404(expense_id)
        week_id = expense.delivery_week_id
        db.session.delete(expense)
        db.session.commit()
        flash('Expense deleted', 'success')
        return redirect(url_for('finance', week_id=week_id))

    # ─── SETTINGS ────────────────────────────────────────────────────────────

    @app.route('/settings')
    @login_required
    def settings():
        if current_user.role != 'admin':
            flash('Admin access required', 'error')
            return redirect(url_for('dashboard'))
        users = User.query.all()
        weeks = DeliveryWeek.query.order_by(DeliveryWeek.delivery_date.desc()).all()
        return render_template('settings.html', users=users, weeks=weeks, config=app.config)

    @app.route('/settings/user/add', methods=['POST'])
    @login_required
    def add_user():
        if current_user.role != 'admin':
            abort(403)
        password = request.form.get('password')
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        user = User(
            name=request.form.get('name'),
            username=request.form.get('username'),
            password_hash=hashed,
            role=request.form.get('role', 'team')
        )
        db.session.add(user)
        db.session.commit()
        flash('User added!', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/user/<int:user_id>/delete', methods=['POST'])
    @login_required
    def delete_user(user_id):
        if current_user.role != 'admin':
            abort(403)
        user = User.query.get_or_404(user_id)
        if user.id == current_user.id:
            flash("Can't delete yourself", 'error')
            return redirect(url_for('settings'))
        db.session.delete(user)
        db.session.commit()
        flash('User deleted', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/week/add', methods=['POST'])
    @login_required
    def add_delivery_week():
        if current_user.role != 'admin':
            abort(403)
        week = DeliveryWeek(
            week_start=datetime.strptime(request.form.get('week_start'), '%Y-%m-%d').date(),
            week_end=datetime.strptime(request.form.get('week_end'), '%Y-%m-%d').date(),
            delivery_date=datetime.strptime(request.form.get('delivery_date'), '%Y-%m-%d').date(),
            status='open'
        )
        db.session.add(week)
        db.session.commit()
        flash('Delivery week added!', 'success')
        return redirect(url_for('settings'))

    @app.route('/settings/week/<int:week_id>/close', methods=['POST'])
    @login_required
    def close_week(week_id):
        if current_user.role != 'admin':
            abort(403)
        week = DeliveryWeek.query.get_or_404(week_id)
        week.status = 'closed'
        db.session.commit()
        flash('Week closed', 'success')
        return redirect(url_for('settings'))

    # ─── WHATSAPP WEBHOOK ────────────────────────────────────────────────────

    @app.route('/webhook/whatsapp', methods=['GET', 'POST'])
    def whatsapp_webhook():
        if request.method == 'GET':
            token = request.args.get('hub.verify_token')
            if token == app.config.get('WHATSAPP_VERIFY_TOKEN'):
                return request.args.get('hub.challenge', ''), 200
            return 'Forbidden', 403
        try:
            data = request.json
            entry = data.get('entry', [{}])[0]
            changes = entry.get('changes', [{}])[0]
            value = changes.get('value', {})
            messages = value.get('messages', [])
            for msg in messages:
                phone = msg.get('from', '')
                text = msg.get('text', {}).get('body', '')
                wa_msg = WhatsAppMessage(direction='in', phone=phone, message=text, is_read=False)
                customer = Customer.query.filter_by(phone=phone).first()
                if customer:
                    wa_msg.customer_id = customer.id
                db.session.add(wa_msg)
            db.session.commit()
        except Exception:
            pass
        return 'OK', 200

    # ─── HELPERS ─────────────────────────────────────────────────────────────

    def generate_customer_id(area):
        code = app.config['AREA_CODES'].get(area, 'XX')
        year = datetime.now().strftime('%y')
        count = Customer.query.filter(Customer.customer_id.like(f'{code}{year}%')).count()
        return f"{code}{year}{count + 1:03d}"

    def generate_payment_ref(area_code, year):
        count = Order.query.filter(Order.payment_reference.like(f'{area_code}{year}%')).count()
        return f"{area_code}{year}{count + 1:03d}"

    @app.template_filter('currency')
    def currency_filter(value):
        try:
            return f"£{float(value):.2f}"
        except:
            return '£0.00'

    @app.template_filter('status_badge')
    def status_badge_filter(status):
        badges = {
            'received': ('🟡', 'badge-warning'),
            'availability_confirmed': ('🔵', 'badge-info'),
            'invoice_sent': ('📄', 'badge-muted'),
            'payment_pending': ('⏳', 'badge-warning'),
            'payment_received': ('💰', 'badge-info'),
            'payment_verified': ('✅', 'badge-success'),
            'delivered': ('🚚', 'badge-success'),
        }
        icon, cls = badges.get(status, ('•', 'badge-muted'))
        return f'<span class="badge {cls}">{icon} {status.replace("_", " ").title()}</span>'

    return app


if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
