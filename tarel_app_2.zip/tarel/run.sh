#!/bin/bash
set -e

echo ""
echo "=========================================="
echo "  TAREL Fish Delivery — Admin System"
echo "=========================================="
echo ""

# First-time setup
if [ ! -f .env ]; then
    echo "  [!] First time setup..."
    cp .env.example .env
    echo ""
    echo "  [!] .env file created."
    echo "  [!] Please edit it with your Supabase URL and secret key:"
    echo ""
    echo "      nano .env"
    echo "   OR open .env in any text editor"
    echo ""
    echo "  Then run ./run.sh again."
    exit 0
fi

# Check python
if command -v python3 &>/dev/null; then
    PY=python3
    PIP=pip3
elif command -v python &>/dev/null; then
    PY=python
    PIP=pip
else
    echo "  [!] Python not found. Install from python.org"
    exit 1
fi

echo "  [1/3] Installing packages..."
$PIP install -r requirements.txt -q

echo "  [2/3] Setting up database..."
$PY seed_data.py

echo "  [3/3] Starting TAREL..."
echo ""
echo "=========================================="
echo "  Open in browser: http://localhost:5000"
echo "  Login: admin / tarel2026"
echo "  Stop with: Ctrl+C"
echo "=========================================="
echo ""

# Open browser
if command -v open &>/dev/null; then
    sleep 1.5 && open http://localhost:5000 &
elif command -v xdg-open &>/dev/null; then
    sleep 1.5 && xdg-open http://localhost:5000 &
fi

$PY app.py
