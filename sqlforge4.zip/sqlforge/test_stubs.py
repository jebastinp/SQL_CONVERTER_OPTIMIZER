"""
Test stubs for sqlglot and bcrypt.
Installed only into sys.modules during testing — never imported in production.

The real libraries are pulled in via `pip install -r requirements.txt`.
"""
import sys
import re
import hashlib
import types


# ---------------------------------------------------------------------------
# Fake bcrypt
# ---------------------------------------------------------------------------
def _make_bcrypt():
    mod = types.ModuleType("bcrypt")

    def gensalt():
        return b"$2b$12$" + b"x" * 22

    def hashpw(pw, salt):
        # SHA256 with the salt prefix — for testing only
        return salt + hashlib.sha256(salt + pw).hexdigest().encode()

    def checkpw(pw, hashed):
        salt = hashed[:29]
        return hashpw(pw, salt) == hashed

    mod.gensalt = gensalt
    mod.hashpw = hashpw
    mod.checkpw = checkpw
    return mod


# ---------------------------------------------------------------------------
# Fake sqlglot — enough to drive end-to-end tests of the API surface.
# Real conversions live in the real library; here we just simulate the
# transformations the app expects.
# ---------------------------------------------------------------------------
def _make_sqlglot():
    mod = types.ModuleType("sqlglot")
    mod.__version__ = "test-stub-0.0.0"

    exp = types.ModuleType("sqlglot.exp")

    # Node base
    class Node:
        def __init__(self, sql_text=""):
            self.sql_text = sql_text
            self.args = {}
            self.this = None
            self._table = ""
            self._is_string = False
            self._name = ""

        @property
        def table(self):
            return self._table

        @property
        def is_string(self):
            return self._is_string

        @property
        def alias_or_name(self):
            return self._name or self._table

        def find_all(self, cls):
            # Walk text to find pattern occurrences and yield typed nodes.
            text = self.sql_text or ""
            upper = text.upper()
            if cls is Star:
                if re.search(r"\bSELECT\s+\*", upper):
                    yield Star()
            elif cls is Join:
                for _ in re.finditer(r"\bJOIN\b", upper):
                    yield Join()
            elif cls is Subquery:
                # Extract inner SQL text for each subquery so its tables are isolated.
                depth = 0
                in_sub = False
                start = 0
                i_pos = 0
                while i_pos < len(text):
                    if text[i_pos] == '(':
                        if depth == 0:
                            # Peek next non-space chars
                            j = i_pos + 1
                            while j < len(text) and text[j].isspace(): j += 1
                            if text[j:j+6].upper() == "SELECT":
                                in_sub = True
                                start = i_pos + 1
                                depth = 1
                                i_pos = j
                                continue
                        else:
                            depth += 1
                    elif text[i_pos] == ')' and in_sub:
                        depth -= 1
                        if depth == 0:
                            inner = text[start:i_pos]
                            n = Subquery()
                            n.sql_text = inner
                            yield n
                            in_sub = False
                    i_pos += 1
            elif cls is Select:
                for _ in re.finditer(r"\bSELECT\b", upper):
                    n = Select()
                    n.sql_text = text
                    n.args["distinct"] = bool(re.search(r"\bSELECT\s+DISTINCT\b", upper))
                    n.args["from"] = Node(text) if re.search(r"\bFROM\b", upper) else None
                    n.args["joins"] = list(Node().find_all_dummy()) if "JOIN" in upper else []
                    n.args["where"] = Where(text) if re.search(r"\bWHERE\b", upper) else None
                    yield n
                    break  # only top-level for tests
            elif cls is Order:
                if re.search(r"\bORDER\s+BY\b", upper):
                    yield Order()
            elif cls is Limit:
                if re.search(r"\bLIMIT\b", upper):
                    yield Limit()
            elif cls is Fetch:
                if re.search(r"\bFETCH\s+FIRST\b", upper):
                    yield Fetch()
            elif cls is Group:
                if re.search(r"\bGROUP\s+BY\b", upper):
                    yield Group()
            elif cls is Where:
                if re.search(r"\bWHERE\b", upper):
                    yield Where(text)
            elif cls is Table:
                # Match tables in FROM ... and JOIN ... clauses, capturing both table and alias.
                for m in re.finditer(r"\bFROM\s+([A-Za-z_]\w*)(?:\s+(?:AS\s+)?([A-Za-z_]\w*))?", self.sql_text or "", re.IGNORECASE):
                    n = Table(); n._table = m.group(1); n._name = m.group(2) or m.group(1); yield n
                for m in re.finditer(r"\bJOIN\s+([A-Za-z_]\w*)(?:\s+(?:AS\s+)?([A-Za-z_]\w*))?", self.sql_text or "", re.IGNORECASE):
                    n = Table(); n._table = m.group(1); n._name = m.group(2) or m.group(1); yield n
            elif cls is Like:
                for m in re.finditer(r"LIKE\s+'([^']*)'", text):
                    n = Like()
                    lit = Literal()
                    lit._is_string = True
                    lit.this = m.group(1)
                    n.args["expression"] = lit
                    yield n
            elif cls is Func:
                # functions inside WHERE
                where_m = re.search(r"\bWHERE\b([\s\S]*)", text, re.IGNORECASE)
                if where_m:
                    body = where_m.group(1)
                    for m in re.finditer(r"\b(UPPER|LOWER|YEAR|EXTRACT|DATEPART|CAST|CONVERT|TRIM|SUBSTRING)\s*\(([^)]*)\)", body, re.IGNORECASE):
                        f = Func()
                        f.sql_text = m.group(0)
                        yield f
            elif cls is Column:
                # any A.B token
                for m in re.finditer(r"\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)\b", self.sql_text or ""):
                    c = Column(); c._table = m.group(1); yield c
            elif cls is Not:
                # NOT IN (SELECT ...)
                for m in re.finditer(r"\bNOT\s+IN\s*\(\s*SELECT", self.sql_text or "", re.IGNORECASE):
                    n = Not()
                    inner = In()
                    inner.args["query"] = Subquery()
                    n.this = inner
                    yield n
            elif cls is In:
                pass

        def find_all_dummy(self):
            return iter([])

        def sql(self, dialect="postgres", pretty=True):
            # Apply the expected transformation per (read, dialect) pair.
            text = self.sql_text or ""
            src = (self._read or "postgres").lower()
            tgt = (dialect or "postgres").lower()

            out = text
            if src == "tsql" and tgt == "postgres":
                m = re.search(r"\bTOP\s+(\d+)\b", out, re.IGNORECASE)
                limit = m.group(1) if m else None
                out = re.sub(r"\bSELECT\s+TOP\s+\d+\s+", "SELECT ", out, flags=re.IGNORECASE)
                out = re.sub(r"\bGETDATE\s*\(\s*\)", "CURRENT_TIMESTAMP", out, flags=re.IGNORECASE)
                out = re.sub(r"\bISNULL\s*\(", "COALESCE(", out, flags=re.IGNORECASE)
                out = re.sub(r"\bYEAR\s*\(([^)]+)\)", r"EXTRACT(YEAR FROM \1)", out, flags=re.IGNORECASE)
                out = re.sub(r"\[(\w+)\]", r'"\1"', out)
                if limit and not re.search(r"\bLIMIT\b", out, re.IGNORECASE):
                    out = out.rstrip().rstrip(";") + f"\nLIMIT {limit};"
            elif src == "postgres" and tgt == "tsql":
                m = re.search(r"\bLIMIT\s+(\d+)", out, re.IGNORECASE)
                if m:
                    out = re.sub(r"\bLIMIT\s+\d+\s*;?", ";", out, flags=re.IGNORECASE)
                    out = re.sub(r"\bSELECT\b", f"SELECT TOP {m.group(1)}", out, count=1, flags=re.IGNORECASE)
                out = re.sub(r'"(\w+)"', r"[\1]", out)
            elif src == "mysql" and tgt == "postgres":
                out = re.sub(r"`(\w+)`", r'"\1"', out)
                out = re.sub(r"\bIFNULL\s*\(", "COALESCE(", out, flags=re.IGNORECASE)
            elif src == "oracle" and tgt == "postgres":
                out = re.sub(r"\bNVL\s*\(", "COALESCE(", out, flags=re.IGNORECASE)
                out = re.sub(r"\bSYSDATE\b", "CURRENT_TIMESTAMP", out, flags=re.IGNORECASE)
                m = re.search(r"ROWNUM\s*<=?\s*(\d+)", out, re.IGNORECASE)
                if m:
                    n = m.group(1)
                    out = re.sub(r"(AND\s+)?ROWNUM\s*<=?\s*\d+\s*(AND\s+)?", "", out, flags=re.IGNORECASE)
                    out = re.sub(r"\bWHERE\s*$", "", out.rstrip(), flags=re.IGNORECASE)
                    out = out.rstrip().rstrip(";") + f"\nLIMIT {n};"
            # else identity
            return out.rstrip()

    # Node subclasses (markers)
    class Star(Node): pass
    class Join(Node): pass
    class Subquery(Node): pass
    class Select(Node): pass
    class Order(Node): pass
    class Limit(Node): pass
    class Fetch(Node): pass
    class Group(Node): pass
    class Where(Node): pass
    class Table(Node): pass
    class Like(Node): pass
    class Func(Node): pass
    class Column(Node): pass
    class Not(Node): pass
    class In(Node): pass
    class Literal(Node): pass

    exp.Star = Star; exp.Join = Join; exp.Subquery = Subquery; exp.Select = Select
    exp.Order = Order; exp.Limit = Limit; exp.Fetch = Fetch; exp.Group = Group
    exp.Where = Where; exp.Table = Table; exp.Like = Like; exp.Func = Func
    exp.Column = Column; exp.Not = Not; exp.In = In; exp.Literal = Literal

    def parse(sql, read="postgres"):
        # Reject obviously bad input so we can test parse-error paths.
        if not sql or not sql.strip():
            raise ValueError("empty")
        if "@@@PARSE_FAIL@@@" in sql:
            raise ValueError("simulated parse error")
        n = Node(sql)
        n._read = read
        return [n]

    optimizer_mod = types.ModuleType("sqlglot.optimizer")
    def optimize(node, *args, **kwargs):
        return node
    optimizer_mod.optimize = optimize

    mod.parse = parse
    mod.exp = exp
    mod.optimizer = optimizer_mod
    return mod, exp, optimizer_mod


def install_stubs():
    bcrypt_mod = _make_bcrypt()
    sqlglot_mod, exp_mod, optimizer_mod = _make_sqlglot()
    sys.modules["bcrypt"] = bcrypt_mod
    sys.modules["sqlglot"] = sqlglot_mod
    sys.modules["sqlglot.exp"] = exp_mod
    sys.modules["sqlglot.optimizer"] = optimizer_mod
    # sqlglot.optimizer.optimize submodule
    optimize_submod = types.ModuleType("sqlglot.optimizer.optimize")
    optimize_submod.optimize = optimizer_mod.optimize
    sys.modules["sqlglot.optimizer.optimize"] = optimize_submod


if __name__ == "__main__":
    install_stubs()
    print("Stubs installed.")
