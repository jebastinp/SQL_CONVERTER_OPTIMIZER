// Test the tokenizer + highlighter from app.js
// Runs in Node by extracting the relevant functions and asserting on their output.

const fs = require('fs');
const path = require('path');

// Read app.js and extract the functions we need (between the markers)
const appJs = fs.readFileSync(path.join(__dirname, 'static', 'app.js'), 'utf-8');

// Pull SQL_KEYWORDS, tokenize, escapeHtml, highlight using a sandbox
// Wrap them in a CommonJS shim
const shim = `
${appJs.match(/const SQL_KEYWORDS = new Set\(\[[\s\S]*?\]\);/)[0]}
${appJs.match(/function tokenize\(sql\) \{[\s\S]*?\n\}\n/)[0]}
${appJs.match(/function escapeHtml\(s\) \{[\s\S]*?\n\}\n/)[0]}
${appJs.match(/function highlight\(sql\) \{[\s\S]*?\n\}/)[0]}
module.exports = { tokenize, escapeHtml, highlight, SQL_KEYWORDS };
`;

const tmpFile = '/tmp/sqlforge_tokenizer.js';
fs.writeFileSync(tmpFile, shim);
const { tokenize, escapeHtml, highlight } = require(tmpFile);

let pass = 0, fail = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    console.log(`  ✓ ${name}`);
    pass++;
  } catch (e) {
    console.log(`  ✗ ${name}`);
    console.log(`    ${e.message}`);
    fail++;
    failures.push(name + ': ' + e.message);
  }
}

function assert(cond, msg) { if (!cond) throw new Error(msg); }
function assertEqual(a, b, msg) { if (a !== b) throw new Error(`${msg}\n  expected: ${JSON.stringify(b)}\n  actual:   ${JSON.stringify(a)}`); }

console.log('\n── Tokenizer basics ─────────────────────────────────');

test('Tokenizes simple SELECT', () => {
  const toks = tokenize('SELECT 1');
  const kw = toks.find(t => t.value === 'SELECT');
  assert(kw && kw.type === 'keyword', 'SELECT not keyword');
});

test('Number recognized', () => {
  const toks = tokenize('SELECT 42');
  const n = toks.find(t => t.value === '42');
  assertEqual(n.type, 'number', 'number type');
});

test('String literal recognized', () => {
  const toks = tokenize("WHERE x = 'hello'");
  const s = toks.find(t => t.value === "'hello'");
  assertEqual(s.type, 'string', 'string type');
});

test('String with escaped quote', () => {
  const toks = tokenize("'it''s ok'");
  const s = toks.find(t => t.value === "'it''s ok'");
  assert(s, "couldn't find escaped-quote string");
  assertEqual(s.type, 'string', 'string type');
});

test('Line comment', () => {
  const toks = tokenize('-- hello\nSELECT 1');
  const c = toks.find(t => t.value === '-- hello');
  assertEqual(c.type, 'comment', 'comment type');
});

test('Block comment', () => {
  const toks = tokenize('/* multi\nline */ SELECT 1');
  const c = toks.find(t => t.type === 'comment');
  assert(c.value.startsWith('/*'), 'block comment captured');
});

test('Function name vs keyword', () => {
  const toks = tokenize('SELECT COUNT(*)');
  const sel = toks.find(t => t.value === 'SELECT');
  const cnt = toks.find(t => t.value === 'COUNT');
  assertEqual(sel.type, 'keyword');
  assertEqual(cnt.type, 'function');
});

test('Identifier with brackets', () => {
  const toks = tokenize('SELECT [Name] FROM [Customer]');
  const ids = toks.filter(t => t.value.startsWith('['));
  assertEqual(ids.length, 2);
  assert(ids.every(t => t.type === 'identifier'));
});

test('Identifier with backticks', () => {
  const toks = tokenize('SELECT `name` FROM `customer`');
  const ids = toks.filter(t => t.value.startsWith('`'));
  assertEqual(ids.length, 2);
});

test('Operators tokenized', () => {
  const toks = tokenize('a >= 5 AND b <> 3');
  assert(toks.some(t => t.value === '>=' && t.type === 'operator'));
  assert(toks.some(t => t.value === '<>' && t.type === 'operator'));
});


console.log('\n── HTML output safety ───────────────────────────────');

test('escapeHtml escapes <, >, &', () => {
  assertEqual(escapeHtml('a < b & c > d'), 'a &lt; b &amp; c &gt; d');
});

test('highlight produces valid HTML (no unclosed spans)', () => {
  const sql = `SELECT TOP 10 c.Name FROM Customers c WHERE c.Age > 25 AND c.Email LIKE '%@example.com' -- comment`;
  const html = highlight(sql);
  // Count opening and closing span tags
  const opens = (html.match(/<span/g) || []).length;
  const closes = (html.match(/<\/span>/g) || []).length;
  assertEqual(opens, closes, `unbalanced spans (${opens} opens, ${closes} closes)`);
});

test('highlight never produces "lass=" in rendered text (the original bug)', () => {
  // The original bug rendered "lass=tok-kw>SELECT" as VISIBLE TEXT because
  // the regex was eating the 'c' of class="...". We simulate rendering by
  // stripping all valid <span class="..."> tags and </span> tags, then
  // checking the remaining "rendered text" never contains "lass=".
  const sql = `SELECT * FROM customers c WHERE c.email LIKE '%test%' ORDER BY c.created DESC LIMIT 10;`;
  const html = highlight(sql);
  const rendered = html
    .replace(/<span class="tok-[a-z]+">/g, '')
    .replace(/<\/span>/g, '');
  assert(!rendered.includes('lass='), 'BUG: rendered text contains "lass=" (broken HTML attribute leaking)');
  assert(!rendered.includes('<span'), 'BUG: malformed span tag in rendered text');
});

test('highlight handles aliases like `c.CustomerID` cleanly', () => {
  const html = highlight('SELECT c.CustomerID FROM Customers c');
  // Make sure no part of "class=" leaks
  assert(!html.includes('class="tok-fn"(c'), 'alias confused with function');
  // c is an identifier, not a keyword
  assert(html.includes('<span class="tok-id">c</span>'), 'identifier c not styled');
});

test('highlight on the previously broken sample produces clean HTML', () => {
  const sql = `-- Find top customers
SELECT c.CustomerID, c.Name, c.Email,
    (SELECT COUNT(*) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS OrderCount,
    NOW() AS RetrievedAt,
    COALESCE(c.Country, 'Unknown') AS Country
FROM Customers c
WHERE c.Status = 'active'
  AND c.Email LIKE '%@example.com'
  AND EXTRACT(YEAR FROM c.CreatedAt) = 2024
ORDER BY OrderCount DESC
LIMIT 10;`;
  const html = highlight(sql);
  // Strip valid tags, then check the rendered text has no leaks
  const rendered = html
    .replace(/<span class="tok-[a-z]+">/g, '')
    .replace(/<\/span>/g, '');
  assert(!rendered.includes('lass='), 'rendered text contains "lass="');
  assert(!rendered.includes('<span'), 'rendered text contains malformed span');
  // Balanced spans
  const opens = (html.match(/<span\s/g) || []).length;
  const closes = (html.match(/<\/span>/g) || []).length;
  assertEqual(opens, closes, `unbalanced: ${opens}/${closes}`);
  // SELECT, FROM, WHERE should be keyword-tagged
  assert(html.includes('<span class="tok-kw">SELECT</span>'));
  assert(html.includes('<span class="tok-kw">FROM</span>'));
  assert(html.includes('<span class="tok-kw">WHERE</span>'));
  // COUNT, NOW, COALESCE, EXTRACT should be function-tagged
  assert(html.includes('<span class="tok-fn">COUNT</span>'));
  assert(html.includes('<span class="tok-fn">NOW</span>'));
  assert(html.includes('<span class="tok-fn">COALESCE</span>'));
});

test('highlight handles dangerous HTML in strings', () => {
  const html = highlight(`SELECT '<script>alert(1)</script>'`);
  assert(!html.includes('<script>'), 'XSS leak in string');
  assert(html.includes('&lt;script&gt;'), 'script not escaped');
});

test('highlight handles "<" comparison operator without breaking', () => {
  const html = highlight('WHERE a < b AND b > c');
  // < and > should appear as &lt; / &gt; inside operator spans
  assert(html.includes('&lt;'), '< not escaped');
  assert(html.includes('&gt;'), '> not escaped');
  const opens = (html.match(/<span\s/g) || []).length;
  const closes = (html.match(/<\/span>/g) || []).length;
  assertEqual(opens, closes, 'unbalanced spans around comparison');
});

test('Empty input is safe', () => {
  assertEqual(highlight(''), '');
});

test('Whitespace-only input is preserved', () => {
  const out = highlight('   \n  ');
  assertEqual(out, '   \n  ');
});


console.log('\n── End-to-end realistic queries ─────────────────────');

const realistic = [
  "SELECT TOP 10 * FROM Customers WHERE Age > 21;",
  "SELECT a.id, b.name FROM a JOIN b ON a.id = b.a_id WHERE b.active = TRUE;",
  "INSERT INTO users (id, name) VALUES (1, 'Alice');",
  "UPDATE orders SET status = 'shipped' WHERE order_id IN (1, 2, 3);",
  "SELECT * FROM t WHERE name LIKE '%test%' AND created_at > '2024-01-01';",
  "WITH cte AS (SELECT id FROM orders) SELECT COUNT(*) FROM cte;",
];

realistic.forEach((sql, i) => {
  test(`Realistic query #${i+1} produces valid HTML`, () => {
    const html = highlight(sql);
    const opens = (html.match(/<span\s/g) || []).length;
    const closes = (html.match(/<\/span>/g) || []).length;
    assertEqual(opens, closes, `unbalanced (${opens} vs ${closes})`);
    // Rendered text must not contain "lass=" or malformed spans
    const rendered = html
      .replace(/<span class="tok-[a-z]+">/g, '')
      .replace(/<\/span>/g, '');
    assert(!rendered.includes('lass='), 'rendered text contains "lass=" — attribute leak');
    assert(!rendered.includes('<span'), 'rendered text contains malformed span');
  });
});


console.log();
console.log(`━━━ ${pass} passed, ${fail} failed ` + '━'.repeat(30));
if (fail) {
  console.log('\nFailures:');
  failures.forEach(f => console.log('  • ' + f));
  process.exit(1);
}
