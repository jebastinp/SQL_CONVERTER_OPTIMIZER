/* =========================================================
   SQL Forge — Frontend
   ========================================================= */
const API = "";

const SAMPLES = {
  mssql: `-- Find top customers and their recent orders
SELECT TOP 10 c.CustomerID, c.Name, c.Email,
    (SELECT COUNT(*) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS OrderCount,
    GETDATE() AS RetrievedAt,
    ISNULL(c.Country, 'Unknown') AS Country
FROM Customers c
WHERE c.Status = 'active'
    AND c.Email LIKE '%@example.com'
    AND YEAR(c.CreatedAt) = 2024
ORDER BY OrderCount DESC;`,
  postgresql: `SELECT c.customer_id, c.name, c.email,
    COUNT(o.order_id) AS order_count
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.customer_id
WHERE c.status = 'active'
GROUP BY c.customer_id, c.name, c.email
ORDER BY order_count DESC
LIMIT 10;`,
  mysql: `SELECT c.id, c.name, c.email,
    DATE_FORMAT(c.created_at, '%Y-%m-%d') AS joined,
    IFNULL(c.country, 'N/A') AS country
FROM customers c
WHERE c.status = 'active'
LIMIT 10;`,
  oracle: `SELECT c.customer_id, c.name, NVL(c.country, 'Unknown') AS country
FROM customers c
WHERE ROWNUM <= 10
  AND SYSDATE - c.created_at < 365;`,
  sqlite: `SELECT c.id, c.name, c.email
FROM customers c
WHERE c.status = 'active'
LIMIT 10;`,
  snowflake: `SELECT c.id, c.name, CURRENT_TIMESTAMP() AS now
FROM customers c
QUALIFY ROW_NUMBER() OVER (PARTITION BY c.country ORDER BY c.created_at DESC) = 1;`,
  bigquery: `SELECT c.id, c.name, FORMAT_TIMESTAMP('%Y-%m-%d', c.created_at) AS joined
FROM \`project.dataset.customers\` c
WHERE c.status = 'active'
LIMIT 10;`,
  redshift: `SELECT c.id, c.name, GETDATE() AS now
FROM customers c LIMIT 10;`,
  duckdb: `SELECT c.id, c.name FROM customers c WHERE c.status = 'active' LIMIT 10;`
};

/* =========================================================
   SQL TOKENIZER (state machine — not regex)
   ========================================================= */
const SQL_KEYWORDS = new Set([
  'SELECT','FROM','WHERE','GROUP','BY','ORDER','HAVING','LIMIT','OFFSET',
  'INNER','LEFT','RIGHT','FULL','OUTER','CROSS','JOIN','ON','USING',
  'AND','OR','NOT','IN','EXISTS','LIKE','ILIKE','BETWEEN','IS','NULL',
  'AS','UNION','ALL','INSERT','INTO','VALUES','UPDATE','SET','DELETE',
  'CASE','WHEN','THEN','ELSE','END','WITH','RECURSIVE','DISTINCT','TOP',
  'FETCH','FIRST','NEXT','ROWS','ONLY','PARTITION','OVER','WINDOW',
  'CREATE','TABLE','VIEW','INDEX','DROP','ALTER','ADD','COLUMN',
  'PRIMARY','KEY','FOREIGN','REFERENCES','CONSTRAINT','UNIQUE','DEFAULT',
  'CAST','CONVERT','ASC','DESC','TRUE','FALSE','LATERAL','QUALIFY',
  'GENERATED','ALWAYS','IDENTITY','RETURNING','EXTRACT'
]);

function tokenize(sql) {
  const tokens = [];
  let i = 0;
  const len = sql.length;

  while (i < len) {
    const ch = sql[i];

    if (/\s/.test(ch)) {
      let j = i;
      while (j < len && /\s/.test(sql[j])) j++;
      tokens.push({ type: 'ws', value: sql.slice(i, j) });
      i = j; continue;
    }

    if (ch === '-' && sql[i + 1] === '-') {
      let j = i;
      while (j < len && sql[j] !== '\n') j++;
      tokens.push({ type: 'comment', value: sql.slice(i, j) });
      i = j; continue;
    }

    if (ch === '/' && sql[i + 1] === '*') {
      let j = i + 2;
      while (j < len - 1 && !(sql[j] === '*' && sql[j + 1] === '/')) j++;
      j = Math.min(len, j + 2);
      tokens.push({ type: 'comment', value: sql.slice(i, j) });
      i = j; continue;
    }

    if (ch === "'") {
      let j = i + 1;
      while (j < len) {
        if (sql[j] === "'" && sql[j + 1] === "'") { j += 2; continue; }
        if (sql[j] === "'") { j++; break; }
        j++;
      }
      tokens.push({ type: 'string', value: sql.slice(i, j) });
      i = j; continue;
    }

    if (ch === '"' || ch === '`') {
      const close = ch;
      let j = i + 1;
      while (j < len && sql[j] !== close) j++;
      j = Math.min(len, j + 1);
      tokens.push({ type: 'identifier', value: sql.slice(i, j) });
      i = j; continue;
    }
    if (ch === '[') {
      let j = i + 1;
      while (j < len && sql[j] !== ']') j++;
      j = Math.min(len, j + 1);
      tokens.push({ type: 'identifier', value: sql.slice(i, j) });
      i = j; continue;
    }

    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(sql[i + 1] || ''))) {
      let j = i;
      while (j < len && /[0-9.]/.test(sql[j])) j++;
      tokens.push({ type: 'number', value: sql.slice(i, j) });
      i = j; continue;
    }

    if (/[=<>!+\-*\/%,;().|&^]/.test(ch)) {
      const two = sql.slice(i, i + 2);
      if (['<=', '>=', '<>', '!=', '||', '&&', '::'].includes(two)) {
        tokens.push({ type: 'operator', value: two });
        i += 2; continue;
      }
      if (',;().'.includes(ch)) {
        tokens.push({ type: 'punct', value: ch });
      } else {
        tokens.push({ type: 'operator', value: ch });
      }
      i++; continue;
    }

    if (/[A-Za-z_]/.test(ch)) {
      let j = i;
      while (j < len && /[A-Za-z0-9_]/.test(sql[j])) j++;
      const word = sql.slice(i, j);
      const upper = word.toUpperCase();

      let k = j;
      while (k < len && /\s/.test(sql[k])) k++;
      const isFunction = sql[k] === '(' && !SQL_KEYWORDS.has(upper);

      if (SQL_KEYWORDS.has(upper)) tokens.push({ type: 'keyword', value: word });
      else if (isFunction) tokens.push({ type: 'function', value: word });
      else tokens.push({ type: 'identifier', value: word });
      i = j; continue;
    }

    tokens.push({ type: 'other', value: ch });
    i++;
  }

  return tokens;
}

function escapeHtml(s) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function highlight(sql) {
  const tokens = tokenize(sql);
  return tokens.map(t => {
    const escaped = escapeHtml(t.value);
    switch (t.type) {
      case 'keyword':    return `<span class="tok-kw">${escaped}</span>`;
      case 'function':   return `<span class="tok-fn">${escaped}</span>`;
      case 'string':     return `<span class="tok-str">${escaped}</span>`;
      case 'number':     return `<span class="tok-num">${escaped}</span>`;
      case 'comment':    return `<span class="tok-com">${escaped}</span>`;
      case 'operator':   return `<span class="tok-op">${escaped}</span>`;
      case 'identifier': return `<span class="tok-id">${escaped}</span>`;
      default:           return escaped;
    }
  }).join('');
}

/* =========================================================
   State + API
   ========================================================= */
const state = {
  token: localStorage.getItem('sqlforge_token') || null,
  user: null,
  dialects: [],
  lastConvert: null,
  currentView: 'landing',
  mode: 'both',
};

async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (state.token) headers['Authorization'] = `Bearer ${state.token}`;
  try {
    const res = await fetch(API + path, { ...opts, headers });
    let data = null;
    try { data = await res.json(); } catch (e) {}
    return { ok: res.ok, status: res.status, data };
  } catch (e) {
    return { ok: false, status: 0, data: { error: 'Network error' } };
  }
}

const $ = id => document.getElementById(id);

function showToast(msg, isError = false) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.toggle('error', !!isError);
  t.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => t.classList.remove('show'), 1800);
}

function setView(name) {
  state.currentView = name;
  document.body.dataset.view = name;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  const target = $('view-' + name);
  if (target) {
    target.classList.add('active');
    target.querySelectorAll('.reveal').forEach(el => {
      el.style.animation = 'none';
      void el.offsetWidth;
      el.style.animation = '';
    });
  }
  document.body.classList.remove('menu-open');
  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (name === 'history') loadHistory();
  if (name === 'saved') loadSaved();
}

async function loadDialects() {
  const res = await api('/api/dialects');
  if (!res.ok || !res.data) {
    state.dialects = [
      { id: 'mssql', name: 'MSSQL' }, { id: 'postgresql', name: 'PostgreSQL' },
      { id: 'mysql', name: 'MySQL' }, { id: 'oracle', name: 'Oracle' },
      { id: 'sqlite', name: 'SQLite' },
    ];
  } else {
    state.dialects = res.data.dialects;
  }
  const srcSel = $('srcDialect');
  const tgtSel = $('tgtDialect');
  const opts = state.dialects.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
  srcSel.innerHTML = opts;
  tgtSel.innerHTML = opts;
  srcSel.value = 'mssql';
  tgtSel.value = 'postgresql';
  updateLabels();
}

function updateLabels() {
  const find = id => state.dialects.find(d => d.id === id);
  const s = find($('srcDialect').value);
  const t = find($('tgtDialect').value);
  if (s) $('srcLabel').textContent = s.name;
  if (t) $('tgtLabel').textContent = t.name;
}

async function checkAuth() {
  if (!state.token) {
    document.body.classList.remove('authed');
    renderAuthArea();
    return;
  }
  const res = await api('/api/auth/me');
  if (res.ok && res.data && res.data.authenticated) {
    state.user = res.data.user;
    document.body.classList.add('authed');
  } else {
    state.token = null;
    state.user = null;
    localStorage.removeItem('sqlforge_token');
    document.body.classList.remove('authed');
  }
  renderAuthArea();
}

function renderAuthArea() {
  const desktop = $('authArea');
  const drawer = $('drawerAuth');
  if (state.user) {
    desktop.innerHTML = `
      <span class="user-chip">${escapeHtml(state.user.email)}</span>
      <button class="btn btn-ghost" id="logoutBtn">Sign out</button>
    `;
    drawer.innerHTML = `
      <div style="font-size: 13px; color: var(--text-2); padding: 8px;">${escapeHtml(state.user.email)}</div>
      <button class="btn btn-glass" id="logoutBtnM">Sign out</button>
    `;
    $('logoutBtn').onclick = logout;
    $('logoutBtnM').onclick = logout;
  } else {
    desktop.innerHTML = `
      <button class="btn btn-ghost" id="loginBtn">Sign in</button>
      <button class="btn btn-primary" id="signupBtn">Get started</button>
    `;
    drawer.innerHTML = `
      <button class="btn btn-glass" id="loginBtnM">Sign in</button>
      <button class="btn btn-primary" id="signupBtnM">Get started</button>
    `;
    $('loginBtn').onclick = () => openAuth('login');
    $('signupBtn').onclick = () => openAuth('signup');
    $('loginBtnM').onclick = () => openAuth('login');
    $('signupBtnM').onclick = () => openAuth('signup');
  }
}

let authMode = 'login';

function openAuth(mode) {
  authMode = mode;
  document.body.classList.remove('menu-open');
  $('authTitle').textContent = mode === 'login' ? 'Sign in' : 'Create account';
  $('authSub').textContent = mode === 'login'
    ? 'Welcome back. Sign in to save queries and view history.'
    : 'Create a free account to save queries and view your history.';
  $('authSubmit').textContent = mode === 'login' ? 'Sign in' : 'Create account';
  $('authSwitchText').textContent = mode === 'login' ? "Don't have an account?" : 'Already have an account?';
  $('authSwitchBtn').textContent = mode === 'login' ? 'Sign up' : 'Sign in';
  $('authError').textContent = '';
  $('authPassword').setAttribute('autocomplete', mode === 'login' ? 'current-password' : 'new-password');
  $('authModal').classList.add('open');
  setTimeout(() => $('authEmail').focus(), 80);
}

function closeModal(el) { el.classList.remove('open'); }

async function submitAuth(e) {
  e.preventDefault();
  const email = $('authEmail').value.trim();
  const password = $('authPassword').value;
  $('authError').textContent = '';
  $('authSubmit').disabled = true;
  $('authSubmit').textContent = '…';

  const res = await api(`/api/auth/${authMode === 'login' ? 'login' : 'signup'}`, {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  $('authSubmit').disabled = false;
  $('authSubmit').textContent = authMode === 'login' ? 'Sign in' : 'Create account';

  if (!res.ok) {
    $('authError').textContent = (res.data && res.data.error) || 'Something went wrong';
    return;
  }

  state.token = res.data.token;
  state.user = res.data.user;
  localStorage.setItem('sqlforge_token', state.token);
  document.body.classList.add('authed');
  renderAuthArea();
  closeModal($('authModal'));
  showToast(authMode === 'login' ? 'Welcome back' : 'Welcome!');
}

async function logout() {
  await api('/api/auth/logout', { method: 'POST' });
  state.token = null;
  state.user = null;
  localStorage.removeItem('sqlforge_token');
  document.body.classList.remove('authed');
  renderAuthArea();
  setView('landing');
  showToast('Signed out');
}

function updateLineNumbers() {
  const input = $('inputSQL');
  const lnIn = $('lnInput');
  const lines = (input.value.split('\n').length) || 1;
  lnIn.innerHTML = Array.from({ length: lines }, (_, i) => i + 1).join('<br>');
}

function setOutputLineNumbers(text) {
  const lnOut = $('lnOutput');
  const lines = (text || '').split('\n').length;
  lnOut.innerHTML = Array.from({ length: lines }, (_, i) => i + 1).join('<br>');
}

function getOpt(name) {
  const el = document.querySelector(`.toggle[data-opt="${name}"]`);
  return el && el.classList.contains('active');
}

function setActivePane(which) {
  document.querySelectorAll('.pane-tab').forEach(t => {
    const isActive = t.dataset.pane === which;
    t.classList.toggle('active', isActive);
    t.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });
  const src = document.querySelector('.pane-source');
  const out = document.querySelector('.pane-output');
  if (src) src.classList.toggle('mobile-hidden', which !== 'source');
  if (out) out.classList.toggle('mobile-hidden', which !== 'output');
  if (which === 'output') {
    const badge = $('outputBadge');
    if (badge) badge.hidden = true;
  }
}

function isMobile() {
  return window.matchMedia('(max-width: 640px)').matches;
}

function setMode(mode) {
  state.mode = mode;
  document.body.dataset.mode = mode;
  document.querySelectorAll('.mode-btn').forEach(b => {
    const isActive = b.dataset.mode === mode;
    b.classList.toggle('active', isActive);
    b.setAttribute('aria-checked', isActive ? 'true' : 'false');
  });
  const desktopLabel = $('convertBtnText');
  const mobileLabel = $('mobileConvertText');
  const tgtLabel = $('tgtLabel');
  const btnText = mode === 'optimize' ? 'Optimize' : 'Convert';
  if (desktopLabel) desktopLabel.textContent = btnText;
  if (mobileLabel) mobileLabel.textContent = btnText;

  if (mode === 'optimize') {
    $('tgtDialect').value = $('srcDialect').value;
    if (tgtLabel) {
      const d = state.dialects.find(x => x.id === $('srcDialect').value);
      tgtLabel.textContent = d ? d.name : '';
    }
  }
  updateLabels();
}

function setStatus(text, kind = '') {
  $('wsStatusText').textContent = text;
  const ws = $('wsStatus');
  ws.classList.remove('busy', 'error');
  if (kind) ws.classList.add(kind);
}

function resetStats() {
  $('statBigO').textContent = 'O(?)';
  $('statBigOSub').textContent = 'Run conversion to estimate';
  $('statCost').textContent = '—';
  $('statCostSub').textContent = 'Relative scan + join cost';
  $('statCostSub').className = 'stat-sub';
  $('costFill').style.width = '0%';
  $('statOpt').textContent = '0';
  $('statOptSub').textContent = 'Function & syntax fixes';
  $('statIssues').textContent = '0';
  $('statIssuesSub').textContent = 'Anti-patterns + warnings';
}

function countUp(el, to, duration = 600) {
  const start = parseInt(el.textContent) || 0;
  const startTime = performance.now();
  function step(now) {
    const t = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    el.textContent = Math.round(start + (to - start) * eased);
    if (t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function renderReport(items) {
  const list = $('reportList');
  if (!items || !items.length) {
    list.innerHTML = `
      <div class="empty-report">
        <div class="empty-icon" style="color: var(--green); opacity: 1;">✓</div>
        No issues found — query looks clean.
      </div>`;
    return;
  }
  list.innerHTML = items.map((it, idx) => `
    <div class="report-item ${it.type}" style="animation-delay: ${idx * 0.05}s">
      <div class="report-tag">${it.type === 'crit' ? 'Critical' : it.type === 'warn' ? 'Warning' : it.type === 'ok' ? 'Improved' : 'Info'}</div>
      <div class="report-body">
        <strong>${escapeHtml(it.title)}</strong>
        <span>${escapeHtml(it.desc)}</span>
      </div>
      <div class="report-impact">${it.impact ? 'Impact · ' + escapeHtml(it.impact) : ''}</div>
    </div>
  `).join('');
}

async function doConvert() {
  const sql = $('inputSQL').value.trim();
  if (!sql) { showToast('Paste a query first', true); return; }

  setStatus('Working…', 'busy');
  $('loader').classList.add('on');
  $('convertBtn').disabled = true;
  const mobileBtn = $('mobileConvertBtn');
  if (mobileBtn) mobileBtn.disabled = true;

  const srcDialect = $('srcDialect').value;
  const tgtDialect = state.mode === 'optimize' ? srcDialect : $('tgtDialect').value;

  const t0 = performance.now();
  const res = await api('/api/convert', {
    method: 'POST',
    body: JSON.stringify({
      sql,
      source_dialect: srcDialect,
      target_dialect: tgtDialect,
      mode: state.mode,
      format: getOpt('format'),
    }),
  });
  const t1 = performance.now();

  $('loader').classList.remove('on');
  $('convertBtn').disabled = false;
  if (mobileBtn) mobileBtn.disabled = false;

  if (!res.ok || !res.data) {
    setStatus('Server error', 'error');
    showToast('Server error — check connection', true);
    return;
  }

  const data = res.data;
  if (data.ok === false) {
    setStatus('Parse error', 'error');
    $('outputSQL').innerHTML = `<span class="tok-com">-- ${escapeHtml(data.error)}</span>`;
    setOutputLineNumbers('');
    resetStats();
    renderReport([{
      type: 'crit',
      title: 'Could not parse source query',
      desc: data.error || 'The query could not be parsed in the selected source dialect. Check the dialect and syntax.',
      impact: '—',
    }]);
    $('reportTime').textContent = `Failed · ${(t1 - t0).toFixed(0)} ms`;
    return;
  }

  state.lastConvert = data;
  const out = data.output_sql || '';
  $('outputSQL').innerHTML = highlight(out);
  setOutputLineNumbers(out);

  if (isMobile()) {
    setActivePane('output');
    if (navigator.vibrate) navigator.vibrate(10);
  }

  const cx = data.complexity || {};
  $('statBigO').textContent = cx.bigO || 'O(?)';
  $('statBigOSub').textContent = cx.desc || '';

  const cost = cx.cost != null ? cx.cost : 0;
  countUp($('statCost'), cost);
  setTimeout(() => $('statCost').textContent = `${cost} / 100`, 650);
  $('costFill').style.width = cost + '%';
  $('statCostSub').textContent = cx.costLabel || '';
  $('statCostSub').className = 'stat-sub ' + (cx.costClass || '');

  const stats = data.stats || {};
  countUp($('statOpt'), stats.conversions_applied || 0);
  $('statOptSub').textContent = (stats.conversions_applied || 0) === 0
    ? 'No rewrites needed' : 'Function & syntax fixes';
  countUp($('statIssues'), stats.issues_found || 0);
  $('statIssuesSub').textContent = (stats.issues_found || 0) === 0
    ? 'No anti-patterns found' : 'See report below';

  const allNotes = [...(data.conversion_notes || []), ...(data.issues || [])];
  renderReport(allNotes);
  $('reportTime').textContent = `Generated · ${(t1 - t0).toFixed(0)} ms`;
  setStatus('Ready');
}

function fmtTime(unix) {
  const d = new Date(unix * 1000);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)}d ago`;
  return d.toLocaleDateString();
}

async function loadHistory() {
  const list = $('historyList');
  list.innerHTML = '<div class="empty-report"><div class="empty-icon">◌</div>Loading…</div>';

  if (!state.user) {
    list.innerHTML = '<div class="empty-report"><div class="empty-icon">🔒</div>Sign in to view history.</div>';
    return;
  }
  const res = await api('/api/history');
  if (!res.ok) {
    list.innerHTML = '<div class="empty-report">Could not load history.</div>';
    return;
  }
  const items = res.data.history || [];
  if (!items.length) {
    list.innerHTML = '<div class="empty-report"><div class="empty-icon">∅</div>No conversions yet. Run one and it will appear here.</div>';
    return;
  }
  list.innerHTML = items.map((h, idx) => `
    <div class="history-item reveal" data-id="${h.id}" style="--delay: ${idx * 0.04}s">
      <div class="history-meta">
        <div><span class="dialect-pill">${escapeHtml(h.source_dialect)}</span> → <span class="dialect-pill">${escapeHtml(h.target_dialect)}</span></div>
        <div style="margin-top:6px">${fmtTime(h.created_at)}</div>
      </div>
      <div class="history-snippet">${escapeHtml(h.source_sql.split('\n')[0].slice(0, 120))}</div>
      <div class="history-meta">${escapeHtml((h.complexity && h.complexity.bigO) || '')}</div>
    </div>
  `).join('');
  list.querySelectorAll('.history-item').forEach(el => {
    el.addEventListener('click', () => {
      const id = parseInt(el.dataset.id);
      const item = items.find(x => x.id === id);
      if (!item) return;
      $('srcDialect').value = item.source_dialect;
      $('tgtDialect').value = item.target_dialect;
      $('inputSQL').value = item.source_sql;
      updateLabels();
      updateLineNumbers();
      $('outputSQL').innerHTML = highlight(item.output_sql);
      setOutputLineNumbers(item.output_sql);
      setView('convert');
      showToast('Loaded from history');
    });
  });
}

async function loadSaved() {
  const list = $('savedList');
  list.innerHTML = '<div class="empty-report"><div class="empty-icon">◌</div>Loading…</div>';

  if (!state.user) {
    list.innerHTML = '<div class="empty-report"><div class="empty-icon">🔒</div>Sign in to view saved queries.</div>';
    return;
  }
  const res = await api('/api/saved');
  if (!res.ok) {
    list.innerHTML = '<div class="empty-report">Could not load saved queries.</div>';
    return;
  }
  const items = res.data.saved || [];
  if (!items.length) {
    list.innerHTML = '<div class="empty-report"><div class="empty-icon">∅</div>No saved queries yet.</div>';
    return;
  }
  list.innerHTML = items.map((h, idx) => `
    <div class="history-item reveal" data-id="${h.id}" style="--delay: ${idx * 0.04}s">
      <div>
        <div class="history-name">${escapeHtml(h.name)}</div>
        <div><span class="dialect-pill">${escapeHtml(h.source_dialect)}</span> → <span class="dialect-pill">${escapeHtml(h.target_dialect)}</span></div>
      </div>
      <div class="history-snippet">${escapeHtml(h.source_sql.split('\n')[0].slice(0, 120))}</div>
      <div class="history-actions">
        <button class="icon-btn delete-saved" data-id="${h.id}" title="Delete">×</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.history-item').forEach(el => {
    el.addEventListener('click', e => {
      if (e.target.classList.contains('delete-saved')) return;
      const id = parseInt(el.dataset.id);
      const item = items.find(x => x.id === id);
      if (!item) return;
      $('srcDialect').value = item.source_dialect;
      $('tgtDialect').value = item.target_dialect;
      $('inputSQL').value = item.source_sql;
      updateLabels();
      updateLineNumbers();
      $('outputSQL').innerHTML = highlight(item.output_sql);
      setOutputLineNumbers(item.output_sql);
      setView('convert');
      showToast('Loaded saved query');
    });
  });

  list.querySelectorAll('.delete-saved').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const r = await api('/api/saved/' + id, { method: 'DELETE' });
      if (r.ok) { showToast('Deleted'); loadSaved(); }
      else showToast('Failed to delete', true);
    });
  });
}

function init() {
  document.addEventListener('click', e => {
    const goEl = e.target.closest('[data-go]');
    if (goEl) {
      const v = goEl.dataset.go;
      if (['convert','landing','history','saved'].includes(v)) setView(v);
      return;
    }
    const navEl = e.target.closest('.nav-link');
    if (navEl && navEl.dataset.view) {
      if (navEl.dataset.authOnly !== undefined && !state.user) {
        openAuth('login'); return;
      }
      setView(navEl.dataset.view);
    }
  });

  $('menuToggle').addEventListener('click', () => {
    document.body.classList.toggle('menu-open');
  });

  document.addEventListener('click', e => {
    if (e.target.id === 'signupBtnHero' || e.target.id === 'signupBtnFooter') {
      openAuth('signup');
    }
  });

  document.querySelectorAll('.toggle').forEach(t => {
    t.addEventListener('click', e => {
      if (e.target.tagName === 'INPUT') return;
      t.classList.toggle('active');
      const cb = t.querySelector('input');
      cb.checked = t.classList.contains('active');
    });
  });

  $('srcDialect').addEventListener('change', () => {
    updateLabels();
    if (state.mode === 'optimize') {
      $('tgtDialect').value = $('srcDialect').value;
      updateLabels();
    }
  });
  $('tgtDialect').addEventListener('change', updateLabels);
  $('swapBtn').addEventListener('click', () => {
    if (state.mode === 'optimize') return;
    const a = $('srcDialect').value, b = $('tgtDialect').value;
    $('srcDialect').value = b; $('tgtDialect').value = a;
    updateLabels();
  });

  document.querySelectorAll('.mode-btn').forEach(b => {
    b.addEventListener('click', () => setMode(b.dataset.mode));
  });

  $('sampleBtn').addEventListener('click', () => {
    const src = $('srcDialect').value;
    $('inputSQL').value = SAMPLES[src] || SAMPLES.mssql;
    updateLineNumbers();
  });
  $('clearBtn').addEventListener('click', () => {
    $('inputSQL').value = '';
    updateLineNumbers();
    $('outputSQL').innerHTML = '<span class="placeholder">-- Cleared.</span>';
    setOutputLineNumbers('');
    resetStats();
    $('reportList').innerHTML = `
      <div class="empty-report">
        <div class="empty-icon">⌁</div>
        Run a conversion to see what changed and why.
      </div>`;
    $('reportTime').textContent = 'Awaiting input';
    setStatus('Ready');
  });

  $('copyInBtn').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText($('inputSQL').value); showToast('Source copied'); }
    catch { showToast('Copy blocked', true); }
  });
  $('pasteBtn').addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      $('inputSQL').value = text;
      updateLineNumbers();
    } catch { showToast('Clipboard blocked', true); }
  });
  $('copyOutBtn').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText($('outputSQL').textContent); showToast('Output copied'); }
    catch { showToast('Copy blocked', true); }
  });
  $('downloadBtn').addEventListener('click', () => {
    const blob = new Blob([$('outputSQL').textContent], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `query_${$('tgtDialect').value}.sql`;
    a.click();
    showToast('Downloaded');
  });

  $('convertBtn').addEventListener('click', doConvert);
  const mobileConvertBtn = $('mobileConvertBtn');
  if (mobileConvertBtn) mobileConvertBtn.addEventListener('click', doConvert);

  document.querySelectorAll('.pane-tab').forEach(tab => {
    tab.addEventListener('click', () => setActivePane(tab.dataset.pane));
  });

  $('inputSQL').addEventListener('focus', () => {
    if (isMobile() && document.querySelector('.pane-output:not(.mobile-hidden)')) {
      setActivePane('source');
    }
  });

  const mq = window.matchMedia('(max-width: 640px)');
  const onMq = e => {
    if (!e.matches) {
      document.querySelector('.pane-source')?.classList.remove('mobile-hidden');
      document.querySelector('.pane-output')?.classList.remove('mobile-hidden');
    } else {
      setActivePane(state.lastConvert ? 'output' : 'source');
    }
  };
  if (mq.addEventListener) mq.addEventListener('change', onMq);
  else mq.addListener(onMq);

  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      if (state.currentView === 'convert') {
        e.preventDefault();
        doConvert();
      }
    }
  });

  $('saveBtn').addEventListener('click', () => {
    if (!state.user) { openAuth('login'); return; }
    if (!state.lastConvert) { showToast('Run a conversion first', true); return; }
    $('saveModal').classList.add('open');
    setTimeout(() => $('saveName').focus(), 80);
  });

  $('inputSQL').addEventListener('input', updateLineNumbers);

  document.querySelectorAll('[data-close]').forEach(b => {
    b.addEventListener('click', () => closeModal(b.closest('.modal-backdrop')));
  });
  document.querySelectorAll('.modal-backdrop').forEach(b => {
    b.addEventListener('click', e => {
      if (e.target === b) closeModal(b);
    });
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.open').forEach(m => closeModal(m));
      document.body.classList.remove('menu-open');
    }
  });

  $('authForm').addEventListener('submit', submitAuth);
  $('authSwitchBtn').addEventListener('click', () => {
    openAuth(authMode === 'login' ? 'signup' : 'login');
  });

  $('saveForm').addEventListener('submit', async e => {
    e.preventDefault();
    const name = $('saveName').value.trim();
    if (!name || !state.lastConvert) return;
    const res = await api('/api/saved', {
      method: 'POST',
      body: JSON.stringify({
        name,
        source_dialect: $('srcDialect').value,
        target_dialect: $('tgtDialect').value,
        source_sql: $('inputSQL').value,
        output_sql: state.lastConvert.output_sql,
      }),
    });
    if (res.ok) {
      showToast('Saved');
      closeModal($('saveModal'));
      $('saveName').value = '';
    } else {
      showToast((res.data && res.data.error) || 'Save failed', true);
    }
  });
}

(async function boot() {
  init();
  await loadDialects();
  await checkAuth();
  setMode('both');
  setActivePane('source');
  $('inputSQL').value = SAMPLES.mssql;
  updateLineNumbers();
})();
