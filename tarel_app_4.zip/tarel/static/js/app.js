/* TAREL Management — App JS */

// ── Toast system ────────────────────────────────────────────
function showToast(msg, type = 'info') {
  const icons = {
    success: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`,
    error:   `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
    info:    `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
  };
  const wrap = document.getElementById('toast-wrap');
  if (!wrap) return;
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `${icons[type] || icons.info}<span>${msg}</span>`;
  wrap.appendChild(t);
  setTimeout(() => { t.style.transition = '.3s ease'; t.style.opacity = '0'; t.style.transform = 'translateY(-8px)'; setTimeout(() => t.remove(), 320); }, 3200);
}

// ── Confirm ─────────────────────────────────────────────────
function confirmAction(msg) { return confirm(msg || 'Are you sure?'); }

// ── Avatar menu ──────────────────────────────────────────────
document.addEventListener('click', function(e) {
  const avatar = document.querySelector('.avatar');
  const menu   = document.querySelector('.avatar-menu');
  if (!avatar || !menu) return;
  if (avatar.contains(e.target)) { menu.classList.toggle('open'); }
  else { menu.classList.remove('open'); }
});

// ── Bottom tab active ────────────────────────────────────────
document.querySelectorAll('.btab').forEach(tab => {
  const href = tab.getAttribute('href');
  if (href && window.location.pathname.startsWith(href) && href !== '/') {
    tab.classList.add('active');
  }
});

// ── Flash messages auto-dismiss ──────────────────────────────
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(a => {
    a.style.transition = '.4s'; a.style.opacity = '0'; a.style.transform = 'translateY(-6px)';
    setTimeout(() => a.remove(), 420);
  });
}, 5000);
