#!/bin/bash
echo ""
echo "=========================================="
echo "  TAREL Fish Delivery — Admin System"
echo "=========================================="
echo ""

if [ ! -f .env ]; then
    cp .env.example .env
    echo "  [!] .env created. Open it and fill in your DATABASE_URL and SECRET_KEY, then run ./run.sh again."
    open .env 2>/dev/null || nano .env 2>/dev/null || echo "  -> Please open .env in a text editor"
    exit 0
fi

# Detect python
PY=""
for cmd in python3 python3.11 python3.10 python3.9 python; do
    if command -v $cmd &>/dev/null; then
        PY=$cmd
        break
    fi
done
if [ -z "$PY" ]; then echo "Python not found. Install from python.org"; exit 1; fi

PIP=""
for cmd in pip3 pip; do
    if command -v $cmd &>/dev/null; then
        PIP=$cmd
        break
    fi
done

echo "  [1/3] Installing packages..."
$PIP install -r requirements.txt --quiet 2>/dev/null || \
$PIP install -r requirements.txt --user --quiet 2>/dev/null || \
$PY -m pip install -r requirements.txt --user --quiet

echo "  [2/3] Setting up database..."
$PY seed_data.py

echo "  [3/3] Starting TAREL..."
echo ""
echo "=========================================="
echo "  Open: http://localhost:5000"
echo "  Login: admin / tarel2026"
echo "  Stop: Ctrl+C"
echo "=========================================="
echo ""

# Open browser after 1.5 seconds
(sleep 1.5 && open http://localhost:5000 2>/dev/null || xdg-open http://localhost:5000 2>/dev/null) &

$PY app.py
