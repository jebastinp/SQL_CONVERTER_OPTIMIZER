# Tarel Rebuild — Continuation Plan

This document tracks where the rebuild is and what comes next. Each
phase is small enough to complete in a single follow-up turn.

---

## Status snapshot

| Layer / feature                                 | Status   |
|-------------------------------------------------|----------|
| **Foundation** (config, constants, DB, DI, R2) | ✅ done  |
| Request-ID middleware + per-file logs           | ✅ done  |
| Repository pattern + generic `AsyncRepository`  | ✅ done  |
| **Products module** (reference vertical slice)  | ✅ done  |
| **Supabase Auth** integration (backend)         | ✅ done  |
| **Users module** with postcode/address fields   | ✅ done  |
| Lazy-create user on first Supabase sign-in      | ✅ done  |
| Customer search by email/phone/postcode/code    | ✅ done  |
| **Vendor report** XLSX download                 | ✅ done  |
| Delivery utilities preserved verbatim           | ✅ done  |
| **VisionOS design system** (glass, depth, HIG)  | ✅ done  |
| Mobile bottom tab bar + safe-area insets        | ✅ done  |
| Hidden admin route via env slug + middleware    | ✅ done  |
| Supabase frontend client + AuthProvider         | ✅ done  |
| Auth-gated `AddToCartModal`                     | ✅ done  |
| Product search with debounced filtering         | ✅ done  |
| Login + Register + Profile pages                | ✅ done  |
| Toast notifications                             | ✅ done  |
| Next-delivery card (preserved logic)            | ✅ done  |
| Admin dashboard (KPI + next delivery)           | ✅ done  |
| Admin orders with priority + filters + search   | ✅ done  |
| Admin customers grid with email search          | ✅ done  |
| Admin reports page with download                | ✅ done  |
| PWA manifest + iOS Add-to-Home meta             | ✅ done  |
| **Categories module** (small)                   | ⏭ next   |
| **Orders module** (model→service→router)        | ⏭ next   |
| **Delivery module** routes (admin schedule)     | ⏭ next   |
| **Support module**                              | ⏭ next   |
| **Site settings** module                        | ⏭ next   |
| Alembic migration for the new schema            | ⏭ next   |
| Data-copy script from legacy `tarel.dump`       | ⏭ next   |
| Order detail pages (user + admin)               | ⏭ next   |
| Cart page + checkout flow                       | ⏭ next   |
| Stripe payment integration                      | ⏭ next   |
| Email templates (order confirmation, OTP)       | ⏭ next   |
| Unit tests per module                           | ⏭ next   |
| Dockerfile + docker-compose for prod            | ⏭ next   |
| CI (GitHub Actions) for lint + typecheck + test | ⏭ next   |

---

## Recommended order for the next turns

Each row is roughly one focused conversation turn.

### Turn 1 — Categories + Orders (the big one)
- `app/modules/categories/` — small, warms up to the orders pattern
- `app/modules/orders/` — models (Order, OrderItem), schemas, repo, service (preserving the status machine + cancellation rules verbatim), router
- Frontend: order detail page (user view), order detail page (admin view with status controls)

### Turn 2 — Cart → Checkout → Stripe
- `lib/api/orders.ts` (typed bindings)
- `/cart` page using the existing `CartProvider`
- `/checkout` page that resolves the user's saved postcode, picks the next delivery window, and creates the Order via the backend
- Stripe payment intent flow (backend `/orders/{uuid}/payment-intent`, frontend Stripe Elements)

### Turn 3 — Delivery scheduling + Support
- `/admin/delivery` page for weekly delivery management
- Support module (user-facing inbox + admin reply UI)

### Turn 4 — Site settings + Email
- Site settings module
- Email service (SMTP) for order confirmations + password reset

### Turn 5 — Migrations + Tests + Production
- Alembic migration creating the new schema
- One-time data-copy script from the legacy dump
- Per-module pytest suites (using a fake repo to test services in isolation)
- Dockerfile + docker-compose.yml
- GitHub Actions CI workflow

---

## How to pick up next turn

Tell me which row above to start with. I'll mirror the Products
module's shape exactly:

```
app/modules/<feature>/
├── __init__.py
├── models.py        ← legacy schema + IdentityMixin
├── schemas.py       ← Pydantic In/Out
├── repository.py    ← extends AsyncRepository[ModelT]
├── service.py       ← business logic, unchanged from legacy
├── dependencies.py  ← FastAPI DI providers
└── router.py        ← thin HTTP layer
```

…then register the router in `app/main.py` and add typed bindings in
`web/lib/api/<feature>.ts`.
