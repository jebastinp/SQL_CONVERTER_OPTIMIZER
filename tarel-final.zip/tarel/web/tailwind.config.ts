import type { Config } from 'tailwindcss'

/**
 * Tarel Design System — "VisionOS-inspired material UI" on top of the
 * existing brand palette. The palette HEX values are unchanged
 * (#2F4135 / #708E53 / #E9E2D5) — what changes is how they're applied:
 * the beige is the wallpaper, white-glass + dark-glass are the
 * materials placed on top, and the dark/olive carry meaning (text,
 * primary actions, success states).
 *
 * Glass tokens, depth shadows, vibrancy colours, spring easings and
 * Apple type-scale sizes are added below. Class names that components
 * use (brand-dark, brand-olive, brand-beige, primary, secondary,
 * background) remain identical to the legacy apps.
 */
const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './providers/**/*.{ts,tsx}',
    './hooks/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          dark: '#2F4135',
          'dark-soft': '#3a4f42',
          olive: '#708E53',
          'olive-soft': '#84a564',
          'olive-deep': '#5d7842',
          beige: '#E9E2D5',
          'beige-soft': '#f1ece2',
          'beige-deep': '#d8cdb8',
        },
        primary: '#2F4135',
        secondary: '#708E53',
        background: '#E9E2D5',

        // Glass tints — used inside backdrop-filter contexts
        glass: {
          light: 'rgba(255,255,255,0.65)',
          'light-soft': 'rgba(255,255,255,0.45)',
          'light-strong': 'rgba(255,255,255,0.82)',
          dark: 'rgba(47,65,53,0.72)',
          'dark-soft': 'rgba(47,65,53,0.45)',
          border: 'rgba(255,255,255,0.55)',
          'border-dark': 'rgba(47,65,53,0.18)',
        },
      },

      // Apple HIG type scale — values from the iOS Human Interface
      // Guidelines, in px so they map cleanly to Tailwind.
      fontSize: {
        'caption-2': ['11px', { lineHeight: '13px', letterSpacing: '0.066em' }],
        caption: ['12px', { lineHeight: '16px', letterSpacing: '0' }],
        footnote: ['13px', { lineHeight: '18px', letterSpacing: '-0.008em' }],
        subhead: ['15px', { lineHeight: '20px', letterSpacing: '-0.024em' }],
        callout: ['16px', { lineHeight: '21px', letterSpacing: '-0.032em' }],
        body: ['17px', { lineHeight: '22px', letterSpacing: '-0.041em' }],
        headline: ['17px', { lineHeight: '22px', letterSpacing: '-0.041em' }],
        'title-3': ['20px', { lineHeight: '25px', letterSpacing: '-0.045em' }],
        'title-2': ['22px', { lineHeight: '28px', letterSpacing: '-0.026em' }],
        'title-1': ['28px', { lineHeight: '34px', letterSpacing: '-0.026em' }],
        'large-title': ['34px', { lineHeight: '41px', letterSpacing: '-0.024em' }],
      },
      fontFamily: {
        // -apple-system gives SF Pro on Apple devices natively (no web
        // font needed). Android/Windows fall back to Roboto/Segoe —
        // both 17pt-grid families that play well with the same metrics.
        sans: [
          '-apple-system',
          'BlinkMacSystemFont',
          'SF Pro Text',
          'SF Pro Display',
          'system-ui',
          'Segoe UI',
          'Roboto',
          'Helvetica Neue',
          'Arial',
          'sans-serif',
        ],
        display: [
          '-apple-system',
          'BlinkMacSystemFont',
          'SF Pro Display',
          'system-ui',
          'Segoe UI',
          'Roboto',
          'sans-serif',
        ],
      },

      // Radii match the iOS/visionOS card geometry — generous but not
      // pill-shaped (those are reserved for buttons & tags).
      borderRadius: {
        xs: '6px',
        sm: '10px',
        md: '14px',
        lg: '20px',
        xl: '26px',
        '2xl': '32px',
        card: '22px',
        sheet: '28px',
        pill: '9999px',
      },

      // Paired soft/hard shadows give the "floating glass" effect
      boxShadow: {
        glass:
          '0 1px 0 rgba(255,255,255,0.6) inset, 0 8px 24px -8px rgba(47,65,53,0.12), 0 2px 6px -2px rgba(47,65,53,0.08)',
        'glass-lg':
          '0 1px 0 rgba(255,255,255,0.7) inset, 0 24px 60px -20px rgba(47,65,53,0.22), 0 8px 18px -8px rgba(47,65,53,0.10)',
        'glass-dark':
          '0 1px 0 rgba(255,255,255,0.12) inset, 0 18px 48px -16px rgba(0,0,0,0.45), 0 6px 14px -6px rgba(0,0,0,0.18)',
        'inner-soft': 'inset 0 1px 0 rgba(255,255,255,0.7)',
        focus: '0 0 0 4px rgba(112,142,83,0.25)',
        tab: '0 -8px 28px -8px rgba(47,65,53,0.18)',
      },

      // backdrop-filter blur amounts mapped to Apple's "Material" tiers
      backdropBlur: {
        'apple-thin': '14px',
        'apple-regular': '22px',
        'apple-thick': '32px',
        'apple-ultra': '48px',
      },
      backdropSaturate: {
        125: '1.25',
        150: '1.5',
        180: '1.8',
      },

      // Spring-feel timings (Apple uses cubic-bezier(0.32, 0.72, 0, 1)
      // for most snappy transitions; we expose a few variants).
      transitionTimingFunction: {
        spring: 'cubic-bezier(0.32, 0.72, 0, 1)',
        'spring-gentle': 'cubic-bezier(0.4, 0.0, 0.2, 1)',
        'spring-bounce': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
      },

      // Safe-area utilities for iOS notch & home indicator
      spacing: {
        'safe-top': 'env(safe-area-inset-top)',
        'safe-bottom': 'env(safe-area-inset-bottom)',
        'safe-left': 'env(safe-area-inset-left)',
        'safe-right': 'env(safe-area-inset-right)',
        tap: '44px', // minimum tap target per HIG
      },

      keyframes: {
        'sheet-up': {
          '0%': { transform: 'translateY(100%)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        },
      },
      animation: {
        'sheet-up': 'sheet-up 320ms cubic-bezier(0.32, 0.72, 0, 1)',
        'fade-in': 'fade-in 240ms cubic-bezier(0.4, 0, 0.2, 1)',
        'scale-in': 'scale-in 220ms cubic-bezier(0.34, 1.56, 0.64, 1)',
        shimmer: 'shimmer 2s linear infinite',
      },
    },
  },
  plugins: [],
}

export default config
