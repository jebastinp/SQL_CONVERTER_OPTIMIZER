import type { Metadata, Viewport } from 'next'
import { BRAND } from '@/lib/constants'
import { AuthProvider } from '@/providers/AuthProvider'
import { CartProvider } from '@/providers/CartProvider'
import { ToastProvider } from '@/providers/ToastProvider'
import { MobileTabBar } from '@/components/layout/MobileTabBar'
import './globals.css'

export const metadata: Metadata = {
  title: BRAND.name,
  description: 'Fresh produce, delivered weekly.',
  icons: { icon: BRAND.logoPath, apple: BRAND.logoPath },
  // PWA / iOS Add-to-Home affordances
  appleWebApp: {
    capable: true,
    title: BRAND.name,
    statusBarStyle: 'black-translucent',
  },
  manifest: '/manifest.webmanifest',
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  // No max scale — we still want pinch-to-zoom for accessibility.
  themeColor: BRAND.palette.beige,
  viewportFit: 'cover', // edge-to-edge for iOS notch
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="pb-[max(env(safe-area-inset-bottom),0px)] md:pb-0">
        <AuthProvider>
          <CartProvider>
            <ToastProvider>
              {children}
              <MobileTabBar />
              {/* Spacer so content isn't hidden behind the mobile tab bar */}
              <div aria-hidden className="h-24 md:hidden" />
            </ToastProvider>
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
