'use client'

import { useState } from 'react'
import { FileSpreadsheet, Download, CheckCircle2 } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { apiDownload } from '@/lib/api/client'
import { useToast } from '@/providers/ToastProvider'

export default function AdminReportsPage() {
  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-title-1 font-bold">Reports</h1>
        <p className="text-footnote text-brand-dark/60 mt-1">
          Downloadable spreadsheets for vendors and operations
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <VendorReportCard />
      </div>
    </div>
  )
}

function VendorReportCard() {
  const toast = useToast()
  const [downloading, setDownloading] = useState(false)
  const [lastDownloadedAt, setLastDownloadedAt] = useState<Date | null>(null)

  async function onDownload() {
    setDownloading(true)
    try {
      const blob = await apiDownload('/admin/reports/vendor.xlsx')
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `tarel-vendor-report-${new Date().toISOString().slice(0, 10)}.xlsx`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      setLastDownloadedAt(new Date())
      toast.success('Report downloaded', 'Check your downloads folder')
    } catch (err) {
      toast.error(
        'Download failed',
        err instanceof Error ? err.message : 'Please try again',
      )
    } finally {
      setDownloading(false)
    }
  }

  return (
    <Card>
      <div className="flex items-start gap-3">
        <div className="w-11 h-11 rounded-pill bg-brand-olive/15 flex items-center justify-center shrink-0">
          <FileSpreadsheet className="w-5 h-5 text-brand-olive-deep" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-display font-semibold text-callout text-brand-dark">
            Vendor report
          </p>
          <p className="text-footnote text-brand-dark/65 mt-1">
            All products grouped by category, with codes, stock levels, and
            per-kg prices. Branded XLSX, opens in Excel / Numbers / Sheets.
          </p>
          {lastDownloadedAt && (
            <p className="text-caption text-brand-olive-deep mt-2 inline-flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Downloaded at {lastDownloadedAt.toLocaleTimeString()}
            </p>
          )}
          <Button
            className="mt-4"
            onClick={onDownload}
            loading={downloading}
            leadingIcon={<Download className="w-4 h-4" />}
          >
            Download XLSX
          </Button>
        </div>
      </div>
    </Card>
  )
}
