'use client'

import { notFound, useParams, useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { ADMIN_PATH, ROLES, ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { AdminSidebar } from '@/components/admin/AdminSidebar'

/**
 * Belt-and-braces: the middleware already rejects bad slugs and
 * non-admin sessions with a 404 rewrite. This layout does the same
 * checks on the client side so a stale cache or a direct render never
 * leaks the admin UI to the wrong user.
 */
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const params = useParams<{ adminSlug: string }>()
  const router = useRouter()
  const { user, loading } = useAuth()

  // If somehow the slug doesn't match (e.g. dev preview), 404 it.
  if (params?.adminSlug !== ADMIN_PATH) {
    notFound()
  }

  useEffect(() => {
    if (loading) return
    if (!user) {
      router.replace(ROUTES.adminLogin)
      return
    }
    if (user.role !== ROLES.admin) {
      // Not an admin — pretend the path doesn't exist.
      router.replace('/not-found')
    }
  }, [loading, user, router])

  if (loading || !user || user.role !== ROLES.admin) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-brand-dark/15 border-t-brand-olive animate-spin" />
          <p className="text-brand-dark/55 text-footnote">Loading…</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex bg-brand-beige">
      <AdminSidebar />
      <div className="flex-1 min-w-0">
        <main className="p-6">{children}</main>
      </div>
    </div>
  )
}
