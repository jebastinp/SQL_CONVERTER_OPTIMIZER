'use client'

import { useEffect, useMemo, useState } from 'react'
import { Flame } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { type OrderSummary } from '@/components/order/OrderCard'
import { SearchBar } from '@/components/product/SearchBar'
import { ORDERS_PER_ROW, ROUTES } from '@/lib/constants'
import { apiFetch } from '@/lib/api/client'

interface AdminOrderSummary extends OrderSummary {
  customer_name: string | null
  customer_email: string | null
  customer_postcode: string | null
  delivery_date: string | null // ISO date
}

type Filter = 'priority' | 'all' | 'delivered'

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<AdminOrderSummary[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<Filter>('priority')

  useEffect(() => {
    apiFetch<AdminOrderSummary[]>('/admin/orders')
      .then(setOrders)
      .catch((err: Error) => setError(err.message))
  }, [])

  const sorted = useMemo(() => {
    if (!orders) return []

    let list = orders
    if (filter === 'delivered') {
      list = list.filter((o) => o.status === 'delivered')
    } else if (filter === 'priority') {
      list = list.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled')
    }

    if (query.trim()) {
      const q = query.toLowerCase().trim()
      list = list.filter((o) => {
        return (
          (o.code ?? '').toLowerCase().includes(q) ||
          (o.customer_name ?? '').toLowerCase().includes(q) ||
          (o.customer_email ?? '').toLowerCase().includes(q) ||
          (o.customer_postcode ?? '').toLowerCase().includes(q)
        )
      })
    }

    // Priority sort: orders with earliest delivery_date first, then by created_at desc.
    return [...list].sort((a, b) => {
      if (filter === 'priority') {
        const ad = a.delivery_date ? new Date(a.delivery_date).getTime() : Infinity
        const bd = b.delivery_date ? new Date(b.delivery_date).getTime() : Infinity
        if (ad !== bd) return ad - bd
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    })
  }, [orders, filter, query])

  const gridCols =
    ORDERS_PER_ROW === 3
      ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
      : 'grid-cols-1 sm:grid-cols-2'

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-title-1 font-bold">Orders</h1>
          {orders && (
            <p className="text-footnote text-brand-dark/60 mt-1">
              {sorted.length} of {orders.length} · {ORDERS_PER_ROW} per row
            </p>
          )}
        </div>
        <div className="sm:w-80">
          <SearchBar
            value={query}
            onChange={setQuery}
            placeholder="Search code, customer, postcode…"
          />
        </div>
      </header>

      {/* Filter pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        <FilterChip
          active={filter === 'priority'}
          onClick={() => setFilter('priority')}
          icon={<Flame className="w-3.5 h-3.5" />}
        >
          Priority (next delivery)
        </FilterChip>
        <FilterChip active={filter === 'all'} onClick={() => setFilter('all')}>
          All
        </FilterChip>
        <FilterChip active={filter === 'delivered'} onClick={() => setFilter('delivered')}>
          Delivered
        </FilterChip>
      </div>

      {error ? (
        <Card>
          <p className="text-red-700 text-callout">{error}</p>
        </Card>
      ) : orders === null ? (
        <div className={`grid ${gridCols} gap-4`}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-40 rounded-card" />
          ))}
        </div>
      ) : sorted.length === 0 ? (
        <Card>
          <p className="text-brand-dark/70 text-callout">
            No orders match the current filter.
          </p>
        </Card>
      ) : (
        <div className={`grid ${gridCols} gap-4`}>
          {sorted.map((order) => (
            <AdminOrderCard
              key={order.id}
              order={order}
              href={`${ROUTES.adminOrders}/${order.id}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function FilterChip({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean
  onClick: () => void
  icon?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      className={`pill px-3.5 py-2 transition shrink-0 ${
        active
          ? 'bg-brand-dark text-white shadow-glass'
          : 'material-thin text-brand-dark/80 hover:bg-white/70'
      }`}
    >
      <span className="inline-flex items-center gap-1.5">
        {icon}
        {children}
      </span>
    </button>
  )
}

function AdminOrderCard({
  order,
  href,
}: {
  order: AdminOrderSummary
  href: string
}) {
  return (
    <a href={href} className="block">
      <Card interactive className="h-full">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-caption text-brand-dark/60">
              {order.code ?? order.id.slice(0, 8)}
            </p>
            <p className="font-display font-semibold text-callout text-brand-dark truncate mt-0.5">
              {order.customer_name ?? 'Unknown customer'}
            </p>
            {order.customer_email && (
              <p className="text-footnote text-brand-dark/60 truncate">
                {order.customer_email}
              </p>
            )}
          </div>
          <StatusBadge status={order.status} />
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 text-footnote">
          <div>
            <p className="text-caption text-brand-dark/55 uppercase tracking-wider">Items</p>
            <p className="text-brand-dark font-medium">{order.item_count}</p>
          </div>
          <div>
            <p className="text-caption text-brand-dark/55 uppercase tracking-wider">Total</p>
            <p className="text-brand-dark font-semibold">£{order.total_amount.toFixed(2)}</p>
          </div>
          {order.delivery_date && (
            <div className="col-span-2">
              <p className="text-caption text-brand-dark/55 uppercase tracking-wider">
                Delivery
              </p>
              <p className="text-brand-dark font-medium">
                {new Date(order.delivery_date).toLocaleDateString(undefined, {
                  weekday: 'short',
                  day: 'numeric',
                  month: 'short',
                })}
                {order.customer_postcode && (
                  <span className="text-brand-dark/55 font-normal">
                    {' '}· {order.customer_postcode}
                  </span>
                )}
              </p>
            </div>
          )}
        </div>
      </Card>
    </a>
  )
}

function StatusBadge({ status }: { status: OrderSummary['status'] }) {
  const TONE: Record<typeof status, string> = {
    pending: 'bg-amber-100/80 text-amber-900',
    paid: 'bg-sky-100/80 text-sky-900',
    processing: 'bg-violet-100/80 text-violet-900',
    out_for_delivery: 'bg-blue-100/80 text-blue-900',
    delivered: 'bg-emerald-100/80 text-emerald-900',
    cancelled: 'bg-red-100/80 text-red-900',
  }
  const LABEL: Record<typeof status, string> = {
    pending: 'Pending',
    paid: 'Paid',
    processing: 'Processing',
    out_for_delivery: 'Out',
    delivered: 'Delivered',
    cancelled: 'Cancelled',
  }
  return <span className={`pill ${TONE[status]}`}>{LABEL[status]}</span>
}
