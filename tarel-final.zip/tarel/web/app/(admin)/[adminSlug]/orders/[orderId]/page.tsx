'use client'

import { useParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Calendar, RotateCcw } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { BackButton } from '@/components/ui/BackButton'
import { StatusPill } from '@/components/ui/StatusPill'
import { Sheet } from '@/components/ui/Sheet'
import { Input } from '@/components/ui/Input'
import { ordersApi, type OrderDetail, type OrderStatus } from '@/lib/api/orders'
import { ROUTES } from '@/lib/constants'
import { useToast } from '@/providers/ToastProvider'

const NEXT_STATUSES: Partial<Record<OrderStatus, OrderStatus[]>> = {
  pending: ['paid', 'cancelled'],
  paid: ['processing', 'cancelled'],
  processing: ['out_for_delivery', 'cancelled'],
  out_for_delivery: ['delivered', 'cancelled'],
}

const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: 'Pending',
  paid: 'Mark as paid',
  processing: 'Start processing',
  out_for_delivery: 'Out for delivery',
  delivered: 'Mark delivered',
  cancelled: 'Cancel',
}

export default function AdminOrderDetailPage() {
  const params = useParams<{ orderId: string; adminSlug: string }>()
  const router = useRouter()
  const toast = useToast()
  const [order, setOrder] = useState<OrderDetail | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [updating, setUpdating] = useState(false)
  const [showRefund, setShowRefund] = useState(false)
  const [refundAmount, setRefundAmount] = useState('')
  const [refundReason, setRefundReason] = useState('')
  const [refunding, setRefunding] = useState(false)

  const orderId = params?.orderId

  useEffect(() => {
    if (!orderId) return
    ordersApi
      .adminGet(orderId)
      .then(setOrder)
      .catch((err: Error) => setError(err.message))
  }, [orderId])

  async function moveStatus(next: OrderStatus) {
    if (!orderId) return
    setUpdating(true)
    try {
      const updated = await ordersApi.adminUpdateStatus(orderId, next)
      setOrder(updated)
      toast.success('Status updated', `Order is now ${next.replace(/_/g, ' ')}`)
    } catch (err) {
      toast.error('Update failed', err instanceof Error ? err.message : 'Please try again')
    } finally {
      setUpdating(false)
    }
  }

  async function onRefund() {
    if (!orderId) return
    setRefunding(true)
    try {
      const amount = refundAmount ? parseFloat(refundAmount) : undefined
      await ordersApi.adminRefund(orderId, amount, refundReason || undefined)
      const fresh = await ordersApi.adminGet(orderId)
      setOrder(fresh)
      setShowRefund(false)
      setRefundAmount('')
      setRefundReason('')
      toast.success('Refund issued', 'The customer will be notified')
    } catch (err) {
      toast.error('Refund failed', err instanceof Error ? err.message : 'Please try again')
    } finally {
      setRefunding(false)
    }
  }

  if (error) {
    return (
      <Card>
        <p className="text-callout text-red-700">{error}</p>
      </Card>
    )
  }
  if (!order) {
    return (
      <div className="space-y-4 max-w-4xl">
        <BackButton fallbackHref={ROUTES.adminOrders} label="Orders" />
        <div className="skeleton h-40 rounded-card" />
        <div className="skeleton h-64 rounded-card" />
      </div>
    )
  }

  const allowed = NEXT_STATUSES[order.status] ?? []
  const canRefund =
    order.status !== 'cancelled' &&
    order.status !== 'pending' &&
    order.status !== 'delivered'

  return (
    <div className="space-y-5 max-w-4xl">
      <BackButton fallbackHref={ROUTES.adminOrders} label="Orders" />

      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-caption text-brand-dark/60">
              {order.code ?? order.id.slice(0, 8)}
            </p>
            <h1 className="font-display text-title-1 font-bold mt-1">Order</h1>
            <p className="text-footnote text-brand-dark/65 mt-1">
              Placed {new Date(order.created_at).toLocaleString()}
            </p>
          </div>
          <StatusPill status={order.status} />
        </div>

        {order.delivery_date && (
          <div className="mt-4 flex items-center gap-2 text-callout text-brand-dark/85">
            <Calendar className="w-4 h-4 text-brand-olive-deep" />
            <span>
              Delivery on{' '}
              <span className="font-medium">
                {new Date(order.delivery_date).toLocaleDateString(undefined, {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                })}
              </span>
            </span>
          </div>
        )}

        {allowed.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {allowed.map((next) => (
              <Button
                key={next}
                size="sm"
                variant={next === 'cancelled' ? 'outline' : 'primary'}
                onClick={() => moveStatus(next)}
                disabled={updating}
                className={
                  next === 'cancelled'
                    ? 'text-red-700 border-red-300/60'
                    : ''
                }
              >
                {STATUS_LABEL[next]}
              </Button>
            ))}
            {canRefund && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowRefund(true)}
                leadingIcon={<RotateCcw className="w-3.5 h-3.5" />}
              >
                Issue refund
              </Button>
            )}
          </div>
        )}
      </Card>

      <Card>
        <h2 className="font-display text-title-3 font-semibold">Items</h2>
        <ul className="mt-3 divide-y divide-brand-dark/10">
          {order.items.map((item) => (
            <li
              key={item.id}
              className="py-3 flex items-center justify-between gap-3 text-callout"
            >
              <div className="min-w-0 flex-1">
                <p className="font-medium text-brand-dark truncate">{item.product_name}</p>
                <p className="text-caption text-brand-dark/60">
                  {item.qty_kg.toFixed(1)} kg × £{item.price_per_kg.toFixed(2)}
                </p>
              </div>
              <p className="tabular-nums font-medium">£{item.line_total.toFixed(2)}</p>
            </li>
          ))}
        </ul>
        <div className="mt-4 pt-3 border-t border-brand-dark/10 flex items-center justify-between">
          <span className="font-display text-headline font-semibold">Total</span>
          <span className="font-display text-headline font-bold tabular-nums">
            £{order.total_amount.toFixed(2)}
          </span>
        </div>
      </Card>

      <Sheet
        open={showRefund}
        onClose={() => setShowRefund(false)}
        title="Issue refund"
        size="sm"
      >
        <div className="space-y-3">
          <Input
            label="Amount (£)"
            type="number"
            step="0.01"
            placeholder={order.total_amount.toFixed(2)}
            value={refundAmount}
            onChange={(e) => setRefundAmount(e.target.value)}
            hint="Leave blank for a full refund"
          />
          <Input
            label="Reason (optional)"
            value={refundReason}
            onChange={(e) => setRefundReason(e.target.value)}
            placeholder="Customer request"
          />
          <p className="text-footnote text-brand-dark/65">
            This will cancel the order and send a refund through HandyPay.
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowRefund(false)}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              fullWidth
              loading={refunding}
              onClick={onRefund}
            >
              Refund
            </Button>
          </div>
        </div>
      </Sheet>
    </div>
  )
}
