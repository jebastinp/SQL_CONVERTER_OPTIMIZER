'use client'

import { useEffect, useState } from 'react'
import { Mail, Phone, MapPin, Calendar, ChevronLeft, ChevronRight } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { SearchBar } from '@/components/product/SearchBar'
import { apiFetch } from '@/lib/api/client'

interface UserSummary {
  id: string
  user_code: string | null
  name: string
  email: string
  phone: string | null
  postcode: string | null
  role: 'user' | 'admin'
  created_at: string
  last_sign_in_at: string | null
}

interface Paged {
  items: UserSummary[]
  total: number
  page: number
  page_size: number
  total_pages: number
}

const PAGE_SIZE = 12

export default function AdminCustomersPage() {
  const [query, setQuery] = useState('')
  const [page, setPage] = useState(1)
  const [data, setData] = useState<Paged | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Reset to page 1 whenever the query changes
    setPage(1)
  }, [query])

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    const params = new URLSearchParams()
    if (query.trim()) params.set('q', query.trim())
    params.set('page', String(page))
    params.set('page_size', String(PAGE_SIZE))

    apiFetch<Paged>(`/admin/customers?${params.toString()}`)
      .then((res) => {
        if (!cancelled) {
          setData(res)
          setError(null)
        }
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [query, page])

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-title-1 font-bold">Customers</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            {data ? `${data.total} total` : '…'} · search by email, name, phone, postcode or code
          </p>
        </div>
        <div className="sm:w-80">
          <SearchBar value={query} onChange={setQuery} placeholder="Search customers…" />
        </div>
      </header>

      {error ? (
        <Card>
          <p className="text-red-700 text-callout">{error}</p>
        </Card>
      ) : loading && !data ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-44 rounded-card" />
          ))}
        </div>
      ) : !data || data.items.length === 0 ? (
        <Card>
          <p className="text-brand-dark/70 text-callout">
            {query ? `No customers match "${query}".` : 'No customers yet.'}
          </p>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.items.map((u) => (
              <CustomerCard key={u.id} customer={u} />
            ))}
          </div>
          <Pager page={data.page} totalPages={data.total_pages} onChange={setPage} />
        </>
      )}
    </div>
  )
}

function CustomerCard({ customer }: { customer: UserSummary }) {
  const initials = customer.name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0])
    .join('')
    .toUpperCase()

  return (
    <Card interactive className="h-full">
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-pill bg-brand-olive/15 text-brand-olive-deep font-display font-bold flex items-center justify-center shrink-0">
          {initials || '·'}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-display font-semibold text-callout text-brand-dark truncate">
                {customer.name}
              </p>
              <p className="text-caption text-brand-dark/55">
                {customer.user_code ?? customer.id.slice(0, 8)}
              </p>
            </div>
            {customer.role === 'admin' && (
              <span className="pill bg-brand-dark/10 text-brand-dark">Admin</span>
            )}
          </div>

          <ul className="mt-3 space-y-1.5 text-footnote text-brand-dark/75">
            <li className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 shrink-0 text-brand-dark/45" />
              <span className="truncate">{customer.email}</span>
            </li>
            {customer.phone && (
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 shrink-0 text-brand-dark/45" />
                <span>{customer.phone}</span>
              </li>
            )}
            {customer.postcode && (
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 shrink-0 text-brand-dark/45" />
                <span>{customer.postcode}</span>
              </li>
            )}
            <li className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 shrink-0 text-brand-dark/45" />
              <span>Joined {new Date(customer.created_at).toLocaleDateString()}</span>
            </li>
          </ul>
        </div>
      </div>
    </Card>
  )
}

function Pager({
  page,
  totalPages,
  onChange,
}: {
  page: number
  totalPages: number
  onChange: (next: number) => void
}) {
  if (totalPages <= 1) return null
  return (
    <div className="flex items-center justify-center gap-3 pt-2">
      <Button
        variant="outline"
        size="sm"
        disabled={page <= 1}
        onClick={() => onChange(page - 1)}
        leadingIcon={<ChevronLeft className="w-4 h-4" />}
      >
        Previous
      </Button>
      <span className="text-footnote text-brand-dark/70">
        Page {page} of {totalPages}
      </span>
      <Button
        variant="outline"
        size="sm"
        disabled={page >= totalPages}
        onClick={() => onChange(page + 1)}
        trailingIcon={<ChevronRight className="w-4 h-4" />}
      >
        Next
      </Button>
    </div>
  )
}
