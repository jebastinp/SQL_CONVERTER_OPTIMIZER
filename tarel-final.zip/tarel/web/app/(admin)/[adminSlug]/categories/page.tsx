'use client'

import { useEffect, useState } from 'react'
import { Plus, Edit, Trash2 } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Sheet } from '@/components/ui/Sheet'
import { categoriesApi, type Category } from '@/lib/api/categories'
import { useToast } from '@/providers/ToastProvider'

export default function AdminCategoriesPage() {
  const toast = useToast()
  const [categories, setCategories] = useState<Category[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [editing, setEditing] = useState<Category | null>(null)
  const [creating, setCreating] = useState(false)

  async function refresh() {
    try {
      setCategories(await categoriesApi.adminList())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load categories')
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  async function onDelete(cat: Category) {
    if (!confirm(`Delete "${cat.name}"? Products in this category will be orphaned.`)) {
      return
    }
    try {
      await categoriesApi.adminDelete(cat.id)
      toast.success('Category deleted')
      refresh()
    } catch (err) {
      toast.error('Delete failed', err instanceof Error ? err.message : 'Please try again')
    }
  }

  return (
    <div className="space-y-5">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-title-1 font-bold">Categories</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            {categories ? `${categories.length} categories` : '…'}
          </p>
        </div>
        <Button leadingIcon={<Plus className="w-4 h-4" />} onClick={() => setCreating(true)}>
          New category
        </Button>
      </header>

      {error ? (
        <Card>
          <p className="text-red-700 text-callout">{error}</p>
        </Card>
      ) : categories === null ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-28 rounded-card" />
          ))}
        </div>
      ) : categories.length === 0 ? (
        <Card>
          <p className="text-brand-dark/70 text-callout">No categories yet.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map((cat) => (
            <Card key={cat.id} interactive className="h-full">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-display font-semibold text-callout text-brand-dark truncate">
                    {cat.name}
                  </p>
                  <p className="text-caption text-brand-dark/55 truncate">/{cat.slug}</p>
                </div>
                <span
                  className={`pill ${
                    cat.is_active
                      ? 'bg-emerald-100/80 text-emerald-900'
                      : 'bg-gray-200/80 text-gray-700'
                  }`}
                >
                  {cat.is_active ? 'Active' : 'Inactive'}
                </span>
              </div>
              {cat.description && (
                <p className="text-footnote text-brand-dark/65 mt-2 line-clamp-2">
                  {cat.description}
                </p>
              )}
              <div className="mt-3 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  leadingIcon={<Edit className="w-3.5 h-3.5" />}
                  onClick={() => setEditing(cat)}
                >
                  Edit
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => onDelete(cat)}
                  className="text-red-700"
                  leadingIcon={<Trash2 className="w-3.5 h-3.5" />}
                >
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <CategorySheet
        open={creating}
        onClose={() => setCreating(false)}
        onSaved={() => {
          setCreating(false)
          refresh()
        }}
      />
      <CategorySheet
        open={editing !== null}
        category={editing ?? undefined}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null)
          refresh()
        }}
      />
    </div>
  )
}

function CategorySheet({
  open,
  category,
  onClose,
  onSaved,
}: {
  open: boolean
  category?: Category
  onClose: () => void
  onSaved: () => void
}) {
  const toast = useToast()
  const isEditing = category !== undefined
  const [name, setName] = useState(category?.name ?? '')
  const [slug, setSlug] = useState(category?.slug ?? '')
  const [description, setDescription] = useState(category?.description ?? '')
  const [active, setActive] = useState(category?.is_active ?? true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (open) {
      setName(category?.name ?? '')
      setSlug(category?.slug ?? '')
      setDescription(category?.description ?? '')
      setActive(category?.is_active ?? true)
      setError(null)
    }
  }, [open, category])

  async function onSave(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      const payload = {
        name,
        slug: slug || name.toLowerCase().replace(/\s+/g, '-'),
        description: description || null,
        is_active: active,
      }
      if (isEditing && category) {
        await categoriesApi.adminUpdate(category.id, payload)
      } else {
        await categoriesApi.adminCreate(payload)
      }
      toast.success(isEditing ? 'Category updated' : 'Category created')
      onSaved()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={isEditing ? 'Edit category' : 'New category'}
    >
      <form onSubmit={onSave} className="space-y-3">
        <Input
          label="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <Input
          label="Slug"
          value={slug}
          onChange={(e) => setSlug(e.target.value)}
          hint="URL fragment (e.g. 'fresh-greens'). Auto-generated from name if left blank."
        />
        <div className="space-y-1.5">
          <label className="block text-footnote font-medium text-brand-dark/80">
            Description
          </label>
          <textarea
            className="field min-h-[80px]"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <label className="flex items-center gap-2 text-callout">
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => setActive(e.target.checked)}
            className="w-4 h-4"
          />
          <span>Active (visible to customers)</span>
        </label>
        {error && (
          <p className="text-footnote text-red-700 bg-red-50/80 border border-red-200/60 rounded-md px-3 py-2">
            {error}
          </p>
        )}
        <div className="flex gap-2 pt-2">
          <Button type="button" variant="outline" fullWidth onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" fullWidth loading={saving}>
            {isEditing ? 'Save' : 'Create'}
          </Button>
        </div>
      </form>
    </Sheet>
  )
}
