'use client'

import { TrendingUp, ShoppingBag, Users, Box } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { NextDeliveryCard } from '@/components/delivery/NextDeliveryCard'
import { useAuth } from '@/providers/AuthProvider'

interface Kpi {
  label: string
  value: string
  delta?: string
  icon: React.ComponentType<{ className?: string }>
  tone: string
}

const KPIS: Kpi[] = [
  {
    label: 'Orders today',
    value: '—',
    icon: ShoppingBag,
    tone: 'bg-brand-olive/15 text-brand-olive-deep',
  },
  {
    label: 'Revenue this week',
    value: '—',
    icon: TrendingUp,
    tone: 'bg-emerald-100/80 text-emerald-700',
  },
  {
    label: 'Active customers',
    value: '—',
    icon: Users,
    tone: 'bg-sky-100/80 text-sky-700',
  },
  {
    label: 'Low-stock items',
    value: '—',
    icon: Box,
    tone: 'bg-amber-100/80 text-amber-800',
  },
]

export default function AdminDashboardPage() {
  const { user } = useAuth()
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'

  return (
    <div className="space-y-5">
      <header>
        <p className="text-footnote text-brand-dark/55">{greeting}</p>
        <h1 className="font-display text-title-1 font-bold mt-0.5">
          {user?.name?.split(' ')[0] ?? 'Welcome back'}
        </h1>
      </header>

      <NextDeliveryCard />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {KPIS.map((kpi) => (
          <KpiCard key={kpi.label} {...kpi} />
        ))}
      </div>

      <Card>
        <h2 className="font-display text-title-3 font-semibold mb-1">Recent activity</h2>
        <p className="text-footnote text-brand-dark/60">
          Orders and customer events will appear here once the orders module is migrated.
        </p>
      </Card>
    </div>
  )
}

function KpiCard({ label, value, icon: Icon, tone }: Kpi) {
  return (
    <Card className="overflow-hidden">
      <div className={`w-10 h-10 rounded-pill flex items-center justify-center ${tone}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-caption uppercase tracking-wider text-brand-dark/55 mt-3">{label}</p>
      <p className="font-display text-title-2 font-bold text-brand-dark mt-1">{value}</p>
    </Card>
  )
}
