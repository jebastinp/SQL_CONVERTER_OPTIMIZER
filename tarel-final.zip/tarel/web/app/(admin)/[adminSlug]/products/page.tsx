'use client'

import { useEffect, useMemo, useState } from 'react'
import Image from 'next/image'
import { Plus } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { SearchBar } from '@/components/product/SearchBar'
import { productsApi, type Product } from '@/lib/api/products'

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')

  useEffect(() => {
    productsApi
      .list()
      .then(setProducts)
      .catch((e: Error) => setError(e.message))
  }, [])

  const filtered = useMemo(() => {
    if (!products) return []
    if (!query.trim()) return products
    const q = query.toLowerCase().trim()
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.slug.toLowerCase().includes(q) ||
        (p.code ?? '').toLowerCase().includes(q) ||
        (p.category?.name ?? '').toLowerCase().includes(q),
    )
  }, [products, query])

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-title-1 font-bold">Products</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            {products ? `${filtered.length} of ${products.length}` : '…'} ·
            search by name, code or category
          </p>
        </div>
        <div className="flex items-center gap-2 sm:w-auto">
          <div className="flex-1 sm:w-72">
            <SearchBar value={query} onChange={setQuery} placeholder="Search products…" />
          </div>
          <Button leadingIcon={<Plus className="w-4 h-4" />}>New</Button>
        </div>
      </header>

      {error ? (
        <Card>
          <p className="text-red-700 text-callout">{error}</p>
        </Card>
      ) : products === null ? (
        <Card padded={false}>
          <div className="p-4 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="skeleton h-12 rounded-md" />
            ))}
          </div>
        </Card>
      ) : filtered.length === 0 ? (
        <Card>
          <p className="text-brand-dark/70 text-callout">
            {query ? `No products match "${query}".` : 'No products yet.'}
          </p>
        </Card>
      ) : (
        <Card padded={false} className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-footnote">
              <thead className="text-left text-brand-dark/55 bg-brand-beige/40">
                <tr>
                  <th className="px-4 py-3 font-medium text-caption uppercase tracking-wider">Product</th>
                  <th className="px-4 py-3 font-medium text-caption uppercase tracking-wider hidden md:table-cell">Category</th>
                  <th className="px-4 py-3 font-medium text-caption uppercase tracking-wider text-right">£ / kg</th>
                  <th className="px-4 py-3 font-medium text-caption uppercase tracking-wider text-right hidden sm:table-cell">Stock</th>
                  <th className="px-4 py-3 font-medium text-caption uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => (
                  <tr key={p.id} className="border-t border-glass-border-dark">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-brand-beige-deep/40 relative overflow-hidden shrink-0">
                          {p.image_url && (
                            <Image
                              src={p.image_url}
                              alt={p.name}
                              fill
                              sizes="40px"
                              className="object-cover"
                            />
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-brand-dark truncate">{p.name}</p>
                          <p className="text-caption text-brand-dark/55">
                            {p.code ?? p.id.slice(0, 8)}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-brand-dark/75 hidden md:table-cell">
                      {p.category?.name ?? '—'}
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">
                      £{(p.one_kg_price ?? p.price_per_kg).toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums hidden sm:table-cell">
                      {p.stock_kg.toFixed(1)} kg
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`pill ${
                          p.is_active
                            ? 'bg-emerald-100/80 text-emerald-900 ring-1 ring-emerald-200/60'
                            : 'bg-gray-200/80 text-gray-700 ring-1 ring-gray-300/60'
                        }`}
                      >
                        {p.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}
