'use client'

import { useEffect, useMemo, useState } from 'react'
import { CreditCard, RefreshCw, ExternalLink } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Sheet } from '@/components/ui/Sheet'
import { Input } from '@/components/ui/Input'
import { SearchBar } from '@/components/product/SearchBar'
import { apiFetch } from '@/lib/api/client'
import { ROUTES } from '@/lib/constants'
import { useToast } from '@/providers/ToastProvider'

interface PaymentRow {
  id: string
  code: string | null
  order_id: string
  order_code: string | null
  customer_name: string | null
  customer_email: string | null
  provider: string
  provider_payment_id: string | null
  amount: number
  currency: string
  status:
    | 'pending'
    | 'succeeded'
    | 'failed'
    | 'cancelled'
    | 'refunded'
    | 'partially_refunded'
  confirmed_at: string | null
  failure_reason: string | null
  created_at: string
  total_refunded: number
}

type StatusFilter = 'all' | 'succeeded' | 'pending' | 'failed' | 'refunded'

const STATUS_TONE: Record<PaymentRow['status'], string> = {
  pending: 'bg-amber-100/80 text-amber-900',
  succeeded: 'bg-emerald-100/80 text-emerald-900',
  failed: 'bg-red-100/80 text-red-900',
  cancelled: 'bg-gray-100/80 text-gray-700',
  refunded: 'bg-violet-100/80 text-violet-900',
  partially_refunded: 'bg-violet-100/80 text-violet-900',
}

const STATUS_LABEL: Record<PaymentRow['status'], string> = {
  pending: 'Pending',
  succeeded: 'Paid',
  failed: 'Failed',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
  partially_refunded: 'Partial refund',
}

export default function AdminPaymentsPage() {
  const [payments, setPayments] = useState<PaymentRow[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<StatusFilter>('all')
  const [refundTarget, setRefundTarget] = useState<PaymentRow | null>(null)

  useEffect(() => {
    let cancelled = false
    apiFetch<PaymentRow[]>('/admin/payments')
      .then((rows) => {
        if (!cancelled) setPayments(rows)
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const filtered = useMemo(() => {
    if (!payments) return []
    let list = payments
    if (filter !== 'all') {
      list = list.filter(
        (p) =>
          p.status === filter ||
          (filter === 'refunded' && p.status === 'partially_refunded'),
      )
    }
    if (query.trim()) {
      const q = query.toLowerCase().trim()
      list = list.filter(
        (p) =>
          (p.code ?? '').toLowerCase().includes(q) ||
          (p.order_code ?? '').toLowerCase().includes(q) ||
          (p.customer_name ?? '').toLowerCase().includes(q) ||
          (p.customer_email ?? '').toLowerCase().includes(q) ||
          (p.provider_payment_id ?? '').toLowerCase().includes(q),
      )
    }
    return list
  }, [payments, filter, query])

  async function onRefundComplete(refunded: PaymentRow) {
    setPayments((prev) =>
      prev
        ? prev.map((p) => (p.id === refunded.id ? refunded : p))
        : prev,
    )
    setRefundTarget(null)
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-title-1 font-bold">Payments</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            {payments ? `${filtered.length} of ${payments.length}` : '…'} · search by code,
            order, customer or provider id
          </p>
        </div>
        <div className="sm:w-80">
          <SearchBar
            value={query}
            onChange={setQuery}
            placeholder="Search payments…"
          />
        </div>
      </header>

      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {(['all', 'succeeded', 'pending', 'failed', 'refunded'] as StatusFilter[]).map(
          (f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`pill px-3.5 py-2 transition shrink-0 capitalize ${
                filter === f
                  ? 'bg-brand-dark text-white shadow-glass'
                  : 'material-thin text-brand-dark/80 hover:bg-white/70'
              }`}
            >
              {f}
            </button>
          ),
        )}
      </div>

      {error ? (
        <Card>
          <p className="text-red-700 text-callout">{error}</p>
        </Card>
      ) : payments === null ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="skeleton h-20 rounded-card" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <p className="text-brand-dark/70 text-callout">
            {query ? `No payments match "${query}".` : 'No payments yet.'}
          </p>
        </Card>
      ) : (
        <Card padded={false}>
          <ul className="divide-y divide-glass-border-dark">
            {filtered.map((p) => (
              <li key={p.id} className="px-4 py-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-caption text-brand-dark/60">
                        {p.code ?? p.id.slice(0, 8)}
                      </span>
                      <span className={`pill ${STATUS_TONE[p.status]}`}>
                        {STATUS_LABEL[p.status]}
                      </span>
                      <span className="text-caption text-brand-dark/50 capitalize">
                        via {p.provider}
                      </span>
                    </div>
                    <p className="font-display font-semibold text-callout text-brand-dark mt-1 truncate">
                      {p.customer_name ?? '(no customer name)'}
                      <span className="text-brand-dark/60 font-normal">
                        {' '}— {p.customer_email ?? ''}
                      </span>
                    </p>
                    <p className="text-footnote text-brand-dark/60 mt-0.5">
                      Order{' '}
                      <a
                        href={`${ROUTES.adminOrders}/${p.order_id}`}
                        className="text-brand-olive-deep hover:underline inline-flex items-center gap-1"
                      >
                        {p.order_code ?? p.order_id.slice(0, 8)}
                        <ExternalLink className="w-3 h-3" />
                      </a>{' '}
                      · {new Date(p.created_at).toLocaleString()}
                    </p>
                    {p.failure_reason && (
                      <p className="text-caption text-red-700 mt-1">
                        {p.failure_reason}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <p className="font-display text-title-3 font-bold text-brand-dark">
                        {p.currency} {p.amount.toFixed(2)}
                      </p>
                      {p.total_refunded > 0 && (
                        <p className="text-caption text-brand-dark/60">
                          refunded {p.currency} {p.total_refunded.toFixed(2)}
                        </p>
                      )}
                    </div>
                    {(p.status === 'succeeded' ||
                      p.status === 'partially_refunded') &&
                      p.total_refunded < p.amount && (
                        <Button
                          variant="outline"
                          size="sm"
                          leadingIcon={<RefreshCw className="w-3.5 h-3.5" />}
                          onClick={() => setRefundTarget(p)}
                        >
                          Refund
                        </Button>
                      )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {refundTarget && (
        <RefundSheet
          payment={refundTarget}
          onClose={() => setRefundTarget(null)}
          onSuccess={onRefundComplete}
        />
      )}
    </div>
  )
}

function RefundSheet({
  payment,
  onClose,
  onSuccess,
}: {
  payment: PaymentRow
  onClose: () => void
  onSuccess: (refunded: PaymentRow) => void
}) {
  const toast = useToast()
  const remaining = payment.amount - payment.total_refunded
  const [amount, setAmount] = useState(remaining.toFixed(2))
  const [reason, setReason] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function submit() {
    setBusy(true)
    setErr(null)
    try {
      const parsed = parseFloat(amount)
      if (Number.isNaN(parsed) || parsed <= 0) {
        throw new Error('Enter a positive amount.')
      }
      if (parsed > remaining + 0.001) {
        throw new Error(
          `Refund amount can't exceed remaining ${payment.currency} ${remaining.toFixed(2)}`,
        )
      }
      const updated = await apiFetch<PaymentRow>(
        `/admin/payments/${payment.id}/refund`,
        {
          method: 'POST',
          body: { amount: parsed, reason: reason || null },
        },
      )
      toast.success('Refund issued', `${payment.currency} ${parsed.toFixed(2)}`)
      onSuccess(updated)
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Refund failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Sheet open onClose={onClose} title="Issue refund" size="sm">
      <div className="space-y-4">
        <div className="material-thin rounded-card p-4">
          <p className="text-caption uppercase tracking-wider text-brand-dark/55">
            Payment
          </p>
          <p className="font-display text-title-3 font-bold mt-1">
            {payment.currency} {payment.amount.toFixed(2)}
          </p>
          <p className="text-footnote text-brand-dark/60 mt-1">
            Remaining refundable: {payment.currency} {remaining.toFixed(2)}
          </p>
        </div>
        <Input
          label={`Amount (${payment.currency})`}
          inputMode="decimal"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          leadingIcon={<CreditCard className="w-4 h-4" />}
        />
        <Input
          label="Reason (optional)"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g. customer cancelled before cutoff"
        />
        {err && (
          <p className="text-callout text-red-700 bg-red-50/80 border border-red-200/60 rounded-md px-3 py-2">
            {err}
          </p>
        )}
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} loading={busy} variant="danger">
            {busy ? 'Refunding…' : `Refund ${payment.currency} ${amount || '0.00'}`}
          </Button>
        </div>
      </div>
    </Sheet>
  )
}
