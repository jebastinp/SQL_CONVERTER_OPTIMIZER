'use client'

import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Lock, Mail } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { BRAND, ROLES, ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { useToast } from '@/providers/ToastProvider'

export default function AdminLoginPage() {
  const router = useRouter()
  const { signIn, signOut } = useAuth()
  const toast = useToast()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const user = await signIn(email, password)
      if (user.role !== ROLES.admin) {
        await signOut()
        throw new Error('This account does not have admin access.')
      }
      toast.success('Welcome back', `${user.name || user.email}`)
      router.replace(ROUTES.adminDashboard)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign in failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card material="thick" className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-5">
          <div className="w-14 h-14 rounded-pill bg-brand-olive/15 flex items-center justify-center">
            <Image src={BRAND.logoPath} alt={BRAND.name} width={36} height={36} />
          </div>
          <h1 className="mt-3 font-display text-title-2 font-bold">Admin sign in</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            Authorised personnel only
          </p>
        </div>

        <form onSubmit={onSubmit} className="space-y-3">
          <Input
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            leadingIcon={<Mail className="w-4 h-4" />}
            placeholder="you@tarel.com"
          />
          <Input
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            leadingIcon={<Lock className="w-4 h-4" />}
            placeholder="••••••••"
            error={error ?? undefined}
          />
          <Button type="submit" fullWidth loading={loading}>
            {loading ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>
      </Card>
    </div>
  )
}
