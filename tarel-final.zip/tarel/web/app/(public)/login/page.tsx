'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Lock, Mail } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { BackButton } from '@/components/ui/BackButton'
import { ROLES, ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { useToast } from '@/providers/ToastProvider'

export default function LoginPage() {
  const router = useRouter()
  const { signIn } = useAuth()
  const toast = useToast()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const user = await signIn(email, password)
      toast.success('Welcome back!', user.name || user.email)
      router.replace(user.role === ROLES.admin ? ROUTES.adminDashboard : ROUTES.account)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign in failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-sm mx-auto space-y-4">
      <BackButton fallbackHref={ROUTES.home} label="Home" />
      <Card material="thick">
        <header className="mb-5">
          <h1 className="font-display text-title-1 font-bold">Sign in</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            Welcome back. Pick up where you left off.
          </p>
        </header>

        <form onSubmit={onSubmit} className="space-y-3">
          <Input
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            leadingIcon={<Mail className="w-4 h-4" />}
            placeholder="you@example.com"
          />
          <Input
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            leadingIcon={<Lock className="w-4 h-4" />}
            placeholder="••••••••"
            error={error ?? undefined}
          />
          <Button type="submit" fullWidth loading={loading}>
            {loading ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>

        <p className="text-center text-footnote text-brand-dark/60 mt-5">
          New here?{' '}
          <Link href={ROUTES.register} className="font-medium text-brand-olive-deep hover:underline">
            Create an account
          </Link>
        </p>
      </Card>
    </div>
  )
}
