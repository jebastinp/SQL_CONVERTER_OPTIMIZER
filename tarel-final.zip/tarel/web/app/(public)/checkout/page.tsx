'use client'

import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { MapPin, Phone, User, ArrowRight, Lock } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { BackButton } from '@/components/ui/BackButton'
import { NextDeliveryCard } from '@/components/delivery/NextDeliveryCard'
import { ROUTES } from '@/lib/constants'
import { ordersApi } from '@/lib/api/orders'
import { useAuth } from '@/providers/AuthProvider'
import { useCart } from '@/providers/CartProvider'
import { useToast } from '@/providers/ToastProvider'

export default function CheckoutPage() {
  const router = useRouter()
  const { user, loading } = useAuth()
  const { lines, subtotal, itemCount } = useCart()
  const toast = useToast()
  const [placing, setPlacing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Auth guard
  useEffect(() => {
    if (!loading && !user) {
      router.replace(ROUTES.login + '?next=/checkout')
    }
  }, [loading, user, router])

  // Empty cart guard
  useEffect(() => {
    if (!loading && lines.length === 0) {
      router.replace(ROUTES.cart)
    }
  }, [loading, lines.length, router])

  async function placeAndPay() {
    setPlacing(true)
    setError(null)
    try {
      // 1. Place the order
      const order = await ordersApi.place({
        items: lines.map((l) => ({
          product_uuid: l.productUuid,
          qty_kg: l.quantityKg,
        })),
      })

      // 2. Start the HandyPay checkout
      const checkout = await ordersApi.startCheckout(order.id)

      // 3. Redirect the browser
      if (!checkout.checkout_url) {
        throw new Error('Payment gateway did not return a checkout URL')
      }
      window.location.href = checkout.checkout_url
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start checkout')
      setPlacing(false)
    }
  }

  if (loading || !user || lines.length === 0) {
    return (
      <div className="space-y-4 max-w-2xl">
        <div className="skeleton h-24 rounded-card" />
        <div className="skeleton h-48 rounded-card" />
        <div className="skeleton h-32 rounded-card" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <BackButton fallbackHref={ROUTES.cart} label="Cart" />
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
      <div className="space-y-4">
        <header>
          <h1 className="font-display text-title-1 font-bold">Checkout</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            Review your details and pay securely.
          </p>
        </header>

        {/* Delivery address */}
        <Card>
          <div className="flex items-start justify-between gap-3">
            <h2 className="font-display text-title-3 font-semibold">Delivery address</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.push(ROUTES.accountProfile)}
            >
              Edit
            </Button>
          </div>
          <dl className="mt-3 space-y-2 text-callout">
            <Row icon={<User className="w-4 h-4" />} label={user.name} />
            <Row icon={<Phone className="w-4 h-4" />} label={user.phone ?? 'No phone'} />
            <Row
              icon={<MapPin className="w-4 h-4" />}
              label={[
                user.address_line1,
                user.locality,
                user.city,
                user.postcode,
              ]
                .filter(Boolean)
                .join(', ') || 'No address yet — please update your profile.'}
            />
          </dl>
        </Card>

        {/* Order items */}
        <Card>
          <h2 className="font-display text-title-3 font-semibold">
            Your order ({itemCount})
          </h2>
          <ul className="mt-3 divide-y divide-brand-dark/10">
            {lines.map((line) => {
              const full = Math.floor(line.quantityKg)
              const hasHalf = line.quantityKg - full === 0.5
              const total = full * line.oneKgPrice + (hasHalf ? line.halfKgPrice : 0)
              return (
                <li
                  key={line.productUuid}
                  className="py-2.5 flex items-center justify-between text-callout"
                >
                  <span className="truncate min-w-0 flex-1">
                    {line.name}
                    <span className="text-brand-dark/55 text-footnote">
                      {' '}· {line.quantityKg.toFixed(1)} kg
                    </span>
                  </span>
                  <span className="font-medium tabular-nums ml-3">
                    £{total.toFixed(2)}
                  </span>
                </li>
              )
            })}
          </ul>
        </Card>
      </div>

      {/* Pay sidebar */}
      <aside className="space-y-4 lg:sticky lg:top-20 self-start">
        <NextDeliveryCard />
        <Card material="thick">
          <h2 className="font-display text-title-3 font-semibold">Summary</h2>
          <dl className="mt-3 space-y-2 text-callout">
            <div className="flex justify-between">
              <dt className="text-brand-dark/70">Subtotal</dt>
              <dd className="font-medium">£{subtotal.toFixed(2)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-brand-dark/70">Delivery</dt>
              <dd className="text-brand-olive-deep font-medium">Free</dd>
            </div>
            <div className="border-t border-brand-dark/10 my-2" />
            <div className="flex justify-between">
              <dt className="font-display text-headline font-semibold">Total</dt>
              <dd className="font-display text-headline font-bold">
                £{subtotal.toFixed(2)}
              </dd>
            </div>
          </dl>

          {error && (
            <p className="mt-3 text-footnote text-red-700 bg-red-50/80 border border-red-200/60 rounded-md px-3 py-2">
              {error}
            </p>
          )}

          <Button
            fullWidth
            size="lg"
            className="mt-4"
            loading={placing}
            onClick={placeAndPay}
            leadingIcon={<Lock className="w-4 h-4" />}
          >
            {placing ? 'Redirecting…' : 'Pay securely'}
          </Button>
          <p className="text-caption text-center text-brand-dark/55 mt-2">
            Powered by HandyPay
          </p>
        </Card>
      </aside>
    </div>
    </div>
  )
}

function Row({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-2.5 text-brand-dark/85">
      <span className="text-brand-dark/45">{icon}</span>
      <span className="min-w-0 truncate">{label}</span>
    </div>
  )
}
