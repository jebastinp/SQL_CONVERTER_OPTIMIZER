'use client'

import Link from 'next/link'
import { XCircle } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { ROUTES } from '@/lib/constants'

export default function CheckoutCancelledPage() {
  return (
    <div className="max-w-md mx-auto">
      <Card material="thick" className="text-center py-10">
        <div className="mx-auto w-14 h-14 rounded-pill bg-red-100 flex items-center justify-center">
          <XCircle className="w-8 h-8 text-red-700" />
        </div>
        <h1 className="font-display text-title-1 font-bold mt-4">Payment cancelled</h1>
        <p className="text-callout text-brand-dark/70 mt-2">
          No charge was made. Your cart is still saved.
        </p>
        <div className="flex flex-col gap-2 mt-6">
          <Link href={ROUTES.cart}>
            <Button fullWidth>Back to cart</Button>
          </Link>
          <Link href={ROUTES.home}>
            <Button fullWidth variant="outline">
              Keep shopping
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  )
}
