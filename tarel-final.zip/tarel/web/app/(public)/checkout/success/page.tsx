'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import { CheckCircle2, Loader2, ArrowRight } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { ROUTES } from '@/lib/constants'
import { ordersApi } from '@/lib/api/orders'
import { useCart } from '@/providers/CartProvider'

type Phase = 'polling' | 'success' | 'still_pending' | 'failed' | 'unknown'

export default function CheckoutSuccessPage() {
  const params = useSearchParams()
  const orderUuid = params?.get('order') ?? null
  const { clear } = useCart()

  const [phase, setPhase] = useState<Phase>('polling')
  const [error, setError] = useState<string | null>(null)
  const attemptsRef = useRef(0)

  // Poll the payment status until success / timeout
  useEffect(() => {
    if (!orderUuid) {
      setPhase('unknown')
      return
    }

    let cancelled = false

    async function poll() {
      try {
        const payment = await ordersApi.getPaymentStatus(orderUuid as string)
        if (cancelled) return

        if (payment.status === 'succeeded') {
          setPhase('success')
          clear()
          return
        }
        if (payment.status === 'failed' || payment.status === 'cancelled') {
          setPhase('failed')
          return
        }
        attemptsRef.current += 1
        if (attemptsRef.current >= 12) {
          // 12 attempts * 2.5s ≈ 30s
          setPhase('still_pending')
          return
        }
        setTimeout(poll, 2500)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Could not verify payment')
        setPhase('unknown')
      }
    }

    poll()
    return () => {
      cancelled = true
    }
  }, [orderUuid, clear])

  return (
    <div className="max-w-md mx-auto">
      <Card material="thick" className="text-center py-10">
        {phase === 'polling' && (
          <>
            <Loader2 className="w-10 h-10 mx-auto text-brand-olive animate-spin" />
            <p className="font-display text-title-2 font-bold mt-4">
              Confirming your payment…
            </p>
            <p className="text-footnote text-brand-dark/65 mt-1">
              This usually takes a few seconds.
            </p>
          </>
        )}

        {phase === 'success' && (
          <>
            <div className="mx-auto w-14 h-14 rounded-pill bg-emerald-100 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-700" />
            </div>
            <h1 className="font-display text-title-1 font-bold mt-4">Payment received</h1>
            <p className="text-callout text-brand-dark/70 mt-2">
              Thanks for your order — you&apos;ll get a confirmation email shortly.
            </p>
            <div className="flex flex-col gap-2 mt-6">
              {orderUuid && (
                <Link href={`${ROUTES.accountOrders}/${orderUuid}`}>
                  <Button
                    fullWidth
                    trailingIcon={<ArrowRight className="w-4 h-4" />}
                  >
                    View order
                  </Button>
                </Link>
              )}
              <Link href={ROUTES.home}>
                <Button fullWidth variant="outline">
                  Back to shop
                </Button>
              </Link>
            </div>
          </>
        )}

        {phase === 'still_pending' && (
          <>
            <Loader2 className="w-10 h-10 mx-auto text-brand-olive animate-spin" />
            <p className="font-display text-title-3 font-semibold mt-4">
              Still processing
            </p>
            <p className="text-footnote text-brand-dark/65 mt-1">
              Your payment is taking a bit longer. We&apos;ll email you the moment it&apos;s confirmed.
            </p>
            {orderUuid && (
              <Link href={`${ROUTES.accountOrders}/${orderUuid}`} className="block mt-5">
                <Button fullWidth>View order</Button>
              </Link>
            )}
          </>
        )}

        {phase === 'failed' && (
          <>
            <p className="font-display text-title-2 font-bold text-red-700">
              Payment failed
            </p>
            <p className="text-footnote text-brand-dark/70 mt-2">
              Your card wasn&apos;t charged. Please try again or use a different payment method.
            </p>
            <Link href={ROUTES.cart} className="block mt-5">
              <Button fullWidth>Back to cart</Button>
            </Link>
          </>
        )}

        {phase === 'unknown' && (
          <>
            <p className="font-display text-title-3 font-semibold">
              Couldn&apos;t verify payment
            </p>
            <p className="text-footnote text-red-700 mt-2">{error}</p>
            <Link href={ROUTES.accountOrders} className="block mt-5">
              <Button fullWidth>Check your orders</Button>
            </Link>
          </>
        )}
      </Card>
    </div>
  )
}
