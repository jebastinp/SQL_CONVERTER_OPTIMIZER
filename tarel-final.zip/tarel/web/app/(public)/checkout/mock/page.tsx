'use client'

/**
 * Mock checkout simulator.
 *
 * The MockPaymentGateway sends the customer here instead of to a real
 * provider. This page lets you (or QA, or the customer in a dev env)
 * click "Pay" or "Cancel" to simulate either outcome — and then
 * forwards the call to our own webhook endpoint so the rest of the
 * system experiences the same flow as a real gateway integration.
 *
 * In production with PAYMENT_GATEWAY=handypay, this page is never
 * reached — HandyPay's hosted checkout is shown instead.
 */

import { useRouter, useSearchParams } from 'next/navigation'
import { Suspense, useState } from 'react'
import { CheckCircle2, XCircle, ShieldCheck, Loader2 } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { API_BASE } from '@/lib/constants'

function MockCheckoutInner() {
  const router = useRouter()
  const params = useSearchParams()

  const paymentId = params.get('payment_id') ?? ''
  const orderUuid = params.get('order') ?? ''
  const amount = params.get('amount') ?? '0'
  const currency = params.get('currency') ?? 'USD'
  const successUrl = params.get('success') ?? '/checkout/success'
  const cancelUrl = params.get('cancel') ?? '/checkout/cancelled'

  const [busy, setBusy] = useState<'pay' | 'fail' | null>(null)

  async function notifyWebhook(eventType: 'payment.succeeded' | 'payment.failed') {
    // The mock gateway accepts any payload, no signature required.
    const body = {
      event_type: eventType,
      payment_id: paymentId,
      provider_payment_id: paymentId,
      amount: parseFloat(amount),
      currency,
    }
    try {
      await fetch(`${API_BASE}/webhook/handypay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
    } catch {
      // Even if the webhook call from the browser fails, the redirect
      // pages below show appropriate UI. The backend will reconcile
      // on next status poll.
    }
  }

  async function onPay() {
    setBusy('pay')
    await notifyWebhook('payment.succeeded')
    router.replace(successUrl + (successUrl.includes('?') ? '&' : '?') + `payment=${paymentId}`)
  }

  async function onFail() {
    setBusy('fail')
    await notifyWebhook('payment.failed')
    router.replace(cancelUrl + (cancelUrl.includes('?') ? '&' : '?') + `payment=${paymentId}`)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card material="thick" className="w-full max-w-md">
        <div className="text-center mb-5">
          <div className="mx-auto w-14 h-14 rounded-pill bg-brand-olive/15 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-brand-olive-deep" />
          </div>
          <p className="mt-3 text-caption uppercase tracking-wider text-brand-dark/55">
            Secure checkout (mock)
          </p>
          <h1 className="font-display text-title-2 font-bold text-brand-dark mt-1">
            {currency} {parseFloat(amount).toFixed(2)}
          </h1>
          <p className="text-footnote text-brand-dark/60 mt-2">
            This is a development simulator. In production, HandyPay's real hosted
            checkout appears here. Choose an outcome to test the flow.
          </p>
        </div>

        <div className="material-thin rounded-card p-3 text-caption font-mono text-brand-dark/60 break-all">
          payment_id: {paymentId}
          <br />
          order: {orderUuid}
        </div>

        <div className="mt-5 space-y-2">
          <Button
            fullWidth
            size="lg"
            onClick={onPay}
            loading={busy === 'pay'}
            leadingIcon={<CheckCircle2 className="w-5 h-5" />}
          >
            Pay {currency} {parseFloat(amount).toFixed(2)}
          </Button>
          <Button
            fullWidth
            variant="outline"
            onClick={onFail}
            loading={busy === 'fail'}
            leadingIcon={<XCircle className="w-4 h-4" />}
          >
            Simulate failure
          </Button>
        </div>
      </Card>
    </div>
  )
}

export default function MockCheckoutPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-brand-dark/40" />
        </div>
      }
    >
      <MockCheckoutInner />
    </Suspense>
  )
}
