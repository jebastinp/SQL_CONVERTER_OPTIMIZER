'use client'

import { useEffect, useMemo, useState } from 'react'
import { Card } from '@/components/ui/Card'
import { ProductCard } from '@/components/product/ProductCard'
import { SearchBar } from '@/components/product/SearchBar'
import { productsApi, type Product } from '@/lib/api/products'
import { COPY } from '@/lib/constants'

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')

  useEffect(() => {
    productsApi
      .list()
      .then(setProducts)
      .catch((err: Error) => setError(err.message))
  }, [])

  const filtered = useMemo(() => {
    if (!products) return []
    if (!query.trim()) return products
    const q = query.toLowerCase().trim()
    return products.filter((p) => {
      return (
        p.name.toLowerCase().includes(q) ||
        p.slug.toLowerCase().includes(q) ||
        (p.description ?? '').toLowerCase().includes(q) ||
        (p.category?.name ?? '').toLowerCase().includes(q)
      )
    })
  }, [products, query])

  return (
    <div className="space-y-6">
      <header className="space-y-3">
        <h1 className="font-display text-title-1 font-bold">Shop</h1>
        <SearchBar value={query} onChange={setQuery} placeholder="Search products, categories…" />
        {products && (
          <p className="text-footnote text-brand-dark/60">
            {filtered.length} of {products.length} {products.length === 1 ? 'product' : 'products'}
            {query && ` matching "${query}"`}
          </p>
        )}
      </header>

      {error ? (
        <Card>
          <p className="text-red-700 text-callout">{error}</p>
        </Card>
      ) : products === null ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="skeleton aspect-square rounded-card" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <p className="text-brand-dark/70 text-callout">
            {query ? `No products match "${query}".` : 'No products yet.'}
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  )
}
