'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { NextDeliveryCard } from '@/components/delivery/NextDeliveryCard'
import { COPY, ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { useCart, type CartLine } from '@/providers/CartProvider'

const STEP = 0.5

export default function CartPage() {
  const router = useRouter()
  const { user } = useAuth()
  const { lines, setQuantity, remove, subtotal, itemCount } = useCart()

  if (lines.length === 0) {
    return (
      <Card className="text-center py-12 max-w-md mx-auto">
        <div className="mx-auto w-14 h-14 rounded-pill bg-brand-olive/15 flex items-center justify-center">
          <ShoppingBag className="w-6 h-6 text-brand-olive-deep" />
        </div>
        <p className="font-display text-title-3 font-semibold mt-4">{COPY.cartEmpty}</p>
        <p className="text-footnote text-brand-dark/65 mt-1">
          Browse the shop to add some fresh produce.
        </p>
        <Link href={ROUTES.products}>
          <Button className="mt-5" trailingIcon={<ArrowRight className="w-4 h-4" />}>
            Start shopping
          </Button>
        </Link>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
      <div className="space-y-3">
        <header>
          <h1 className="font-display text-title-1 font-bold">Cart</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            {itemCount} {itemCount === 1 ? 'item' : 'items'}
          </p>
        </header>
        {lines.map((line) => (
          <CartLineCard
            key={line.productUuid}
            line={line}
            onIncrement={() =>
              setQuantity(line.productUuid, +(line.quantityKg + STEP).toFixed(1))
            }
            onDecrement={() =>
              setQuantity(
                line.productUuid,
                Math.max(0, +(line.quantityKg - STEP).toFixed(1)),
              )
            }
            onRemove={() => remove(line.productUuid)}
          />
        ))}
      </div>

      {/* Summary */}
      <aside className="space-y-4 lg:sticky lg:top-20 self-start">
        <NextDeliveryCard />
        <Card material="thick">
          <h2 className="font-display text-title-3 font-semibold">Summary</h2>
          <dl className="mt-3 space-y-2 text-callout">
            <div className="flex justify-between">
              <dt className="text-brand-dark/70">Subtotal</dt>
              <dd className="font-medium">£{subtotal.toFixed(2)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-brand-dark/70">Delivery</dt>
              <dd className="text-brand-olive-deep font-medium">Free</dd>
            </div>
            <div className="border-t border-brand-dark/10 my-2" />
            <div className="flex justify-between">
              <dt className="font-display text-headline font-semibold">Total</dt>
              <dd className="font-display text-headline font-bold">
                £{subtotal.toFixed(2)}
              </dd>
            </div>
          </dl>
          <Button
            fullWidth
            size="lg"
            className="mt-4"
            onClick={() => router.push(user ? ROUTES.checkout : ROUTES.login)}
            trailingIcon={<ArrowRight className="w-4 h-4" />}
          >
            {user ? 'Checkout' : 'Sign in to checkout'}
          </Button>
        </Card>
      </aside>
    </div>
  )
}

function CartLineCard({
  line,
  onIncrement,
  onDecrement,
  onRemove,
}: {
  line: CartLine
  onIncrement: () => void
  onDecrement: () => void
  onRemove: () => void
}) {
  const fullKgs = Math.floor(line.quantityKg)
  const hasHalf = line.quantityKg - fullKgs === 0.5
  const lineTotal = fullKgs * line.oneKgPrice + (hasHalf ? line.halfKgPrice : 0)

  return (
    <Card padded={false} className="p-3 sm:p-4">
      <div className="flex gap-3 sm:gap-4">
        <div className="w-20 h-20 sm:w-24 sm:h-24 relative rounded-md bg-brand-beige-deep/40 overflow-hidden shrink-0">
          {line.imageUrl && (
            <Image
              src={line.imageUrl}
              alt={line.name}
              fill
              sizes="96px"
              className="object-cover"
            />
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="font-display font-semibold text-callout text-brand-dark line-clamp-1">
              {line.name}
            </p>
            <button
              onClick={onRemove}
              aria-label="Remove"
              className="text-brand-dark/45 hover:text-red-600 transition shrink-0"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
          <p className="text-footnote text-brand-dark/60 mt-0.5">
            £{line.oneKgPrice.toFixed(2)} / kg
          </p>

          <div className="mt-2 flex items-center justify-between">
            <div className="inline-flex items-center gap-2 material-thin rounded-pill px-1">
              <button
                onClick={onDecrement}
                className="icon-btn w-8 h-8"
                aria-label="Decrease"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="text-callout font-medium w-12 text-center tabular-nums">
                {line.quantityKg.toFixed(1)}
              </span>
              <button
                onClick={onIncrement}
                className="icon-btn w-8 h-8"
                aria-label="Increase"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="font-display font-semibold text-brand-dark">
              £{lineTotal.toFixed(2)}
            </p>
          </div>
        </div>
      </div>
    </Card>
  )
}
