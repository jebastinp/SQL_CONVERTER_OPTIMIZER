'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { NextDeliveryCard } from '@/components/delivery/NextDeliveryCard'
import { ProductCard } from '@/components/product/ProductCard'
import { productsApi, type Product } from '@/lib/api/products'
import { ROUTES } from '@/lib/constants'

export default function HomePage() {
  const [products, setProducts] = useState<Product[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    productsApi
      .list()
      .then((list) => setProducts(list.slice(0, 8)))
      .catch((err: Error) => setError(err.message))
  }, [])

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Hero card */}
      <Card material="dark" className="overflow-hidden relative">
        <div className="relative z-10 py-2 sm:py-4">
          <p className="text-caption uppercase tracking-wider text-white/60">
            Welcome to Tarel
          </p>
          <h1 className="font-display text-large-title sm:text-large-title font-bold mt-2 max-w-md leading-tight">
            Fresh produce,<br />delivered weekly.
          </h1>
          <p className="text-callout text-white/80 mt-3 max-w-md">
            Order before the cutoff and we&apos;ll deliver to your door next week. Free
            delivery in your area.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Link href={ROUTES.products}>
              <Button trailingIcon={<ArrowRight className="w-4 h-4" />}>Shop now</Button>
            </Link>
            <Link href={ROUTES.categories}>
              <Button variant="outline">Browse categories</Button>
            </Link>
          </div>
        </div>
        {/* Decorative gradient glow */}
        <div className="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-brand-olive/30 blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 w-60 h-60 rounded-full bg-brand-olive/20 blur-3xl pointer-events-none" />
      </Card>

      <NextDeliveryCard />

      <section className="space-y-4">
        <div className="flex items-end justify-between">
          <h2 className="font-display text-title-2 font-bold text-brand-dark">
            Popular this week
          </h2>
          <Link
            href={ROUTES.products}
            className="text-callout text-brand-olive-deep font-medium hover:underline"
          >
            View all
          </Link>
        </div>

        {error ? (
          <Card>
            <p className="text-callout text-red-700">{error}</p>
          </Card>
        ) : products === null ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="skeleton aspect-square rounded-card" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <Card>
            <p className="text-callout text-brand-dark/70">
              Nothing here yet — check back soon.
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
