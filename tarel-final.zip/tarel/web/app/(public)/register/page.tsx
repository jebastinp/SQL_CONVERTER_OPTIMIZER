'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Lock, Mail, MapPin, Phone, User } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { BackButton } from '@/components/ui/BackButton'
import { ROUTES } from '@/lib/constants'
import { useAuth, type SignUpProfile } from '@/providers/AuthProvider'
import { useToast } from '@/providers/ToastProvider'

interface FormState extends SignUpProfile {
  email: string
  password: string
  confirm: string
}

export default function RegisterPage() {
  const router = useRouter()
  const { signUp } = useAuth()
  const toast = useToast()

  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    password: '',
    confirm: '',
    phone: '',
    address_line1: '',
    locality: '',
    city: '',
    postcode: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault()
    setError(null)

    if (form.password.length < 8) {
      setError('Password must be at least 8 characters.')
      return
    }
    if (form.password !== form.confirm) {
      setError('Passwords do not match.')
      return
    }

    setLoading(true)
    try {
      const user = await signUp(form.email, form.password, {
        name: form.name,
        phone: form.phone,
        address_line1: form.address_line1,
        locality: form.locality || undefined,
        city: form.city,
        postcode: form.postcode,
      })
      toast.success(`Welcome, ${user.name.split(' ')[0] || 'there'}!`, 'Your account is ready.')
      router.replace(ROUTES.account)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign up failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-lg mx-auto space-y-4">
      <BackButton fallbackHref={ROUTES.login} label="Sign in" />
      <Card material="thick">
        <header className="mb-5">
          <h1 className="font-display text-title-1 font-bold">Create your account</h1>
          <p className="text-footnote text-brand-dark/60 mt-1">
            We need your delivery address to schedule weekly drop-offs.
          </p>
        </header>

        <form onSubmit={onSubmit} className="space-y-4">
          {/* Personal */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="Full name"
              value={form.name}
              onChange={(e) => update('name', e.target.value)}
              required
              autoComplete="name"
              leadingIcon={<User className="w-4 h-4" />}
            />
            <Input
              label="Phone"
              type="tel"
              value={form.phone}
              onChange={(e) => update('phone', e.target.value)}
              required
              autoComplete="tel"
              leadingIcon={<Phone className="w-4 h-4" />}
            />
          </div>

          <Input
            label="Email"
            type="email"
            value={form.email}
            onChange={(e) => update('email', e.target.value)}
            required
            autoComplete="email"
            leadingIcon={<Mail className="w-4 h-4" />}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="Password"
              type="password"
              value={form.password}
              onChange={(e) => update('password', e.target.value)}
              required
              autoComplete="new-password"
              leadingIcon={<Lock className="w-4 h-4" />}
              hint="At least 8 characters"
            />
            <Input
              label="Confirm password"
              type="password"
              value={form.confirm}
              onChange={(e) => update('confirm', e.target.value)}
              required
              autoComplete="new-password"
              leadingIcon={<Lock className="w-4 h-4" />}
            />
          </div>

          {/* Delivery address */}
          <div className="pt-2">
            <p className="text-caption uppercase tracking-wider text-brand-dark/55 mb-3">
              Delivery address
            </p>
            <div className="space-y-3">
              <Input
                label="Address line"
                value={form.address_line1}
                onChange={(e) => update('address_line1', e.target.value)}
                required
                autoComplete="street-address"
                leadingIcon={<MapPin className="w-4 h-4" />}
                placeholder="123 Example Road"
              />
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input
                  label="Locality"
                  value={form.locality}
                  onChange={(e) => update('locality', e.target.value)}
                  autoComplete="address-level2"
                  placeholder="Optional"
                />
                <Input
                  label="City"
                  value={form.city}
                  onChange={(e) => update('city', e.target.value)}
                  required
                  autoComplete="address-level1"
                />
                <Input
                  label="Postcode"
                  value={form.postcode}
                  onChange={(e) => update('postcode', e.target.value.toUpperCase())}
                  required
                  autoComplete="postal-code"
                  placeholder="SW1A 1AA"
                />
              </div>
            </div>
          </div>

          {error && (
            <p className="text-callout text-red-700 bg-red-50/80 border border-red-200/60 rounded-md px-3 py-2">
              {error}
            </p>
          )}

          <Button type="submit" fullWidth loading={loading} size="lg">
            {loading ? 'Creating account…' : 'Create account'}
          </Button>
        </form>

        <p className="text-center text-footnote text-brand-dark/60 mt-5">
          Already have an account?{' '}
          <Link href={ROUTES.login} className="font-medium text-brand-olive-deep hover:underline">
            Sign in
          </Link>
        </p>
      </Card>
    </div>
  )
}
