'use client'

import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'

export default function UserLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) router.replace(ROUTES.login)
  }, [loading, user, router])

  if (loading || !user) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-brand-dark/15 border-t-brand-olive animate-spin" />
          <p className="text-brand-dark/55 text-footnote">Loading your account…</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 py-6 sm:py-8">{children}</main>
      <Footer />
    </>
  )
}
