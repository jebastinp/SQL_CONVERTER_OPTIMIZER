'use client'

import { useParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Calendar, MapPin, X } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { BackButton } from '@/components/ui/BackButton'
import { StatusPill } from '@/components/ui/StatusPill'
import { Sheet } from '@/components/ui/Sheet'
import { ordersApi, type OrderDetail } from '@/lib/api/orders'
import { ROUTES } from '@/lib/constants'
import { useToast } from '@/providers/ToastProvider'

export default function UserOrderDetailPage() {
  const params = useParams<{ orderId: string }>()
  const router = useRouter()
  const toast = useToast()
  const [order, setOrder] = useState<OrderDetail | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showCancel, setShowCancel] = useState(false)
  const [cancelling, setCancelling] = useState(false)

  const orderId = params?.orderId

  useEffect(() => {
    if (!orderId) return
    ordersApi
      .getMine(orderId)
      .then(setOrder)
      .catch((err: Error) => setError(err.message))
  }, [orderId])

  async function onCancel() {
    if (!orderId) return
    setCancelling(true)
    try {
      const updated = await ordersApi.cancelMine(orderId)
      setOrder(updated)
      setShowCancel(false)
      toast.success('Order cancelled', 'Your refund will arrive in a few days')
    } catch (err) {
      toast.error('Could not cancel', err instanceof Error ? err.message : 'Please try again')
    } finally {
      setCancelling(false)
    }
  }

  if (error) {
    return (
      <div className="space-y-4 max-w-3xl">
        <BackButton fallbackHref={ROUTES.accountOrders} label="Orders" />
        <Card>
          <p className="text-callout text-red-700">{error}</p>
        </Card>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="space-y-4 max-w-3xl">
        <BackButton fallbackHref={ROUTES.accountOrders} label="Orders" />
        <div className="skeleton h-32 rounded-card" />
        <div className="skeleton h-48 rounded-card" />
        <div className="skeleton h-24 rounded-card" />
      </div>
    )
  }

  return (
    <div className="space-y-5 max-w-3xl">
      <BackButton fallbackHref={ROUTES.accountOrders} label="Orders" />

      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-caption text-brand-dark/60">
              {order.code ?? order.id.slice(0, 8)}
            </p>
            <h1 className="font-display text-title-1 font-bold mt-1">
              Order details
            </h1>
            <p className="text-footnote text-brand-dark/65 mt-1">
              Placed {new Date(order.created_at).toLocaleDateString()}
            </p>
          </div>
          <StatusPill status={order.status} />
        </div>

        {order.delivery_date && (
          <div className="mt-4 flex items-center gap-2 text-callout text-brand-dark/85">
            <Calendar className="w-4 h-4 text-brand-olive-deep" />
            <span>
              Delivery on{' '}
              <span className="font-medium">
                {new Date(order.delivery_date).toLocaleDateString(undefined, {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                })}
              </span>
              {order.delivery_slot && <> · {order.delivery_slot}</>}
            </span>
          </div>
        )}
      </Card>

      <Card>
        <h2 className="font-display text-title-3 font-semibold">Items</h2>
        <ul className="mt-3 divide-y divide-brand-dark/10">
          {order.items.map((item) => (
            <li
              key={item.id}
              className="py-3 flex items-center justify-between gap-3 text-callout"
            >
              <div className="min-w-0 flex-1">
                <p className="font-medium text-brand-dark truncate">{item.product_name}</p>
                <p className="text-caption text-brand-dark/60">
                  {item.qty_kg.toFixed(1)} kg × £{item.price_per_kg.toFixed(2)}
                </p>
              </div>
              <p className="tabular-nums font-medium">£{item.line_total.toFixed(2)}</p>
            </li>
          ))}
        </ul>
        <div className="mt-4 pt-3 border-t border-brand-dark/10 flex items-center justify-between">
          <span className="font-display text-headline font-semibold">Total</span>
          <span className="font-display text-headline font-bold tabular-nums">
            £{order.total_amount.toFixed(2)}
          </span>
        </div>
      </Card>

      {(order.status === 'pending' ||
        order.status === 'paid' ||
        order.status === 'processing') &&
        order.cancellation_allowed && (
          <Card>
            <h2 className="font-display text-title-3 font-semibold">Need to cancel?</h2>
            <p className="text-footnote text-brand-dark/65 mt-1">
              You can cancel before the order cutoff. Refunds are processed automatically.
            </p>
            <Button
              variant="outline"
              className="mt-3 text-red-700 border-red-300/60"
              onClick={() => setShowCancel(true)}
              leadingIcon={<X className="w-4 h-4" />}
            >
              Cancel order
            </Button>
          </Card>
        )}

      <Sheet
        open={showCancel}
        onClose={() => setShowCancel(false)}
        title="Cancel this order?"
        size="sm"
      >
        <p className="text-callout text-brand-dark/75">
          The full amount of £{order.total_amount.toFixed(2)} will be refunded to your
          original payment method. This usually takes 3–5 business days.
        </p>
        <div className="mt-4 flex gap-2">
          <Button
            variant="outline"
            fullWidth
            onClick={() => setShowCancel(false)}
          >
            Keep order
          </Button>
          <Button
            variant="danger"
            fullWidth
            loading={cancelling}
            onClick={onCancel}
          >
            Cancel & refund
          </Button>
        </div>
      </Sheet>
    </div>
  )
}
