'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ListOrdered, ArrowRight } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { OrderCard, type OrderSummary } from '@/components/order/OrderCard'
import { ORDERS_PER_ROW, ROUTES } from '@/lib/constants'
import { apiFetch } from '@/lib/api/client'

export default function UserOrdersPage() {
  const [orders, setOrders] = useState<OrderSummary[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    apiFetch<OrderSummary[]>('/orders/me')
      .then(setOrders)
      .catch((err: Error) => setError(err.message))
  }, [])

  const gridCols =
    ORDERS_PER_ROW === 3
      ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
      : 'grid-cols-1 sm:grid-cols-2'

  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-title-1 font-bold">My orders</h1>
        {orders && (
          <p className="text-footnote text-brand-dark/60 mt-1">
            {orders.length} order{orders.length === 1 ? '' : 's'}
          </p>
        )}
      </header>

      {error ? (
        <Card>
          <p className="text-callout text-red-700">{error}</p>
        </Card>
      ) : orders === null ? (
        <div className={`grid ${gridCols} gap-4`}>
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="skeleton h-40 rounded-card" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <Card className="text-center py-10">
          <div className="mx-auto w-14 h-14 rounded-pill bg-brand-olive/15 flex items-center justify-center">
            <ListOrdered className="w-6 h-6 text-brand-olive-deep" />
          </div>
          <p className="font-display text-title-3 font-semibold mt-4">No orders yet</p>
          <p className="text-footnote text-brand-dark/65 mt-1">
            Your weekly deliveries will show up here.
          </p>
          <Link href={ROUTES.products}>
            <Button className="mt-5" trailingIcon={<ArrowRight className="w-4 h-4" />}>
              Start shopping
            </Button>
          </Link>
        </Card>
      ) : (
        <div className={`grid ${gridCols} gap-4`}>
          {orders.map((order) => (
            <OrderCard
              key={order.id}
              order={order}
              href={`${ROUTES.accountOrders}/${order.id}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
