'use client'

import Link from 'next/link'
import { ChevronRight, ListOrdered, MapPin, User, HelpCircle } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { NextDeliveryCard } from '@/components/delivery/NextDeliveryCard'
import { ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'

const SECTIONS = [
  {
    href: ROUTES.accountOrders,
    label: 'Orders',
    description: 'Track and manage your deliveries',
    icon: ListOrdered,
  },
  {
    href: ROUTES.accountProfile,
    label: 'Profile',
    description: 'Name, contact and delivery address',
    icon: User,
  },
  {
    href: ROUTES.accountSupport,
    label: 'Support',
    description: 'Get help with a recent order',
    icon: HelpCircle,
  },
] as const

export default function AccountPage() {
  const { user } = useAuth()
  if (!user) return null

  return (
    <div className="space-y-5">
      {/* Profile summary */}
      <Card>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-pill bg-brand-olive/15 text-brand-olive-deep font-display font-bold text-title-3 flex items-center justify-center shrink-0">
            {user.name
              .split(/\s+/)
              .filter(Boolean)
              .slice(0, 2)
              .map((p) => p[0])
              .join('')
              .toUpperCase() || '·'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-display text-title-2 font-bold text-brand-dark truncate">
              {user.name}
            </p>
            <p className="text-footnote text-brand-dark/65 truncate">{user.email}</p>
            {user.postcode && (
              <p className="text-footnote text-brand-dark/65 mt-1 inline-flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" />
                {user.postcode}
              </p>
            )}
          </div>
        </div>
      </Card>

      <NextDeliveryCard />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {SECTIONS.map(({ href, label, description, icon: Icon }) => (
          <Link key={href} href={href}>
            <Card interactive className="h-full">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-pill bg-brand-olive/15 text-brand-olive-deep flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-display font-semibold text-callout text-brand-dark">
                      {label}
                    </p>
                    <ChevronRight className="w-4 h-4 text-brand-dark/40" />
                  </div>
                  <p className="text-footnote text-brand-dark/65 mt-1">{description}</p>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
