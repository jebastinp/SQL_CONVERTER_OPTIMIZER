'use client'

import { useEffect, useState } from 'react'
import { MapPin, Phone, User as UserIcon } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { BackButton } from '@/components/ui/BackButton'
import { ROUTES } from '@/lib/constants'
import { apiFetch } from '@/lib/api/client'
import { useAuth, type AuthUser } from '@/providers/AuthProvider'
import { useToast } from '@/providers/ToastProvider'

export default function ProfilePage() {
  const { user, refreshProfile } = useAuth()
  const toast = useToast()

  const [form, setForm] = useState({
    name: '',
    phone: '',
    address_line1: '',
    locality: '',
    city: '',
    postcode: '',
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!user) return
    setForm({
      name: user.name ?? '',
      phone: user.phone ?? '',
      address_line1: user.address_line1 ?? '',
      locality: user.locality ?? '',
      city: user.city ?? '',
      postcode: user.postcode ?? '',
    })
  }, [user])

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  async function onSave(event: React.FormEvent) {
    event.preventDefault()
    setSaving(true)
    setError(null)
    try {
      await apiFetch<AuthUser>('/users/me', {
        method: 'PATCH',
        body: form,
      })
      await refreshProfile()
      toast.success('Profile saved', 'Your changes are live')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed')
    } finally {
      setSaving(false)
    }
  }

  if (!user) return null

  return (
    <div className="space-y-5">
      <BackButton fallbackHref={ROUTES.account} label="Account" />
      <header>
        <h1 className="font-display text-title-1 font-bold">Profile</h1>
        <p className="text-footnote text-brand-dark/60 mt-1">
          {user.email} · {user.user_code ?? user.id.slice(0, 8)}
        </p>
      </header>

      <Card>
        <form onSubmit={onSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="Full name"
              value={form.name}
              onChange={(e) => update('name', e.target.value)}
              leadingIcon={<UserIcon className="w-4 h-4" />}
              required
            />
            <Input
              label="Phone"
              value={form.phone}
              onChange={(e) => update('phone', e.target.value)}
              leadingIcon={<Phone className="w-4 h-4" />}
              type="tel"
            />
          </div>

          <div className="pt-2">
            <p className="text-caption uppercase tracking-wider text-brand-dark/55 mb-3">
              Delivery address
            </p>
            <div className="space-y-3">
              <Input
                label="Address line"
                value={form.address_line1}
                onChange={(e) => update('address_line1', e.target.value)}
                leadingIcon={<MapPin className="w-4 h-4" />}
              />
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input
                  label="Locality"
                  value={form.locality}
                  onChange={(e) => update('locality', e.target.value)}
                />
                <Input
                  label="City"
                  value={form.city}
                  onChange={(e) => update('city', e.target.value)}
                />
                <Input
                  label="Postcode"
                  value={form.postcode}
                  onChange={(e) => update('postcode', e.target.value.toUpperCase())}
                />
              </div>
            </div>
          </div>

          {error && (
            <p className="text-callout text-red-700 bg-red-50/80 border border-red-200/60 rounded-md px-3 py-2">
              {error}
            </p>
          )}

          <div className="flex justify-end">
            <Button type="submit" loading={saving}>
              {saving ? 'Saving…' : 'Save changes'}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  )
}
