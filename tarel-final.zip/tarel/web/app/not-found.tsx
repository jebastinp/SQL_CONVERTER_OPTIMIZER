import Link from 'next/link'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { COPY, ROUTES } from '@/lib/constants'

export default function NotFound() {
  return (
    <main className="min-h-[100dvh] flex items-center justify-center p-6">
      <Card material="thick" className="max-w-sm text-center">
        <p className="font-display text-large-title font-bold text-brand-dark/40 tabular-nums">
          404
        </p>
        <h2 className="font-display text-title-2 font-semibold text-brand-dark mt-1">
          {COPY.notFoundTitle}
        </h2>
        <p className="text-callout text-brand-dark/65 mt-3">
          {COPY.notFoundBody}
        </p>
        <Link href={ROUTES.home} className="inline-block mt-6">
          <Button>Back home</Button>
        </Link>
      </Card>
    </main>
  )
}
