import { NextRequest, NextResponse } from 'next/server'
import { ADMIN_PATH, ROUTES, AUTH_COOKIE_NAME, ROLES } from '@/lib/constants'

/**
 * Admin hiding strategy
 * ─────────────────────
 * The admin tree is at `/(admin)/[adminSlug]` — a dynamic segment.
 * `NEXT_PUBLIC_ADMIN_PATH` is the only value that matches.
 *
 *  1. Any request to /<adminSlug>/... where adminSlug !== ADMIN_PATH
 *     gets a real 404. To the outside world the path simply does
 *     not exist.
 *  2. A request to the correct slug but without a valid admin JWT
 *     also gets a 404 (not a 401 — we don't tell unauthenticated
 *     callers that the path is even there).
 *  3. Only requests carrying a valid admin token pass through.
 *
 * The JWT signature is validated server-side; we only do a lightweight
 * shape check here (the auth provider issues `sub`, `role`, `exp`).
 */

const PUBLIC_FILE = /\.(.*)$/

function isAdminPath(pathname: string): { match: boolean; slug?: string } {
  // pathname starts with "/<segment>/..."
  const segments = pathname.split('/').filter(Boolean)
  if (segments.length === 0) return { match: false }
  const first = segments[0]
  // Heuristic: anything that "looks like" a slug at the root and is NOT
  // a known public route is a candidate. We compare against the
  // configured admin slug; mismatches 404.
  const knownPublicRoots = new Set<string>([
    '',
    'products',
    'categories',
    'cart',
    'checkout',
    'login',
    'register',
    'legal',
    'account',
    'api',
    '_next',
    'favicon.ico',
  ])
  if (knownPublicRoots.has(first)) return { match: false }
  return { match: true, slug: first }
}

function decodeJwtPayload(token: string): { role?: string; exp?: number } | null {
  try {
    const [, payload] = token.split('.')
    if (!payload) return null
    const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
    return JSON.parse(json)
  } catch {
    return null
  }
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Skip static assets
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    PUBLIC_FILE.test(pathname)
  ) {
    return NextResponse.next()
  }

  const candidate = isAdminPath(pathname)
  if (!candidate.match) return NextResponse.next()

  // Wrong slug → real 404. Path doesn't exist as far as the world knows.
  if (candidate.slug !== ADMIN_PATH) {
    return NextResponse.rewrite(new URL(ROUTES.notFound, request.url))
  }

  // Right slug, now check auth. No token / non-admin → still 404.
  const token = request.cookies.get(AUTH_COOKIE_NAME)?.value
  if (!token) {
    return NextResponse.rewrite(new URL(ROUTES.notFound, request.url))
  }
  const payload = decodeJwtPayload(token)
  if (!payload || payload.role !== ROLES.admin) {
    return NextResponse.rewrite(new URL(ROUTES.notFound, request.url))
  }
  if (payload.exp && Date.now() / 1000 > payload.exp) {
    return NextResponse.rewrite(new URL(ROUTES.notFound, request.url))
  }

  return NextResponse.next()
}

export const config = {
  // Apply to everything except Next internals and static files
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
