'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import type { Product } from '@/lib/api/products'

export interface CartLine {
  productUuid: string
  slug: string
  name: string
  imageUrl: string | null
  quantityKg: number      // increments of 0.5
  oneKgPrice: number
  halfKgPrice: number
}

interface CartState {
  lines: CartLine[]
  itemCount: number
  subtotal: number
  add: (product: Product, quantityKg: number) => void
  setQuantity: (productUuid: string, quantityKg: number) => void
  remove: (productUuid: string) => void
  clear: () => void
  requireAuthBeforeAdd: boolean
}

const CartContext = createContext<CartState | null>(null)

const STORAGE_KEY = 'tarel.cart.v1'

function readPersisted(): CartLine[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? (parsed as CartLine[]) : []
  } catch {
    return []
  }
}

function priceForLine(line: CartLine): number {
  const fullKg = Math.floor(line.quantityKg)
  const halfPart = line.quantityKg - fullKg === 0.5 ? 1 : 0
  return fullKg * line.oneKgPrice + halfPart * line.halfKgPrice
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([])

  useEffect(() => {
    setLines(readPersisted())
  }, [])

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines))
      } catch {
        // storage full / disabled — fine, cart just won't persist
      }
    }
  }, [lines])

  const add = useCallback((product: Product, quantityKg: number) => {
    if (quantityKg <= 0) return
    setLines((prev) => {
      const existing = prev.find((l) => l.productUuid === product.id)
      const oneKgPrice = product.one_kg_price ?? product.price_per_kg
      const halfKgPrice = product.half_kg_price ?? Math.round((product.price_per_kg / 2) * 100) / 100
      if (existing) {
        return prev.map((l) =>
          l.productUuid === product.id
            ? { ...l, quantityKg: l.quantityKg + quantityKg }
            : l,
        )
      }
      return [
        ...prev,
        {
          productUuid: product.id,
          slug: product.slug,
          name: product.name,
          imageUrl: product.image_url,
          quantityKg,
          oneKgPrice,
          halfKgPrice,
        },
      ]
    })
  }, [])

  const setQuantity = useCallback((productUuid: string, quantityKg: number) => {
    setLines((prev) =>
      quantityKg <= 0
        ? prev.filter((l) => l.productUuid !== productUuid)
        : prev.map((l) => (l.productUuid === productUuid ? { ...l, quantityKg } : l)),
    )
  }, [])

  const remove = useCallback((productUuid: string) => {
    setLines((prev) => prev.filter((l) => l.productUuid !== productUuid))
  }, [])

  const clear = useCallback(() => setLines([]), [])

  const value = useMemo<CartState>(() => {
    const itemCount = lines.length
    const subtotal = lines.reduce((sum, l) => sum + priceForLine(l), 0)
    return {
      lines,
      itemCount,
      subtotal,
      add,
      setQuantity,
      remove,
      clear,
      requireAuthBeforeAdd: true,
    }
  }, [lines, add, setQuantity, remove, clear])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart(): CartState {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>')
  return ctx
}
