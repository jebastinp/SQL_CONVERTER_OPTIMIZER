'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { getSupabaseClient } from '@/lib/supabase/client'
import { apiFetch } from '@/lib/api/client'
import { ROLES, type Role } from '@/lib/constants'

export interface AuthUser {
  id: string // the user's UUID (the backend aliases `uuid` to `id` in responses)
  email: string
  name: string
  role: Role
  phone: string | null
  postcode: string | null
  address_line1: string | null
  city: string | null
  locality: string | null
  user_code: string | null
}

interface AuthState {
  user: AuthUser | null
  token: string | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<AuthUser>
  signUp: (email: string, password: string, profile: SignUpProfile) => Promise<AuthUser>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

export interface SignUpProfile {
  name: string
  phone: string
  address_line1: string
  locality?: string
  city: string
  postcode: string
}

const AuthContext = createContext<AuthState | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null)
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)

  const loadProfile = useCallback(async (accessToken: string): Promise<AuthUser | null> => {
    try {
      const profile = await apiFetch<AuthUser>('/auth/me', { token: accessToken })
      return profile
    } catch {
      return null
    }
  }, [])

  // Hydrate session on mount + subscribe to Supabase auth changes
  useEffect(() => {
    const supabase = getSupabaseClient()
    let mounted = true

    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return
      const session = data.session
      if (session?.access_token) {
        setToken(session.access_token)
        const profile = await loadProfile(session.access_token)
        if (mounted) {
          setUser(profile)
          setLoading(false)
        }
      } else {
        setLoading(false)
      }
    })

    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.access_token) {
        setToken(session.access_token)
        const profile = await loadProfile(session.access_token)
        setUser(profile)
      } else {
        setToken(null)
        setUser(null)
      }
    })

    return () => {
      mounted = false
      sub.subscription.unsubscribe()
    }
  }, [loadProfile])

  const signIn = useCallback(
    async (email: string, password: string): Promise<AuthUser> => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) throw new Error(error.message)
      if (!data.session) throw new Error('Sign in succeeded but no session returned')
      const profile = await loadProfile(data.session.access_token)
      if (!profile) {
        throw new Error('Could not load your profile. Please contact support.')
      }
      setToken(data.session.access_token)
      setUser(profile)
      return profile
    },
    [loadProfile],
  )

  const signUp = useCallback(
    async (email: string, password: string, profileData: SignUpProfile): Promise<AuthUser> => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { name: profileData.name } },
      })
      if (error) throw new Error(error.message)
      if (!data.session) {
        throw new Error('Please confirm your email to complete sign-up.')
      }
      // Complete the profile on our backend (postcode, address, phone, etc.)
      const profile = await apiFetch<AuthUser>('/auth/register', {
        method: 'POST',
        body: profileData,
        token: data.session.access_token,
      })
      setToken(data.session.access_token)
      setUser(profile)
      return profile
    },
    [],
  )

  const signOut = useCallback(async (): Promise<void> => {
    const supabase = getSupabaseClient()
    await supabase.auth.signOut()
    setToken(null)
    setUser(null)
  }, [])

  const refreshProfile = useCallback(async (): Promise<void> => {
    if (!token) return
    const profile = await loadProfile(token)
    setUser(profile)
  }, [token, loadProfile])

  const value = useMemo<AuthState>(
    () => ({ user, token, loading, signIn, signUp, signOut, refreshProfile }),
    [user, token, loading, signIn, signUp, signOut, refreshProfile],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>')
  return ctx
}

export { ROLES }
