'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import { CheckCircle2, AlertCircle, Info } from 'lucide-react'
import { cn } from '@/lib/cn'

type ToastKind = 'success' | 'error' | 'info'

interface Toast {
  id: string
  kind: ToastKind
  title: string
  description?: string
}

interface ToastApi {
  show: (toast: Omit<Toast, 'id'>) => void
  success: (title: string, description?: string) => void
  error: (title: string, description?: string) => void
  info: (title: string, description?: string) => void
}

const ToastContext = createContext<ToastApi | null>(null)

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const show = useCallback((toast: Omit<Toast, 'id'>) => {
    const id =
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random()}`
    setToasts((prev) => [...prev, { id, ...toast }])
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id))
    }, 3500)
  }, [])

  const api = useMemo<ToastApi>(
    () => ({
      show,
      success: (title, description) => show({ kind: 'success', title, description }),
      error: (title, description) => show({ kind: 'error', title, description }),
      info: (title, description) => show({ kind: 'info', title, description }),
    }),
    [show],
  )

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="fixed top-0 inset-x-0 z-[60] pt-safe-top pointer-events-none">
        <div className="max-w-md mx-auto px-3 pt-3 flex flex-col gap-2">
          {toasts.map((t) => (
            <ToastItem key={t.id} toast={t} />
          ))}
        </div>
      </div>
    </ToastContext.Provider>
  )
}

function ToastItem({ toast }: { toast: Toast }) {
  const Icon =
    toast.kind === 'success' ? CheckCircle2 : toast.kind === 'error' ? AlertCircle : Info
  const iconColor =
    toast.kind === 'success'
      ? 'text-emerald-600'
      : toast.kind === 'error'
        ? 'text-red-600'
        : 'text-sky-600'
  return (
    <div
      className={cn(
        'material-thick rounded-card px-4 py-3 flex items-start gap-3 animate-scale-in pointer-events-auto',
      )}
    >
      <Icon className={cn('w-5 h-5 mt-0.5 shrink-0', iconColor)} />
      <div className="min-w-0">
        <p className="text-callout font-semibold text-brand-dark">{toast.title}</p>
        {toast.description && (
          <p className="text-footnote text-brand-dark/70 mt-0.5">{toast.description}</p>
        )}
      </div>
    </div>
  )
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast must be used inside <ToastProvider>')
  return ctx
}
