/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  images: {
    // Allow R2 + Supabase + dev images
    remotePatterns: [
      { protocol: 'https', hostname: '**.r2.dev' },
      { protocol: 'https', hostname: '**.r2.cloudflarestorage.com' },
      { protocol: 'https', hostname: '**.supabase.co' },
      { protocol: 'http', hostname: 'localhost' },
      { protocol: 'http', hostname: '127.0.0.1' },
      // Allow any 192.168.x.x address (typical home LAN) so product
      // images served from the dev backend render on mobile.
      { protocol: 'http', hostname: '192.168.*.*' },
      { protocol: 'http', hostname: '10.*.*.*' },
    ],
  },

  /**
   * Proxy /api/* to the FastAPI backend.
   *
   * This is the trick that makes mobile work: the frontend calls
   * `/api/v1/...` (same origin), Next.js proxies it to the backend at
   * NEXT_PUBLIC_BACKEND_URL (defaulting to http://localhost:8000).
   *
   * When you open the app on your phone via http://192.168.x.x:3000,
   * the browser hits http://192.168.x.x:3000/api/v1/... and Next.js
   * (running on the dev machine) forwards that to the local backend.
   * Without this, the phone would try to hit `localhost:8000` (itself)
   * and fail.
   */
  async rewrites() {
    const backend = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:8000'
    return [
      {
        source: '/api/:path*',
        destination: `${backend}/api/:path*`,
      },
    ]
  },

  env: {
    NEXT_PUBLIC_ADMIN_PATH: process.env.NEXT_PUBLIC_ADMIN_PATH,
    NEXT_PUBLIC_API_BASE: process.env.NEXT_PUBLIC_API_BASE,
    NEXT_PUBLIC_BACKEND_URL: process.env.NEXT_PUBLIC_BACKEND_URL,
  },
}

export default nextConfig
