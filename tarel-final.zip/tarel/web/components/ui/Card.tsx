import { HTMLAttributes, forwardRef } from 'react'
import { cn } from '@/lib/cn'

type Material = 'regular' | 'thin' | 'thick' | 'dark'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  material?: Material
  padded?: boolean
  interactive?: boolean
}

const materialClass: Record<Material, string> = {
  regular: 'material',
  thin: 'material-thin',
  thick: 'material-thick',
  dark: 'material-dark',
}

/**
 * Card — a translucent material surface. The default `regular` reads
 * like the cards on the iOS home screen: white-frosted glass over the
 * beige wallpaper, with a 1px inner highlight and a soft drop shadow.
 */
export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ material = 'regular', padded = true, interactive = false, className, ...rest }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          materialClass[material],
          'rounded-card',
          padded && 'p-5',
          interactive && 'transition duration-200 ease-spring hover:shadow-glass-lg hover:-translate-y-0.5 active:translate-y-0',
          className,
        )}
        {...rest}
      />
    )
  },
)
Card.displayName = 'Card'
