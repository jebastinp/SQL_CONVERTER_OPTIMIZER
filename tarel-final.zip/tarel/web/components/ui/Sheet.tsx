'use client'

import { useEffect } from 'react'
import { X } from 'lucide-react'
import { cn } from '@/lib/cn'

interface SheetProps {
  open: boolean
  onClose: () => void
  title?: string
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
}

const sizeClass = {
  sm: 'max-w-sm',
  md: 'max-w-lg',
  lg: 'max-w-2xl',
}

/**
 * Sheet — modal on desktop, bottom-sheet on mobile.
 * Uses scale-in animation on desktop, slide-up on mobile.
 */
export function Sheet({ open, onClose, title, children, size = 'md' }: SheetProps) {
  useEffect(() => {
    if (!open) return
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = original
      window.removeEventListener('keydown', onKey)
    }
  }, [open, onClose])

  if (!open) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center animate-fade-in"
      role="dialog"
      aria-modal="true"
    >
      {/* Backdrop — translucent dim that lets the wallpaper show through */}
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-brand-dark/30 backdrop-blur-sm"
      />

      {/* Container */}
      <div
        className={cn(
          'relative w-full mx-2 mb-2 sm:mb-0 material-thick',
          'rounded-sheet sm:rounded-card',
          'animate-sheet-up sm:animate-scale-in',
          sizeClass[size],
        )}
      >
        {/* Drag handle (decorative) */}
        <div className="sm:hidden flex justify-center pt-2 pb-1">
          <div className="w-9 h-1 rounded-full bg-brand-dark/20" />
        </div>

        {(title || true) && (
          <div className="flex items-center justify-between px-5 pt-4 pb-3">
            <h3 className="font-display text-title-3 font-semibold">{title}</h3>
            <button
              onClick={onClose}
              aria-label="Close"
              className="icon-btn w-9 h-9"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
        <div className="px-5 pb-5">{children}</div>
      </div>
    </div>
  )
}
