import { InputHTMLAttributes, forwardRef, useId } from 'react'
import { cn } from '@/lib/cn'

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  hint?: string
  error?: string
  leadingIcon?: React.ReactNode
  trailingIcon?: React.ReactNode
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, hint, error, leadingIcon, trailingIcon, id, className, ...rest }, ref) => {
    const reactId = useId()
    const inputId = id ?? reactId
    return (
      <div className="space-y-1.5">
        {label && (
          <label htmlFor={inputId} className="block text-footnote font-medium text-brand-dark/80">
            {label}
          </label>
        )}
        <div className="relative">
          {leadingIcon && (
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-brand-dark/50 pointer-events-none">
              {leadingIcon}
            </span>
          )}
          <input
            ref={ref}
            id={inputId}
            className={cn(
              'field',
              leadingIcon && 'pl-10',
              trailingIcon && 'pr-10',
              error && 'border-red-400 focus:border-red-500 focus:shadow-[0_0_0_4px_rgba(220,38,38,0.18)]',
              className,
            )}
            {...rest}
          />
          {trailingIcon && (
            <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-brand-dark/50">
              {trailingIcon}
            </span>
          )}
        </div>
        {error ? (
          <p className="text-caption text-red-600">{error}</p>
        ) : hint ? (
          <p className="text-caption text-brand-dark/60">{hint}</p>
        ) : null}
      </div>
    )
  },
)
Input.displayName = 'Input'
