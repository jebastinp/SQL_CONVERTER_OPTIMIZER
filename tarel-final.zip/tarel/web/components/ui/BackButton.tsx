'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ChevronLeft } from 'lucide-react'
import { cn } from '@/lib/cn'

interface BackButtonProps {
  /**
   * Where to go if there's no browser history (i.e. user opened the
   * page in a new tab). Optional — if not provided, uses router.back()
   * unconditionally.
   */
  fallbackHref?: string
  /**
   * Label shown next to the chevron. iOS convention is the previous
   * page's name (e.g. "Orders" → order detail).
   */
  label?: string
  className?: string
}

/**
 * BackButton — Apple-style chevron + label, in a glass pill.
 * 44pt tap target. Active-press feedback.
 */
export function BackButton({
  fallbackHref,
  label = 'Back',
  className,
}: BackButtonProps) {
  const router = useRouter()

  const content = (
    <span
      className={cn(
        'inline-flex items-center gap-1 -ml-1 py-2 px-2 pr-3 rounded-pill',
        'text-callout font-medium text-brand-olive-deep',
        'transition active:scale-95 active:bg-brand-dark/5',
        className,
      )}
    >
      <ChevronLeft className="w-5 h-5" strokeWidth={2.5} />
      <span className="truncate max-w-[10rem]">{label}</span>
    </span>
  )

  if (fallbackHref) {
    return (
      <Link href={fallbackHref} aria-label={`Back to ${label}`}>
        {content}
      </Link>
    )
  }

  return (
    <button
      type="button"
      onClick={() => router.back()}
      aria-label={`Back to ${label}`}
    >
      {content}
    </button>
  )
}
