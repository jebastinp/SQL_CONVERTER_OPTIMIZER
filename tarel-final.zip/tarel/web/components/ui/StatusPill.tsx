import { ORDER_STATUS, ORDER_STATUS_LABEL, type OrderStatus } from '@/lib/constants'

const TONE: Record<OrderStatus, string> = {
  [ORDER_STATUS.pending]: 'bg-amber-100/80 text-amber-900 ring-1 ring-amber-200/60',
  [ORDER_STATUS.paid]: 'bg-sky-100/80 text-sky-900 ring-1 ring-sky-200/60',
  [ORDER_STATUS.processing]: 'bg-violet-100/80 text-violet-900 ring-1 ring-violet-200/60',
  [ORDER_STATUS.outForDelivery]: 'bg-blue-100/80 text-blue-900 ring-1 ring-blue-200/60',
  [ORDER_STATUS.delivered]: 'bg-emerald-100/80 text-emerald-900 ring-1 ring-emerald-200/60',
  [ORDER_STATUS.cancelled]: 'bg-red-100/80 text-red-900 ring-1 ring-red-200/60',
}

export function StatusPill({ status }: { status: OrderStatus }) {
  return <span className={`pill ${TONE[status]}`}>{ORDER_STATUS_LABEL[status]}</span>
}
