import Link from 'next/link'
import { Card } from '@/components/ui/Card'
import { StatusPill } from '@/components/ui/StatusPill'
import type { OrderStatus } from '@/lib/constants'

export interface OrderSummary {
  id: string // uuid
  code: string | null
  status: OrderStatus
  total_amount: number
  created_at: string
  item_count: number
  delivery_slot: string | null
}

export function OrderCard({ order, href }: { order: OrderSummary; href?: string }) {
  const content = (
    <Card interactive className="h-full flex flex-col justify-between">
      <div>
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-caption text-brand-dark/55">
              {order.code ?? order.id.slice(0, 8)}
            </p>
            <p className="text-footnote text-brand-dark/65 mt-0.5">
              {new Date(order.created_at).toLocaleDateString()}
            </p>
          </div>
          <StatusPill status={order.status} />
        </div>
        <div className="mt-3 text-footnote text-brand-dark/75">
          {order.item_count} item{order.item_count === 1 ? '' : 's'}
          {order.delivery_slot && (
            <>
              <span className="mx-1.5 text-brand-dark/30">·</span>
              <span>{order.delivery_slot}</span>
            </>
          )}
        </div>
      </div>
      <div className="mt-4 flex items-end justify-between">
        <p className="text-title-3 font-display font-bold text-brand-dark tabular-nums">
          £{order.total_amount.toFixed(2)}
        </p>
        <span className="text-caption text-brand-olive-deep font-semibold">View →</span>
      </div>
    </Card>
  )
  return href ? <Link href={href}>{content}</Link> : content
}
