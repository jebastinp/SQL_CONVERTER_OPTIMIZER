'use client'

import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Boxes,
  LayoutDashboard,
  ListOrdered,
  CreditCard,
  Tags,
  Truck,
  Users,
  HelpCircle,
  FileSpreadsheet,
  LogOut,
} from 'lucide-react'
import { BRAND, ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { cn } from '@/lib/cn'

const ITEMS = [
  { href: ROUTES.adminDashboard, label: 'Dashboard', icon: LayoutDashboard },
  { href: ROUTES.adminOrders, label: 'Orders', icon: ListOrdered, badge: 'priority' as const },
  { href: ROUTES.adminPayments, label: 'Payments', icon: CreditCard },
  { href: ROUTES.adminProducts, label: 'Products', icon: Boxes },
  { href: ROUTES.adminCategories, label: 'Categories', icon: Tags },
  { href: ROUTES.adminCustomers, label: 'Customers', icon: Users },
  { href: ROUTES.adminDelivery, label: 'Delivery', icon: Truck },
  { href: ROUTES.adminSupport, label: 'Support', icon: HelpCircle },
  { href: ROUTES.adminReports, label: 'Reports', icon: FileSpreadsheet },
] as const

export function AdminSidebar() {
  const pathname = usePathname() ?? ''
  const { user, signOut } = useAuth()

  return (
    <aside
      className="hidden md:flex w-64 shrink-0 flex-col"
      style={{ paddingTop: 'env(safe-area-inset-top)' }}
    >
      <div className="m-3 flex-1 flex flex-col material-thick rounded-card overflow-hidden">
        {/* Header */}
        <div className="px-4 py-4 flex items-center gap-3 border-b border-glass-border-dark">
          <Image src={BRAND.logoPath} alt={BRAND.name} width={36} height={36} />
          <div className="min-w-0">
            <p className="text-callout font-display font-semibold text-brand-dark truncate">
              {BRAND.name}
            </p>
            <p className="text-caption text-brand-dark/55">Admin Console</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5">
          {ITEMS.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(href + '/')
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-md text-callout font-medium transition',
                  active
                    ? 'bg-brand-olive text-white shadow-glass'
                    : 'text-brand-dark/80 hover:bg-brand-dark/5',
                )}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{label}</span>
              </Link>
            )
          })}
        </nav>

        {/* User footer */}
        <div className="p-3 border-t border-glass-border-dark">
          {user && (
            <div className="px-3 py-2">
              <p className="text-footnote font-medium text-brand-dark truncate">{user.name}</p>
              <p className="text-caption text-brand-dark/55 truncate">{user.email}</p>
            </div>
          )}
          <button
            onClick={signOut}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-callout font-medium text-brand-dark/80 hover:bg-brand-dark/5 transition"
          >
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
        </div>
      </div>
    </aside>
  )
}
