'use client'

import { Search, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { cn } from '@/lib/cn'

interface SearchBarProps {
  value: string
  onChange: (next: string) => void
  placeholder?: string
  autoFocus?: boolean
  className?: string
}

/**
 * SearchBar — controlled input with debounced upstream updates.
 * Renders as a translucent pill that sits cleanly on any glass surface.
 */
export function SearchBar({
  value,
  onChange,
  placeholder = 'Search…',
  autoFocus,
  className,
}: SearchBarProps) {
  const [internal, setInternal] = useState(value)

  // Push internal → external on change with a 200ms debounce
  useEffect(() => {
    const id = window.setTimeout(() => onChange(internal), 200)
    return () => window.clearTimeout(id)
  }, [internal, onChange])

  // Sync external → internal when the parent resets the value
  useEffect(() => {
    setInternal(value)
  }, [value])

  return (
    <div className={cn('relative', className)}>
      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-dark/50 pointer-events-none" />
      <input
        type="search"
        value={internal}
        autoFocus={autoFocus}
        onChange={(e) => setInternal(e.target.value)}
        placeholder={placeholder}
        className="field-search pl-11 pr-11"
        aria-label={placeholder}
      />
      {internal && (
        <button
          type="button"
          onClick={() => {
            setInternal('')
            onChange('')
          }}
          className="absolute right-3 top-1/2 -translate-y-1/2 icon-btn w-7 h-7"
          aria-label="Clear search"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  )
}
