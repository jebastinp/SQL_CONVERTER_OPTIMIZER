'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Minus, Plus, Lock } from 'lucide-react'
import { Sheet } from '@/components/ui/Sheet'
import { Button } from '@/components/ui/Button'
import { ROUTES } from '@/lib/constants'
import type { Product } from '@/lib/api/products'
import { useAuth } from '@/providers/AuthProvider'
import { useCart } from '@/providers/CartProvider'
import { useToast } from '@/providers/ToastProvider'

interface Props {
  product: Product
  open: boolean
  onClose: () => void
}

const STEP = 0.5

export function AddToCartModal({ product, open, onClose }: Props) {
  const router = useRouter()
  const { user, loading } = useAuth()
  const { add } = useCart()
  const toast = useToast()

  const [qty, setQty] = useState<number>(0.5)

  const oneKg = product.one_kg_price ?? product.price_per_kg
  const halfKg = product.half_kg_price ?? Math.round((product.price_per_kg / 2) * 100) / 100

  const fullKgs = Math.floor(qty)
  const hasHalf = qty - fullKgs === 0.5
  const total = fullKgs * oneKg + (hasHalf ? halfKg : 0)

  if (!open) return null

  // ── Auth gate ─────────────────────────────────────────────────────────────
  if (!loading && !user) {
    return (
      <Sheet open={open} onClose={onClose} title="Sign in to add items" size="sm">
        <div className="text-center space-y-4 py-2">
          <div className="mx-auto w-14 h-14 rounded-full material-thin flex items-center justify-center">
            <Lock className="w-6 h-6 text-brand-olive-deep" />
          </div>
          <div className="space-y-1">
            <p className="text-callout font-medium text-brand-dark">
              You need an account to shop
            </p>
            <p className="text-footnote text-brand-dark/70">
              Sign in or create one — it takes less than a minute.
            </p>
          </div>
          <div className="flex flex-col gap-2 pt-2">
            <Button
              fullWidth
              onClick={() => {
                onClose()
                router.push(ROUTES.login)
              }}
            >
              Sign in
            </Button>
            <Button
              fullWidth
              variant="outline"
              onClick={() => {
                onClose()
                router.push(ROUTES.register)
              }}
            >
              Create account
            </Button>
          </div>
        </div>
      </Sheet>
    )
  }

  return (
    <Sheet open={open} onClose={onClose} title={product.name}>
      <div className="space-y-4">
        {product.description && (
          <p className="text-footnote text-brand-dark/70 line-clamp-3">
            {product.description}
          </p>
        )}

        {/* Quantity stepper */}
        <div className="material-thin rounded-card p-4 flex items-center justify-between">
          <div>
            <p className="text-caption uppercase tracking-wider text-brand-dark/60">Quantity</p>
            <p className="text-title-2 font-semibold mt-1">
              {qty.toFixed(1)}
              <span className="text-callout text-brand-dark/60 ml-1">kg</span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="icon-btn"
              aria-label="Decrease"
              onClick={() => setQty((q) => Math.max(STEP, +(q - STEP).toFixed(1)))}
            >
              <Minus className="w-4 h-4" />
            </button>
            <button
              className="icon-btn"
              aria-label="Increase"
              onClick={() => setQty((q) => +(q + STEP).toFixed(1))}
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Breakdown */}
        <div className="text-footnote text-brand-dark/70 flex justify-between">
          <span>
            {fullKgs > 0 && (
              <>
                {fullKgs} × £{oneKg.toFixed(2)}
              </>
            )}
            {fullKgs > 0 && hasHalf && ' + '}
            {hasHalf && <>½ kg × £{halfKg.toFixed(2)}</>}
          </span>
          <span className="font-semibold text-brand-dark text-callout">
            £{total.toFixed(2)}
          </span>
        </div>

        <Button
          fullWidth
          onClick={() => {
            add(product, qty)
            toast.success('Added to cart', `${qty.toFixed(1)} kg of ${product.name}`)
            onClose()
          }}
        >
          Add to cart · £{total.toFixed(2)}
        </Button>
      </div>
    </Sheet>
  )
}
