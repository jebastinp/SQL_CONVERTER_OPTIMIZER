'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { Plus } from 'lucide-react'
import { ROUTES } from '@/lib/constants'
import type { Product } from '@/lib/api/products'
import { Card } from '@/components/ui/Card'
import { AddToCartModal } from '@/components/product/AddToCartModal'

export function ProductCard({ product }: { product: Product }) {
  const [open, setOpen] = useState(false)
  const price = product.one_kg_price ?? product.price_per_kg

  return (
    <>
      <Card padded={false} interactive className="overflow-hidden group">
        <Link href={ROUTES.product(product.slug)} className="block">
          <div className="aspect-square relative bg-brand-beige-deep/40">
            {product.image_url ? (
              <Image
                src={product.image_url}
                alt={product.name}
                fill
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                className="object-cover transition duration-500 group-hover:scale-105"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-brand-dark/30 text-footnote">
                No image
              </div>
            )}
            {!product.is_active && (
              <div className="absolute top-2 left-2 pill bg-brand-dark/80 text-white">
                Inactive
              </div>
            )}
          </div>
        </Link>
        <div className="p-4 flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <Link href={ROUTES.product(product.slug)}>
              <h3 className="font-display font-semibold text-callout text-brand-dark line-clamp-1">
                {product.name}
              </h3>
            </Link>
            {product.category && (
              <p className="text-caption text-brand-dark/55 mt-0.5">{product.category.name}</p>
            )}
            <p className="mt-2 font-semibold text-brand-dark">
              £{price.toFixed(2)}
              <span className="text-caption text-brand-dark/55 font-normal"> / kg</span>
            </p>
          </div>
          <button
            aria-label={`Add ${product.name} to cart`}
            onClick={(e) => {
              e.preventDefault()
              setOpen(true)
            }}
            className="icon-btn w-10 h-10 shrink-0 bg-brand-olive text-white border-transparent shadow-glass hover:bg-brand-olive-deep"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </Card>
      <AddToCartModal product={product} open={open} onClose={() => setOpen(false)} />
    </>
  )
}
