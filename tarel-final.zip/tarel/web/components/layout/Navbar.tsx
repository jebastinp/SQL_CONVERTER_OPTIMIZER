'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ShoppingCart, Search, User, LogOut } from 'lucide-react'
import { BRAND, ROUTES, COPY } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { useCart } from '@/providers/CartProvider'

export function Navbar() {
  const router = useRouter()
  const { user, signOut } = useAuth()
  const { itemCount } = useCart()

  return (
    <header
      className="sticky top-0 z-30"
      style={{ paddingTop: 'env(safe-area-inset-top)' }}
    >
      <div className="material-thin border-b border-glass-border-dark">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <Link href={ROUTES.home} className="flex items-center gap-2 active:scale-95 transition">
            <Image src={BRAND.logoPath} alt={BRAND.name} width={28} height={28} priority />
            <span className="font-display font-semibold text-headline text-brand-dark hidden sm:inline">
              {BRAND.name}
            </span>
          </Link>

          {/* Inline search — hidden on smallest screens; mobile uses /search */}
          <div className="hidden sm:flex flex-1 max-w-md mx-4">
            <button
              onClick={() => router.push(ROUTES.products)}
              className="field-search w-full text-left text-brand-dark/50 flex items-center gap-2"
            >
              <Search className="w-4 h-4" />
              Search products…
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => router.push(ROUTES.products)}
              className="icon-btn sm:hidden"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            <Link href={ROUTES.cart} className="icon-btn relative" aria-label="Cart">
              <ShoppingCart className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-brand-olive text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white">
                  {itemCount > 99 ? '99+' : itemCount}
                </span>
              )}
            </Link>

            {user ? (
              <>
                <Link href={ROUTES.account} className="icon-btn hidden md:inline-flex" aria-label="Account">
                  <User className="w-5 h-5" />
                </Link>
                <button onClick={signOut} className="icon-btn hidden md:inline-flex" aria-label="Sign out">
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <Link href={ROUTES.login} className="btn btn-sm hidden md:inline-flex">
                {COPY.signIn}
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
