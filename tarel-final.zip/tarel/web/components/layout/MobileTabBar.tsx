'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Search, ShoppingBag, ListOrdered, User } from 'lucide-react'
import { ROUTES } from '@/lib/constants'
import { useAuth } from '@/providers/AuthProvider'
import { useCart } from '@/providers/CartProvider'
import { cn } from '@/lib/cn'

interface TabDef {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  match: (path: string) => boolean
  badge?: number
}

export function MobileTabBar() {
  const pathname = usePathname() ?? ''
  const { user } = useAuth()
  const { itemCount } = useCart()

  // Hide on admin routes — admin has its own chrome.
  if (pathname.startsWith('/' + (process.env.NEXT_PUBLIC_ADMIN_PATH ?? 'tarel-control'))) {
    return null
  }

  const tabs: TabDef[] = [
    {
      href: ROUTES.home,
      label: 'Home',
      icon: Home,
      match: (p) => p === '/' || p === '',
    },
    {
      href: ROUTES.products,
      label: 'Shop',
      icon: Search,
      match: (p) => p.startsWith('/products') || p.startsWith('/categories'),
    },
    {
      href: ROUTES.cart,
      label: 'Cart',
      icon: ShoppingBag,
      match: (p) => p.startsWith('/cart') || p.startsWith('/checkout'),
      badge: itemCount,
    },
    {
      href: user ? ROUTES.accountOrders : ROUTES.login,
      label: 'Orders',
      icon: ListOrdered,
      match: (p) => p.startsWith('/account/orders'),
    },
    {
      href: user ? ROUTES.account : ROUTES.login,
      label: user ? 'Account' : 'Sign in',
      icon: User,
      match: (p) => p.startsWith('/account') || p.startsWith('/login'),
    },
  ]

  return (
    <nav className="tab-bar md:hidden" aria-label="Primary">
      <div className="tab-bar-inner">
        {tabs.map(({ href, label, icon: Icon, match, badge }) => {
          const active = match(pathname)
          return (
            <Link key={href + label} href={href} className={cn('tab-item', active && 'active')}>
              <span className="relative">
                <Icon className="w-5 h-5" />
                {badge && badge > 0 ? (
                  <span className="absolute -top-1 -right-2 min-w-[16px] h-[16px] px-1 rounded-full bg-brand-olive text-white text-[9px] font-bold flex items-center justify-center">
                    {badge > 9 ? '9+' : badge}
                  </span>
                ) : null}
              </span>
              <span>{label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
