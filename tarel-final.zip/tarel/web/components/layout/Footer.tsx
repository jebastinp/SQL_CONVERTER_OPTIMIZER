import Image from 'next/image'
import Link from 'next/link'
import { BRAND, ROUTES } from '@/lib/constants'

export function Footer() {
  return (
    <footer className="mt-12 md:mt-16">
      <div className="material-thin border-t border-glass-border-dark">
        <div className="max-w-6xl mx-auto px-4 py-6 flex flex-col sm:flex-row gap-4 sm:items-center sm:justify-between text-footnote text-brand-dark/70">
          <div className="flex items-center gap-2">
            <Image src={BRAND.logoPath} alt={BRAND.name} width={20} height={20} />
            <p>© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</p>
          </div>
          <nav className="flex flex-wrap gap-4">
            <Link href={ROUTES.legal('terms')} className="hover:text-brand-dark">Terms</Link>
            <Link href={ROUTES.legal('privacy')} className="hover:text-brand-dark">Privacy</Link>
            <Link href={ROUTES.legal('cookies')} className="hover:text-brand-dark">Cookies</Link>
          </nav>
        </div>
      </div>
    </footer>
  )
}
