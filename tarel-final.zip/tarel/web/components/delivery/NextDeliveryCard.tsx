'use client'

import { Truck } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { Card } from '@/components/ui/Card'

interface DeliverySettings {
  cutoff_day: number   // 0=Mon … 6=Sun
  delivery_day: number
}

const DAY_NAMES = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
]

/**
 * Preserved verbatim from backend `delivery_utils.py` —
 * port to the browser so the user sees the SAME calculation that the
 * backend will eventually accept/reject orders against.
 */
function sundayStart(target: Date): Date {
  const d = new Date(target)
  d.setHours(0, 0, 0, 0)
  // JS: Mon=1..Sun=0; Python weekday: Mon=0..Sun=6
  const pythonWeekday = (d.getDay() + 6) % 7
  const offset = (pythonWeekday + 1) % 7
  d.setDate(d.getDate() - offset)
  return d
}

function getDeliveryDate(orderDate: Date, deliveryDay: number): Date {
  const weekStart = sundayStart(orderDate)
  const offset = deliveryDay + 1
  const result = new Date(weekStart)
  result.setDate(result.getDate() + 7 + offset)
  return result
}

function formatLong(d: Date): string {
  return d.toLocaleDateString(undefined, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  })
}

function daysBetween(a: Date, b: Date): number {
  const ms = b.getTime() - a.getTime()
  return Math.ceil(ms / (1000 * 60 * 60 * 24))
}

/**
 * Optionally accepts `settings`. If not given, defaults to
 * `(cutoff_day=4, delivery_day=2)` matching the backend defaults.
 */
export function NextDeliveryCard({ settings }: { settings?: DeliverySettings }) {
  const [now, setNow] = useState<Date | null>(null)

  // Defer to client to avoid hydration mismatches around midnight.
  useEffect(() => {
    setNow(new Date())
  }, [])

  const effective = settings ?? { cutoff_day: 4, delivery_day: 2 }

  const { deliveryDate, cutoffDate, daysToCutoff } = useMemo(() => {
    if (!now) {
      return { deliveryDate: null, cutoffDate: null, daysToCutoff: 0 }
    }
    const delivery = getDeliveryDate(now, effective.delivery_day)
    const weekStart = sundayStart(delivery)
    weekStart.setDate(weekStart.getDate() - 7) // order week start
    const cutoff = new Date(weekStart)
    cutoff.setDate(cutoff.getDate() + effective.cutoff_day + 1)
    return {
      deliveryDate: delivery,
      cutoffDate: cutoff,
      daysToCutoff: daysBetween(now, cutoff),
    }
  }, [now, effective])

  return (
    <Card className="overflow-hidden">
      <div className="flex items-start gap-4">
        <div className="w-11 h-11 rounded-pill bg-brand-olive/15 flex items-center justify-center shrink-0">
          <Truck className="w-5 h-5 text-brand-olive-deep" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-caption uppercase tracking-wider text-brand-dark/55">
            Next delivery window
          </p>
          {deliveryDate ? (
            <>
              <p className="font-display text-title-3 font-semibold text-brand-dark mt-0.5">
                {formatLong(deliveryDate)}
              </p>
              <p className="text-footnote text-brand-dark/70 mt-1">
                Order by{' '}
                <span className="font-semibold text-brand-dark">
                  {DAY_NAMES[effective.cutoff_day]}
                </span>
                {cutoffDate && (
                  <>
                    {' '}({cutoffDate.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })})
                  </>
                )}
                {' · '}
                {daysToCutoff > 0
                  ? `${daysToCutoff} day${daysToCutoff === 1 ? '' : 's'} left`
                  : 'cutoff passed'}
              </p>
            </>
          ) : (
            <p className="text-footnote text-brand-dark/55 mt-1">Loading…</p>
          )}
        </div>
      </div>
    </Card>
  )
}
