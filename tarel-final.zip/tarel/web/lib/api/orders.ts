/**
 * Orders endpoints — typed wrappers.
 */

import { apiFetch } from '@/lib/api/client'

export type OrderStatus =
  | 'pending'
  | 'paid'
  | 'processing'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled'

export interface OrderItemInput {
  product_uuid: string
  qty_kg: number
  cut_clean_label?: string | null
}

export interface OrderItem {
  id: string
  product_id: string
  product_name: string
  qty_kg: number
  price_per_kg: number
  line_total: number
  cut_clean_label: string | null
}

export interface OrderSummary {
  id: string
  code: string | null
  status: OrderStatus
  total_amount: number
  item_count: number
  created_at: string
  delivery_date: string | null
  delivery_slot: string | null
}

export interface AdminOrderSummary extends OrderSummary {
  customer_name: string | null
  customer_email: string | null
  customer_postcode: string | null
}

export interface OrderDetail {
  id: string
  code: string | null
  status: OrderStatus
  total_amount: number
  order_date: string
  delivery_date: string | null
  delivery_slot: string | null
  notes: string | null
  items: OrderItem[]
  created_at: string
  paid_at: string | null
  delivered_at: string | null
  cancelled_at: string | null
  cancellation_allowed: boolean
}

export interface CreateOrderRequest {
  items: OrderItemInput[]
  delivery_slot?: string
  notes?: string
}

export interface CheckoutResponse {
  payment_id: string
  checkout_url: string
  amount: number
  currency: string
}

export const ordersApi = {
  // User
  listMine: () => apiFetch<OrderSummary[]>('/orders/me'),
  getMine: (orderUuid: string) => apiFetch<OrderDetail>(`/orders/${orderUuid}`),
  place: (payload: CreateOrderRequest) =>
    apiFetch<OrderDetail>('/orders', { method: 'POST', body: payload }),
  cancelMine: (orderUuid: string) =>
    apiFetch<OrderDetail>(`/orders/${orderUuid}/cancel`, { method: 'POST' }),
  startCheckout: (orderUuid: string) =>
    apiFetch<CheckoutResponse>(`/orders/${orderUuid}/checkout`, { method: 'POST' }),
  getPaymentStatus: (orderUuid: string) =>
    apiFetch<{ status: string; amount: number; currency: string }>(
      `/orders/${orderUuid}/payment`,
    ),

  // Admin
  adminList: () => apiFetch<AdminOrderSummary[]>('/admin/orders'),
  adminGet: (orderUuid: string) =>
    apiFetch<OrderDetail>(`/admin/orders/${orderUuid}`),
  adminUpdateStatus: (orderUuid: string, status: OrderStatus) =>
    apiFetch<OrderDetail>(`/admin/orders/${orderUuid}/status`, {
      method: 'PATCH',
      body: { status },
    }),
  adminRefund: (orderUuid: string, amount?: number, reason?: string) =>
    apiFetch<{ id: string; amount: number; status: string }>(
      `/admin/orders/${orderUuid}/refund`,
      {
        method: 'POST',
        body: { amount, reason },
      },
    ),
}
