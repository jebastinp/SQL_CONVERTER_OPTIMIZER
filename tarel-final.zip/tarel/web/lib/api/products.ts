/**
 * Products endpoints — typed wrappers over the generic apiFetch.
 */

import { apiFetch } from '@/lib/api/client'

export interface CategoryBrief {
  id: string // uuid
  name: string
  slug: string
  description: string | null
  is_active: boolean
}

export interface Product {
  id: string // uuid (the integer PK is hidden by the backend)
  code: string | null
  name: string
  slug: string
  description: string | null
  price_per_kg: number
  half_kg_price: number | null
  one_kg_price: number | null
  image_url: string | null
  stock_kg: number
  is_dry: boolean
  is_active: boolean
  category: CategoryBrief | null
}

export interface CutCleanOption {
  id: string
  label: string
  is_active: boolean
  sort_order: number
}

export const productsApi = {
  list: () => apiFetch<Product[]>('/products'),
  getBySlug: (slug: string) => apiFetch<Product>(`/products/${slug}`),
  cutCleanOptions: () => apiFetch<CutCleanOption[]>('/products/cut-clean-options'),

  // Admin-only — token must carry role=admin
  create: (payload: Partial<Product> & { category_uuid: string }) =>
    apiFetch<Product>('/products', { method: 'POST', body: payload }),
  update: (productUuid: string, payload: Partial<Product>) =>
    apiFetch<Product>(`/products/${productUuid}`, { method: 'PATCH', body: payload }),
  remove: (productUuid: string) =>
    apiFetch<{ message: string }>(`/products/${productUuid}`, { method: 'DELETE' }),
}
