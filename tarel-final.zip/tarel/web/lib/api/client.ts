/**
 * API client.
 *
 * - Every request carries an ``X-Request-ID`` (uuid4) so the server's
 *   per-request log files can be cross-referenced from frontend errors.
 * - The bearer token comes from the live Supabase session (or from the
 *   ``token`` option if explicitly passed).
 * - All header/route literals come from ``lib/constants.ts``.
 */

import {
  API_BASE,
  AUTH_SCHEME_BEARER,
  HEADERS,
} from '@/lib/constants'
import { getSupabaseClient } from '@/lib/supabase/client'

export class ApiError extends Error {
  status: number
  requestId: string | null
  body: unknown

  constructor(message: string, opts: { status: number; requestId: string | null; body: unknown }) {
    super(message)
    this.name = 'ApiError'
    this.status = opts.status
    this.requestId = opts.requestId
    this.body = opts.body
  }
}

function uuidv4(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID()
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

async function getActiveToken(): Promise<string | null> {
  if (typeof window === 'undefined') return null
  try {
    const supabase = getSupabaseClient()
    const { data } = await supabase.auth.getSession()
    return data.session?.access_token ?? null
  } catch {
    return null
  }
}

export interface ApiOptions extends Omit<RequestInit, 'body' | 'headers'> {
  body?: unknown
  headers?: Record<string, string>
  /** Override the auth token. ``null`` sends no Authorization header. */
  token?: string | null
  /** If true, return raw Response (e.g. for file downloads). */
  raw?: boolean
}

export async function apiFetch<T = unknown>(
  path: string,
  options: ApiOptions = {},
): Promise<T> {
  const requestId = uuidv4()
  const token = options.token !== undefined ? options.token : await getActiveToken()

  const headers: Record<string, string> = {
    [HEADERS.requestId]: requestId,
    ...(options.headers ?? {}),
  }
  // Only set Content-Type for non-GET; some CORS preflights are fussy.
  if (options.body != null && !headers[HEADERS.contentType]) {
    headers[HEADERS.contentType] = 'application/json'
  }
  if (token) {
    headers[HEADERS.authorization] = `${AUTH_SCHEME_BEARER} ${token}`
  }

  const url = path.startsWith('http') ? path : `${API_BASE}${path}`

  const response = await fetch(url, {
    ...options,
    headers,
    body: options.body == null ? undefined : JSON.stringify(options.body),
  })

  const responseRequestId = response.headers.get(HEADERS.requestId)

  if (options.raw) return response as unknown as T
  if (response.status === 204) return undefined as unknown as T

  const text = await response.text()
  let parsed: unknown = undefined
  if (text) {
    try {
      parsed = JSON.parse(text)
    } catch {
      parsed = text
    }
  }

  if (!response.ok) {
    const message =
      parsed &&
      typeof parsed === 'object' &&
      'detail' in parsed &&
      typeof (parsed as { detail: unknown }).detail === 'string'
        ? (parsed as { detail: string }).detail
        : `Request failed with status ${response.status}`
    throw new ApiError(message, {
      status: response.status,
      requestId: responseRequestId,
      body: parsed,
    })
  }
  return parsed as T
}

/**
 * Download a file as a Blob (for "Download report" admin buttons).
 */
export async function apiDownload(path: string): Promise<Blob> {
  const response = (await apiFetch(path, { raw: true })) as unknown as Response
  if (!response.ok) {
    throw new ApiError(`Download failed: ${response.status}`, {
      status: response.status,
      requestId: response.headers.get(HEADERS.requestId),
      body: null,
    })
  }
  return await response.blob()
}
