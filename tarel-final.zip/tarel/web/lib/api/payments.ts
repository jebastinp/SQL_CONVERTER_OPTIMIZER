/**
 * Payment endpoints — typed wrappers over apiFetch.
 *
 * The actual checkout flow is:
 *   1. POST /orders            → creates the order
 *   2. POST /orders/{uuid}/checkout → returns a hosted-checkout URL
 *   3. Browser is redirected to that URL
 *   4. Gateway eventually POSTs to /webhook/handypay (server-to-server)
 *   5. Browser lands on /checkout/success or /checkout/cancelled
 */

import { apiFetch } from '@/lib/api/client'

export interface PaymentSummary {
  id: string
  code: string | null
  order_id: string
  provider: string
  provider_payment_id: string | null
  amount: number
  currency: string
  status:
    | 'pending'
    | 'succeeded'
    | 'failed'
    | 'cancelled'
    | 'refunded'
    | 'partially_refunded'
  confirmed_at: string | null
  failure_reason: string | null
  created_at: string
  total_refunded: number
}

export interface CheckoutSession {
  payment: PaymentSummary
  checkout_url: string
}

export interface RefundOut {
  id: string
  code: string | null
  payment_id: string
  provider_refund_id: string | null
  amount: number
  reason: string | null
  status: 'pending' | 'succeeded' | 'failed'
  confirmed_at: string | null
  created_at: string
}

export const paymentsApi = {
  startCheckout: (orderUuid: string) =>
    apiFetch<CheckoutSession>(`/orders/${orderUuid}/checkout`, { method: 'POST' }),

  getOrderPayment: (orderUuid: string) =>
    apiFetch<PaymentSummary>(`/orders/${orderUuid}/payment`),

  // ── Admin ────────────────────────────────────────────────────────────────
  adminList: () => apiFetch<PaymentSummary[]>('/admin/payments'),

  adminRefund: (paymentUuid: string, amount: number, reason?: string | null) =>
    apiFetch<PaymentSummary>(`/admin/payments/${paymentUuid}/refund`, {
      method: 'POST',
      body: { amount, reason: reason ?? null },
    }),
}
