import { apiFetch } from '@/lib/api/client'

export interface Category {
  id: string
  code: string | null
  name: string
  slug: string
  description: string | null
  is_active: boolean
  sort_order: number
}

export interface CategoryCreate {
  name: string
  slug: string
  description?: string | null
  is_active?: boolean
  sort_order?: number
}

export const categoriesApi = {
  list: () => apiFetch<Category[]>('/categories'),
  get: (slug: string) => apiFetch<Category>(`/categories/${slug}`),

  adminList: () => apiFetch<Category[]>('/admin/categories'),
  adminCreate: (payload: CategoryCreate) =>
    apiFetch<Category>('/admin/categories', { method: 'POST', body: payload }),
  adminUpdate: (uuid: string, payload: Partial<CategoryCreate>) =>
    apiFetch<Category>(`/admin/categories/${uuid}`, { method: 'PATCH', body: payload }),
  adminDelete: (uuid: string) =>
    apiFetch<{ message: string }>(`/admin/categories/${uuid}`, { method: 'DELETE' }),
}
