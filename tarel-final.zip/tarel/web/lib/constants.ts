/**
 * Central frontend constants.
 *
 * Rule (mirrors the backend): if you find yourself typing a literal
 * string or number in components or pages, add it here first.
 */

// ── Environment-derived ─────────────────────────────────────────────────────
export const ADMIN_PATH =
  process.env.NEXT_PUBLIC_ADMIN_PATH ?? 'tarel-control'

// Backend API base. Same-origin so it works on localhost AND on
// the LAN IP from a phone (Next.js rewrites /api/* to the backend).
export const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE ?? '/api/v1'

// ── HTTP ────────────────────────────────────────────────────────────────────
export const HEADERS = {
  requestId: 'X-Request-ID',
  contentType: 'Content-Type',
  authorization: 'Authorization',
} as const

export const AUTH_SCHEME_BEARER = 'Bearer'
export const AUTH_COOKIE_NAME = 'tarel_session'
export const AUTH_STORAGE_KEY = 'tarel.token'

// ── Roles ───────────────────────────────────────────────────────────────────
export const ROLES = {
  user: 'user',
  admin: 'admin',
} as const

export type Role = (typeof ROLES)[keyof typeof ROLES]

// ── Routes (the only place hardcoded paths exist) ───────────────────────────
export const ROUTES = {
  home: '/',
  products: '/products',
  product: (slug: string) => `/products/${slug}`,
  categories: '/categories',
  cart: '/cart',
  checkout: '/checkout',
  checkoutSuccess: '/checkout/success',
  checkoutCancelled: '/checkout/cancelled',
  login: '/login',
  register: '/register',
  account: '/account',
  accountOrders: '/account/orders',
  accountProfile: '/account/profile',
  accountSupport: '/account/support',
  legal: (slug: string) => `/legal/${slug}`,
  notFound: '/not-found',

  // Admin routes are built off ADMIN_PATH so changing the slug only
  // touches the env var, never the code.
  adminRoot: `/${ADMIN_PATH}`,
  adminLogin: `/${ADMIN_PATH}/login`,
  adminDashboard: `/${ADMIN_PATH}/dashboard`,
  adminProducts: `/${ADMIN_PATH}/products`,
  adminCategories: `/${ADMIN_PATH}/categories`,
  adminOrders: `/${ADMIN_PATH}/orders`,
  adminPayments: `/${ADMIN_PATH}/payments`,
  adminCustomers: `/${ADMIN_PATH}/customers`,
  adminDelivery: `/${ADMIN_PATH}/delivery`,
  adminSupport: `/${ADMIN_PATH}/support`,
  adminReports: `/${ADMIN_PATH}/reports`,
} as const

// ── Pagination ──────────────────────────────────────────────────────────────
export const PAGE_SIZE_DEFAULT = 12
export const PAGE_SIZE_ORDERS = 9 // 3 per row × 3 rows
export const ORDERS_PER_ROW = 3

// ── Branding ────────────────────────────────────────────────────────────────
export const BRAND = {
  name: 'Tarel',
  logoPath: '/logo.png',
  palette: {
    dark: '#2F4135',
    olive: '#708E53',
    beige: '#E9E2D5',
  },
} as const

// ── UI literals ─────────────────────────────────────────────────────────────
export const COPY = {
  notFoundTitle: 'Page not found',
  notFoundBody: 'The page you’re looking for doesn’t exist.',
  loading: 'Loading…',
  errorGeneric: 'Something went wrong. Please try again.',
  cartEmpty: 'Your cart is empty',
  ordersEmpty: 'You have no orders yet',
  signIn: 'Sign in',
  signOut: 'Sign out',
  signUp: 'Create an account',
} as const

// ── Order statuses (mirror of backend) ──────────────────────────────────────
export const ORDER_STATUS = {
  pending: 'pending',
  paid: 'paid',
  processing: 'processing',
  outForDelivery: 'out_for_delivery',
  delivered: 'delivered',
  cancelled: 'cancelled',
} as const

export type OrderStatus = (typeof ORDER_STATUS)[keyof typeof ORDER_STATUS]

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  pending: 'Pending',
  paid: 'Paid',
  processing: 'Processing',
  out_for_delivery: 'Out for delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
}
