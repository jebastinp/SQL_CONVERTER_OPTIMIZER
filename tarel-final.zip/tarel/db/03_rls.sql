-- =============================================================================
-- Tarel v2 — Row-Level Security (defense in depth)
-- =============================================================================
-- Our backend authenticates customers, scopes every query to the
-- current user, and connects to Postgres as the `postgres` superuser
-- (which bypasses RLS). So RLS is not the PRIMARY defense — the
-- service layer is.
--
-- This file adds RLS as a SECOND layer: if some future code path or
-- ad-hoc query ever talks to the DB as the Supabase `anon` or
-- `authenticated` roles, those roles get **deny-by-default**. They
-- have zero access to any tarel table.
--
-- Run this AFTER 01_schema.sql and 02_payments.sql in Supabase
-- SQL Editor.
-- =============================================================================

-- ── Re-enable RLS on every domain table ────────────────────────────────────
-- (The earlier scripts disable RLS so the backend can write. We
-- re-enable it here AND keep the `postgres` role's bypass intact.)
alter table public.users             enable row level security;
alter table public.categories        enable row level security;
alter table public.products          enable row level security;
alter table public.cut_clean_options enable row level security;
alter table public.delivery_settings enable row level security;
alter table public.orders            enable row level security;
alter table public.order_items       enable row level security;
alter table public.support_messages  enable row level security;
alter table public.delivery_orders   enable row level security;
alter table public.site_settings     enable row level security;
alter table public.payments          enable row level security;
alter table public.refunds           enable row level security;
alter table public.payment_events    enable row level security;

-- ── Force RLS even for table owners (catches super-careful auditors) ─────
-- The `postgres` role is the table owner; by default it bypasses RLS.
-- We DON'T force it here because the backend connects as postgres and
-- needs unrestricted access. If you ever switch the backend to use a
-- limited role, run `alter table ... force row level security` on
-- those tables.

-- ── Public read access for the storefront catalog ──────────────────────────
-- Customers can browse products without being logged in. These rows
-- are public anyway, so we expose them to the `anon` role too. The
-- backend still uses postgres so this is purely belt-and-braces.
do $$
declare
  t text;
begin
  for t in select unnest(array['categories', 'products', 'cut_clean_options'])
  loop
    execute format(
      'drop policy if exists pub_read on public.%I', t
    );
    execute format(
      'create policy pub_read on public.%I for select to anon, authenticated using (is_active = true)',
      t
    );
  end loop;
end$$;

-- Delivery settings: read-only public so the "next delivery window"
-- widget can be rendered server-side without auth.
drop policy if exists pub_read on public.delivery_settings;
create policy pub_read on public.delivery_settings
  for select to anon, authenticated using (true);

-- Site settings: same.
drop policy if exists pub_read on public.site_settings;
create policy pub_read on public.site_settings
  for select to anon, authenticated using (true);

-- ── Everything else: NO access via anon or authenticated roles ─────────────
-- (No policies defined → default deny.) The application MUST go
-- through the backend (which is the postgres role).
--
-- This guards against:
--   * accidentally querying directly from a service-key-leaking
--     environment
--   * future code paths that try to read user/order/payment data
--     from the browser via supabase-js
--
-- If you ever DO want to talk to the DB from the browser, write a
-- policy that scopes to the authenticated user. Example for users
-- table:
--
--   create policy own_row on public.users
--     for select to authenticated
--     using (supabase_id = (auth.jwt() ->> 'sub')::uuid);
--
-- For orders:
--
--   create policy own_orders on public.orders
--     for select to authenticated
--     using (user_id in (
--       select id from public.users
--       where supabase_id = (auth.jwt() ->> 'sub')::uuid
--     ));

-- ── Verify ─────────────────────────────────────────────────────────────────
-- Run this to confirm the model — every table should show rls=true:
--   select relname, relrowsecurity from pg_class
--   where relkind = 'r' and relnamespace = 'public'::regnamespace
--   order by relname;
