-- =============================================================================
-- Tarel v2 — payment-related tables
-- Run this in Supabase SQL Editor AFTER the original schema queries.
-- =============================================================================
-- Adds three new tables that the Payments module needs:
--   - payments         one row per checkout attempt
--   - refunds          one row per refund issued
--   - payment_events   audit trail of every gateway callback received
--
-- The `orders` and `order_items` tables already exist from the first
-- schema script — these are net-new additions.
-- =============================================================================

-- ── Payments ────────────────────────────────────────────────────────────────
create table if not exists public.payments (
  id                    bigserial primary key,
  uuid                  uuid not null unique default gen_random_uuid(),
  code                  varchar(32) unique,
  order_id              bigint not null references public.orders(id) on delete cascade,
  provider              varchar(32) not null default 'handypay',
  provider_payment_id   varchar(128),
  provider_checkout_url varchar(1000),
  amount                double precision not null,
  currency              varchar(8) not null default 'USD',
  status                varchar(24) not null default 'pending'
                        check (status in ('pending','succeeded','failed','cancelled','refunded','partially_refunded')),
  confirmed_at          timestamptz,
  failure_reason        varchar(255),
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index if not exists idx_payments_order on public.payments(order_id);
create index if not exists idx_payments_provider_id on public.payments(provider_payment_id);
create index if not exists idx_payments_status on public.payments(status);

-- ── Refunds ─────────────────────────────────────────────────────────────────
create table if not exists public.refunds (
  id                   bigserial primary key,
  uuid                 uuid not null unique default gen_random_uuid(),
  code                 varchar(32) unique,
  payment_id           bigint not null references public.payments(id) on delete cascade,
  provider_refund_id   varchar(128),
  amount               double precision not null,
  reason               varchar(255),
  status               varchar(16) not null default 'pending'
                       check (status in ('pending','succeeded','failed')),
  confirmed_at         timestamptz,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index if not exists idx_refunds_payment on public.refunds(payment_id);

-- ── Payment events (audit trail) ────────────────────────────────────────────
create table if not exists public.payment_events (
  id           bigserial primary key,
  uuid         uuid not null unique default gen_random_uuid(),
  code         varchar(32) unique,
  payment_id   bigint references public.payments(id) on delete cascade,
  provider     varchar(32) not null default 'handypay',
  event_type   varchar(64) not null,
  payload      text not null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists idx_payment_events_payment on public.payment_events(payment_id);

-- ── updated_at triggers ─────────────────────────────────────────────────────
do $$
declare t text;
begin
  for t in select unnest(array['payments','refunds','payment_events'])
  loop
    execute format('drop trigger if exists trg_%I_updated_at on public.%I', t, t);
    execute format(
      'create trigger trg_%I_updated_at before update on public.%I
       for each row execute function public.set_updated_at()', t, t
    );
  end loop;
end$$;

-- ── Disable RLS (backend uses service-role) ─────────────────────────────────
alter table public.payments       disable row level security;
alter table public.refunds        disable row level security;
alter table public.payment_events disable row level security;

-- ── Done ────────────────────────────────────────────────────────────────────
-- Verify with:
--   select table_name from information_schema.tables
--   where table_schema = 'public' and table_name in ('payments','refunds','payment_events');
