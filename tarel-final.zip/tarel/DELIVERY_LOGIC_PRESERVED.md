# Preserved Logic — Reference

This document is the contract: the functions and rules listed below
are moved into the new structure **without changing their behaviour**.
Names, signatures, return types, edge cases — all preserved.

## Delivery timing & date calculation
**From** `backend/app/utils/delivery_utils.py`
**To**   `backend/app/modules/delivery/utils.py`

| Function | Behaviour preserved |
|----------|---------------------|
| `get_delivery_settings(db)` | Returns latest `DeliverySetting`, creates default `(cutoff_day=4, delivery_day=2)` on first run |
| `_sunday_start(target)` | Returns the Sunday of the week containing `target` |
| `get_delivery_date(order_date, delivery_day=2)` | Order placed → delivery date = next week's `delivery_day` |
| `get_week_range(delivery_date)` | Returns `(order_week_start, order_week_end)` — Sunday→Saturday |
| `is_cancellation_allowed(order_date, cutoff_day=4, delivery_day=2, today=None)` | True iff today ≤ `order_week_start + cutoff_day + 1` |
| `calculate_bags(total_kg)` | Returns `(one_kg_count, half_kg_count)` quantised to 0.5 |
| `next_delivery_date(today, delivery_day)` | Forward to the next `delivery_day` weekday |
| `DAY_NAMES` | `["Monday", …, "Sunday"]` |

## Pricing
**From** `backend/app/utils/pricing.py`
**To**   `backend/app/modules/orders/pricing.py`

| Function | Behaviour preserved |
|----------|---------------------|
| `calculate_price(weight_kg, one_kg_price, half_kg_price)` | `full_kgs * one_kg_price + (half_kg_price if 0.5 remainder else 0)` |

## Product price derivation
**From** `backend/app/routers/products.py` (`_serialize_product`)
**To**   `backend/app/modules/products/service.py` (`_derive_prices`)

```
one_kg_price  = payload.one_kg_price  if not None else price_per_kg
half_kg_price = payload.half_kg_price if not None else round(price_per_kg / 2, 2)
# both must end up non-None or raise 400
```

## Order rules (to be migrated)
**From** `backend/app/routers/orders.py` and `routers/admin.py`
**To**   `backend/app/modules/orders/service.py`

These get moved in the orders-module phase, unchanged:
- Status transitions (`pending → paid → processing → out_for_delivery → delivered`, `cancelled` from any non-terminal)
- Cancellation honours `is_cancellation_allowed`
- Total = sum of `qty_kg * price_per_kg` for items
- Stock decrement on `paid`, restock on `cancelled`

## What IS changing (deliberately)

These are not business logic; they're transport or storage details:

| Was | Now |
|-----|-----|
| Google OAuth + own JWT issuance | Supabase Auth issues JWTs; we verify |
| Cloudinary (optional) | Cloudflare R2 (required for product images) |
| UUID primary key | `id` (BIGSERIAL) + `uuid` (exposed to frontend) |
| One log file `app.log` | One file per request in `logs/requests/<id>.log` |
| Constants scattered in code | Centralised in `core/constants.py` / `lib/constants.ts` |
| Two frontend apps | One Next.js app with hidden admin slug |
