# Tarel

Full-stack weekly-delivery / e-commerce platform.

This is the **v2 rebuild**. See:
- [`ARCHITECTURE_AND_PLAN.md`](./ARCHITECTURE_AND_PLAN.md) — target architecture and design decisions
- [`DELIVERY_LOGIC_PRESERVED.md`](./DELIVERY_LOGIC_PRESERVED.md) — every preserved function listed by name
- [`CONTINUATION_PLAN.md`](./CONTINUATION_PLAN.md) — what's done, what's next, in what order

## Layout

```
.
├── backend/         FastAPI · async SQLAlchemy · SOLID · repository pattern
├── web/             One Next.js 14 app — customer + (hidden) admin
├── ARCHITECTURE_AND_PLAN.md
├── DELIVERY_LOGIC_PRESERVED.md
├── CONTINUATION_PLAN.md
├── Makefile
└── README.md        ← you are here
```

## Quick start

### Prerequisites
- Python 3.11+
- Node 20+
- A **Supabase** project (for Postgres + auth)
- A **Cloudflare R2** bucket + API token

### 1) Set up Supabase
1. Create a project at <https://supabase.com>.
2. Project Settings → API → copy:
   - Project URL → `SUPABASE_URL` (backend) and `NEXT_PUBLIC_SUPABASE_URL` (web)
   - `anon public` key → `SUPABASE_ANON_KEY` + `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (backend only)
   - `JWT Secret` → `SUPABASE_JWT_SECRET` (backend only — this is what
     verifies tokens locally without a network call per request)
3. Project Settings → Database → Connection string → copy the
   *Session* pooler URL → `DATABASE_URL` (prefix it with
   `postgresql+asyncpg://` instead of `postgresql://`)

### 2) Set up Cloudflare R2
1. Create a bucket called `tarel-products`.
2. R2 → API Tokens → create one with **Object Read & Write**.
3. Copy account ID, access key, secret into the backend `.env`.

### 3) Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env       # fill in Supabase + R2 + JWT secret
uvicorn app.main:app --reload --port 8000
```
- Health: <http://localhost:8000/health>
- Docs:   <http://localhost:8000/docs>

### 4) Web (customer + admin in one app)
```bash
cd web
cp .env.local.example .env.local
npm install
npm run dev
```
- **Customer site**: <http://localhost:3000>
- **Admin**: <http://localhost:3000/[NEXT_PUBLIC_ADMIN_PATH]> (e.g. `/tarel-control`)
  - Non-admins (or wrong slugs) get a real 404 — admin URL is invisible
  - Visit `/<admin-slug>/login` to sign in with an admin account

## Brand & design

- Palette preserved exactly: `#2F4135` (brand-dark), `#708E53`
  (brand-olive), `#E9E2D5` (brand-beige)
- Logo: original `public/logo.png` (and `.svg`) copied verbatim
- Type: SF Pro via `-apple-system` stack (native on iOS/macOS,
  Roboto on Android, Segoe on Windows) at Apple HIG sizes
  (caption / footnote / subhead / callout / body / headline /
  title-1 / title-2 / large-title)
- Look: VisionOS-inspired translucent materials, depth via paired
  soft+hard shadows, spring easings, 44pt tap targets, safe-area
  insets, mobile-first throughout, bottom tab bar on mobile

## Conventions (short list)

- **No literal strings/numbers in business code.** Constants live in
  `backend/app/core/constants.py` and `web/lib/constants.ts`.
- **No credentials in code.** Everything secret comes from `.env`.
- **Routers are thin.** They call the service and return; no business
  logic, no SQLAlchemy.
- **Services don't import SQLAlchemy.** They take repositories.
- **One engine, one sessionmaker.** Created at import time in
  `backend/app/db/session.py`.
- **Every table** has `id` (BIGSERIAL PK), `uuid` (exposed to frontend
  as `id`), optional `code` (e.g. `ORD-000123`), `created_at`,
  `updated_at` — via `IdentityMixin`.
- **Every request** gets a UUID written to its own file at
  `logs/requests/<id>.log`. The id is returned to the browser as
  `X-Request-ID` so frontend errors can be cross-referenced.

## What's in this drop

| Layer / feature                                         | ✓ |
|---------------------------------------------------------|---|
| Backend foundation (config, constants, DB, DI, R2)      | ✅ |
| Request-ID middleware + per-file logs                   | ✅ |
| Repository pattern + generic `AsyncRepository`          | ✅ |
| Products module (reference vertical slice)              | ✅ |
| Supabase Auth (drops Google OAuth)                      | ✅ |
| Users module (postcode, address, phone, code)           | ✅ |
| Customer search by email / phone / postcode / code      | ✅ |
| Vendor report (downloadable XLSX)                       | ✅ |
| Delivery utilities preserved verbatim                   | ✅ |
| VisionOS-style design system + glass components         | ✅ |
| Mobile bottom tab bar + iOS safe-area insets            | ✅ |
| Hidden admin route via env slug + middleware            | ✅ |
| Auth-gated Add to Cart                                  | ✅ |
| Product search with live filter                         | ✅ |
| Login + Register + Profile                              | ✅ |
| Admin: dashboard, orders w/ priority, customers, reports | ✅ |
| Toast notifications + login-success feedback            | ✅ |
| Next-delivery card (preserved logic)                    | ✅ |
| PWA manifest + iOS Add-to-Home                          | ✅ |

What's next — see `CONTINUATION_PLAN.md`.
