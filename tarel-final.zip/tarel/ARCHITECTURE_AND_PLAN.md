# Tarel — Production Rebuild Plan

This document is the source of truth for the rebuild. It captures the
target architecture, the decisions behind it, and the phased migration
path so we can pick up exactly where we leave off.

---

## 1. Goals (from your brief)

- Keep fonts, colour palette, logo, and existing business logic untouched.
- One unified frontend serving both customer and admin areas; admin
  reachable only via an obscure URL that ordinary users cannot find.
- Database moved to **Supabase Postgres**.
- Product images served from **Cloudflare R2** (S3-compatible).
- Every HTTP request gets its own UUID; the entire lifecycle is written
  to its own log file (`logs/requests/<request_id>.log`).
- All credentials, URLs, keys live in `.env` — nothing hardcoded in code.
- Every table has both `id` (integer primary key, for joins) and `uuid`
  (exposed to the frontend), with an optional `code` (e.g. ORD-000123).
- No magic numbers/strings in business code; everything sits in a
  central `constants.py`.
- SOLID, async/await, dependency injection, repository pattern, a single
  shared DB engine.

---

## 2. Target backend layout

```
backend/
├── .env.example                 ← documented, no real secrets
├── requirements.txt
├── alembic.ini                  ← migrations (Supabase-friendly)
├── alembic/
│   ├── env.py
│   └── versions/
└── app/
    ├── main.py                  ← FastAPI app factory + router wiring
    ├── core/
    │   ├── config.py            ← Settings (Pydantic BaseSettings)
    │   ├── constants.py         ← every literal value, named
    │   ├── exceptions.py        ← domain-specific HTTP errors
    │   ├── security.py          ← JWT + password hashing
    │   ├── dependencies.py      ← FastAPI Depends() providers (DI)
    │   ├── logging/
    │   │   ├── config.py        ← root logger setup
    │   │   └── request_logger.py← writes per-request file logs
    │   └── middleware/
    │       └── request_id.py    ← attaches UUID, times the request
    ├── db/
    │   ├── session.py           ← single async engine + sessionmaker
    │   ├── base.py              ← Base + IdentityMixin (id+uuid+code)
    │   └── types.py             ← portable GUID column type
    ├── storage/
    │   ├── base.py              ← StorageClient protocol (interface)
    │   └── r2_client.py         ← Cloudflare R2 implementation
    ├── repositories/
    │   └── base.py              ← AsyncRepository[ModelT] generic
    ├── services/
    │   └── base.py              ← BaseService (gets injected repo+deps)
    ├── schemas/
    │   └── common.py            ← MessageResponse, PagedResponse, etc.
    └── modules/                 ← feature modules — each self-contained
        ├── products/            ← ★ REFERENCE IMPLEMENTATION
        │   ├── models.py
        │   ├── schemas.py
        │   ├── repository.py
        │   ├── service.py
        │   ├── router.py
        │   └── dependencies.py
        ├── auth/                ← migrate next
        ├── users/
        ├── categories/
        ├── orders/
        ├── delivery/
        ├── support/
        └── site_settings/
```

### Why this layout

- **`modules/` instead of `routers/` + `models/` + `schemas/` + `services/`**
  scattered. Each feature is a vertical slice: changing "products"
  touches one folder. This is how the codebase scales without becoming
  a swamp.
- **Repository pattern** lives in `repositories/base.py` — a generic
  `AsyncRepository[ModelT]` you parameterise per model. The service
  layer never imports SQLAlchemy directly; it asks the repo. That makes
  the service unit-testable with a fake repo.
- **`core/dependencies.py`** is where every `Depends(...)` provider
  lives. Routers do `db = Depends(get_db)`, `svc = Depends(get_product_service)`.
  Nothing constructs its own dependencies — that's the DI rule.
- **Single engine**, single `async_sessionmaker`, created once at
  import time in `db/session.py`. Every request gets a *session* (not
  a new engine).

### SOLID, applied concretely

- **S** — each module owns one feature; each class one reason to change.
- **O** — repository/service take protocols; swap R2 for S3 without
  touching services.
- **L** — every `AsyncRepository[T]` subclass honours the same contract.
- **I** — `StorageClient` exposes the small surface services need
  (`upload`, `signed_url`, `delete`), not the whole boto3 client.
- **D** — routers depend on `ProductService` (abstraction), not on
  `AsyncSession` directly.

---

## 3. Target frontend layout

One Next.js 14 app, App Router, route groups for separation. Admin
route slug is **read from `NEXT_PUBLIC_ADMIN_PATH`** so it isn't even
present in source as a literal string. Middleware returns a real 404
to non-admins hitting the admin tree, so the path looks non-existent to
the outside world.

```
web/
├── .env.local.example
├── next.config.mjs
├── tailwind.config.ts           ← brand-dark / brand-olive / brand-beige
├── middleware.ts                ← hides admin route from non-admins
├── app/
│   ├── layout.tsx               ← root layout (fonts, providers)
│   ├── globals.css              ← unchanged palette
│   ├── (public)/                ← storefront
│   │   ├── layout.tsx           ← Navbar + Footer
│   │   ├── page.tsx
│   │   ├── products/[slug]/
│   │   ├── categories/
│   │   ├── cart/
│   │   ├── checkout/
│   │   ├── login/
│   │   ├── register/
│   │   └── legal/[slug]/
│   ├── (user)/account/          ← authenticated user
│   │   ├── layout.tsx           ← UserGuard
│   │   ├── orders/              ← 3 cards per row (lg:grid-cols-3)
│   │   ├── profile/
│   │   └── support/
│   └── (admin)/[adminSlug]/     ← dynamic segment from env
│       ├── layout.tsx           ← AdminGuard + AdminShell
│       ├── login/
│       ├── dashboard/
│       ├── products/
│       ├── categories/
│       ├── orders/
│       ├── customers/
│       ├── delivery/
│       └── support/
├── components/
│   ├── ui/                      ← Button, Input, Card, Modal, Table
│   ├── layout/                  ← Navbar, Footer, AdminSidebar
│   ├── product/                 ← ProductCard, ProductGrid
│   ├── order/                   ← OrderCard (used in 3-col grid)
│   └── admin/
├── lib/
│   ├── api/                     ← typed fetcher; sends X-Request-ID
│   ├── constants.ts             ← UI literals; route slugs, page sizes
│   ├── auth.ts
│   └── theme.ts                 ← palette tokens (one place)
├── providers/
└── hooks/
```

### How the admin is hidden

1. `NEXT_PUBLIC_ADMIN_PATH=tarel-control` (or any string) lives in `.env`.
2. The admin route is at `app/(admin)/[adminSlug]/...` — a dynamic
   segment.
3. `middleware.ts` checks the incoming pathname:
   - If it starts with the configured slug **and** the user has a valid
     admin JWT, allow.
   - If it starts with the configured slug but the user is not an
     admin, return a real 404 (`NextResponse.rewrite('/not-found')`).
   - If `[adminSlug]` matches a value other than the configured one
     (someone guessing), return 404 too.
4. Nothing in the visible UI ever links to the admin path.

This isn't "security through obscurity as a substitute for auth" — the
JWT check is the real gate. The slug just keeps it out of search
engines and casual probing.

---

## 4. Database changes

### Identity model on every table

Each table gets:

| Column        | Type                | Purpose                                     |
|---------------|---------------------|---------------------------------------------|
| `id`          | `BIGSERIAL` PK      | internal joins, fast indexes                |
| `uuid`        | `UUID`, unique      | exposed to frontend; URLs use this          |
| `code`        | `VARCHAR`, nullable | human-readable (e.g. `ORD-000123`, `USR-…`) |
| `created_at`  | `TIMESTAMPTZ`       | audit                                       |
| `updated_at`  | `TIMESTAMPTZ`       | audit                                       |

A SQLAlchemy mixin (`IdentityMixin` in `db/base.py`) adds all of these
so every model is consistent.

The Pydantic `*Out` schemas only ever expose `uuid` (renamed to `id`
in the JSON response), not the internal integer `id`. Frontend never
sees the integer.

### Supabase

Supabase is just managed Postgres + Auth + Storage. We're using **only
its Postgres**. The connection string goes in `DATABASE_URL`. Nothing
in the code knows or cares that it's Supabase.

> Use the *transaction pooler* connection string from Supabase
> (port 6543) for serverless-style workloads, or the *session pooler*
> (5432) for long-running connections. We use `asyncpg` directly so
> the URL prefix is `postgresql+asyncpg://...`.

### Cloudflare R2

R2 is S3-compatible. We use `aioboto3` against the R2 endpoint URL.
The `StorageClient` interface in `storage/base.py` keeps R2 a swappable
detail — services depend on the interface, not boto3.

---

## 5. Request lifecycle & logging

```
client request
   │
   ▼
RequestIdMiddleware:
   - reads X-Request-ID header, or generates uuid4
   - sets contextvar so every log line in this request carries it
   - opens logs/requests/<rid>.log
   - records: method, path, query, client IP, user agent
   │
   ▼
route handler (uses contextvar-aware logger)
   - logs every meaningful step (auth check, repo call, response)
   │
   ▼
middleware finally block:
   - records status code, duration_ms, error (if any)
   - closes the per-request log
```

Every log line in `logs/requests/<rid>.log` is one JSON object — easy
to parse, grep, ship to a log aggregator later.

Code that wants to log just uses standard Python `logging`; the
formatter pulls the request id from the contextvar automatically.

---

## 6. Configuration & constants — the rules

1. **No literal strings or numbers in business code.** If you find
   yourself typing `"pending"` or `5` in a service or router, it goes
   in `core/constants.py` first.
2. **All credentials, URLs, third-party keys** are loaded by
   `core/config.py` from `.env`. The `Settings` class is the single
   source of truth at runtime.
3. **`Settings` is constructed once** (module-level) and injected via
   `Depends(get_settings)` where modules need it. Never re-instantiate.
4. `.env.example` documents every variable with a comment explaining
   what it's for. Real `.env` is gitignored.

---

## 7. Phased migration

| Phase | Scope                                                           | Status              |
|-------|-----------------------------------------------------------------|---------------------|
| **0** | Plan, conventions, target structure (this document)             | ✅ done             |
| **1** | Foundation: config, constants, db, logging, DI, base classes    | ✅ done             |
| **2** | Reference module: **Products** (model→repo→service→router)      | ✅ done             |
| **3** | Frontend skeleton: unified Next.js app, hidden admin, palette   | ✅ scaffold done    |
| **4** | Migrate auth + users (depends on identity model + JWT helpers)  | ⏭ next              |
| **5** | Migrate categories (small, useful warm-up)                      | ⏭ next              |
| **6** | Migrate orders + order items (3-per-row admin grid)             | ⏭ next              |
| **7** | Migrate delivery, support, site_settings                        | ⏭ next              |
| **8** | Frontend pages: storefront (home, product, cart, checkout)      | ⏭ next              |
| **9** | Frontend pages: user account, admin pages                       | ⏭ next              |
| **10**| Alembic migration matching new schema                           | ⏭ next              |
| **11**| Tests: per-module unit tests against fake repos                 | ⏭ next              |
| **12**| Production: Dockerfile, docker-compose, CI, healthchecks        | ⏭ next              |

Each follow-up phase is small and predictable because the foundation
is already laid. We literally copy the Products module's structure for
every other feature, adjusting only the fields and the business rules
(which are not being changed, per your instructions).

---

## 8. What's intentionally *not* changing

- **Business logic** — pricing, delivery date calculation, order
  validation, cancellation rules: all preserved verbatim. The functions
  in `delivery_utils.py` and `pricing.py` move into
  `modules/delivery/utils.py` and `modules/orders/utils.py` unchanged.
- **Brand**: colours `#2F4135`, `#708E53`, `#E9E2D5`; the existing
  logo in `public/`; existing font stack. The Tailwind config in the
  new `web/` keeps the same `brand-dark`, `brand-olive`, `brand-beige`
  tokens so existing class names continue working.
- **Public API shape**: response shapes are preserved (the frontend
  doesn't need to change its parsing). Internal table primary keys
  changing from UUID to integer is invisible to the frontend because
  responses expose `uuid` as `id`.
