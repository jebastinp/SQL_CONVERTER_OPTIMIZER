"""FastAPI dependency providers (the DI seams).

Routers and services receive their dependencies from here via
``Depends(...)``. This is the *only* place that constructs concrete
implementations — everywhere else takes interfaces / protocols.
"""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings, get_settings
from app.core.exceptions import ServiceUnavailableError
from app.db.session import get_async_session
from app.storage.base import StorageClient
from app.storage.r2_client import R2StorageClient
from app.storage.supabase_client import SupabaseStorageClient

# ── Reusable annotated types so handlers stay short ───────────────────────────
SettingsDep = Annotated[Settings, Depends(get_settings)]
SessionDep = Annotated[AsyncSession, Depends(get_async_session)]


# ── Storage backend selection ────────────────────────────────────────────────
# Selected by Settings.STORAGE_BACKEND ("supabase" or "r2"). Adding a
# new backend means: implement the StorageClient protocol and add a
# branch here. Nothing else in the codebase changes.
_STORAGE_FACTORIES: dict[str, type[StorageClient]] = {
    "supabase": SupabaseStorageClient,
    "r2": R2StorageClient,
}


def get_storage_client(settings: SettingsDep) -> StorageClient:
    """Return the configured storage client."""
    backend = (settings.STORAGE_BACKEND or "").lower()
    factory = _STORAGE_FACTORIES.get(backend)
    if factory is None:
        raise ServiceUnavailableError(
            f"Unknown STORAGE_BACKEND '{settings.STORAGE_BACKEND}'. "
            f"Expected one of: {', '.join(_STORAGE_FACTORIES.keys())}"
        )
    return factory(settings=settings)


StorageDep = Annotated[StorageClient, Depends(get_storage_client)]
