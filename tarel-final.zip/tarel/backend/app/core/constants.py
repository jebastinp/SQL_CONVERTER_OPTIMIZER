"""Central constants for the Tarel backend.

Rule: if you find yourself typing a literal string or number in business
code (services, routers, repositories), add it here first and import it.
This is the single source of truth for non-secret values that need a
name. Secrets and environment-dependent values live in
``app/core/config.py`` and are sourced from ``.env``.
"""

from __future__ import annotations

from typing import Final

# ── Project / API ─────────────────────────────────────────────────────────────
PROJECT_NAME_DEFAULT: Final[str] = "Tarel API"
API_PREFIX_DEFAULT: Final[str] = "/api"
API_V1_PREFIX_DEFAULT: Final[str] = "/api/v1"

# ── Environment values ────────────────────────────────────────────────────────
ENV_DEVELOPMENT: Final[str] = "development"
ENV_STAGING: Final[str] = "staging"
ENV_PRODUCTION: Final[str] = "production"

# ── HTTP headers ──────────────────────────────────────────────────────────────
HEADER_REQUEST_ID: Final[str] = "X-Request-ID"
HEADER_AUTHORIZATION: Final[str] = "Authorization"
HEADER_AUTH_SCHEME_BEARER: Final[str] = "Bearer"

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_REQUEST_DIRECTORY_DEFAULT: Final[str] = "logs/requests"
LOG_FILE_ENCODING: Final[str] = "utf-8"
LOG_LEVEL_DEFAULT: Final[str] = "INFO"
LOG_FORMAT: Final[str] = "%(asctime)s %(levelname)s %(name)s [%(request_id)s] %(message)s"
LOG_CONTEXTVAR_NAME: Final[str] = "request_id"
LOG_DEFAULT_REQUEST_ID: Final[str] = "-"

# ── Security ──────────────────────────────────────────────────────────────────
JWT_ALGORITHM_DEFAULT: Final[str] = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES_DEFAULT: Final[int] = 60 * 24 * 7  # 7 days
PASSWORD_HASH_SCHEMES: Final[tuple[str, ...]] = ("pbkdf2_sha256",)
JWT_CLAIM_SUBJECT: Final[str] = "sub"
JWT_CLAIM_ROLE: Final[str] = "role"
JWT_CLAIM_EXPIRES_AT: Final[str] = "exp"

# ── Identity / codes ──────────────────────────────────────────────────────────
USER_CODE_PREFIX: Final[str] = "USR"
ORDER_CODE_PREFIX: Final[str] = "ORD"
PRODUCT_CODE_PREFIX: Final[str] = "PRD"
CATEGORY_CODE_PREFIX: Final[str] = "CAT"
SUPPORT_CODE_PREFIX: Final[str] = "SUP"
DELIVERY_CODE_PREFIX: Final[str] = "DLV"
CODE_PAD_WIDTH: Final[int] = 6  # ORD-000123

# ── Pagination ────────────────────────────────────────────────────────────────
PAGE_NUMBER_DEFAULT: Final[int] = 1
PAGE_SIZE_DEFAULT: Final[int] = 20
PAGE_SIZE_MAX: Final[int] = 100

# ── Storage (R2 + Supabase, S3-compatible & REST) ────────────────────────────
R2_REGION: Final[str] = "auto"
R2_ENDPOINT_TEMPLATE: Final[str] = "https://{account_id}.r2.cloudflarestorage.com"
STORAGE_KEY_PREFIX_PRODUCT: Final[str] = "products/"
STORAGE_KEY_PREFIX_USER: Final[str] = "users/"
STORAGE_CONTENT_TYPE_DEFAULT: Final[str] = "application/octet-stream"
STORAGE_ALLOWED_IMAGE_MIME: Final[tuple[str, ...]] = (
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
)
STORAGE_MAX_UPLOAD_BYTES: Final[int] = 8 * 1024 * 1024  # 8 MiB

# Legacy aliases (kept so existing imports don't break).
R2_KEY_PREFIX_PRODUCT: Final[str] = STORAGE_KEY_PREFIX_PRODUCT
R2_KEY_PREFIX_USER: Final[str] = STORAGE_KEY_PREFIX_USER
R2_CONTENT_TYPE_DEFAULT: Final[str] = STORAGE_CONTENT_TYPE_DEFAULT
R2_ALLOWED_IMAGE_MIME: Final[tuple[str, ...]] = STORAGE_ALLOWED_IMAGE_MIME
R2_MAX_UPLOAD_BYTES: Final[int] = STORAGE_MAX_UPLOAD_BYTES

# ── CORS ──────────────────────────────────────────────────────────────────────
CORS_ALLOW_METHODS: Final[tuple[str, ...]] = ("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
CORS_ALLOW_HEADERS: Final[tuple[str, ...]] = ("*",)
CORS_EXPOSE_HEADERS: Final[tuple[str, ...]] = (HEADER_REQUEST_ID,)

# ── Database ──────────────────────────────────────────────────────────────────
DB_POOL_SIZE_DEFAULT: Final[int] = 10
DB_MAX_OVERFLOW_DEFAULT: Final[int] = 20
DB_POOL_RECYCLE_SECONDS: Final[int] = 1800  # half hour

# ── Health endpoint ───────────────────────────────────────────────────────────
HEALTH_STATUS_OK: Final[str] = "ok"
HEALTH_STATUS_DEGRADED: Final[str] = "degraded"

# ── Order statuses (mirror of the Enum, but as literals usable in queries) ────
ORDER_STATUS_PENDING: Final[str] = "pending"
ORDER_STATUS_PAID: Final[str] = "paid"
ORDER_STATUS_PROCESSING: Final[str] = "processing"
ORDER_STATUS_OUT_FOR_DELIVERY: Final[str] = "out_for_delivery"
ORDER_STATUS_DELIVERED: Final[str] = "delivered"
ORDER_STATUS_CANCELLED: Final[str] = "cancelled"
