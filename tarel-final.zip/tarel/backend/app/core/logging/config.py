"""Root logger configuration.

Every log line carries the current request ID via a contextvar. Modules
just call ``get_logger(__name__)`` and log as usual — the request_id
is filled in by a logging filter.
"""

from __future__ import annotations

import logging
from pathlib import Path

from app.core import constants as C
from app.core.logging.request_logger import get_current_request_id


class _RequestIdFilter(logging.Filter):
    """Inject the current request id into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:  # noqa: D401
        record.request_id = get_current_request_id() or C.LOG_DEFAULT_REQUEST_ID
        return True


def configure_logging(
    *,
    level: str = C.LOG_LEVEL_DEFAULT,
    request_log_directory: str = C.LOG_REQUEST_DIRECTORY_DEFAULT,
) -> None:
    """Configure the root logger.

    Idempotent: safe to call multiple times (e.g. tests).
    """
    Path(request_log_directory).mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(level.upper())

    # Replace any prior handlers (uvicorn adds its own; we want our format)
    for handler in list(root_logger.handlers):
        root_logger.removeHandler(handler)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter(C.LOG_FORMAT))
    stream_handler.addFilter(_RequestIdFilter())
    root_logger.addHandler(stream_handler)


def get_logger(name: str) -> logging.Logger:
    """Convenience: returns a named logger. Use this everywhere."""
    return logging.getLogger(name)
