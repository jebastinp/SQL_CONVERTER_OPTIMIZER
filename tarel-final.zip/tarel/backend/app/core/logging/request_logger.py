"""Per-request file logger.

Each HTTP request gets a UUID. Every event in that request's lifecycle
is appended as a JSON line to ``logs/requests/<request_id>.log``. The
current request id is also exposed via a contextvar so any logger in
the codebase can include it automatically (see ``logging/config.py``).
"""

from __future__ import annotations

import json
from contextvars import ContextVar, Token
from pathlib import Path
from typing import Any, Optional

from app.core import constants as C

_request_id_var: ContextVar[Optional[str]] = ContextVar(C.LOG_CONTEXTVAR_NAME, default=None)


def get_current_request_id() -> Optional[str]:
    return _request_id_var.get()


def bind_request_id(request_id: str) -> Token:
    """Bind ``request_id`` for the duration of the current async task.

    Returns the contextvar token; the caller must reset it in a
    ``finally`` block.
    """
    return _request_id_var.set(request_id)


def unbind_request_id(token: Token) -> None:
    _request_id_var.reset(token)


class RequestLogger:
    """Writes per-request log lines as JSON to a dedicated file.

    Thin wrapper, intentionally minimal. The middleware constructs one
    per request and calls ``event(...)`` for each notable step.
    """

    def __init__(self, request_id: str, directory: str) -> None:
        self._request_id = request_id
        self._directory = Path(directory)
        self._directory.mkdir(parents=True, exist_ok=True)
        self._path = self._directory / f"{request_id}.log"

    @property
    def request_id(self) -> str:
        return self._request_id

    @property
    def path(self) -> Path:
        return self._path

    def event(self, **payload: Any) -> None:
        """Append a JSON event line to this request's log file."""
        payload.setdefault("request_id", self._request_id)
        line = json.dumps(payload, ensure_ascii=False, default=str)
        with self._path.open("a", encoding=C.LOG_FILE_ENCODING) as handle:
            handle.write(line + "\n")
