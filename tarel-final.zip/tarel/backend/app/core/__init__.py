"""Cross-cutting infrastructure: config, constants, security, logging, DI."""
