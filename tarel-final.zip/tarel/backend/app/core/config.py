"""Runtime configuration loaded from environment variables / .env.

`Settings` is constructed once at import time. Anything that wants a
config value gets it injected via `Depends(get_settings)` — never
re-instantiate.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core import constants as C


class Settings(BaseSettings):
    """All configuration sourced from environment variables.

    Field names mirror the keys in .env exactly (case-sensitive).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding=C.LOG_FILE_ENCODING,
        case_sensitive=True,
        extra="ignore",
    )

    # ── Project / API ─────────────────────────────────────────────────────────
    PROJECT_NAME: str = C.PROJECT_NAME_DEFAULT
    ENVIRONMENT: str = C.ENV_DEVELOPMENT
    DEBUG: bool = False
    API_PREFIX: str = C.API_PREFIX_DEFAULT
    API_V1_PREFIX: str = C.API_V1_PREFIX_DEFAULT

    # ── Database ──────────────────────────────────────────────────────────────
    DATABASE_URL: str
    DATABASE_ECHO: bool = False
    DB_POOL_SIZE: int = C.DB_POOL_SIZE_DEFAULT
    DB_MAX_OVERFLOW: int = C.DB_MAX_OVERFLOW_DEFAULT

    # ── Security ──────────────────────────────────────────────────────────────
    JWT_SECRET: str
    JWT_ALGORITHM: str = C.JWT_ALGORITHM_DEFAULT
    ACCESS_TOKEN_EXPIRE_MINUTES: int = C.ACCESS_TOKEN_EXPIRE_MINUTES_DEFAULT

    # ── CORS ──────────────────────────────────────────────────────────────────
    FRONTEND_ORIGINS: str = "http://localhost:3000"
    FRONTEND_APP_URL: str = "http://localhost:3000"

    @field_validator("FRONTEND_ORIGINS", mode="before")
    @classmethod
    def _coerce_origins(cls, value):
        if isinstance(value, list):
            return ",".join(value)
        return value

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.FRONTEND_ORIGINS.split(",") if origin.strip()]

    # ── Logging ───────────────────────────────────────────────────────────────
    LOG_LEVEL: str = C.LOG_LEVEL_DEFAULT
    LOG_REQUEST_DIRECTORY: str = C.LOG_REQUEST_DIRECTORY_DEFAULT
    LOG_REQUEST_RETENTION_DAYS: int = 30

    # ── Cloudflare R2 ─────────────────────────────────────────────────────────
    R2_ACCOUNT_ID: Optional[str] = None
    R2_ACCESS_KEY_ID: Optional[str] = None
    R2_SECRET_ACCESS_KEY: Optional[str] = None
    R2_BUCKET: Optional[str] = None
    R2_PUBLIC_BASE_URL: Optional[str] = None
    R2_SIGNED_URL_TTL_SECONDS: int = 3600

    @property
    def r2_endpoint_url(self) -> Optional[str]:
        if not self.R2_ACCOUNT_ID:
            return None
        return C.R2_ENDPOINT_TEMPLATE.format(account_id=self.R2_ACCOUNT_ID)

    @property
    def r2_configured(self) -> bool:
        return all([
            self.R2_ACCOUNT_ID,
            self.R2_ACCESS_KEY_ID,
            self.R2_SECRET_ACCESS_KEY,
            self.R2_BUCKET,
        ])

    # ── Storage backend selection ─────────────────────────────────────────────
    # Which object-storage backend to use: "supabase" or "r2".
    # Default is supabase (no card required, uses your existing Supabase
    # project). Swap to "r2" later by changing this single value.
    STORAGE_BACKEND: str = "supabase"
    # Bucket name shared by both backends.
    STORAGE_BUCKET: str = "tarel-products"

    # ── Supabase (auth + database) ────────────────────────────────────────────
    # The project's URL (https://<ref>.supabase.co) and anon/service keys.
    # JWT secret is the HMAC key Supabase signs access tokens with —
    # we use it to verify tokens locally without network round-trips.
    SUPABASE_URL: Optional[str] = None
    SUPABASE_ANON_KEY: Optional[str] = None
    SUPABASE_SERVICE_ROLE_KEY: Optional[str] = None
    SUPABASE_JWT_SECRET: Optional[str] = None

    # ── Stripe (deprecated — using HandyPay) ──────────────────────────────────
    STRIPE_SECRET_KEY: Optional[str] = None
    STRIPE_WEBHOOK_SECRET: Optional[str] = None

    # ── HandyPay payment gateway ──────────────────────────────────────────────
    # Which gateway to use: "mock" or "handypay".
    # Default is "mock" so the entire checkout flow works end-to-end
    # before you have real HandyPay credentials. Switch to "handypay"
    # once you've filled in the four keys below.
    PAYMENT_GATEWAY: str = "mock"

    # The 4 keys the user obtains from HandyPay's merchant dashboard.
    HANDYPAY_API_KEY: Optional[str] = None
    HANDYPAY_SECRET: Optional[str] = None
    HANDYPAY_MERCHANT_ID: Optional[str] = None
    HANDYPAY_WEBHOOK_SECRET: Optional[str] = None
    # Optional override (e.g. for HandyPay's sandbox env).
    HANDYPAY_BASE_URL: Optional[str] = None

    # ── Payment defaults ──────────────────────────────────────────────────────
    PAYMENT_CURRENCY: str = "USD"
    # Override the auto-built webhook URL (useful when behind ngrok in dev).
    PAYMENT_WEBHOOK_URL: Optional[str] = None

    # ── Mail ──────────────────────────────────────────────────────────────────
    MAIL_SERVER: Optional[str] = None
    MAIL_PORT: int = 587
    MAIL_USE_TLS: bool = True
    MAIL_USERNAME: Optional[str] = None
    MAIL_PASSWORD: Optional[str] = None
    MAIL_DEFAULT_SENDER: Optional[str] = None

    # ── Address lookup ────────────────────────────────────────────────────────
    GETADDRESS_API_KEY: Optional[str] = None
    GETADDRESS_BASE_URL: str = "https://api.getAddress.io"

    # ── Reporting ─────────────────────────────────────────────────────────────
    REPORT_EMAIL: str = "admin@tarel.local"

    # ── Helpers ───────────────────────────────────────────────────────────────
    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == C.ENV_PRODUCTION


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings instance — safe to call as a FastAPI dependency."""
    return Settings()  # type: ignore[call-arg]


# Module-level convenience reference for non-DI code paths (e.g. main.py
# wiring). Prefer `Depends(get_settings)` inside business code.
settings = get_settings()
