"""RequestIdMiddleware.

For every incoming HTTP request:
  1. Reads ``X-Request-ID`` from the headers, or generates a uuid4.
  2. Binds it to a contextvar so every log line in this request carries it.
  3. Opens a per-request file logger ``logs/requests/<id>.log``.
  4. Echoes the id back to the client in the response headers.
  5. On exit, writes a summary line (method, path, status, duration).
"""

from __future__ import annotations

import logging
from time import perf_counter
from uuid import uuid4

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core import constants as C
from app.core.logging.request_logger import (
    RequestLogger,
    bind_request_id,
    unbind_request_id,
)

_logger = logging.getLogger("tarel.request")


class RequestIdMiddleware(BaseHTTPMiddleware):
    """ASGI middleware that wires a per-request id and log file."""

    def __init__(self, app, *, log_directory: str) -> None:
        super().__init__(app)
        self._log_directory = log_directory

    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = request.headers.get(C.HEADER_REQUEST_ID) or str(uuid4())
        token = bind_request_id(request_id)
        req_log = RequestLogger(request_id=request_id, directory=self._log_directory)

        started_at = perf_counter()
        status_code = 500
        error_message: str | None = None
        response: Response | None = None

        # ── inbound ───────────────────────────────────────────────────────────
        req_log.event(
            phase="request_received",
            method=request.method,
            path=str(request.url.path),
            query=str(request.url.query),
            client=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )

        try:
            response = await call_next(request)
            status_code = response.status_code
            response.headers[C.HEADER_REQUEST_ID] = request_id
            return response
        except Exception as exc:
            error_message = str(exc)
            _logger.exception("Unhandled error in request %s", request_id)
            raise
        finally:
            duration_ms = round((perf_counter() - started_at) * 1000, 2)
            req_log.event(
                phase="request_completed",
                status_code=status_code,
                duration_ms=duration_ms,
                error=error_message,
            )
            unbind_request_id(token)
