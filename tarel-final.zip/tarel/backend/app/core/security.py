"""Security primitives: password hashing and JWT issuance/verification.

Pure functions; takes Settings as an argument so it's testable and
doesn't reach into globals.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core import constants as C
from app.core.config import Settings
from app.core.exceptions import UnauthorizedError

_pwd_context = CryptContext(schemes=list(C.PASSWORD_HASH_SCHEMES), deprecated="auto")


def hash_password(plain_password: str) -> str:
    return _pwd_context.hash(plain_password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    return _pwd_context.verify(plain_password, password_hash)


def create_access_token(
    *,
    subject: str,
    role: str,
    settings: Settings,
    extra_claims: dict[str, Any] | None = None,
    expires_minutes: int | None = None,
) -> str:
    """Encode a JWT for the given subject (typically user uuid)."""
    expires_at = datetime.now(tz=timezone.utc) + timedelta(
        minutes=expires_minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    claims: dict[str, Any] = {
        C.JWT_CLAIM_SUBJECT: subject,
        C.JWT_CLAIM_ROLE: role,
        C.JWT_CLAIM_EXPIRES_AT: expires_at,
    }
    if extra_claims:
        claims.update(extra_claims)

    return jwt.encode(claims, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def decode_access_token(token: str, settings: Settings) -> dict[str, Any]:
    """Decode and validate a JWT. Raises UnauthorizedError on failure."""
    try:
        return jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
    except JWTError as exc:
        raise UnauthorizedError("Invalid or expired token") from exc
