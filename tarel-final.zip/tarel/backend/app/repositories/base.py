"""Generic async repository.

Subclass per model to add domain-specific queries; the common CRUD
operations are inherited. Services depend on repositories, never on
``AsyncSession`` directly — that's how unit tests substitute a fake
repo without touching SQLAlchemy.
"""

from __future__ import annotations

from typing import Any, Generic, Iterable, Sequence, Type, TypeVar
from uuid import UUID

from sqlalchemy import delete as sa_delete
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import Base

ModelT = TypeVar("ModelT", bound=Base)


class AsyncRepository(Generic[ModelT]):
    """Common async CRUD on a single model."""

    model: Type[ModelT]  # subclasses must set this

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    # ── Read ──────────────────────────────────────────────────────────────────
    async def get_by_id(self, pk: int) -> ModelT | None:
        return await self._session.get(self.model, pk)

    async def get_by_uuid(self, uuid_value: UUID) -> ModelT | None:
        stmt = select(self.model).where(self.model.uuid == uuid_value)  # type: ignore[attr-defined]
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_field(self, field_name: str, value: Any) -> ModelT | None:
        column = getattr(self.model, field_name)
        stmt = select(self.model).where(column == value)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list(
        self,
        *,
        filters: dict[str, Any] | None = None,
        limit: int | None = None,
        offset: int | None = None,
        order_by: Iterable[Any] | None = None,
    ) -> Sequence[ModelT]:
        stmt = select(self.model)
        if filters:
            for field_name, value in filters.items():
                column = getattr(self.model, field_name)
                stmt = stmt.where(column == value)
        if order_by:
            stmt = stmt.order_by(*order_by)
        if offset is not None:
            stmt = stmt.offset(offset)
        if limit is not None:
            stmt = stmt.limit(limit)
        result = await self._session.execute(stmt)
        return result.scalars().all()

    async def count(self, *, filters: dict[str, Any] | None = None) -> int:
        stmt = select(func.count()).select_from(self.model)
        if filters:
            for field_name, value in filters.items():
                column = getattr(self.model, field_name)
                stmt = stmt.where(column == value)
        result = await self._session.execute(stmt)
        return int(result.scalar_one())

    # ── Write ─────────────────────────────────────────────────────────────────
    async def add(self, instance: ModelT) -> ModelT:
        self._session.add(instance)
        await self._session.flush()
        await self._session.refresh(instance)
        return instance

    async def update(self, instance: ModelT, fields: dict[str, Any]) -> ModelT:
        for key, value in fields.items():
            setattr(instance, key, value)
        await self._session.flush()
        await self._session.refresh(instance)
        return instance

    async def delete(self, instance: ModelT) -> None:
        await self._session.delete(instance)
        await self._session.flush()

    async def delete_by_uuid(self, uuid_value: UUID) -> int:
        stmt = sa_delete(self.model).where(self.model.uuid == uuid_value)  # type: ignore[attr-defined]
        result = await self._session.execute(stmt)
        await self._session.flush()
        return int(result.rowcount or 0)
