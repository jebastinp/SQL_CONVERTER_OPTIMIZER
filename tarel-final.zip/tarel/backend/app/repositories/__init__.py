"""Repository layer."""

from app.repositories.base import AsyncRepository

__all__ = ["AsyncRepository"]
