"""FastAPI application factory."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core import constants as C
from app.core.config import settings
from app.core.logging import configure_logging
from app.core.middleware.request_id import RequestIdMiddleware
from app.db.session import async_engine
from app.modules.auth import auth_router
from app.modules.categories import categories_router
from app.modules.categories.router import admin_router as categories_admin_router
from app.modules.orders import orders_router, orders_admin_router
from app.modules.payments import payments_admin_router, payments_router
from app.modules.payments.router import webhook_router as payments_webhook_router
from app.modules.products import products_router
from app.modules.reports import reports_router
from app.modules.users.router import admin_router as customers_admin_router
from app.modules.users.router import router as users_router

_logger = logging.getLogger("tarel.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup / shutdown hooks."""
    _logger.info("Starting %s in %s mode", settings.PROJECT_NAME, settings.ENVIRONMENT)
    yield
    _logger.info("Shutting down — disposing DB engine")
    await async_engine.dispose()


def create_app() -> FastAPI:
    configure_logging(
        level=settings.LOG_LEVEL,
        request_log_directory=settings.LOG_REQUEST_DIRECTORY,
    )

    app = FastAPI(
        title=settings.PROJECT_NAME,
        debug=settings.DEBUG,
        lifespan=lifespan,
    )

    # ── Middleware (order matters) ────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=list(C.CORS_ALLOW_METHODS),
        allow_headers=list(C.CORS_ALLOW_HEADERS),
        expose_headers=list(C.CORS_EXPOSE_HEADERS),
    )
    app.add_middleware(
        RequestIdMiddleware,
        log_directory=settings.LOG_REQUEST_DIRECTORY,
    )

    # ── Routers ───────────────────────────────────────────────────────────────
    # Customer-facing
    app.include_router(auth_router,            prefix=settings.API_V1_PREFIX)
    app.include_router(users_router,           prefix=settings.API_V1_PREFIX)
    app.include_router(categories_router,      prefix=settings.API_V1_PREFIX)
    app.include_router(products_router,        prefix=settings.API_V1_PREFIX)
    app.include_router(orders_router,          prefix=settings.API_V1_PREFIX)
    app.include_router(payments_router,        prefix=settings.API_V1_PREFIX)
    # Webhooks (no auth, signature-verified inside)
    app.include_router(payments_webhook_router, prefix=settings.API_V1_PREFIX)
    # Admin
    app.include_router(customers_admin_router, prefix=settings.API_V1_PREFIX)
    app.include_router(categories_admin_router, prefix=settings.API_V1_PREFIX)
    app.include_router(orders_admin_router,    prefix=settings.API_V1_PREFIX)
    app.include_router(payments_admin_router,  prefix=settings.API_V1_PREFIX)
    app.include_router(reports_router,         prefix=settings.API_V1_PREFIX)

    # ── Health ────────────────────────────────────────────────────────────────
    @app.get("/health", tags=["ops"])
    async def health_check() -> dict:
        return {"status": C.HEALTH_STATUS_OK, "name": settings.PROJECT_NAME}

    @app.get("/")
    async def root() -> dict:
        return {"status": C.HEALTH_STATUS_OK, "name": settings.PROJECT_NAME}

    return app


app = create_app()
