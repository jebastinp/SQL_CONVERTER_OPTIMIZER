"""Tarel backend application package."""

__version__ = "2.0.0"
