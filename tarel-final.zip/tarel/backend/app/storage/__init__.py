"""Object storage abstractions and adapters."""

from app.storage.base import StorageClient, UploadResult
from app.storage.r2_client import R2StorageClient
from app.storage.supabase_client import SupabaseStorageClient

__all__ = [
    "StorageClient",
    "UploadResult",
    "R2StorageClient",
    "SupabaseStorageClient",
]
