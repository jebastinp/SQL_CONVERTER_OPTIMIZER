"""Cloudflare R2 implementation of :class:`StorageClient`.

R2 is S3-compatible; we point ``aioboto3`` at the R2 endpoint URL.
"""

from __future__ import annotations

import logging

import aioboto3
from botocore.config import Config as BotoConfig

from app.core import constants as C
from app.core.config import Settings
from app.core.exceptions import ServiceUnavailableError
from app.storage.base import StorageClient, UploadResult

_logger = logging.getLogger("tarel.storage.r2")


class R2StorageClient(StorageClient):
    """Async client for Cloudflare R2 (S3-compatible)."""

    def __init__(self, settings: Settings) -> None:
        if not settings.r2_configured:
            raise ServiceUnavailableError("R2 storage is not configured")

        self._settings = settings
        self._bucket = settings.R2_BUCKET
        self._endpoint = settings.r2_endpoint_url
        self._public_base = settings.R2_PUBLIC_BASE_URL
        self._session = aioboto3.Session(
            aws_access_key_id=settings.R2_ACCESS_KEY_ID,
            aws_secret_access_key=settings.R2_SECRET_ACCESS_KEY,
            region_name=C.R2_REGION,
        )
        self._boto_config = BotoConfig(
            signature_version="s3v4",
            s3={"addressing_style": "path"},
        )

    def _public_url(self, key: str) -> str:
        if not self._public_base:
            # Fall back to the R2 dev URL; callers can override later.
            return f"{self._endpoint}/{self._bucket}/{key}"
        return f"{self._public_base.rstrip('/')}/{key}"

    async def upload(
        self,
        *,
        key: str,
        data: bytes,
        content_type: str,
    ) -> UploadResult:
        _logger.info("Uploading to R2: bucket=%s key=%s size=%d", self._bucket, key, len(data))
        async with self._session.client(
            "s3",
            endpoint_url=self._endpoint,
            config=self._boto_config,
        ) as s3:
            await s3.put_object(
                Bucket=self._bucket,
                Key=key,
                Body=data,
                ContentType=content_type,
            )
        return UploadResult(
            key=key,
            public_url=self._public_url(key),
            content_type=content_type,
            size_bytes=len(data),
        )

    async def signed_url(self, *, key: str, expires_in_seconds: int) -> str:
        async with self._session.client(
            "s3",
            endpoint_url=self._endpoint,
            config=self._boto_config,
        ) as s3:
            return await s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": self._bucket, "Key": key},
                ExpiresIn=expires_in_seconds,
            )

    async def delete(self, *, key: str) -> None:
        _logger.info("Deleting from R2: bucket=%s key=%s", self._bucket, key)
        async with self._session.client(
            "s3",
            endpoint_url=self._endpoint,
            config=self._boto_config,
        ) as s3:
            await s3.delete_object(Bucket=self._bucket, Key=key)
