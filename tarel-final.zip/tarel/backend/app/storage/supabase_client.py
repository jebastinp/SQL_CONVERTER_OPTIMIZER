"""Supabase Storage implementation of :class:`StorageClient`.

Supabase Storage exposes a simple REST API on top of object storage.
We talk to it directly with ``httpx`` (no extra SDK needed). The
``SUPABASE_SERVICE_ROLE_KEY`` authenticates writes; public buckets
serve reads without auth.

Endpoint shapes:
  - Upload: POST   {url}/storage/v1/object/{bucket}/{key}
  - Delete: DELETE {url}/storage/v1/object/{bucket}/{key}
  - Sign:   POST   {url}/storage/v1/object/sign/{bucket}/{key}
  - Public: GET    {url}/storage/v1/object/public/{bucket}/{key}
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from app.core.config import Settings
from app.core.exceptions import ServiceUnavailableError
from app.storage.base import StorageClient, UploadResult

_logger = logging.getLogger("tarel.storage.supabase")


class SupabaseStorageClient(StorageClient):
    """Async client for Supabase Storage."""

    def __init__(self, settings: Settings) -> None:
        if not (settings.SUPABASE_URL and settings.SUPABASE_SERVICE_ROLE_KEY):
            raise ServiceUnavailableError("Supabase storage is not configured")
        if not settings.STORAGE_BUCKET:
            raise ServiceUnavailableError("STORAGE_BUCKET is not configured")

        self._base = settings.SUPABASE_URL.rstrip("/")
        self._bucket = settings.STORAGE_BUCKET
        self._service_key = settings.SUPABASE_SERVICE_ROLE_KEY

    # ── URL helpers ───────────────────────────────────────────────────────────
    def _public_url(self, key: str) -> str:
        return f"{self._base}/storage/v1/object/public/{self._bucket}/{key.lstrip('/')}"

    def _api_url(self, key: str) -> str:
        return f"{self._base}/storage/v1/object/{self._bucket}/{key.lstrip('/')}"

    def _sign_url(self, key: str) -> str:
        return f"{self._base}/storage/v1/object/sign/{self._bucket}/{key.lstrip('/')}"

    def _auth_headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers = {
            "Authorization": f"Bearer {self._service_key}",
            # Supabase requires apikey too for storage operations.
            "apikey": self._service_key,
        }
        if extra:
            headers.update(extra)
        return headers

    # ── StorageClient implementation ──────────────────────────────────────────
    async def upload(
        self,
        *,
        key: str,
        data: bytes,
        content_type: str,
    ) -> UploadResult:
        url = self._api_url(key)
        _logger.info(
            "Uploading to Supabase Storage: bucket=%s key=%s size=%d",
            self._bucket, key, len(data),
        )

        headers = self._auth_headers({
            "Content-Type": content_type,
            # Overwrite if it already exists, matching the R2 behaviour.
            "x-upsert": "true",
        })

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, content=data, headers=headers)

        if response.status_code not in (200, 201):
            _logger.error(
                "Supabase upload failed: status=%d body=%s",
                response.status_code, response.text[:500],
            )
            raise ServiceUnavailableError(
                f"Storage upload failed ({response.status_code})"
            )

        return UploadResult(
            key=key,
            public_url=self._public_url(key),
            content_type=content_type,
            size_bytes=len(data),
        )

    async def signed_url(self, *, key: str, expires_in_seconds: int) -> str:
        url = self._sign_url(key)
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                url,
                json={"expiresIn": expires_in_seconds},
                headers=self._auth_headers({"Content-Type": "application/json"}),
            )

        if response.status_code != 200:
            _logger.error(
                "Supabase signed-url failed: status=%d body=%s",
                response.status_code, response.text[:500],
            )
            raise ServiceUnavailableError(
                f"Could not create signed URL ({response.status_code})"
            )

        payload: dict[str, Any] = response.json()
        signed_path = payload.get("signedURL") or payload.get("signedUrl")
        if not signed_path:
            raise ServiceUnavailableError("Signed URL not returned by Supabase")
        # Supabase returns a relative path like `/object/sign/...?token=...`
        if signed_path.startswith("http"):
            return signed_path
        return f"{self._base}/storage/v1{signed_path}"

    async def delete(self, *, key: str) -> None:
        url = self._api_url(key)
        _logger.info(
            "Deleting from Supabase Storage: bucket=%s key=%s",
            self._bucket, key,
        )
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.delete(url, headers=self._auth_headers())

        # 200 = deleted, 404 = already gone (idempotent).
        if response.status_code not in (200, 204, 404):
            _logger.error(
                "Supabase delete failed: status=%d body=%s",
                response.status_code, response.text[:500],
            )
            raise ServiceUnavailableError(
                f"Storage delete failed ({response.status_code})"
            )
