"""Storage interface.

Services depend on this :class:`StorageClient` protocol, not on
``aioboto3`` directly. Swapping R2 for S3 or local disk just means
providing another implementation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class UploadResult:
    """The minimal information a service needs after storing a file."""

    key: str            # object key inside the bucket
    public_url: str     # browser-accessible URL (or signed URL)
    content_type: str
    size_bytes: int


@runtime_checkable
class StorageClient(Protocol):
    """Abstract storage backend."""

    async def upload(
        self,
        *,
        key: str,
        data: bytes,
        content_type: str,
    ) -> UploadResult:
        """Upload a blob; return its key and a URL."""

    async def signed_url(self, *, key: str, expires_in_seconds: int) -> str:
        """Return a time-limited URL that can read the object."""

    async def delete(self, *, key: str) -> None:
        """Delete the object; idempotent."""
