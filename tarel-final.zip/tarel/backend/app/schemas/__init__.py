"""Shared Pydantic schemas (cross-module)."""

from app.schemas.common import MessageResponse, PagedResponse

__all__ = ["MessageResponse", "PagedResponse"]
