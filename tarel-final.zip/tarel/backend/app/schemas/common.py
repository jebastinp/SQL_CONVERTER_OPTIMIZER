"""Reusable Pydantic schema wrappers."""

from __future__ import annotations

from typing import Generic, List, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class MessageResponse(BaseModel):
    """Used by endpoints that just acknowledge success."""

    message: str


class PagedResponse(BaseModel, Generic[T]):
    """Standard pagination envelope."""

    items: List[T]
    total: int
    page: int
    page_size: int
    total_pages: int
