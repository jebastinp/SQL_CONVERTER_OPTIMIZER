"""SQLAlchemy declarative base and the IdentityMixin.

Every domain table inherits ``IdentityMixin`` so it has:

* ``id``   — internal ``BIGSERIAL`` primary key, used for joins
* ``uuid`` — UUID exposed to the frontend (returned as ``id`` in JSON)
* ``code`` — optional human-readable identifier (e.g. ``ORD-000123``)
* ``created_at`` / ``updated_at`` — audit timestamps (timezone-aware)
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import BigInteger, Column, DateTime, String, func
from sqlalchemy.orm import DeclarativeBase

from app.db.types import GUID


class Base(DeclarativeBase):
    """Project-wide declarative base."""


class IdentityMixin:
    """Adds the standard identity + audit columns to every model."""

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    uuid = Column(
        GUID,
        unique=True,
        nullable=False,
        index=True,
        default=uuid.uuid4,
    )
    code = Column(String(32), unique=True, nullable=True, index=True)
    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(tz=timezone.utc),
        server_default=func.now(),
    )
    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(tz=timezone.utc),
        onupdate=lambda: datetime.now(tz=timezone.utc),
        server_default=func.now(),
    )
