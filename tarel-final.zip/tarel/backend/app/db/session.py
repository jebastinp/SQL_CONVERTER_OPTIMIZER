"""Async SQLAlchemy engine + session.

There is exactly one ``async_engine`` and one ``async_session_factory``
for the whole process — created at import time and shared.

Use :func:`get_async_session` as a FastAPI dependency to obtain a
per-request session.
"""

from __future__ import annotations

from typing import AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.core import constants as C
from app.core.config import settings

# Single engine instance for the process. Pool sizes & echo are
# settings-driven.
async_engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DATABASE_ECHO,
    pool_pre_ping=True,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_recycle=C.DB_POOL_RECYCLE_SECONDS,
    future=True,
)

# Session factory bound to the single engine.
async_session_factory: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=async_engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
    class_=AsyncSession,
)


async def get_async_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency that yields an ``AsyncSession`` per request.

    The session is closed when the request ends; transactions are
    committed/rolled back by the calling code (usually the service
    layer) — the dependency only handles the connection lifecycle.
    """
    async with async_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
