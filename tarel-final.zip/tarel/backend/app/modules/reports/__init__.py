"""Admin reports."""

from app.modules.reports.router import router as reports_router

__all__ = ["reports_router"]
