"""Vendor report generator.

Produces a downloadable XLSX summary of products grouped by category,
with totals — suitable for sending to suppliers / vendors. Uses
``openpyxl`` so the output opens cleanly in Excel, Numbers, and
Google Sheets.

The data source is the existing products + categories tables; this
generator does NOT change any pricing or delivery rule.
"""

from __future__ import annotations

from datetime import date
from io import BytesIO
from typing import Iterable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


# Brand palette as cell fills.
HEADER_FILL = PatternFill("solid", fgColor="2F4135")
SUBHEAD_FILL = PatternFill("solid", fgColor="708E53")
ZEBRA_FILL = PatternFill("solid", fgColor="F1ECE2")
HEADER_FONT = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
SUBHEAD_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
BODY_FONT = Font(name="Calibri", size=11, color="2F4135")


def generate_vendor_report(*, products: Iterable[dict]) -> bytes:
    """Return the XLSX bytes for a vendor-ready product report.

    ``products`` is an iterable of dicts shaped like:
        {
            "category_name": str,
            "code": str | None,
            "name": str,
            "stock_kg": float,
            "one_kg_price": float,
            "half_kg_price": float | None,
            "is_active": bool,
        }
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Vendor Report"
    ws.sheet_view.showGridLines = False

    # Title row
    ws.merge_cells("A1:F1")
    title = ws["A1"]
    title.value = f"Tarel — Vendor Report ({date.today().isoformat()})"
    title.font = Font(name="Calibri", size=16, bold=True, color="2F4135")
    title.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 32

    # Column headers
    headers = ["Category", "Code", "Product", "Stock (kg)", "1kg price (£)", "Active"]
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=3, column=col_idx, value=header)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[3].height = 24

    # Body
    row = 4
    last_category: str | None = None
    for idx, product in enumerate(products):
        category = product.get("category_name") or "Uncategorised"
        if category != last_category:
            # Sub-header band for the category
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=6)
            band = ws.cell(row=row, column=1, value=category)
            band.font = SUBHEAD_FONT
            band.fill = SUBHEAD_FILL
            band.alignment = Alignment(horizontal="left", vertical="center")
            ws.row_dimensions[row].height = 20
            row += 1
            last_category = category

        zebra = idx % 2 == 0
        values = [
            "",
            product.get("code") or "—",
            product["name"],
            float(product.get("stock_kg") or 0),
            float(product.get("one_kg_price") or 0),
            "Yes" if product.get("is_active", True) else "No",
        ]
        for col_idx, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col_idx, value=value)
            cell.font = BODY_FONT
            if zebra:
                cell.fill = ZEBRA_FILL
            if col_idx in (4, 5):
                cell.number_format = "#,##0.00"
                cell.alignment = Alignment(horizontal="right")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")
        row += 1

    # Column widths
    widths = [22, 14, 36, 14, 14, 10]
    for col_idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    # Freeze header
    ws.freeze_panes = "A4"

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.getvalue()
