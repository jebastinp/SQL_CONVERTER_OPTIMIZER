"""Admin report endpoints."""

from __future__ import annotations

from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, Response
from sqlalchemy import select

from app.core.dependencies import SessionDep
from app.modules.auth.dependencies import CurrentAdminDep
from app.modules.products.models import Product
from app.modules.reports.vendor_report import generate_vendor_report

router = APIRouter(prefix="/admin/reports", tags=["admin", "reports"])


@router.get("/vendor.xlsx")
async def download_vendor_report(
    session: SessionDep,
    _admin: CurrentAdminDep,
) -> Response:
    """Return a fresh vendor report XLSX as a downloadable attachment."""
    stmt = select(Product).order_by(Product.is_active.desc(), Product.name)
    result = await session.execute(stmt)
    products = result.scalars().all()

    payload = [
        {
            "category_name": p.category.name if p.category else "Uncategorised",
            "code": p.code,
            "name": p.name,
            "stock_kg": p.stock_kg,
            "one_kg_price": p.one_kg_price or p.price_per_kg,
            "half_kg_price": p.half_kg_price,
            "is_active": p.is_active,
        }
        for p in products
    ]

    xlsx_bytes = generate_vendor_report(products=payload)
    filename = f"tarel-vendor-report-{date.today().isoformat()}.xlsx"
    return Response(
        content=xlsx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
