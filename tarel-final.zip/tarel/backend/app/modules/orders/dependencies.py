"""Order DI providers."""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends

from app.core.dependencies import SessionDep
from app.modules.orders.repository import OrderRepository
from app.modules.orders.service import OrderService
from app.modules.products.dependencies import ProductRepoDep


def get_order_repository(session: SessionDep) -> OrderRepository:
    return OrderRepository(session)


OrderRepoDep = Annotated[OrderRepository, Depends(get_order_repository)]


def get_order_service(
    order_repository: OrderRepoDep,
    product_repository: ProductRepoDep,
) -> OrderService:
    return OrderService(
        order_repository=order_repository,
        product_repository=product_repository,
    )


OrderServiceDep = Annotated[OrderService, Depends(get_order_service)]
