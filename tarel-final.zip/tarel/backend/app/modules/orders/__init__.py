"""Orders module."""

from app.modules.orders.router import router as orders_router
from app.modules.orders.router import admin_router as orders_admin_router

__all__ = ["orders_router", "orders_admin_router"]
