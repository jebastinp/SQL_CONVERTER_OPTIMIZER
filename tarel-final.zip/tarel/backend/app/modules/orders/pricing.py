"""Price calculation — preserved verbatim from legacy ``utils/pricing.py``.

``calculate_price`` is the single source of truth for line totals so
the cart, checkout, and order placement always agree.
"""

from __future__ import annotations

from decimal import Decimal


def calculate_price(
    weight_kg: float | Decimal,
    one_kg_price: float,
    half_kg_price: float,
) -> float:
    """Compute the price for ``weight_kg`` at the given prices.

    Behaviour preserved: full kgs are charged at ``one_kg_price``;
    a remaining 0.5 kg is charged at ``half_kg_price``. Anything
    finer than 0.5 kg is rejected upstream — we assume the input
    is already quantised.
    """
    weight = Decimal(str(weight_kg))
    full_kgs = int(weight // 1)
    remainder = weight - Decimal(full_kgs)
    total = Decimal(full_kgs) * Decimal(str(one_kg_price))
    if remainder == Decimal("0.5"):
        total += Decimal(str(half_kg_price))
    return float(total)
