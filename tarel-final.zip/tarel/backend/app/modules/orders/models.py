"""Order domain models.

Status state machine (preserved from legacy):

    pending → paid → processing → out_for_delivery → delivered
       │       │         │              │
       └───────┴─────────┴──────────────┴─────────────→ cancelled

Cancellation rules and stock effects are enforced in OrderService,
not here. Models are just data.
"""

from __future__ import annotations

import enum

from sqlalchemy import (
    Column,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from app.db.base import Base, IdentityMixin


class OrderStatusEnum(str, enum.Enum):
    pending = "pending"
    paid = "paid"
    processing = "processing"
    out_for_delivery = "out_for_delivery"
    delivered = "delivered"
    cancelled = "cancelled"


class Order(IdentityMixin, Base):
    __tablename__ = "orders"

    user_id = Column(ForeignKey("users.id"), nullable=False, index=True)
    status = Column(
        Enum(OrderStatusEnum, name="orderstatusenum"),
        default=OrderStatusEnum.pending,
        nullable=False,
        index=True,
    )

    total_amount = Column(Float, nullable=False, default=0.0)

    order_date = Column(Date, nullable=False)
    delivery_date = Column(Date, nullable=True, index=True)
    delivery_slot = Column(String(60), nullable=True)

    notes = Column(Text, nullable=True)

    cancelled_at = Column(DateTime(timezone=True), nullable=True)
    paid_at = Column(DateTime(timezone=True), nullable=True)
    delivered_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="orders")
    items = relationship(
        "OrderItem",
        back_populates="order",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    payments = relationship(
        "Payment",
        back_populates="order",
        cascade="all, delete-orphan",
        lazy="selectin",
    )


class OrderItem(IdentityMixin, Base):
    __tablename__ = "order_items"

    order_id = Column(ForeignKey("orders.id"), nullable=False, index=True)
    product_id = Column(ForeignKey("products.id"), nullable=False)

    # Snapshot of product fields at the time of order — this is intentional
    # so order history doesn't drift if the catalog changes later.
    product_name = Column(String(160), nullable=False)
    qty_kg = Column(Float, nullable=False)
    price_per_kg = Column(Float, nullable=False)
    line_total = Column(Float, nullable=False)
    cut_clean_label = Column(String(200), nullable=True)

    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")
