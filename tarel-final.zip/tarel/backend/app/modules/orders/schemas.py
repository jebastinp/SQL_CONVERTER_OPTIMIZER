"""Order Pydantic schemas."""

from __future__ import annotations

from datetime import date, datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from app.modules.orders.models import OrderStatusEnum


# ── Items ────────────────────────────────────────────────────────────────────
class OrderItemInput(BaseModel):
    product_uuid: UUID
    qty_kg: float
    cut_clean_label: Optional[str] = None


class OrderItemOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    product_id: UUID
    product_name: str
    qty_kg: float
    price_per_kg: float
    line_total: float
    cut_clean_label: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


# ── Orders ───────────────────────────────────────────────────────────────────
class OrderCreate(BaseModel):
    """Payload to create a new order (used by checkout)."""
    items: List[OrderItemInput]
    delivery_slot: Optional[str] = None
    notes: Optional[str] = None


class OrderStatusUpdate(BaseModel):
    status: OrderStatusEnum


class OrderSummary(BaseModel):
    """Compact projection for list views (3-per-row cards)."""
    id: UUID = Field(..., validation_alias="uuid")
    code: Optional[str] = None
    status: OrderStatusEnum
    total_amount: float
    item_count: int
    created_at: datetime
    delivery_date: Optional[date] = None
    delivery_slot: Optional[str] = None

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class AdminOrderSummary(OrderSummary):
    """Like OrderSummary but with customer info for admin lists."""
    customer_name: Optional[str] = None
    customer_email: Optional[str] = None
    customer_postcode: Optional[str] = None


class OrderDetail(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    code: Optional[str] = None
    status: OrderStatusEnum
    total_amount: float
    order_date: date
    delivery_date: Optional[date] = None
    delivery_slot: Optional[str] = None
    notes: Optional[str] = None
    items: List[OrderItemOut]
    created_at: datetime
    paid_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    cancellation_allowed: bool = True

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
