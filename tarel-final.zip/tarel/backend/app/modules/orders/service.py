"""Order service.

Encapsulates the order lifecycle:
  - placement (validates items, snapshots prices, computes delivery date)
  - status transitions (state machine preserved from legacy)
  - cancellation (honours the cutoff rule from delivery_utils, triggers
    refund via the payment gateway)

Pricing rules, cancellation cutoff, and the status flow are preserved
verbatim from the legacy code.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Sequence
from uuid import UUID

from app.core import constants as C
from app.core.exceptions import BadRequestError, ConflictError, NotFoundError
from app.modules.delivery.utils import (
    get_delivery_date,
    is_cancellation_allowed,
)
from app.modules.orders.models import Order, OrderItem, OrderStatusEnum
from app.modules.orders.pricing import calculate_price
from app.modules.orders.repository import OrderRepository
from app.modules.orders.schemas import OrderCreate, OrderItemInput
from app.modules.products.repository import ProductRepository
from app.modules.users.models import User

_logger = logging.getLogger("tarel.orders.service")


# Allowed forward transitions — declarative, easy to audit.
_TRANSITIONS: dict[OrderStatusEnum, set[OrderStatusEnum]] = {
    OrderStatusEnum.pending: {OrderStatusEnum.paid, OrderStatusEnum.cancelled},
    OrderStatusEnum.paid: {OrderStatusEnum.processing, OrderStatusEnum.cancelled},
    OrderStatusEnum.processing: {OrderStatusEnum.out_for_delivery, OrderStatusEnum.cancelled},
    OrderStatusEnum.out_for_delivery: {OrderStatusEnum.delivered, OrderStatusEnum.cancelled},
    OrderStatusEnum.delivered: set(),       # terminal
    OrderStatusEnum.cancelled: set(),       # terminal
}


def _generate_order_code(internal_id: int) -> str:
    return f"{C.ORDER_CODE_PREFIX}-{internal_id:0{C.CODE_PAD_WIDTH}d}"


class OrderService:
    def __init__(
        self,
        *,
        order_repository: OrderRepository,
        product_repository: ProductRepository,
    ) -> None:
        self._orders = order_repository
        self._products = product_repository

    # ── Reads ─────────────────────────────────────────────────────────────────
    async def list_for_user(self, user: User) -> Sequence[Order]:
        return await self._orders.list_for_user(user.id)

    async def list_all_with_customers(self) -> Sequence[tuple[Order, User]]:
        return await self._orders.list_all_with_customers()

    async def get_by_uuid(self, uuid_value: UUID) -> Order:
        order = await self._orders.get_with_items(uuid_value)
        if order is None:
            raise NotFoundError("Order not found")
        return order

    async def get_for_user(self, uuid_value: UUID, user: User) -> Order:
        order = await self.get_by_uuid(uuid_value)
        if order.user_id != user.id:
            # Don't reveal whether the order exists for someone else.
            raise NotFoundError("Order not found")
        return order

    # ── Placement ────────────────────────────────────────────────────────────
    async def place(self, *, user: User, payload: OrderCreate) -> Order:
        if not payload.items:
            raise BadRequestError("Order must have at least one item")

        items: list[OrderItem] = []
        total = 0.0

        for item_input in payload.items:
            order_item, line_total = await self._build_item(item_input)
            items.append(order_item)
            total += line_total

        order_date = date.today()
        order = Order(
            user_id=user.id,
            status=OrderStatusEnum.pending,
            total_amount=round(total, 2),
            order_date=order_date,
            delivery_date=get_delivery_date(order_date),
            delivery_slot=payload.delivery_slot,
            notes=payload.notes,
            items=items,
        )
        order = await self._orders.add(order)
        # Assign a human-readable code now that we have the integer PK.
        order.code = _generate_order_code(order.id)
        await self._orders.update(order, {"code": order.code})

        _logger.info("Placed order %s (uuid=%s) for user %s, total=%.2f",
                     order.code, order.uuid, user.email, order.total_amount)
        return order

    async def _build_item(self, item: OrderItemInput) -> tuple[OrderItem, float]:
        product = await self._products.get_by_uuid(item.product_uuid)
        if product is None:
            raise BadRequestError(f"Unknown product")
        if not product.is_active:
            raise BadRequestError(f"Product '{product.name}' is no longer available")
        if item.qty_kg <= 0:
            raise BadRequestError("Quantity must be positive")

        one_kg_price = product.one_kg_price or product.price_per_kg
        half_kg_price = product.half_kg_price or round(product.price_per_kg / 2, 2)
        line_total = calculate_price(item.qty_kg, one_kg_price, half_kg_price)

        order_item = OrderItem(
            product_id=product.id,
            product_name=product.name,
            qty_kg=item.qty_kg,
            price_per_kg=one_kg_price,
            line_total=round(line_total, 2),
            cut_clean_label=item.cut_clean_label,
        )
        return order_item, line_total

    # ── State transitions ────────────────────────────────────────────────────
    async def transition(
        self,
        *,
        order: Order,
        next_status: OrderStatusEnum,
    ) -> Order:
        if next_status == order.status:
            return order
        allowed = _TRANSITIONS.get(order.status, set())
        if next_status not in allowed:
            raise ConflictError(
                f"Cannot transition order from {order.status.value} to {next_status.value}"
            )
        updates: dict = {"status": next_status}
        now = datetime.now(tz=timezone.utc)
        if next_status == OrderStatusEnum.paid:
            updates["paid_at"] = now
        elif next_status == OrderStatusEnum.delivered:
            updates["delivered_at"] = now
        elif next_status == OrderStatusEnum.cancelled:
            updates["cancelled_at"] = now
        return await self._orders.update(order, updates)

    async def mark_paid(self, order: Order) -> Order:
        return await self.transition(order=order, next_status=OrderStatusEnum.paid)

    async def cancel(self, *, order: Order, by_admin: bool = False) -> Order:
        """Cancel an order.

        Customers can cancel only inside the cutoff window. Admins can
        always cancel. The actual refund is initiated by the caller
        (PaymentService) after this returns.
        """
        if order.status in (OrderStatusEnum.delivered, OrderStatusEnum.cancelled):
            raise ConflictError(f"Order is already {order.status.value}")
        if not by_admin and not is_cancellation_allowed(order.order_date):
            raise ConflictError(
                "Cancellation window has closed. Please contact support."
            )
        return await self.transition(order=order, next_status=OrderStatusEnum.cancelled)
