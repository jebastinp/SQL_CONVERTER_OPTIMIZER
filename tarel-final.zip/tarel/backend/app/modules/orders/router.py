"""Order HTTP endpoints."""

from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, status

from app.modules.auth.dependencies import CurrentAdminDep, CurrentUserDep
from app.modules.delivery.utils import is_cancellation_allowed
from app.modules.orders.dependencies import OrderServiceDep
from app.modules.orders.schemas import (
    AdminOrderSummary,
    OrderCreate,
    OrderDetail,
    OrderStatusUpdate,
    OrderSummary,
)
from app.schemas.common import MessageResponse

router = APIRouter(prefix="/orders", tags=["orders"])


def _to_summary(order) -> OrderSummary:
    summary = OrderSummary.model_validate(order)
    summary.item_count = len(order.items)
    return summary


def _to_detail(order) -> OrderDetail:
    detail = OrderDetail.model_validate(order)
    detail.cancellation_allowed = is_cancellation_allowed(order.order_date)
    return detail


# ── User endpoints ───────────────────────────────────────────────────────────
@router.get("/me", response_model=List[OrderSummary])
async def list_my_orders(
    user: CurrentUserDep,
    service: OrderServiceDep,
) -> List[OrderSummary]:
    orders = await service.list_for_user(user)
    return [_to_summary(o) for o in orders]


@router.post(
    "",
    response_model=OrderDetail,
    status_code=status.HTTP_201_CREATED,
)
async def place_order(
    payload: OrderCreate,
    user: CurrentUserDep,
    service: OrderServiceDep,
) -> OrderDetail:
    order = await service.place(user=user, payload=payload)
    return _to_detail(order)


@router.get("/{order_uuid}", response_model=OrderDetail)
async def get_my_order(
    order_uuid: UUID,
    user: CurrentUserDep,
    service: OrderServiceDep,
) -> OrderDetail:
    order = await service.get_for_user(order_uuid, user)
    return _to_detail(order)


@router.post("/{order_uuid}/cancel", response_model=OrderDetail)
async def cancel_my_order(
    order_uuid: UUID,
    user: CurrentUserDep,
    service: OrderServiceDep,
) -> OrderDetail:
    order = await service.get_for_user(order_uuid, user)
    cancelled = await service.cancel(order=order, by_admin=False)
    return _to_detail(cancelled)


# ── Admin endpoints ──────────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/admin/orders", tags=["admin", "orders"])


@admin_router.get("", response_model=List[AdminOrderSummary])
async def admin_list_orders(
    service: OrderServiceDep,
    _admin: CurrentAdminDep,
) -> List[AdminOrderSummary]:
    rows = await service.list_all_with_customers()
    out: List[AdminOrderSummary] = []
    for order, user in rows:
        summary = AdminOrderSummary.model_validate(order)
        summary.item_count = len(order.items)
        summary.customer_name = user.name
        summary.customer_email = user.email
        summary.customer_postcode = user.postcode
        out.append(summary)
    return out


@admin_router.get("/{order_uuid}", response_model=OrderDetail)
async def admin_get_order(
    order_uuid: UUID,
    service: OrderServiceDep,
    _admin: CurrentAdminDep,
) -> OrderDetail:
    order = await service.get_by_uuid(order_uuid)
    return _to_detail(order)


@admin_router.patch("/{order_uuid}/status", response_model=OrderDetail)
async def admin_update_status(
    order_uuid: UUID,
    payload: OrderStatusUpdate,
    service: OrderServiceDep,
    _admin: CurrentAdminDep,
) -> OrderDetail:
    order = await service.get_by_uuid(order_uuid)
    updated = await service.transition(order=order, next_status=payload.status)
    return _to_detail(updated)
