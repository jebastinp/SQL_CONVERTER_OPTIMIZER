"""Order persistence."""

from __future__ import annotations

from typing import Sequence

from sqlalchemy import select
from sqlalchemy.orm import joinedload, selectinload

from app.modules.orders.models import Order
from app.modules.users.models import User
from app.repositories.base import AsyncRepository


class OrderRepository(AsyncRepository[Order]):
    model = Order

    async def list_for_user(self, user_id: int) -> Sequence[Order]:
        stmt = (
            select(Order)
            .where(Order.user_id == user_id)
            .order_by(Order.created_at.desc())
            .options(selectinload(Order.items))
        )
        result = await self._session.execute(stmt)
        return result.scalars().all()

    async def list_all_with_customers(self) -> Sequence[tuple[Order, User]]:
        """For the admin list — Order + the owning User in one query."""
        stmt = (
            select(Order, User)
            .join(User, Order.user_id == User.id)
            .options(selectinload(Order.items))
            .order_by(Order.created_at.desc())
        )
        result = await self._session.execute(stmt)
        return result.all()

    async def get_with_items(self, uuid_value) -> Order | None:
        from uuid import UUID as _UUID
        if not isinstance(uuid_value, _UUID):
            uuid_value = _UUID(str(uuid_value))
        stmt = (
            select(Order)
            .where(Order.uuid == uuid_value)
            .options(
                selectinload(Order.items),
                joinedload(Order.user),
                selectinload(Order.payments),
            )
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
