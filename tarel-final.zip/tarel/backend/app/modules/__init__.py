"""Feature modules — each is a self-contained vertical slice."""
