"""Category Pydantic schemas."""

from __future__ import annotations

from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class CategoryBase(BaseModel):
    name: str
    slug: str
    description: Optional[str] = None
    is_active: bool = True
    sort_order: int = 0


class CategoryCreate(CategoryBase):
    pass


class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    sort_order: Optional[int] = None


class CategoryOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    code: Optional[str] = None
    name: str
    slug: str
    description: Optional[str] = None
    is_active: bool
    sort_order: int

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
