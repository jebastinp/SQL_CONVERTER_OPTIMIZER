"""Category business logic."""

from __future__ import annotations

from typing import Sequence
from uuid import UUID

from app.core.exceptions import ConflictError, NotFoundError
from app.modules.categories.models import Category
from app.modules.categories.repository import CategoryRepository
from app.modules.categories.schemas import CategoryCreate, CategoryUpdate


class CategoryService:
    def __init__(self, *, repository: CategoryRepository) -> None:
        self._repo = repository

    async def list_active(self) -> Sequence[Category]:
        return await self._repo.list_active()

    async def list_all(self) -> Sequence[Category]:
        return await self._repo.list(order_by=[Category.sort_order, Category.name])

    async def get_by_uuid(self, uuid_value: UUID) -> Category:
        category = await self._repo.get_by_uuid(uuid_value)
        if category is None:
            raise NotFoundError("Category not found")
        return category

    async def get_by_slug(self, slug: str) -> Category:
        category = await self._repo.get_by_slug(slug)
        if category is None:
            raise NotFoundError("Category not found")
        return category

    async def create(self, payload: CategoryCreate) -> Category:
        existing = await self._repo.get_by_slug(payload.slug)
        if existing:
            raise ConflictError("A category with this slug already exists")
        category = Category(**payload.model_dump())
        return await self._repo.add(category)

    async def update(self, uuid_value: UUID, payload: CategoryUpdate) -> Category:
        category = await self.get_by_uuid(uuid_value)
        fields = payload.model_dump(exclude_unset=True, exclude_none=True)
        if "slug" in fields and fields["slug"] != category.slug:
            colliding = await self._repo.get_by_slug(fields["slug"])
            if colliding and colliding.id != category.id:
                raise ConflictError("A category with this slug already exists")
        return await self._repo.update(category, fields)

    async def delete(self, uuid_value: UUID) -> None:
        category = await self.get_by_uuid(uuid_value)
        await self._repo.delete(category)
