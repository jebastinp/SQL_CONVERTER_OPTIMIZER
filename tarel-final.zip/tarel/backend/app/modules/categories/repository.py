"""Category persistence."""

from __future__ import annotations

from typing import Sequence

from sqlalchemy import select

from app.modules.categories.models import Category
from app.repositories.base import AsyncRepository


class CategoryRepository(AsyncRepository[Category]):
    model = Category

    async def get_by_slug(self, slug: str) -> Category | None:
        stmt = select(Category).where(Category.slug == slug)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_active(self) -> Sequence[Category]:
        return await self.list(
            filters={"is_active": True},
            order_by=[Category.sort_order, Category.name],
        )
