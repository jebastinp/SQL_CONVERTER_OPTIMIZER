"""Category HTTP endpoints."""

from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, status

from app.modules.auth.dependencies import CurrentAdminDep
from app.modules.categories.dependencies import CategoryServiceDep
from app.modules.categories.schemas import (
    CategoryCreate,
    CategoryOut,
    CategoryUpdate,
)
from app.schemas.common import MessageResponse

router = APIRouter(prefix="/categories", tags=["categories"])


@router.get("", response_model=List[CategoryOut])
async def list_categories(service: CategoryServiceDep) -> List[CategoryOut]:
    items = await service.list_active()
    return [CategoryOut.model_validate(c) for c in items]


@router.get("/{slug}", response_model=CategoryOut)
async def get_category_by_slug(slug: str, service: CategoryServiceDep) -> CategoryOut:
    category = await service.get_by_slug(slug)
    return CategoryOut.model_validate(category)


# ── Admin endpoints ──────────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/admin/categories", tags=["admin", "categories"])


@admin_router.get("", response_model=List[CategoryOut])
async def admin_list_categories(
    service: CategoryServiceDep,
    _admin: CurrentAdminDep,
) -> List[CategoryOut]:
    items = await service.list_all()
    return [CategoryOut.model_validate(c) for c in items]


@admin_router.post(
    "",
    response_model=CategoryOut,
    status_code=status.HTTP_201_CREATED,
)
async def admin_create_category(
    payload: CategoryCreate,
    service: CategoryServiceDep,
    _admin: CurrentAdminDep,
) -> CategoryOut:
    category = await service.create(payload)
    return CategoryOut.model_validate(category)


@admin_router.patch("/{category_uuid}", response_model=CategoryOut)
async def admin_update_category(
    category_uuid: UUID,
    payload: CategoryUpdate,
    service: CategoryServiceDep,
    _admin: CurrentAdminDep,
) -> CategoryOut:
    category = await service.update(category_uuid, payload)
    return CategoryOut.model_validate(category)


@admin_router.delete("/{category_uuid}", response_model=MessageResponse)
async def admin_delete_category(
    category_uuid: UUID,
    service: CategoryServiceDep,
    _admin: CurrentAdminDep,
) -> MessageResponse:
    await service.delete(category_uuid)
    return MessageResponse(message="Category deleted")
