"""Category DI providers."""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends

from app.core.dependencies import SessionDep
from app.modules.categories.repository import CategoryRepository
from app.modules.categories.service import CategoryService


def get_category_repository(session: SessionDep) -> CategoryRepository:
    return CategoryRepository(session)


CategoryRepoDep = Annotated[CategoryRepository, Depends(get_category_repository)]


def get_category_service(repo: CategoryRepoDep) -> CategoryService:
    return CategoryService(repository=repo)


CategoryServiceDep = Annotated[CategoryService, Depends(get_category_service)]
