"""Categories module."""

from app.modules.categories.router import router as categories_router

__all__ = ["categories_router"]
