"""Payment domain models.

A single order can have multiple Payment rows (one per checkout
attempt); a successful Payment can have one or more Refund rows.

PaymentEvent records every callback / webhook we receive so we have
an audit trail of what the gateway told us.
"""

from __future__ import annotations

import enum

from sqlalchemy import (
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from app.db.base import Base, IdentityMixin


class PaymentStatusEnum(str, enum.Enum):
    pending = "pending"          # session created, awaiting customer
    succeeded = "succeeded"      # gateway confirmed
    failed = "failed"            # gateway returned failure
    cancelled = "cancelled"      # customer abandoned at gateway
    refunded = "refunded"        # fully refunded
    partially_refunded = "partially_refunded"


class RefundStatusEnum(str, enum.Enum):
    pending = "pending"
    succeeded = "succeeded"
    failed = "failed"


class Payment(IdentityMixin, Base):
    __tablename__ = "payments"

    order_id = Column(ForeignKey("orders.id"), nullable=False, index=True)
    provider = Column(String(32), nullable=False, default="handypay")
    provider_payment_id = Column(String(128), nullable=True, index=True)
    provider_checkout_url = Column(String(1000), nullable=True)

    amount = Column(Float, nullable=False)
    currency = Column(String(8), nullable=False, default="USD")
    status = Column(
        Enum(PaymentStatusEnum, name="paymentstatusenum"),
        default=PaymentStatusEnum.pending,
        nullable=False,
    )

    confirmed_at = Column(DateTime(timezone=True), nullable=True)
    failure_reason = Column(String(255), nullable=True)

    order = relationship("Order", back_populates="payments")
    refunds = relationship(
        "Refund",
        back_populates="payment",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    events = relationship(
        "PaymentEvent",
        back_populates="payment",
        cascade="all, delete-orphan",
        lazy="selectin",
    )


class Refund(IdentityMixin, Base):
    __tablename__ = "refunds"

    payment_id = Column(ForeignKey("payments.id"), nullable=False, index=True)
    provider_refund_id = Column(String(128), nullable=True, index=True)
    amount = Column(Float, nullable=False)
    reason = Column(String(255), nullable=True)
    status = Column(
        Enum(RefundStatusEnum, name="refundstatusenum"),
        default=RefundStatusEnum.pending,
        nullable=False,
    )
    confirmed_at = Column(DateTime(timezone=True), nullable=True)

    payment = relationship("Payment", back_populates="refunds")


class PaymentEvent(IdentityMixin, Base):
    """One row per gateway callback/webhook, for audit & debugging."""
    __tablename__ = "payment_events"

    payment_id = Column(ForeignKey("payments.id"), nullable=True, index=True)
    provider = Column(String(32), nullable=False, default="handypay")
    event_type = Column(String(64), nullable=False)
    payload = Column(Text, nullable=False)  # raw JSON string

    payment = relationship("Payment", back_populates="events")
