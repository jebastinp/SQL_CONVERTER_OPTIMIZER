"""Mock payment gateway — for development & end-to-end testing.

Behaves like a real provider:
  - ``create_checkout_session`` returns a deterministic fake checkout
    URL that points back at the web app's ``/checkout/mock`` page,
    where the user can click "Pay" or "Fail" to simulate either
    outcome.
  - ``verify_webhook`` accepts any payload (no signature check).
  - ``refund`` always succeeds.

Pick this in the ``.env`` with::

    PAYMENT_GATEWAY=mock

…then swap to ``handypay`` once you have the real credentials.
Nothing else in the codebase changes.
"""

from __future__ import annotations

import json
import logging
import uuid as _uuid
from typing import Any

from app.core.config import Settings
from app.modules.payments.gateway import (
    CheckoutSession,
    PaymentGateway,
    RefundResult,
    WebhookVerification,
)

_logger = logging.getLogger("tarel.payments.mock")


class MockPaymentGateway(PaymentGateway):
    """In-process, always-successful gateway for development."""

    provider_name = "mock"

    def __init__(self, settings: Settings) -> None:
        self._frontend_base = (settings.FRONTEND_APP_URL or "http://localhost:3000").rstrip("/")

    async def create_checkout_session(
        self,
        *,
        order_uuid: str,
        amount: float,
        currency: str,
        customer_email: str,
        success_url: str,
        cancel_url: str,
    ) -> CheckoutSession:
        provider_id = f"mock_{_uuid.uuid4().hex[:12]}"
        # Send the user to the simulated checkout page where they can
        # choose to "pay" or "cancel".
        checkout_url = (
            f"{self._frontend_base}/checkout/mock"
            f"?payment_id={provider_id}"
            f"&order={order_uuid}"
            f"&amount={amount:.2f}"
            f"&currency={currency}"
            f"&success={success_url}"
            f"&cancel={cancel_url}"
        )
        _logger.info("Mock checkout created: %s for £%.2f", provider_id, amount)
        return CheckoutSession(
            provider_payment_id=provider_id,
            checkout_url=checkout_url,
            raw_response={
                "provider": self.provider_name,
                "provider_payment_id": provider_id,
                "amount": amount,
                "currency": currency,
            },
        )

    async def verify_webhook(
        self,
        *,
        body: bytes,
        headers: dict[str, str],
    ) -> WebhookVerification:
        # No signature verification in the mock — accept anything.
        try:
            payload: dict[str, Any] = json.loads(body)
        except json.JSONDecodeError:
            payload = {}

        event_type = str(payload.get("event_type") or payload.get("event") or "unknown")
        provider_payment_id = payload.get("payment_id") or payload.get("provider_payment_id")
        provider_refund_id = payload.get("refund_id") or payload.get("provider_refund_id")
        amount = payload.get("amount")
        try:
            amount = float(amount) if amount is not None else None
        except (TypeError, ValueError):
            amount = None

        normalized = self._normalize_event(event_type)
        _logger.info(
            "Mock webhook: %s (payment=%s amount=%s)",
            normalized, provider_payment_id, amount,
        )
        return WebhookVerification(
            event_type=normalized,
            provider_payment_id=provider_payment_id,
            provider_refund_id=provider_refund_id,
            amount=amount,
            raw_payload=payload,
        )

    async def refund(
        self,
        *,
        provider_payment_id: str,
        amount: float,
        reason: str | None = None,
    ) -> RefundResult:
        refund_id = f"mock_refund_{_uuid.uuid4().hex[:12]}"
        _logger.info(
            "Mock refund issued: %s for £%.2f (reason=%s)",
            refund_id, amount, reason,
        )
        return RefundResult(
            provider_refund_id=refund_id,
            amount=amount,
            succeeded=True,
            raw_response={
                "provider": self.provider_name,
                "provider_refund_id": refund_id,
                "amount": amount,
                "reason": reason,
            },
        )

    @staticmethod
    def _normalize_event(raw: str) -> str:
        e = raw.lower().strip()
        if e in ("payment.succeeded", "payment.success", "succeeded", "success", "paid"):
            return "payment.succeeded"
        if e in ("payment.failed", "failed", "fail"):
            return "payment.failed"
        if e in ("payment.cancelled", "cancelled", "canceled"):
            return "payment.cancelled"
        if e in ("refund.succeeded", "refund.success", "refunded"):
            return "refund.succeeded"
        if e in ("refund.failed",):
            return "refund.failed"
        return "unknown"
