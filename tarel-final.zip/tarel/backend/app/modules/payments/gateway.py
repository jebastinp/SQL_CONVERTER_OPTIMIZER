"""Payment gateway abstraction.

The service layer depends on this :class:`PaymentGateway` protocol,
not on any specific provider. Swap HandyPay for Stripe / Paystack /
Razorpay later by writing another implementation and wiring it up in
``app/core/dependencies.py``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class CheckoutSession:
    """What the gateway returns when we ask it to start checkout."""
    provider_payment_id: str
    checkout_url: str
    raw_response: dict[str, Any]


@dataclass(frozen=True, slots=True)
class RefundResult:
    """What the gateway returns when we request a refund."""
    provider_refund_id: str
    amount: float
    succeeded: bool
    raw_response: dict[str, Any]


@dataclass(frozen=True, slots=True)
class WebhookVerification:
    """Verified webhook payload returned to the service layer.

    ``event_type`` is normalised to one of:
      - "payment.succeeded"
      - "payment.failed"
      - "payment.cancelled"
      - "refund.succeeded"
      - "refund.failed"
      - "unknown"
    """
    event_type: str
    provider_payment_id: str | None
    provider_refund_id: str | None
    amount: float | None
    raw_payload: dict[str, Any]


@runtime_checkable
class PaymentGateway(Protocol):
    """Abstract payment gateway."""

    provider_name: str

    async def create_checkout(
        self,
        *,
        order_uuid: str,
        amount: float,
        currency: str,
        customer_email: str,
        customer_name: str,
        success_url: str,
        cancel_url: str,
        webhook_url: str,
    ) -> CheckoutSession:
        """Start a hosted checkout; return the URL to redirect the customer."""

    async def refund(
        self,
        *,
        provider_payment_id: str,
        amount: float,
        reason: str | None = None,
    ) -> RefundResult:
        """Issue a refund against a previous successful payment."""

    def verify_webhook(
        self,
        *,
        body: bytes,
        signature_header: str | None,
    ) -> WebhookVerification:
        """Verify the webhook signature and normalise the payload.

        Raises :class:`UnauthorizedError` if the signature doesn't match.
        """
