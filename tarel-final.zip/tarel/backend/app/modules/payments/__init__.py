"""Payments module — HandyPay gateway integration."""

from app.modules.payments.router import router as payments_router
from app.modules.payments.router import admin_router as payments_admin_router

__all__ = ["payments_router", "payments_admin_router"]
