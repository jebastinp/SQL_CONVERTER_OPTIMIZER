"""Payment persistence."""

from __future__ import annotations

from typing import Sequence

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.modules.orders.models import Order
from app.modules.payments.models import Payment, PaymentEvent, Refund
from app.modules.users.models import User
from app.repositories.base import AsyncRepository


class PaymentRepository(AsyncRepository[Payment]):
    model = Payment

    async def get_by_provider_id(self, provider_payment_id: str) -> Payment | None:
        stmt = (
            select(Payment)
            .where(Payment.provider_payment_id == provider_payment_id)
            .options(selectinload(Payment.refunds), selectinload(Payment.events))
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_latest_for_order(self, order_id: int) -> Payment | None:
        stmt = (
            select(Payment)
            .where(Payment.order_id == order_id)
            .order_by(Payment.created_at.desc())
            .limit(1)
            .options(selectinload(Payment.refunds))
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_all_with_order(self) -> Sequence[tuple[Payment, Order, User | None]]:
        """Admin view: payments + their order + customer for the page."""
        stmt = (
            select(Payment, Order, User)
            .join(Order, Order.id == Payment.order_id)
            .outerjoin(User, User.id == Order.user_id)
            .options(selectinload(Payment.refunds))
            .order_by(Payment.created_at.desc())
        )
        result = await self._session.execute(stmt)
        return result.all()


class RefundRepository(AsyncRepository[Refund]):
    model = Refund


class PaymentEventRepository(AsyncRepository[PaymentEvent]):
    model = PaymentEvent
