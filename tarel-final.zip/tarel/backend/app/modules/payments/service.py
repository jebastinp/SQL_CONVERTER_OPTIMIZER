"""Payment service.

Glues the gateway (HandyPay) to the order lifecycle:
  - ``start_checkout`` creates a Payment row and returns the URL the
    browser must redirect to
  - ``handle_webhook`` is called by the gateway-hooked endpoint; it
    verifies the signature, records the event, updates the Payment
    status, and (on success) marks the linked Order as paid
  - ``refund_order`` is called from order cancellation; it issues a
    refund through the gateway and records a Refund row
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from app.core.config import Settings
from app.core.exceptions import BadRequestError, ConflictError, NotFoundError
from app.modules.orders.models import Order, OrderStatusEnum
from app.modules.orders.service import OrderService
from app.modules.payments.gateway import PaymentGateway
from app.modules.payments.models import (
    Payment,
    PaymentEvent,
    PaymentStatusEnum,
    Refund,
    RefundStatusEnum,
)
from app.modules.payments.repository import (
    PaymentEventRepository,
    PaymentRepository,
    RefundRepository,
)

_logger = logging.getLogger("tarel.payments.service")


class PaymentService:
    def __init__(
        self,
        *,
        payment_repository: PaymentRepository,
        refund_repository: RefundRepository,
        event_repository: PaymentEventRepository,
        order_service: OrderService,
        gateway: PaymentGateway,
        settings: Settings,
    ) -> None:
        self._payments = payment_repository
        self._refunds = refund_repository
        self._events = event_repository
        self._orders = order_service
        self._gateway = gateway
        self._settings = settings

    # ── Customer-facing: start checkout ──────────────────────────────────────
    async def start_checkout(
        self,
        *,
        order: Order,
        customer_email: str,
        customer_name: str,
    ) -> Payment:
        if order.status != OrderStatusEnum.pending:
            raise ConflictError(
                f"Order is already {order.status.value}; cannot pay again"
            )
        if order.total_amount <= 0:
            raise BadRequestError("Order total must be positive")

        # Build the return / webhook URLs from the frontend + API bases.
        frontend = self._settings.FRONTEND_APP_URL.rstrip("/")
        api_base = self._settings.FRONTEND_APP_URL  # webhook lives on backend; injected by router
        # Note: the router passes the correct webhook_url; see router.py.
        success_url = f"{frontend}/checkout/success?order={order.uuid}"
        cancel_url = f"{frontend}/checkout/cancelled?order={order.uuid}"
        webhook_url = self._settings.PAYMENT_WEBHOOK_URL or f"{api_base}/api/v1/payments/webhook/{self._gateway.provider_name}"

        session = await self._gateway.create_checkout(
            order_uuid=str(order.uuid),
            amount=order.total_amount,
            currency=self._settings.PAYMENT_CURRENCY,
            customer_email=customer_email,
            customer_name=customer_name,
            success_url=success_url,
            cancel_url=cancel_url,
            webhook_url=webhook_url,
        )

        payment = Payment(
            order_id=order.id,
            provider=self._gateway.provider_name,
            provider_payment_id=session.provider_payment_id or None,
            provider_checkout_url=session.checkout_url,
            amount=order.total_amount,
            currency=self._settings.PAYMENT_CURRENCY,
            status=PaymentStatusEnum.pending,
        )
        payment = await self._payments.add(payment)

        await self._events.add(PaymentEvent(
            payment_id=payment.id,
            provider=self._gateway.provider_name,
            event_type="checkout.created",
            payload=json.dumps(session.raw_response, default=str),
        ))
        return payment

    # ── Webhook handler ──────────────────────────────────────────────────────
    async def handle_webhook(
        self,
        *,
        body: bytes,
        signature_header: str | None,
    ) -> dict[str, Any]:
        verification = self._gateway.verify_webhook(
            body=body,
            signature_header=signature_header,
        )
        _logger.info(
            "Webhook received: event=%s payment=%s",
            verification.event_type,
            verification.provider_payment_id,
        )

        payment: Payment | None = None
        if verification.provider_payment_id:
            payment = await self._payments.get_by_provider_id(
                verification.provider_payment_id
            )

        # Always record the event, even if we can't match it to a payment.
        await self._events.add(PaymentEvent(
            payment_id=payment.id if payment else None,
            provider=self._gateway.provider_name,
            event_type=verification.event_type,
            payload=json.dumps(verification.raw_payload, default=str),
        ))

        if payment is None:
            _logger.warning("Webhook for unknown payment id %s",
                            verification.provider_payment_id)
            return {"status": "ignored", "reason": "unknown_payment"}

        now = datetime.now(tz=timezone.utc)

        if verification.event_type == "payment.succeeded":
            if payment.status != PaymentStatusEnum.succeeded:
                await self._payments.update(payment, {
                    "status": PaymentStatusEnum.succeeded,
                    "confirmed_at": now,
                })
                # Mark the order as paid.
                order = await self._orders.get_by_uuid(payment.order.uuid)
                if order.status == OrderStatusEnum.pending:
                    await self._orders.mark_paid(order)
            return {"status": "processed"}

        if verification.event_type == "payment.failed":
            await self._payments.update(payment, {
                "status": PaymentStatusEnum.failed,
                "failure_reason": str(verification.raw_payload.get("failure_reason", "")) or "Payment failed",
            })
            return {"status": "processed"}

        if verification.event_type == "payment.cancelled":
            await self._payments.update(payment, {
                "status": PaymentStatusEnum.cancelled,
            })
            return {"status": "processed"}

        if verification.event_type == "refund.succeeded":
            # Find the most recent pending refund for this payment, mark succeeded.
            for refund in payment.refunds:
                if refund.status == RefundStatusEnum.pending:
                    await self._refunds.update(refund, {
                        "status": RefundStatusEnum.succeeded,
                        "confirmed_at": now,
                    })
                    break
            # Update payment-level rollup.
            total_refunded = sum(
                r.amount for r in payment.refunds
                if r.status == RefundStatusEnum.succeeded
            )
            new_status = (
                PaymentStatusEnum.refunded
                if total_refunded >= payment.amount - 0.005
                else PaymentStatusEnum.partially_refunded
            )
            await self._payments.update(payment, {"status": new_status})
            return {"status": "processed"}

        if verification.event_type == "refund.failed":
            for refund in payment.refunds:
                if refund.status == RefundStatusEnum.pending:
                    await self._refunds.update(refund, {
                        "status": RefundStatusEnum.failed,
                    })
                    break
            return {"status": "processed"}

        return {"status": "ignored", "reason": "unhandled_event"}

    # ── Refunds (driven by admin cancellation) ───────────────────────────────
    async def refund_order(
        self,
        *,
        order: Order,
        amount: float | None = None,
        reason: str | None = None,
    ) -> Refund | None:
        """Issue a refund against the order's most recent successful payment.

        Returns the Refund row (in ``pending`` state until the gateway
        confirms via webhook). Returns ``None`` if the order has no
        successful payment to refund.
        """
        payment = await self._payments.get_latest_for_order(order.id)
        if payment is None:
            _logger.info("No payment to refund for order %s", order.uuid)
            return None
        if payment.status not in (
            PaymentStatusEnum.succeeded,
            PaymentStatusEnum.partially_refunded,
        ):
            _logger.info(
                "Skipping refund: payment %s is %s",
                payment.uuid, payment.status.value,
            )
            return None
        if not payment.provider_payment_id:
            raise ConflictError("Payment has no provider id; cannot refund")

        refund_amount = amount if amount is not None else payment.amount
        if refund_amount <= 0:
            raise BadRequestError("Refund amount must be positive")
        if refund_amount > payment.amount:
            raise BadRequestError("Refund amount exceeds payment")

        result = await self._gateway.refund(
            provider_payment_id=payment.provider_payment_id,
            amount=refund_amount,
            reason=reason,
        )

        refund = Refund(
            payment_id=payment.id,
            provider_refund_id=result.provider_refund_id or None,
            amount=refund_amount,
            reason=reason,
            status=(
                RefundStatusEnum.succeeded
                if result.succeeded
                else RefundStatusEnum.pending
            ),
        )
        refund = await self._refunds.add(refund)

        await self._events.add(PaymentEvent(
            payment_id=payment.id,
            provider=self._gateway.provider_name,
            event_type="refund.initiated",
            payload=json.dumps(result.raw_response, default=str),
        ))

        # If the gateway confirmed instantly (synchronous refund), update
        # the parent payment status now; otherwise it'll be done by webhook.
        if result.succeeded:
            total_refunded = refund_amount + sum(
                r.amount for r in payment.refunds
                if r.status == RefundStatusEnum.succeeded
            )
            new_status = (
                PaymentStatusEnum.refunded
                if total_refunded >= payment.amount - 0.005
                else PaymentStatusEnum.partially_refunded
            )
            await self._payments.update(payment, {"status": new_status})

        return refund

    async def get_latest_for_order(self, order_id: int) -> Payment | None:
        return await self._payments.get_latest_for_order(order_id)

    # ── Admin views ──────────────────────────────────────────────────────────
    async def admin_list_all(self) -> list[dict]:
        """Return all payments joined with their order + customer.

        Returns plain dicts (not ORM rows) ready for ``AdminPaymentRow``
        validation in the router.
        """
        joined = await self._payments.list_all_with_order()
        result: list[dict] = []
        for payment, order, user in joined:
            total_refunded = sum(
                r.amount for r in payment.refunds
                if r.status == RefundStatusEnum.succeeded
            )
            result.append({
                "uuid": payment.uuid,
                "code": payment.code,
                "order_id": order.uuid,
                "order_code": order.code,
                "customer_name": user.name if user else None,
                "customer_email": user.email if user else None,
                "provider": payment.provider,
                "provider_payment_id": payment.provider_payment_id,
                "amount": payment.amount,
                "currency": payment.currency,
                "status": payment.status,
                "confirmed_at": payment.confirmed_at,
                "failure_reason": payment.failure_reason,
                "created_at": payment.created_at,
                "total_refunded": total_refunded,
            })
        return result

    async def admin_refund_payment(
        self,
        *,
        payment_uuid: UUID,
        amount: float,
        reason: str | None,
    ) -> Payment:
        """Refund a specific payment directly (admin-driven, not via order).

        Returns the updated payment with refund summary, suitable for
        the admin payments list to refresh the row in-place.
        """
        payment = await self._payments.get_by_uuid(payment_uuid)
        if payment is None:
            raise NotFoundError("Payment not found")
        if payment.status not in (
            PaymentStatusEnum.succeeded,
            PaymentStatusEnum.partially_refunded,
        ):
            raise ConflictError(
                f"Cannot refund a {payment.status.value} payment"
            )
        if not payment.provider_payment_id:
            raise ConflictError("Payment has no provider id; cannot refund")
        if amount <= 0:
            raise BadRequestError("Refund amount must be positive")

        already_refunded = sum(
            r.amount for r in payment.refunds
            if r.status == RefundStatusEnum.succeeded
        )
        remaining = payment.amount - already_refunded
        if amount > remaining + 0.005:
            raise BadRequestError(
                f"Refund amount exceeds remaining {remaining:.2f}"
            )

        result = await self._gateway.refund(
            provider_payment_id=payment.provider_payment_id,
            amount=amount,
            reason=reason,
        )

        refund = Refund(
            payment_id=payment.id,
            provider_refund_id=result.provider_refund_id or None,
            amount=amount,
            reason=reason,
            status=(
                RefundStatusEnum.succeeded
                if result.succeeded
                else RefundStatusEnum.pending
            ),
        )
        await self._refunds.add(refund)

        await self._events.add(PaymentEvent(
            payment_id=payment.id,
            provider=self._gateway.provider_name,
            event_type="refund.initiated",
            payload=json.dumps(result.raw_response, default=str),
        ))

        if result.succeeded:
            total_refunded = already_refunded + amount
            new_status = (
                PaymentStatusEnum.refunded
                if total_refunded >= payment.amount - 0.005
                else PaymentStatusEnum.partially_refunded
            )
            await self._payments.update(payment, {"status": new_status})

        # Re-fetch with updated refunds list
        refreshed = await self._payments.get_by_uuid(payment_uuid)
        return refreshed or payment
