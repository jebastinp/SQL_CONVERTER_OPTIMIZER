"""Payment HTTP endpoints.

Three endpoints:
  - ``POST /orders/{uuid}/checkout``   start a checkout (returns URL)
  - ``POST /payments/webhook/handypay`` gateway callback
  - ``POST /admin/orders/{uuid}/refund`` admin issues a refund
"""

from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, Header, Request, status

from app.core.exceptions import NotFoundError
from app.modules.auth.dependencies import CurrentAdminDep, CurrentUserDep
from app.modules.orders.dependencies import OrderServiceDep
from app.modules.payments.dependencies import PaymentServiceDep
from app.modules.payments.handypay import HANDYPAY_SIGNATURE_HEADER
from app.modules.payments.schemas import (
    AdminPaymentRow,
    CreatePaymentResponse,
    PaymentOut,
    RefundOut,
    RefundRequest,
)

# ── Customer-facing ──────────────────────────────────────────────────────────
router = APIRouter(prefix="/orders", tags=["payments"])


@router.post(
    "/{order_uuid}/checkout",
    response_model=CreatePaymentResponse,
    status_code=status.HTTP_201_CREATED,
)
async def start_checkout(
    order_uuid: UUID,
    user: CurrentUserDep,
    order_service: OrderServiceDep,
    payment_service: PaymentServiceDep,
) -> CreatePaymentResponse:
    """Start a HandyPay checkout for an existing pending order.

    Returns the URL the frontend should redirect the browser to.
    """
    order = await order_service.get_for_user(order_uuid, user)
    payment = await payment_service.start_checkout(
        order=order,
        customer_email=user.email,
        customer_name=user.name,
    )
    return CreatePaymentResponse(
        payment_id=payment.uuid,
        checkout_url=payment.provider_checkout_url or "",
        amount=payment.amount,
        currency=payment.currency,
    )


@router.get("/{order_uuid}/payment", response_model=PaymentOut)
async def get_order_payment(
    order_uuid: UUID,
    user: CurrentUserDep,
    order_service: OrderServiceDep,
    payment_service: PaymentServiceDep,
) -> PaymentOut:
    """Latest payment record for one of *my* orders. Used by the
    /checkout/success page to confirm status before showing success.
    """
    order = await order_service.get_for_user(order_uuid, user)
    payment = await payment_service.get_latest_for_order(order.id)
    if payment is None:
        raise NotFoundError("No payment found for this order")
    return PaymentOut.model_validate(payment)


# ── Webhook (called by HandyPay, no auth) ────────────────────────────────────
webhook_router = APIRouter(prefix="/payments", tags=["payments"])


@webhook_router.post("/webhook/handypay")
async def handypay_webhook(
    request: Request,
    payment_service: PaymentServiceDep,
):
    body = await request.body()
    signature = request.headers.get(HANDYPAY_SIGNATURE_HEADER)
    return await payment_service.handle_webhook(
        body=body,
        signature_header=signature,
    )


# ── Admin ────────────────────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/admin", tags=["admin", "payments"])


@admin_router.get("/payments", response_model=List[AdminPaymentRow])
async def admin_list_payments(
    _admin: CurrentAdminDep,
    payment_service: PaymentServiceDep,
) -> List[AdminPaymentRow]:
    """List every payment with its order + customer context."""
    rows = await payment_service.admin_list_all()
    return [AdminPaymentRow.model_validate(r) for r in rows]


@admin_router.post(
    "/payments/{payment_uuid}/refund",
    response_model=AdminPaymentRow,
    status_code=status.HTTP_201_CREATED,
)
async def admin_refund_payment(
    payment_uuid: UUID,
    payload: RefundRequest,
    _admin: CurrentAdminDep,
    payment_service: PaymentServiceDep,
) -> AdminPaymentRow:
    """Refund a specific payment (partial refunds supported).

    Used by Admin → Payments → Refund button. The amount must be
    positive and not exceed the payment's remaining refundable balance.
    """
    if payload.amount is None or payload.amount <= 0:
        # Default to the remaining refundable amount.
        # Service will validate against actual remaining.
        amount = payload.amount or 0.0
    else:
        amount = payload.amount
    payment = await payment_service.admin_refund_payment(
        payment_uuid=payment_uuid,
        amount=amount,
        reason=payload.reason,
    )
    # Build the admin row from the refreshed payment.
    rows = await payment_service.admin_list_all()
    match = next((r for r in rows if r["uuid"] == payment.uuid), None)
    if match is None:
        raise NotFoundError("Payment not found after refund")
    return AdminPaymentRow.model_validate(match)


@admin_router.post(
    "/orders/{order_uuid}/refund",
    response_model=RefundOut,
    status_code=status.HTTP_201_CREATED,
)
async def admin_refund_order(
    order_uuid: UUID,
    payload: RefundRequest,
    _admin: CurrentAdminDep,
    order_service: OrderServiceDep,
    payment_service: PaymentServiceDep,
) -> RefundOut:
    """Issue a refund against the order's most recent successful payment.

    Also cancels the order if it isn't already cancelled.
    """
    order = await order_service.get_by_uuid(order_uuid)
    refund = await payment_service.refund_order(
        order=order,
        amount=payload.amount,
        reason=payload.reason,
    )
    if order.status.value not in ("cancelled", "delivered"):
        await order_service.cancel(order=order, by_admin=True)
    if refund is None:
        raise NotFoundError("No successful payment to refund for this order")
    return RefundOut.model_validate(refund)
