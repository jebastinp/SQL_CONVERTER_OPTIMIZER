"""HandyPay payment gateway adapter.

NOTE ON ENDPOINTS
─────────────────
HandyPay's developer portal is at https://www.handypayhaiti.com/developer
but it blocks automated crawlers, so the exact endpoint paths below
are based on the universal payment-gateway pattern (hosted checkout +
HMAC-signed webhook + refund API).

When you have access to the HandyPay docs, update the lines marked
``# TODO[handypay]`` with the real paths. The signature scheme and
field names below are also marked — they may differ by a word or two,
but the surrounding code structure won't need to change.

What stays constant regardless of the exact endpoints:
  - Hosted checkout: we POST order details, gateway returns a URL
  - Webhook: gateway POSTs an event to us, signed with HMAC-SHA256
  - Refund: we POST the payment id + amount, gateway responds with status
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from typing import Any

import httpx

from app.core.config import Settings
from app.core.exceptions import (
    ServiceUnavailableError,
    UnauthorizedError,
)
from app.modules.payments.gateway import (
    CheckoutSession,
    PaymentGateway,
    RefundResult,
    WebhookVerification,
)

_logger = logging.getLogger("tarel.payments.handypay")


# TODO[handypay]: replace once HandyPay docs are available.
HANDYPAY_BASE_URL = "https://api.handypayhaiti.com/v1"
HANDYPAY_CHECKOUT_PATH = "/checkouts"           # POST creates checkout
HANDYPAY_REFUND_PATH = "/refunds"               # POST creates refund
HANDYPAY_SIGNATURE_HEADER = "X-HandyPay-Signature"

# Event-type strings we expect HandyPay to send. These are placeholders —
# real names will be in the HandyPay docs.
HANDYPAY_EVENT_PAYMENT_SUCCEEDED = "payment.succeeded"
HANDYPAY_EVENT_PAYMENT_FAILED = "payment.failed"
HANDYPAY_EVENT_PAYMENT_CANCELLED = "payment.cancelled"
HANDYPAY_EVENT_REFUND_SUCCEEDED = "refund.succeeded"
HANDYPAY_EVENT_REFUND_FAILED = "refund.failed"


class HandyPayGateway(PaymentGateway):
    """HandyPay implementation of :class:`PaymentGateway`."""

    provider_name = "handypay"

    def __init__(self, settings: Settings) -> None:
        if not (settings.HANDYPAY_API_KEY and settings.HANDYPAY_SECRET):
            raise ServiceUnavailableError("HandyPay is not configured")

        self._api_key = settings.HANDYPAY_API_KEY
        self._secret = settings.HANDYPAY_SECRET
        self._merchant_id = settings.HANDYPAY_MERCHANT_ID
        self._webhook_secret = settings.HANDYPAY_WEBHOOK_SECRET or settings.HANDYPAY_SECRET
        self._base_url = (settings.HANDYPAY_BASE_URL or HANDYPAY_BASE_URL).rstrip("/")
        self._timeout = 30.0

    # ── HTTP helpers ──────────────────────────────────────────────────────────
    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            # TODO[handypay]: some gateways require X-Merchant-Id header
            "X-Merchant-Id": self._merchant_id or "",
        }

    async def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(url, json=body, headers=self._headers())

        if response.status_code >= 400:
            _logger.error(
                "HandyPay error %d: %s",
                response.status_code, response.text[:500],
            )
            raise ServiceUnavailableError(
                f"Payment gateway returned {response.status_code}"
            )
        return response.json()

    # ── PaymentGateway implementation ─────────────────────────────────────────
    async def create_checkout(
        self,
        *,
        order_uuid: str,
        amount: float,
        currency: str,
        customer_email: str,
        customer_name: str,
        success_url: str,
        cancel_url: str,
        webhook_url: str,
    ) -> CheckoutSession:
        # TODO[handypay]: the exact field names below are the universal
        # pattern. Real HandyPay docs may use slightly different keys
        # (e.g. "redirectUrl" vs "successUrl"). Update once known.
        payload = {
            "merchant_id": self._merchant_id,
            "order_reference": order_uuid,
            "amount": amount,
            "currency": currency,
            "customer": {
                "email": customer_email,
                "name": customer_name,
            },
            "success_url": success_url,
            "cancel_url": cancel_url,
            "webhook_url": webhook_url,
        }
        _logger.info("Creating HandyPay checkout for order %s, amount=%.2f %s",
                     order_uuid, amount, currency)
        data = await self._post(HANDYPAY_CHECKOUT_PATH, payload)

        # TODO[handypay]: real keys may be "id"/"url" or "checkoutId"/"checkoutUrl"
        provider_payment_id = (
            data.get("id")
            or data.get("checkout_id")
            or data.get("payment_id")
            or ""
        )
        checkout_url = (
            data.get("checkout_url")
            or data.get("url")
            or data.get("payment_url")
            or ""
        )
        if not checkout_url:
            raise ServiceUnavailableError("HandyPay did not return a checkout URL")
        return CheckoutSession(
            provider_payment_id=str(provider_payment_id),
            checkout_url=str(checkout_url),
            raw_response=data,
        )

    async def refund(
        self,
        *,
        provider_payment_id: str,
        amount: float,
        reason: str | None = None,
    ) -> RefundResult:
        # TODO[handypay]: field names may differ.
        payload = {
            "payment_id": provider_payment_id,
            "amount": amount,
        }
        if reason:
            payload["reason"] = reason

        _logger.info("Refunding HandyPay payment %s, amount=%.2f",
                     provider_payment_id, amount)
        data = await self._post(HANDYPAY_REFUND_PATH, payload)

        provider_refund_id = str(data.get("id") or data.get("refund_id") or "")
        status_str = str(data.get("status") or "").lower()
        succeeded = status_str in ("succeeded", "success", "completed", "approved")

        return RefundResult(
            provider_refund_id=provider_refund_id,
            amount=amount,
            succeeded=succeeded,
            raw_response=data,
        )

    # ── Webhook verification ──────────────────────────────────────────────────
    def verify_webhook(
        self,
        *,
        body: bytes,
        signature_header: str | None,
    ) -> WebhookVerification:
        if not signature_header:
            raise UnauthorizedError("Missing webhook signature")

        # Universal HMAC-SHA256 verification. If HandyPay uses a
        # different scheme (e.g. SHA512, or HMAC over a specific
        # canonical string), only the next 4 lines change.
        expected = hmac.new(
            self._webhook_secret.encode("utf-8"),
            body,
            hashlib.sha256,
        ).hexdigest()

        # TODO[handypay]: some gateways prefix signatures with "sha256=".
        received = signature_header.strip()
        if received.startswith("sha256="):
            received = received[len("sha256="):]

        if not hmac.compare_digest(expected, received):
            _logger.warning("HandyPay webhook signature mismatch")
            raise UnauthorizedError("Invalid webhook signature")

        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception as exc:
            raise UnauthorizedError("Webhook payload is not valid JSON") from exc

        raw_event = str(payload.get("event") or payload.get("type") or "")
        event_type = _normalise_event(raw_event)

        # TODO[handypay]: payment id might be nested under "data" or "object"
        data_section = payload.get("data") or payload.get("object") or payload
        provider_payment_id = (
            data_section.get("payment_id")
            or data_section.get("id")
            or payload.get("payment_id")
        )
        provider_refund_id = (
            data_section.get("refund_id")
            or (data_section.get("id") if event_type.startswith("refund.") else None)
        )
        amount_raw = data_section.get("amount") or payload.get("amount")
        amount = float(amount_raw) if amount_raw is not None else None

        return WebhookVerification(
            event_type=event_type,
            provider_payment_id=str(provider_payment_id) if provider_payment_id else None,
            provider_refund_id=str(provider_refund_id) if provider_refund_id else None,
            amount=amount,
            raw_payload=payload,
        )


def _normalise_event(raw: str) -> str:
    raw = raw.lower().strip()
    if raw in (HANDYPAY_EVENT_PAYMENT_SUCCEEDED, "payment_succeeded", "charge.succeeded", "succeeded"):
        return "payment.succeeded"
    if raw in (HANDYPAY_EVENT_PAYMENT_FAILED, "payment_failed", "charge.failed", "failed"):
        return "payment.failed"
    if raw in (HANDYPAY_EVENT_PAYMENT_CANCELLED, "payment_cancelled", "cancelled", "canceled"):
        return "payment.cancelled"
    if raw in (HANDYPAY_EVENT_REFUND_SUCCEEDED, "refund_succeeded", "refunded"):
        return "refund.succeeded"
    if raw in (HANDYPAY_EVENT_REFUND_FAILED, "refund_failed"):
        return "refund.failed"
    return "unknown"
