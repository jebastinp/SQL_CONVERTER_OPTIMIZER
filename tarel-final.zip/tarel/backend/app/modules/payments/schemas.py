"""Payment Pydantic schemas."""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from app.modules.payments.models import PaymentStatusEnum, RefundStatusEnum


class CreatePaymentResponse(BaseModel):
    """Returned to the frontend when checkout starts.

    The frontend redirects the browser to ``checkout_url`` so the
    customer can complete payment on HandyPay's hosted page.
    """
    payment_id: UUID
    checkout_url: str
    amount: float
    currency: str


class RefundOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    amount: float
    reason: Optional[str] = None
    status: RefundStatusEnum
    confirmed_at: Optional[datetime] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class PaymentOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    provider: str
    provider_payment_id: Optional[str] = None
    amount: float
    currency: str
    status: PaymentStatusEnum
    confirmed_at: Optional[datetime] = None
    failure_reason: Optional[str] = None
    refunds: List[RefundOut] = []
    created_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class RefundRequest(BaseModel):
    amount: Optional[float] = None    # default = full refund
    reason: Optional[str] = None


class AdminPaymentRow(BaseModel):
    """Admin payments list row.

    Joins payment ↔ order ↔ user so the admin sees everything in
    one card without needing extra fetches.
    """
    id: UUID = Field(..., validation_alias="uuid")
    code: Optional[str] = None
    order_id: UUID
    order_code: Optional[str] = None
    customer_name: Optional[str] = None
    customer_email: Optional[str] = None
    provider: str
    provider_payment_id: Optional[str] = None
    amount: float
    currency: str
    status: PaymentStatusEnum
    confirmed_at: Optional[datetime] = None
    failure_reason: Optional[str] = None
    created_at: datetime
    total_refunded: float = 0.0

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
