"""Payment DI providers."""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends

from app.core.dependencies import SessionDep, SettingsDep
from app.core.exceptions import ServiceUnavailableError
from app.modules.orders.dependencies import OrderServiceDep
from app.modules.payments.gateway import PaymentGateway
from app.modules.payments.handypay import HandyPayGateway
from app.modules.payments.mock import MockPaymentGateway
from app.modules.payments.repository import (
    PaymentEventRepository,
    PaymentRepository,
    RefundRepository,
)
from app.modules.payments.service import PaymentService


def _payment_repository(session: SessionDep) -> PaymentRepository:
    return PaymentRepository(session)


def _refund_repository(session: SessionDep) -> RefundRepository:
    return RefundRepository(session)


def _event_repository(session: SessionDep) -> PaymentEventRepository:
    return PaymentEventRepository(session)


# ── Gateway selection ────────────────────────────────────────────────────────
# Selected by Settings.PAYMENT_GATEWAY ("mock" or "handypay"). Adding a
# new provider means: implement PaymentGateway and add a branch here.
_GATEWAY_FACTORIES: dict[str, type[PaymentGateway]] = {
    "mock": MockPaymentGateway,
    "handypay": HandyPayGateway,
}


def get_payment_gateway(settings: SettingsDep) -> PaymentGateway:
    """Return the configured gateway."""
    name = (settings.PAYMENT_GATEWAY or "").lower()
    factory = _GATEWAY_FACTORIES.get(name)
    if factory is None:
        raise ServiceUnavailableError(
            f"Unknown PAYMENT_GATEWAY '{settings.PAYMENT_GATEWAY}'. "
            f"Expected one of: {', '.join(_GATEWAY_FACTORIES.keys())}"
        )
    return factory(settings=settings)


PaymentRepoDep = Annotated[PaymentRepository, Depends(_payment_repository)]
RefundRepoDep = Annotated[RefundRepository, Depends(_refund_repository)]
EventRepoDep = Annotated[PaymentEventRepository, Depends(_event_repository)]
GatewayDep = Annotated[PaymentGateway, Depends(get_payment_gateway)]


def get_payment_service(
    payment_repository: PaymentRepoDep,
    refund_repository: RefundRepoDep,
    event_repository: EventRepoDep,
    order_service: OrderServiceDep,
    gateway: GatewayDep,
    settings: SettingsDep,
) -> PaymentService:
    return PaymentService(
        payment_repository=payment_repository,
        refund_repository=refund_repository,
        event_repository=event_repository,
        order_service=order_service,
        gateway=gateway,
        settings=settings,
    )


PaymentServiceDep = Annotated[PaymentService, Depends(get_payment_service)]
