"""Product Pydantic schemas.

Input schemas validate user payloads. Output schemas hide the internal
integer ``id`` and expose the ``uuid`` field renamed to ``id`` (so the
frontend continues to see a single opaque identifier).
"""

from __future__ import annotations

from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Category brief, for nesting under ProductOut ─────────────────────────────
class CategoryBrief(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    name: str
    slug: str
    description: Optional[str] = None
    is_active: bool = True

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


# ── Product I/O ──────────────────────────────────────────────────────────────
class ProductBase(BaseModel):
    name: str
    slug: str
    description: Optional[str] = None
    price_per_kg: float
    half_kg_price: Optional[float] = None
    one_kg_price: Optional[float] = None
    image_url: Optional[str] = None
    stock_kg: float = 0
    is_dry: bool = False
    is_active: bool = True


class ProductCreate(ProductBase):
    category_uuid: UUID


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    price_per_kg: Optional[float] = None
    half_kg_price: Optional[float] = None
    one_kg_price: Optional[float] = None
    image_url: Optional[str] = None
    stock_kg: Optional[float] = None
    is_dry: Optional[bool] = None
    is_active: Optional[bool] = None
    category_uuid: Optional[UUID] = None


class ProductOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    code: Optional[str] = None
    name: str
    slug: str
    description: Optional[str] = None
    price_per_kg: float
    half_kg_price: Optional[float] = None
    one_kg_price: Optional[float] = None
    image_url: Optional[str] = None
    stock_kg: float
    is_dry: bool
    is_active: bool
    category: Optional[CategoryBrief] = None

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


# ── Cut & Clean option ───────────────────────────────────────────────────────
class CutCleanOptionOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    label: str
    is_active: bool
    sort_order: float

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
