"""Dependency wiring for the products module."""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends

from app.core.dependencies import SessionDep
from app.modules.products.repository import (
    CutCleanOptionRepository,
    ProductRepository,
)
from app.modules.products.service import ProductService


def get_product_repository(session: SessionDep) -> ProductRepository:
    return ProductRepository(session)


def get_cut_clean_repository(session: SessionDep) -> CutCleanOptionRepository:
    return CutCleanOptionRepository(session)


ProductRepoDep = Annotated[ProductRepository, Depends(get_product_repository)]
CutCleanRepoDep = Annotated[CutCleanOptionRepository, Depends(get_cut_clean_repository)]


def get_product_service(
    product_repository: ProductRepoDep,
    cut_clean_repository: CutCleanRepoDep,
) -> ProductService:
    return ProductService(
        product_repository=product_repository,
        cut_clean_repository=cut_clean_repository,
    )


ProductServiceDep = Annotated[ProductService, Depends(get_product_service)]
