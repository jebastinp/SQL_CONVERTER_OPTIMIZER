"""Products module — reference implementation for vertical slices."""

from app.modules.products.router import router as products_router

__all__ = ["products_router"]
