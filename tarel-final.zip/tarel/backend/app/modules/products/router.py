"""Product HTTP endpoints.

The router is intentionally thin: it converts HTTP <-> service calls
and nothing else. All business rules live in :class:`ProductService`.
"""

from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, status
from sqlalchemy.ext.asyncio import AsyncSession  # noqa: F401 — kept for type completeness

from app.modules.products.dependencies import ProductServiceDep
from app.modules.products.schemas import (
    CutCleanOptionOut,
    ProductCreate,
    ProductOut,
    ProductUpdate,
)
from app.schemas.common import MessageResponse

router = APIRouter(prefix="/products", tags=["products"])


@router.get("", response_model=List[ProductOut])
async def list_products(service: ProductServiceDep) -> List[ProductOut]:
    products = await service.list_active()
    return [ProductOut.model_validate(p) for p in products]


@router.get("/cut-clean-options", response_model=List[CutCleanOptionOut])
async def list_cut_clean_options(service: ProductServiceDep) -> List[CutCleanOptionOut]:
    options = await service.list_cut_clean_options()
    return [CutCleanOptionOut.model_validate(o) for o in options]


@router.get("/{slug}", response_model=ProductOut)
async def get_product(slug: str, service: ProductServiceDep) -> ProductOut:
    product = await service.get_by_slug(slug)
    return ProductOut.model_validate(product)


@router.post("", response_model=ProductOut, status_code=status.HTTP_201_CREATED)
async def create_product(payload: ProductCreate, service: ProductServiceDep) -> ProductOut:
    product = await service.create(payload)
    return ProductOut.model_validate(product)


@router.patch("/{product_uuid}", response_model=ProductOut)
async def update_product(
    product_uuid: UUID,
    payload: ProductUpdate,
    service: ProductServiceDep,
) -> ProductOut:
    product = await service.update(product_uuid, payload)
    return ProductOut.model_validate(product)


@router.delete("/{product_uuid}", response_model=MessageResponse)
async def delete_product(
    product_uuid: UUID,
    service: ProductServiceDep,
) -> MessageResponse:
    await service.delete(product_uuid)
    return MessageResponse(message="Product deleted")
