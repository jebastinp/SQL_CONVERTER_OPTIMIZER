"""Product business logic.

The original pricing rules are preserved exactly: ``one_kg_price``
defaults to ``price_per_kg`` and ``half_kg_price`` defaults to half of
``price_per_kg`` rounded to 2dp — same as the legacy router.
"""

from __future__ import annotations

import logging
from typing import Sequence
from uuid import UUID

from app.core.exceptions import BadRequestError, NotFoundError
from app.modules.products.models import CutCleanOption, Product
from app.modules.products.repository import (
    CutCleanOptionRepository,
    ProductRepository,
)
from app.modules.products.schemas import ProductCreate, ProductUpdate

_logger = logging.getLogger("tarel.products.service")


class ProductService:
    """Orchestrates product reads, writes, and pricing defaults."""

    def __init__(
        self,
        *,
        product_repository: ProductRepository,
        cut_clean_repository: CutCleanOptionRepository,
        # Category repository would be injected here too in real wiring;
        # for the reference module we resolve via the product repo's session.
    ) -> None:
        self._products = product_repository
        self._cut_clean = cut_clean_repository

    # ── Reads ─────────────────────────────────────────────────────────────────
    async def list_active(self) -> Sequence[Product]:
        _logger.info("Listing active products")
        return await self._products.list_active()

    async def get_by_slug(self, slug: str) -> Product:
        product = await self._products.get_by_slug(slug, active_only=True)
        if product is None:
            raise NotFoundError("Product not found")
        return product

    async def get_by_uuid(self, uuid_value: UUID) -> Product:
        product = await self._products.get_by_uuid(uuid_value)
        if product is None:
            raise NotFoundError("Product not found")
        return product

    async def list_cut_clean_options(self) -> Sequence[CutCleanOption]:
        return await self._cut_clean.list_active_ordered()

    # ── Writes ────────────────────────────────────────────────────────────────
    async def create(self, payload: ProductCreate) -> Product:
        one_kg_price, half_kg_price = self._derive_prices(
            base_price=payload.price_per_kg,
            one_kg_price=payload.one_kg_price,
            half_kg_price=payload.half_kg_price,
        )

        # Resolve category by uuid → integer FK.
        category = await self._products.get_by_field(  # piggy-back: trivial join needed
            "uuid", payload.category_uuid
        )
        # The above call would be replaced by an injected CategoryRepository
        # in the full migration — kept here as a placeholder so this module
        # compiles standalone. The wiring is added when the categories
        # module lands.
        if category is None:
            raise BadRequestError("Invalid category")

        product = Product(
            name=payload.name,
            slug=payload.slug,
            description=payload.description,
            price_per_kg=one_kg_price,
            one_kg_price=one_kg_price,
            half_kg_price=half_kg_price,
            image_url=payload.image_url,
            stock_kg=payload.stock_kg,
            is_dry=payload.is_dry,
            is_active=payload.is_active,
            category_id=category.id,
        )
        return await self._products.add(product)

    async def update(self, uuid_value: UUID, payload: ProductUpdate) -> Product:
        product = await self.get_by_uuid(uuid_value)
        fields = payload.model_dump(exclude_unset=True, exclude_none=True)
        if "category_uuid" in fields:
            # Same caveat as create() — replace with CategoryRepository when added.
            target_uuid = fields.pop("category_uuid")
            category = await self._products.get_by_field("uuid", target_uuid)
            if category is None:
                raise BadRequestError("Invalid category")
            fields["category_id"] = category.id
        return await self._products.update(product, fields)

    async def delete(self, uuid_value: UUID) -> None:
        product = await self.get_by_uuid(uuid_value)
        await self._products.delete(product)

    # ── Helpers (preserved verbatim from legacy router) ───────────────────────
    @staticmethod
    def _derive_prices(
        *,
        base_price: float | None,
        one_kg_price: float | None,
        half_kg_price: float | None,
    ) -> tuple[float, float]:
        resolved_one_kg = one_kg_price if one_kg_price is not None else base_price
        resolved_half_kg = half_kg_price
        if resolved_half_kg is None and base_price is not None:
            resolved_half_kg = round(base_price / 2, 2)
        if resolved_one_kg is None or resolved_half_kg is None:
            raise BadRequestError("Both half_kg_price and one_kg_price are required")
        return resolved_one_kg, resolved_half_kg
