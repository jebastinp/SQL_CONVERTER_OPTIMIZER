"""Product domain models.

Field semantics preserved from the legacy schema; only the identity
columns (``id`` + ``uuid`` + ``code``) and audit timestamps are added by
the :class:`IdentityMixin`.
"""

from __future__ import annotations

from sqlalchemy import Boolean, Column, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db.base import Base, IdentityMixin


class Product(IdentityMixin, Base):
    __tablename__ = "products"

    name = Column(String(160), nullable=False)
    slug = Column(String(180), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)

    # Pricing — legacy fields kept verbatim; business rules unchanged.
    price_per_kg = Column(Float, nullable=False)
    half_kg_price = Column(Float, nullable=True)
    one_kg_price = Column(Float, nullable=True)

    # R2 object key; the public URL is derived in the service layer.
    image_url = Column(String(500), nullable=True)
    image_key = Column(String(500), nullable=True)

    stock_kg = Column(Float, default=0, nullable=False)
    is_dry = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    # Integer FK to categories.id (joins by integer PK).
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)

    category = relationship("Category", back_populates="products", lazy="joined")
    order_items = relationship("OrderItem", back_populates="product")


class CutCleanOption(IdentityMixin, Base):
    __tablename__ = "cut_clean_options"

    label = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    sort_order = Column(Float, default=0, nullable=False)
