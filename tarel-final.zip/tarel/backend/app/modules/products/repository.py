"""Product persistence layer.

Domain-specific queries (by slug, active products, cut/clean options)
live here. Generic CRUD comes from :class:`AsyncRepository`.
"""

from __future__ import annotations

from typing import Sequence

from sqlalchemy import select

from app.modules.products.models import CutCleanOption, Product
from app.repositories.base import AsyncRepository


class ProductRepository(AsyncRepository[Product]):
    model = Product

    async def get_by_slug(self, slug: str, *, active_only: bool = True) -> Product | None:
        stmt = select(Product).where(Product.slug == slug)
        if active_only:
            stmt = stmt.where(Product.is_active.is_(True))
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_active(self) -> Sequence[Product]:
        return await self.list(filters={"is_active": True}, order_by=[Product.name])


class CutCleanOptionRepository(AsyncRepository[CutCleanOption]):
    model = CutCleanOption

    async def list_active_ordered(self) -> Sequence[CutCleanOption]:
        return await self.list(
            filters={"is_active": True},
            order_by=[CutCleanOption.sort_order, CutCleanOption.label],
        )
