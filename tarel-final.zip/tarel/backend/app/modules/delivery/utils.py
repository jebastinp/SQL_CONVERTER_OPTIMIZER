"""Delivery utility helpers.

PRESERVED VERBATIM from ``backend/app/utils/delivery_utils.py`` —
behaviour identical. Only the import paths change.
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal
from typing import Optional, Tuple, Union


DAY_NAMES = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
]


def _sunday_start(target: date) -> date:
    """Sunday of the week containing ``target``. (Preserved.)"""
    offset = (target.weekday() + 1) % 7
    return target - timedelta(days=offset)


def get_delivery_date(order_date: date, delivery_day: int = 2) -> date:
    """Order placed → delivery date in the NEXT week. (Preserved.)"""
    delivery_day = int(delivery_day)
    week_start = _sunday_start(order_date)
    offset = delivery_day + 1
    return week_start + timedelta(days=7 + offset)


def get_week_range(delivery_date: date) -> Tuple[date, date]:
    """Returns (order_week_start, order_week_end). (Preserved.)"""
    delivery_week_start = _sunday_start(delivery_date)
    order_week_start = delivery_week_start - timedelta(days=7)
    order_week_end = order_week_start + timedelta(days=6)
    return order_week_start, order_week_end


def is_cancellation_allowed(
    order_date: date,
    cutoff_day: int = 4,
    delivery_day: int = 2,
    today: Optional[date] = None,
) -> bool:
    """True iff today is at or before the cutoff. (Preserved.)"""
    today = today or date.today()
    delivery_date = get_delivery_date(order_date, delivery_day)
    order_week_start, _ = get_week_range(delivery_date)
    cutoff_date = order_week_start + timedelta(days=cutoff_day + 1)
    return today <= cutoff_date


def calculate_bags(total_kg: Union[Decimal, float, int]) -> Tuple[int, int]:
    """Returns ``(one_kg_count, half_kg_count)`` quantised to 0.5. (Preserved.)"""
    total = Decimal(str(total_kg)).quantize(Decimal("0.5"))
    one_kg = int(total // 1)
    remainder = total - Decimal(one_kg)
    half_kg = 1 if remainder == Decimal("0.5") else 0
    return one_kg, half_kg


def next_delivery_date(today: date, delivery_day: int) -> date:
    """Forward to the next ``delivery_day`` weekday. (Preserved.)"""
    weekday = today.weekday()
    if weekday <= delivery_day:
        return today + timedelta(days=delivery_day - weekday)
    return today + timedelta(days=7 + (delivery_day - weekday))
