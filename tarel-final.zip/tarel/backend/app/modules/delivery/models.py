"""Delivery settings & per-order delivery records.

Field shapes preserved from the legacy ``delivery_models.py``; only
the identity columns are added by ``IdentityMixin``.
"""

from __future__ import annotations

from sqlalchemy import Column, Date, DateTime, Integer, Numeric, String

from app.db.base import Base, IdentityMixin


class DeliverySetting(IdentityMixin, Base):
    __tablename__ = "delivery_settings"

    cutoff_day = Column(Integer, default=4, nullable=False)
    delivery_day = Column(Integer, default=2, nullable=False)


class DeliveryOrder(IdentityMixin, Base):
    __tablename__ = "delivery_orders"

    customer_name = Column(String(120), nullable=False)
    customer_phone = Column(String(30), nullable=False)
    item_type = Column(String(10), nullable=False)
    item_name = Column(String(160), nullable=False)
    quantity_kg = Column(Numeric(6, 2), nullable=False)
    order_date = Column(Date, nullable=False)
    delivery_date = Column(Date, nullable=False)
    status = Column(String(10), default="active", nullable=False)
    cancelled_at = Column(DateTime(timezone=True), nullable=True)
