"""User HTTP routes."""

from __future__ import annotations

from math import ceil
from typing import List

from fastapi import APIRouter, Query

from app.core import constants as C
from app.modules.auth.dependencies import (
    CurrentAdminDep,
    CurrentUserDep,
    UserServiceDep,
)
from app.modules.users.schemas import UserOut, UserSummary, UserUpdate
from app.schemas.common import PagedResponse

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserOut)
async def get_my_profile(user: CurrentUserDep) -> UserOut:
    return UserOut.model_validate(user)


@router.patch("/me", response_model=UserOut)
async def update_my_profile(
    payload: UserUpdate,
    user: CurrentUserDep,
    user_service: UserServiceDep,
) -> UserOut:
    updated = await user_service.update_profile(user=user, payload=payload)
    return UserOut.model_validate(updated)


# ── Admin ────────────────────────────────────────────────────────────────────
admin_router = APIRouter(prefix="/admin/customers", tags=["admin", "customers"])


@admin_router.get("", response_model=PagedResponse[UserSummary])
async def search_customers(
    user_service: UserServiceDep,
    _admin: CurrentAdminDep,
    q: str | None = Query(default=None, description="Search by email, name, phone, postcode, or user code"),
    page: int = Query(default=C.PAGE_NUMBER_DEFAULT, ge=1),
    page_size: int = Query(default=C.PAGE_SIZE_DEFAULT, ge=1, le=C.PAGE_SIZE_MAX),
) -> PagedResponse[UserSummary]:
    rows, total = await user_service.search(query=q, page=page, page_size=page_size)
    items: List[UserSummary] = [UserSummary.model_validate(r) for r in rows]
    return PagedResponse[UserSummary](
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=max(1, ceil(total / page_size)),
    )
