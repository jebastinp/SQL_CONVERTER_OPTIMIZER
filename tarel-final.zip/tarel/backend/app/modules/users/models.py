"""User model.

Linked to Supabase Auth via ``supabase_id`` (Supabase user UUID). All
the legacy profile fields are preserved (phone, address, postcode,
locality, city, user_code) so downstream code keeps working unchanged.
"""

from __future__ import annotations

import enum

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, String, Text
from sqlalchemy.orm import relationship

from app.db.base import Base, IdentityMixin
from app.db.types import GUID


class RoleEnum(str, enum.Enum):
    user = "user"
    admin = "admin"


class SupportStatusEnum(str, enum.Enum):
    open = "open"
    pending = "pending"
    closed = "closed"


class User(IdentityMixin, Base):
    __tablename__ = "users"

    # Supabase Auth user UUID. Unique and indexed because we look up
    # by this on every authenticated request.
    supabase_id = Column(GUID, unique=True, nullable=False, index=True)

    name = Column(String(120), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)

    role = Column(Enum(RoleEnum), default=RoleEnum.user, nullable=False)

    profile_photo = Column(String(500), nullable=True)
    phone = Column(String(30), nullable=True)

    # Address (legacy fields, names preserved)
    address_line1 = Column(String(255), nullable=True)
    locality = Column(String(120), nullable=True)
    city = Column(String(120), nullable=True)
    postcode = Column(String(12), nullable=True)

    # Human-friendly user code, separate from `code` (which comes from
    # IdentityMixin and serves the same purpose). Kept distinct so we
    # don't break legacy data.
    user_code = Column(String(16), unique=True, nullable=True)

    is_active = Column(Boolean, default=True, nullable=False)
    last_sign_in_at = Column(DateTime(timezone=True), nullable=True)

    orders = relationship("Order", back_populates="user")


class SupportMessage(IdentityMixin, Base):
    __tablename__ = "support_messages"

    user_id = Column(ForeignKey("users.id"), nullable=False)
    subject = Column(String(160), nullable=False)
    message = Column(Text, nullable=False)
    response = Column(Text, nullable=True)
    status = Column(
        Enum(SupportStatusEnum),
        default=SupportStatusEnum.open,
        nullable=False,
    )

    user = relationship("User")
