"""User persistence."""

from __future__ import annotations

from typing import Sequence
from uuid import UUID

from sqlalchemy import or_, select

from app.modules.users.models import User
from app.repositories.base import AsyncRepository


class UserRepository(AsyncRepository[User]):
    model = User

    async def get_by_supabase_id(self, supabase_id: UUID) -> User | None:
        stmt = select(User).where(User.supabase_id == supabase_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        stmt = select(User).where(User.email == email.lower())
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def search(
        self,
        *,
        query: str | None,
        limit: int,
        offset: int,
    ) -> tuple[Sequence[User], int]:
        """Search by email / name / phone / postcode / code.

        Returns (rows, total) so admin lists can paginate.
        """
        base = select(User)
        if query:
            like = f"%{query.lower().strip()}%"
            base = base.where(
                or_(
                    User.email.ilike(like),
                    User.name.ilike(like),
                    User.phone.ilike(like),
                    User.postcode.ilike(like),
                    User.user_code.ilike(like),
                )
            )

        total_stmt = select(User).with_only_columns(User.id)
        if query:
            like = f"%{query.lower().strip()}%"
            total_stmt = total_stmt.where(
                or_(
                    User.email.ilike(like),
                    User.name.ilike(like),
                    User.phone.ilike(like),
                    User.postcode.ilike(like),
                    User.user_code.ilike(like),
                )
            )
        total_result = await self._session.execute(total_stmt)
        total = len(total_result.scalars().all())

        rows = await self._session.execute(
            base.order_by(User.created_at.desc()).offset(offset).limit(limit)
        )
        return rows.scalars().all(), total
