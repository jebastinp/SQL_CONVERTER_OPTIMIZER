"""User Pydantic schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.modules.users.models import RoleEnum


class UserRegister(BaseModel):
    """Payload sent by the frontend after Supabase sign-up succeeds.

    The frontend creates the account in Supabase, then POSTs here with
    the access token *plus* the profile fields so we create the local
    user row.
    """

    name: str
    phone: str
    address_line1: str
    locality: Optional[str] = None
    city: str
    postcode: str


class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    address_line1: Optional[str] = None
    locality: Optional[str] = None
    city: Optional[str] = None
    postcode: Optional[str] = None
    profile_photo: Optional[str] = None


class UserOut(BaseModel):
    id: UUID = Field(..., validation_alias="uuid")
    code: Optional[str] = None
    user_code: Optional[str] = None
    name: str
    email: EmailStr
    role: RoleEnum
    profile_photo: Optional[str] = None
    phone: Optional[str] = None
    address_line1: Optional[str] = None
    locality: Optional[str] = None
    city: Optional[str] = None
    postcode: Optional[str] = None
    is_active: bool = True
    created_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class UserSummary(BaseModel):
    """Compact projection for admin lists."""

    id: UUID = Field(..., validation_alias="uuid")
    user_code: Optional[str] = None
    name: str
    email: EmailStr
    phone: Optional[str] = None
    postcode: Optional[str] = None
    role: RoleEnum
    created_at: datetime
    last_sign_in_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
