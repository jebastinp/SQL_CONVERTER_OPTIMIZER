"""User service.

Handles the lazy-create on first authenticated request, profile
updates, and admin user-code generation.
"""

from __future__ import annotations

import logging
from typing import Sequence
from uuid import UUID

from app.core import constants as C
from app.core.exceptions import ConflictError, NotFoundError
from app.modules.users.models import RoleEnum, User
from app.modules.users.repository import UserRepository
from app.modules.users.schemas import UserRegister, UserUpdate

_logger = logging.getLogger("tarel.users.service")


def _generate_user_code(internal_id: int) -> str:
    return f"{C.USER_CODE_PREFIX}-{internal_id:0{C.CODE_PAD_WIDTH}d}"


class UserService:
    def __init__(self, *, repository: UserRepository) -> None:
        self._repo = repository

    async def get_or_create_from_supabase(
        self,
        *,
        supabase_id: UUID,
        email: str,
        default_name: str = "",
    ) -> User:
        """Find the local user for a Supabase auth subject; create a
        minimal stub if it's their first sign-in.

        Frontend should follow up with /users/me to fill in profile
        fields, but the stub means the user is usable right away.
        """
        existing = await self._repo.get_by_supabase_id(supabase_id)
        if existing:
            return existing

        # Email might collide if the user was created in Supabase but
        # their local profile was deleted; treat that as a re-link.
        existing_by_email = await self._repo.get_by_email(email)
        if existing_by_email:
            existing_by_email.supabase_id = supabase_id
            await self._repo.update(existing_by_email, {"supabase_id": supabase_id})
            return existing_by_email

        _logger.info("Lazy-creating local user for supabase_id=%s email=%s", supabase_id, email)
        user = User(
            supabase_id=supabase_id,
            email=email.lower(),
            name=default_name or email.split("@")[0],
            role=RoleEnum.user,
        )
        user = await self._repo.add(user)
        # Generate user_code from the now-known integer PK.
        user.user_code = _generate_user_code(user.id)
        await self._repo.update(user, {"user_code": user.user_code})
        return user

    async def complete_registration(
        self,
        *,
        user: User,
        payload: UserRegister,
    ) -> User:
        """Fill in profile fields after sign-up."""
        fields = payload.model_dump(exclude_none=True)
        # Normalise postcode to uppercase, matching the legacy validator.
        if "postcode" in fields and fields["postcode"]:
            fields["postcode"] = fields["postcode"].strip().upper()
        return await self._repo.update(user, fields)

    async def update_profile(self, *, user: User, payload: UserUpdate) -> User:
        fields = payload.model_dump(exclude_unset=True, exclude_none=True)
        if "postcode" in fields and fields["postcode"]:
            fields["postcode"] = fields["postcode"].strip().upper()
        return await self._repo.update(user, fields)

    async def get_by_uuid(self, uuid_value: UUID) -> User:
        user = await self._repo.get_by_uuid(uuid_value)
        if user is None:
            raise NotFoundError("User not found")
        return user

    async def search(
        self,
        *,
        query: str | None,
        page: int,
        page_size: int,
    ) -> tuple[Sequence[User], int]:
        offset = max(0, (page - 1) * page_size)
        return await self._repo.search(query=query, limit=page_size, offset=offset)
