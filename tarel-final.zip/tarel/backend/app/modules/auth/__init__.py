"""Authentication module — Supabase Auth integration.

Supabase issues JWTs to clients; this module verifies those tokens
against Supabase's JWKS endpoint, looks up (or upserts) the matching
local user, and exposes the result as a FastAPI dependency
(`CurrentUserDep`) so any router can require authentication.
"""

from app.modules.auth.router import router as auth_router
from app.modules.auth.dependencies import (
    CurrentUserDep,
    CurrentAdminDep,
    get_current_user,
    get_current_admin,
)

__all__ = [
    "auth_router",
    "CurrentUserDep",
    "CurrentAdminDep",
    "get_current_user",
    "get_current_admin",
]
