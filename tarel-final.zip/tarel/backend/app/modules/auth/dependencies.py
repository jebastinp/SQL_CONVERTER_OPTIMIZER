"""Authentication dependencies.

These are the seam between an HTTP request carrying a Supabase JWT
and the local ``User`` row the application cares about. Every
protected route should depend on ``CurrentUserDep``; admin-only routes
use ``CurrentAdminDep``.
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.config import Settings
from app.core.dependencies import SessionDep, SettingsDep
from app.core.exceptions import ForbiddenError, UnauthorizedError
from app.modules.auth.supabase import SupabaseTokenVerifier
from app.modules.users.models import RoleEnum, User
from app.modules.users.repository import UserRepository
from app.modules.users.service import UserService

_bearer = HTTPBearer(auto_error=False)
BearerDep = Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)]


def _user_repository(session: SessionDep) -> UserRepository:
    return UserRepository(session)


UserRepoDep = Annotated[UserRepository, Depends(_user_repository)]


def _user_service(repo: UserRepoDep) -> UserService:
    return UserService(repository=repo)


UserServiceDep = Annotated[UserService, Depends(_user_service)]


def _token_verifier(settings: SettingsDep) -> SupabaseTokenVerifier:
    return SupabaseTokenVerifier(settings)


TokenVerifierDep = Annotated[SupabaseTokenVerifier, Depends(_token_verifier)]


async def get_current_user(
    credentials: BearerDep,
    verifier: TokenVerifierDep,
    user_service: UserServiceDep,
) -> User:
    if credentials is None or not credentials.credentials:
        raise UnauthorizedError()

    payload = verifier.verify(credentials.credentials)
    supabase_id = UUID(payload["sub"])
    email = payload.get("email") or ""

    # Lazy-create: a Supabase user might exist before our DB row does.
    return await user_service.get_or_create_from_supabase(
        supabase_id=supabase_id,
        email=email,
    )


async def get_current_admin(
    user: Annotated[User, Depends(get_current_user)],
) -> User:
    if user.role != RoleEnum.admin:
        raise ForbiddenError("Admin access required")
    return user


CurrentUserDep = Annotated[User, Depends(get_current_user)]
CurrentAdminDep = Annotated[User, Depends(get_current_admin)]
