"""Supabase JWT verifier.

Supabase signs access tokens with HS256 using the project's JWT secret
(``SUPABASE_JWT_SECRET``). We verify them locally — no network call per
request — for low latency.

Token claims of interest:
  - ``sub``      → Supabase user UUID (matches ``users.supabase_id``)
  - ``email``    → email address
  - ``role``     → ``authenticated`` (Supabase's role, not our app role)
  - ``aud``      → expected ``authenticated``
  - ``app_metadata.role`` → optional, where we put ``user`` / ``admin``
  - ``exp``      → expiry
"""

from __future__ import annotations

from typing import Any

from jose import JWTError, jwt

from app.core.config import Settings
from app.core.exceptions import UnauthorizedError


SUPABASE_AUDIENCE = "authenticated"
SUPABASE_ALGORITHM = "HS256"


class SupabaseTokenVerifier:
    """Verifies Supabase-issued JWTs using the shared project secret."""

    def __init__(self, settings: Settings) -> None:
        if not settings.SUPABASE_JWT_SECRET:
            raise RuntimeError("SUPABASE_JWT_SECRET is not configured")
        self._secret = settings.SUPABASE_JWT_SECRET

    def verify(self, token: str) -> dict[str, Any]:
        try:
            payload = jwt.decode(
                token,
                self._secret,
                algorithms=[SUPABASE_ALGORITHM],
                audience=SUPABASE_AUDIENCE,
            )
        except JWTError as exc:
            raise UnauthorizedError("Invalid or expired Supabase token") from exc

        if not payload.get("sub"):
            raise UnauthorizedError("Token missing subject")
        return payload
