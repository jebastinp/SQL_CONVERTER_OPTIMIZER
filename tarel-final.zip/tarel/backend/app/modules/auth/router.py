"""Authentication HTTP routes.

Supabase issues access tokens directly to the browser; we only need
endpoints that:

  1. Tell the frontend who the current user is (``GET /auth/me``)
  2. Complete sign-up by attaching profile data to the freshly-created
     Supabase user (``POST /auth/register``).
"""

from __future__ import annotations

from fastapi import APIRouter

from app.modules.auth.dependencies import CurrentUserDep, UserServiceDep
from app.modules.users.schemas import UserOut, UserRegister

router = APIRouter(prefix="/auth", tags=["auth"])


@router.get("/me", response_model=UserOut)
async def get_me(user: CurrentUserDep) -> UserOut:
    """Return the authenticated user's full profile."""
    return UserOut.model_validate(user)


@router.post("/register", response_model=UserOut)
async def complete_registration(
    payload: UserRegister,
    user: CurrentUserDep,
    user_service: UserServiceDep,
) -> UserOut:
    """Complete sign-up by attaching profile fields.

    The frontend creates the Supabase account first (which returns a
    token), then calls this endpoint with the access token + the
    profile payload. The local user row is upserted with the postcode,
    address, phone, name, etc.
    """
    updated = await user_service.complete_registration(user=user, payload=payload)
    return UserOut.model_validate(updated)
