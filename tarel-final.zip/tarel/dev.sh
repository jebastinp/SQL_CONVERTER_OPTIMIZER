#!/usr/bin/env bash
# =============================================================================
# Tarel — single-command development script
# =============================================================================
# Starts the FastAPI backend on :8000 and the Next.js web app on :3000,
# both bound to 0.0.0.0 so other devices on the same Wi-Fi (phones,
# tablets) can connect.
#
# Usage:
#   ./dev.sh
#
# Stop everything with Ctrl-C — both processes will exit.
# =============================================================================

set -euo pipefail

# Resolve the LAN IP so we can print URLs that work from a phone.
detect_lan_ip() {
  # Try the modern way first, fall back through other tools.
  if command -v ipconfig >/dev/null 2>&1; then
    # macOS / Windows-Git-Bash
    ipconfig getifaddr en0 2>/dev/null || \
    ipconfig getifaddr en1 2>/dev/null || \
    echo "localhost"
  elif command -v hostname >/dev/null 2>&1; then
    # Linux
    hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost"
  else
    echo "localhost"
  fi
}

LAN_IP="$(detect_lan_ip)"
[ -z "$LAN_IP" ] && LAN_IP="localhost"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
WEB_DIR="$ROOT_DIR/web"

# Colour helpers (no-op if terminal doesn't support it).
green()  { printf "\033[32m%s\033[0m" "$*"; }
yellow() { printf "\033[33m%s\033[0m" "$*"; }
bold()   { printf "\033[1m%s\033[0m"  "$*"; }

# ── Sanity checks ─────────────────────────────────────────────────────────────
if [ ! -d "$BACKEND_DIR" ] || [ ! -d "$WEB_DIR" ]; then
  echo "Expected 'backend/' and 'web/' folders next to this script." >&2
  exit 1
fi

if [ ! -f "$BACKEND_DIR/.env" ]; then
  echo "Missing $BACKEND_DIR/.env — copy backend/.env.example and fill it in." >&2
  exit 1
fi

if [ ! -f "$WEB_DIR/.env.local" ]; then
  echo "Missing $WEB_DIR/.env.local — copy web/.env.local.example and fill it in." >&2
  exit 1
fi

# ── Print URLs so you know what to open ──────────────────────────────────────
cat <<EOF

$(bold "Tarel — development")
────────────────────────────────────────────────────────
$(bold Backend)
  Local           $(green http://localhost:8000)
  LAN (phone)     $(green http://$LAN_IP:8000)
  Docs            $(green http://localhost:8000/docs)
  Health          $(green http://localhost:8000/health)

$(bold Web app)
  Local           $(green http://localhost:3000)
  LAN (phone)     $(green http://$LAN_IP:3000)
  Admin           $(yellow http://localhost:3000/tarel-control)
  Admin (LAN)     $(yellow http://$LAN_IP:3000/tarel-control)

$(bold "Per-request logs")
  backend/logs/requests/<request-id>.log

$(bold "Stop everything")  Ctrl-C
────────────────────────────────────────────────────────

EOF

# ── Start backend ────────────────────────────────────────────────────────────
start_backend() {
  echo "$(yellow "→ starting backend on 0.0.0.0:8000")"
  cd "$BACKEND_DIR"
  # Activate venv if it exists
  if [ -d ".venv" ]; then
    # shellcheck disable=SC1091
    source .venv/bin/activate
  fi
  exec uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
}

# ── Start frontend ───────────────────────────────────────────────────────────
start_web() {
  echo "$(yellow "→ starting web on 0.0.0.0:3000")"
  cd "$WEB_DIR"
  exec npm run dev -- --hostname 0.0.0.0 --port 3000
}

# ── Run both in parallel, propagate Ctrl-C to both ───────────────────────────
pids=()

cleanup() {
  echo ""
  echo "$(yellow "Shutting down…")"
  for pid in "${pids[@]:-}"; do
    kill "$pid" 2>/dev/null || true
  done
  wait 2>/dev/null || true
  exit 0
}
trap cleanup INT TERM

(start_backend) &
pids+=($!)

(start_web) &
pids+=($!)

# Wait for either to exit (and then cleanup).
wait -n
cleanup
