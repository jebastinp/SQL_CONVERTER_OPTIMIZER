"""
Supabase admin client + JWT verification.
Uses service role key — keep on backend ONLY, never expose to frontend.
"""
import os
import jwt
from typing import Optional

try:
    from supabase import create_client, Client
    HAS_SUPABASE = True
except ImportError:
    HAS_SUPABASE = False

SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")
SUPABASE_JWT_SECRET = os.getenv("SUPABASE_JWT_SECRET", "")

_client: Optional["Client"] = None


def get_supabase() -> Optional["Client"]:
    global _client
    if _client is not None:
        return _client
    if not HAS_SUPABASE:
        print("⚠️  supabase-py not installed")
        return None
    if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
        print("⚠️  SUPABASE_URL or SUPABASE_SERVICE_KEY not set")
        return None
    _client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)
    return _client


def verify_user_jwt(token: str) -> Optional[dict]:
    """
    Verify a Supabase user JWT.
    Returns {id, email} or None if invalid.
    """
    if not SUPABASE_JWT_SECRET:
        # Fallback: decode without verifying (DEV ONLY).
        # In production you MUST set SUPABASE_JWT_SECRET.
        try:
            payload = jwt.decode(token, options={"verify_signature": False})
            return {"id": payload.get("sub"), "email": payload.get("email")}
        except Exception:
            return None
    try:
        payload = jwt.decode(
            token,
            SUPABASE_JWT_SECRET,
            algorithms=["HS256"],
            audience="authenticated",
        )
        return {"id": payload.get("sub"), "email": payload.get("email")}
    except jwt.InvalidTokenError as e:
        print(f"⚠️  JWT verification failed: {e}")
        return None
