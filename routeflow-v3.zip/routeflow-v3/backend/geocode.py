"""
UK geocoding via OpenRouteService with Supabase-backed cache.

Get a free API key: https://openrouteservice.org/dev/#/signup
Free tier: 2,000 requests/day.
"""
import os
import httpx
from typing import Optional
from pydantic import BaseModel
from db import get_supabase

ORS_API_KEY = os.getenv("ORS_API_KEY", "")
ORS_BASE = "https://api.openrouteservice.org/geocode/search"


class GeocodeResult(BaseModel):
    lat: float
    lng: float
    confidence: float
    formatted: str
    source: str = "openrouteservice"
    cached: bool = False


def _norm(s: str) -> str:
    return " ".join(s.lower().strip().split())


async def geocode_address(address: str, postcode: Optional[str] = None, country: str = "GB") -> Optional[GeocodeResult]:
    query = address.strip()
    if postcode:
        query = f"{query}, {postcode.strip().upper()}"
    key = _norm(query)

    # 1. Cache check
    sb = get_supabase()
    if sb:
        try:
            res = sb.table("geocode_cache").select("*").eq("query", key).limit(1).execute()
            if res.data:
                row = res.data[0]
                return GeocodeResult(
                    lat=float(row["lat"]),
                    lng=float(row["lng"]),
                    confidence=float(row.get("confidence") or 0.9),
                    formatted=query,
                    source=row.get("source", "cache"),
                    cached=True,
                )
        except Exception as e:
            print(f"⚠️  geocode cache lookup failed: {e}")

    # 2. ORS API call
    if not ORS_API_KEY:
        print("⚠️  ORS_API_KEY not set — cannot geocode")
        return None

    params = {
        "api_key": ORS_API_KEY,
        "text": query,
        "boundary.country": country,
        "size": 1,
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(ORS_BASE, params=params)
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        print(f"❌ ORS geocoding failed for '{query}': {e}")
        return None

    if not data.get("features"):
        return None

    feat = data["features"][0]
    coords = feat.get("geometry", {}).get("coordinates", [])
    if len(coords) < 2:
        return None

    lng, lat = coords[0], coords[1]
    props = feat.get("properties", {})
    confidence = props.get("confidence", 0.7)
    formatted = props.get("label", query)

    result = GeocodeResult(
        lat=lat,
        lng=lng,
        confidence=confidence,
        formatted=formatted,
        source="openrouteservice",
        cached=False,
    )

    # 3. Cache write
    if sb:
        try:
            sb.table("geocode_cache").insert({
                "query": key,
                "lat": lat,
                "lng": lng,
                "confidence": confidence,
                "source": "openrouteservice",
            }).execute()
        except Exception as e:
            print(f"⚠️  geocode cache write failed: {e}")

    return result
