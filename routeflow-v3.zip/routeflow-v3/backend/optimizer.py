"""
Route optimizer using k-means clustering + OR-Tools TSP per cluster.
"""
from typing import List, Optional
from math import radians, cos, sin, asin, sqrt
from pydantic import BaseModel, Field

try:
    from ortools.constraint_solver import routing_enums_pb2, pywrapcp
    HAS_ORTOOLS = True
except ImportError:
    HAS_ORTOOLS = False
    print("⚠️  ortools not installed — falling back to nearest-neighbor heuristic")


# ============================================================
# SCHEMAS
# ============================================================

class Location(BaseModel):
    lat: float
    lng: float


class OrderIn(BaseModel):
    id: Optional[str] = None
    customer_name: str
    address: str
    postcode: str
    lat: float
    lng: float
    delivery_window: Optional[str] = "Anytime"
    priority: Optional[str] = "Med"
    service_minutes: int = 4


class DriverIn(BaseModel):
    id: str
    name: str
    vehicle: Optional[str] = ""
    capacity: int = 30
    shift_start: str = "08:00"
    color: Optional[str] = "#5b8cff"


class OptimizeRequest(BaseModel):
    depot: Location
    orders: List[OrderIn]
    drivers: List[DriverIn]
    avg_speed_kmh: float = Field(22.0)
    fuel_price_gbp: float = Field(1.48)
    vehicle_kml: float = Field(9.0)
    time_limit_sec: int = Field(5)


class StopOut(BaseModel):
    order_id: Optional[str]
    customer_name: str
    address: str
    postcode: str
    lat: float
    lng: float
    sequence: int
    eta_minutes: float
    eta_clock: str


class RouteOut(BaseModel):
    driver_id: str
    driver_name: str
    driver_color: str
    stops: List[StopOut]
    distance_km: float
    duration_minutes: float


class OptimizeResponse(BaseModel):
    routes: List[RouteOut]
    total_distance_km: float
    baseline_distance_km: float
    distance_saved_km: float
    fuel_saved_litres: float
    fuel_saved_gbp: float
    optimization_time_ms: float = 0.0
    algorithm: str = "or-tools-gls" if HAS_ORTOOLS else "nearest-neighbor"


# ============================================================
# MATH
# ============================================================

def haversine_km(a: Location, b: Location) -> float:
    R = 6371.0
    lat1, lat2 = radians(a.lat), radians(b.lat)
    dlat = lat2 - lat1
    dlng = radians(b.lng - a.lng)
    h = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlng / 2) ** 2
    return 2 * R * asin(sqrt(h))


def build_matrix(depot: Location, stops: List[OrderIn]) -> List[List[int]]:
    nodes = [depot] + [Location(lat=s.lat, lng=s.lng) for s in stops]
    n = len(nodes)
    m = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i != j:
                m[i][j] = int(haversine_km(nodes[i], nodes[j]) * 1000)
    return m


# ============================================================
# CLUSTERING (assign orders to drivers by geography)
# ============================================================

def kmeans_cluster(orders: List[OrderIn], k: int, iters: int = 50):
    if k <= 1 or len(orders) <= k:
        return {i: [i] if i < len(orders) else [] for i in range(k)}

    # k-means++ init: pick centroids spread out from each other
    centroids = [(orders[0].lat, orders[0].lng)]
    for _ in range(1, k):
        best, best_d = None, -1.0
        for o in orders:
            d_min = min(((o.lat - c[0]) ** 2 + (o.lng - c[1]) ** 2) for c in centroids)
            if d_min > best_d:
                best_d, best = d_min, (o.lat, o.lng)
        centroids.append(best)

    assigned = [0] * len(orders)
    for _ in range(iters):
        changed = False
        for i, o in enumerate(orders):
            best_k, best_d = 0, float("inf")
            for j, c in enumerate(centroids):
                d = (o.lat - c[0]) ** 2 + (o.lng - c[1]) ** 2
                if d < best_d:
                    best_d, best_k = d, j
            if assigned[i] != best_k:
                assigned[i] = best_k
                changed = True
        if not changed:
            break
        for j in range(k):
            members = [o for i, o in enumerate(orders) if assigned[i] == j]
            if members:
                centroids[j] = (
                    sum(m.lat for m in members) / len(members),
                    sum(m.lng for m in members) / len(members),
                )
    return {j: [i for i, a in enumerate(assigned) if a == j] for j in range(k)}


# ============================================================
# TSP
# ============================================================

def solve_tsp_ortools(matrix: List[List[int]], time_limit_sec: int = 5) -> List[int]:
    n = len(matrix)
    if n <= 2:
        return list(range(n))

    manager = pywrapcp.RoutingIndexManager(n, 1, 0)
    routing = pywrapcp.RoutingModel(manager)

    def distance_callback(from_idx, to_idx):
        return matrix[manager.IndexToNode(from_idx)][manager.IndexToNode(to_idx)]

    transit = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit)

    params = pywrapcp.DefaultRoutingSearchParameters()
    params.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    params.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    params.time_limit.seconds = time_limit_sec

    solution = routing.SolveWithParameters(params)
    if not solution:
        return list(range(n))

    idx = routing.Start(0)
    route = []
    while not routing.IsEnd(idx):
        route.append(manager.IndexToNode(idx))
        idx = solution.Value(routing.NextVar(idx))
    return route


def nearest_neighbor(depot: Location, stops: List[OrderIn]) -> List[int]:
    remaining = list(range(len(stops)))
    current = depot
    order = []
    while remaining:
        best_i, best_d = remaining[0], float("inf")
        for i in remaining:
            d = haversine_km(current, Location(lat=stops[i].lat, lng=stops[i].lng))
            if d < best_d:
                best_d, best_i = d, i
        order.append(best_i)
        current = Location(lat=stops[best_i].lat, lng=stops[best_i].lng)
        remaining.remove(best_i)
    return order


# ============================================================
# MAIN ENTRY
# ============================================================

def optimize_routes(req: OptimizeRequest) -> OptimizeResponse:
    k = min(len(req.drivers), max(1, (len(req.orders) + 7) // 8))
    clusters = kmeans_cluster(req.orders, k)

    routes_out: List[RouteOut] = []
    total_dist = 0.0

    for ci in range(k):
        member_idxs = clusters.get(ci, [])
        if not member_idxs:
            continue
        driver = req.drivers[ci]
        driver_orders = [req.orders[i] for i in member_idxs]

        if HAS_ORTOOLS:
            matrix = build_matrix(req.depot, driver_orders)
            tsp = solve_tsp_ortools(matrix, req.time_limit_sec)
            sequence = [i - 1 for i in tsp[1:] if i > 0]
        else:
            sequence = nearest_neighbor(req.depot, driver_orders)

        stops_out: List[StopOut] = []
        cum_km = 0.0
        prev = req.depot
        start_h, start_m = map(int, driver.shift_start.split(":"))
        start_min = start_h * 60 + start_m

        for seq_i, order_i in enumerate(sequence):
            order = driver_orders[order_i]
            cum_km += haversine_km(prev, Location(lat=order.lat, lng=order.lng))
            drive_min = cum_km / req.avg_speed_kmh * 60
            dwell_min = (seq_i + 1) * order.service_minutes
            eta_min = drive_min + dwell_min
            clock_min = start_min + int(eta_min)
            h, m = clock_min // 60, clock_min % 60
            stops_out.append(StopOut(
                order_id=order.id,
                customer_name=order.customer_name,
                address=order.address,
                postcode=order.postcode,
                lat=order.lat,
                lng=order.lng,
                sequence=seq_i + 1,
                eta_minutes=round(eta_min, 1),
                eta_clock=f"{h % 24:02d}:{m:02d}",
            ))
            prev = Location(lat=order.lat, lng=order.lng)

        cum_km += haversine_km(prev, req.depot)
        duration = cum_km / req.avg_speed_kmh * 60 + len(stops_out) * 4
        total_dist += cum_km

        routes_out.append(RouteOut(
            driver_id=driver.id,
            driver_name=driver.name,
            driver_color=driver.color or "#5b8cff",
            stops=stops_out,
            distance_km=round(cum_km, 2),
            duration_minutes=round(duration, 1),
        ))

    # baseline = depot → orders in input sequence → depot
    baseline = 0.0
    prev = req.depot
    for o in req.orders:
        baseline += haversine_km(prev, Location(lat=o.lat, lng=o.lng))
        prev = Location(lat=o.lat, lng=o.lng)
    baseline += haversine_km(prev, req.depot)

    saved_km = max(0.0, baseline - total_dist)
    fuel_l = saved_km / req.vehicle_kml
    fuel_gbp = fuel_l * req.fuel_price_gbp

    return OptimizeResponse(
        routes=routes_out,
        total_distance_km=round(total_dist, 2),
        baseline_distance_km=round(baseline, 2),
        distance_saved_km=round(saved_km, 2),
        fuel_saved_litres=round(fuel_l, 2),
        fuel_saved_gbp=round(fuel_gbp, 2),
    )
