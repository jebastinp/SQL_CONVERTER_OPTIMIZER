# RouteFlow AI — v3

A multi-tenant route optimization SaaS for UK delivery operations.
**Next.js (Pages Router) + FastAPI + Supabase + OR-Tools + OpenRouteService.**

## ⚡ Quick start

```bash
# 1. Set up Supabase project & paste schema (see docs/SETUP.md)
# 2. Get your OpenRouteService API key (free)
# 3. Edit backend/.env and frontend/.env.local with your keys
# 4. Run setup script:

bash setup.sh              # Mac/Linux
# OR
setup.bat                  # Windows
```

Then start both servers:

```bash
# Terminal 1 — backend
cd backend
source venv/bin/activate   # Windows: venv\Scripts\activate
uvicorn main:app --reload --port 8000

# Terminal 2 — frontend
cd frontend
npm run dev
```

Open **http://localhost:3000** → **/diagnostic** to verify setup → **/signup** to create your first account.

## What's new in v3

- **Pages Router** (simpler than App Router — far fewer compile errors)
- **Built-in diagnostic page** at `/diagnostic` — instantly shows what's broken
- **Setup scripts** that clear cache and reinstall in one command
- **Fixed Supabase trigger** that caused "Database error saving new user" in v2
- **Permissive RLS** so the driver app works without auth (via tokens)
- **Slimmer dependencies** (no @supabase/ssr, no react-leaflet, no chart.js)

## 📁 Project structure

```
routeflow-v2/
├── frontend/                 Next.js 14 (Pages Router)
│   ├── pages/                One file per route
│   ├── components/           Sidebar, RouteMap, AppShell, etc.
│   ├── lib/                  Supabase client, API client, types
│   ├── styles/               globals.css
│   └── public/               Static files
├── backend/                  FastAPI + OR-Tools
├── supabase/
│   └── schema.sql            Run this in SQL Editor
├── docs/
│   ├── SETUP.md              Step-by-step beginner guide
│   ├── DEPLOY.md             Deploy to Vercel + Render + Supabase
│   └── TROUBLESHOOTING.md    Fix any error
└── data/
    └── sample-orders.csv     24 London demo orders
```

## 🔑 Services you need (all free to start)

| Service | What for | Free tier | Setup |
|---|---|---|---|
| Supabase | Postgres + Auth + Realtime | 500MB DB | 5 min |
| OpenRouteService | UK geocoding | 2000 req/day | 2 min |
| Vercel | Frontend hosting | hobby plan | 3 min (later) |
| Render | Backend hosting | 750 hrs/mo | 3 min (later) |

Total to start: **£0/month**.

See `docs/SETUP.md` for click-by-click instructions.

## 🆘 Something not working?

1. Open `http://localhost:3000/diagnostic` — it runs 5 checks and tells you exactly what's broken
2. Read `docs/TROUBLESHOOTING.md` for the top 10 errors and fixes
