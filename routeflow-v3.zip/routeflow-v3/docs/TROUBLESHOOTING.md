# RouteFlow AI — Troubleshooting

> **Always start here:** open `http://localhost:3000/diagnostic`. It runs 5 checks and shows you exactly what's broken with a fix for each.

---

## 🔝 Top errors and exact fixes

### 1. `/_next/static/chunks/fallback/webpack.js 500` (and related fallback chunks)

**What it means:** Next.js build cache is corrupted. Almost always happens after an interrupted install or an env change.

**Fix (Mac/Linux):**
```bash
cd frontend
rm -rf .next node_modules package-lock.json
npm install
npm run dev
```

**Fix (Windows PowerShell):**
```powershell
cd frontend
Remove-Item -Recurse -Force .next, node_modules, package-lock.json
npm install
npm run dev
```

Then hard-refresh the browser: **Cmd+Shift+R** (Mac) / **Ctrl+Shift+R** (Windows).

---

### 2. "Database error saving new user" (on signup)

**What it means:** Supabase auth trigger failed to create your profile row — usually a permissions issue on the trigger.

**Fix:** In Supabase SQL Editor, run:

```sql
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'handle_new_user failed: %', SQLERRM;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

GRANT INSERT ON public.profiles TO supabase_auth_admin;
GRANT USAGE ON SCHEMA public TO supabase_auth_admin;
```

Then delete the half-created user: Supabase → **Authentication → Users** → 3 dots next to your email → **Delete user**. Try signup again.

> The v3 schema.sql already includes this fix. If you ran the v3 schema, you shouldn't see this.

---

### 3. "Failed to fetch" / "TypeError: Failed to fetch"

**What it means:** Frontend can't reach the backend.

**Checklist:**
- Is backend running? Visit `http://localhost:8000/health` in browser — should return JSON.
- Is `NEXT_PUBLIC_API_URL` in `frontend/.env.local` set to `http://localhost:8000`?
- Did you restart `npm run dev` after editing `.env.local`? **You must** — Next.js only reads env vars at startup.

---

### 4. "Invalid API key" (from Supabase)

**What it means:** Wrong key in env file, or you swapped anon/service_role.

**Fix:**
- `frontend/.env.local` → `NEXT_PUBLIC_SUPABASE_ANON_KEY` must be the **anon** key
- `backend/.env` → `SUPABASE_SERVICE_KEY` must be the **service_role** key
- Both come from Supabase → **Settings → API**

Restart both servers after fixing.

---

### 5. Signup hangs / never completes

**What it means:** "Confirm email" is on in Supabase, and the confirmation email got stuck.

**Fix:** Supabase → **Authentication → Providers → Email** → toggle OFF "Confirm email" → **Save**.

---

### 6. Leaflet map shows blank / grey

**What it means:** Leaflet CSS isn't loading.

**Fix:**
```bash
cd frontend
rm -rf .next
npm install leaflet@1.9.4 @types/leaflet@1.9.12
npm run dev
```

If still broken, hard-refresh: **Cmd+Shift+R** / **Ctrl+Shift+R**.

---

### 7. Driver app shows "Invalid driver link"

**What it means:** The token in the URL doesn't match any driver in the database.

**Fix:**
- Open `/drivers` → make sure at least one driver exists
- Click **Copy driver app link** on a driver card (not just any URL)
- Open the *exact* URL — tokens are case-sensitive

If you regenerated drivers, old links won't work. Always copy a fresh one.

---

### 8. Geocoding returns 401 / "Unauthorized"

**What it means:** Wrong or missing `ORS_API_KEY` in `backend/.env`.

**Fix:**
- Get a fresh key at https://openrouteservice.org/dev/#/home
- Paste into `backend/.env` as `ORS_API_KEY=...`
- Restart backend (Ctrl+C in that terminal, then run uvicorn again)

---

### 9. Backend says "ortools not installed"

**Fix:**
```bash
cd backend
source venv/bin/activate           # Windows: venv\Scripts\activate
pip install ortools
```

> **Mac M1/M2:** if `pip install ortools` fails, you're probably on Python 3.12. Use Python **3.11** instead:
> ```bash
> brew install python@3.11
> rm -rf venv
> python3.11 -m venv venv
> source venv/bin/activate
> pip install -r requirements.txt
> ```

---

### 10. CORS error (`blocked by CORS policy`)

**What it means:** Backend's `ALLOWED_ORIGINS` doesn't list the frontend URL.

**Fix (local):** `backend/.env` should have:
```
ALLOWED_ORIGINS=http://localhost:3000
```

**Fix (production):** on Render → Environment → `ALLOWED_ORIGINS`:
```
ALLOWED_ORIGINS=http://localhost:3000,https://your-app.vercel.app
```

Then redeploy / restart backend.

---

### 11. "Not authenticated" on protected pages

**Fix:** Just sign in again. Sessions can expire. If it keeps happening, clear browser site data for `localhost:3000` and try fresh.

---

### 12. Port 3000 / 8000 already in use

**Mac/Linux:**
```bash
lsof -ti:3000 | xargs kill -9       # for frontend
lsof -ti:8000 | xargs kill -9       # for backend
```

**Windows:**
```powershell
netstat -ano | findstr :3000
taskkill /F /PID <PID>
```

---

## 🧰 General "nuclear option" reset

If everything is broken and you just want to start fresh:

```bash
# Stop both servers (Ctrl+C in each terminal)

cd frontend
rm -rf .next node_modules package-lock.json

cd ../backend
rm -rf venv __pycache__

cd ..
bash setup.sh           # Mac/Linux
# OR
setup.bat               # Windows
```

Then start both servers again and visit `/diagnostic`.

---

## 💬 Still stuck?

1. Open browser **DevTools** (F12) → **Console** tab → copy any red errors
2. Open browser **DevTools** → **Network** tab → look for failed requests (red)
3. Check both terminal windows for error messages
4. Visit `/diagnostic` and screenshot it

These four things together will pinpoint almost any issue.
