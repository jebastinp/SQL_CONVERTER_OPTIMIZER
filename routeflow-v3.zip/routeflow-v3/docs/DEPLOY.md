# RouteFlow AI — Deployment Guide

Deploy to: **Vercel** (frontend) + **Render** (backend) + **Supabase** (database).
**All free tiers** — total cost £0/month to start.

> Make sure the app runs locally first (see `SETUP.md`). Don't deploy until `/diagnostic` shows all green ✓.

---

## 🗄 Step 1 — Supabase is already deployed

You already have a Supabase project from local setup. ✅ Nothing more to do — your local app and production app will share the same database. (If you want separate dev/prod, create a second Supabase project and use its keys for production.)

---

## 🐍 Step 2 — Deploy backend to Render

### 2a. Push code to GitHub

If you haven't already:

```bash
cd routeflow-v3
git init
git add .
git commit -m "Initial commit"
```

1. Go to https://github.com/new → create a new **private** repo called `routeflow`
2. Copy the commands GitHub shows you (something like):

```bash
git remote add origin https://github.com/YOU/routeflow.git
git branch -M main
git push -u origin main
```

### 2b. Create Render service

1. Go to https://render.com → sign up (free, use GitHub login)
2. Click **New** → **Web Service**
3. Connect your `routeflow` repo
4. Fill in:

| Field | Value |
|---|---|
| **Name** | `routeflow-backend` |
| **Region** | Frankfurt or Ohio (closest to your users) |
| **Branch** | `main` |
| **Root Directory** | `backend` |
| **Runtime** | Python 3 |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `uvicorn main:app --host 0.0.0.0 --port $PORT` |
| **Plan** | Free |

### 2c. Add environment variables

Scroll down to **Environment Variables** and add:

```
SUPABASE_URL=https://XXXXX.supabase.co
SUPABASE_SERVICE_KEY=eyJ...service_role-key...
SUPABASE_JWT_SECRET=your-jwt-secret
ORS_API_KEY=5b3ce3597851...
ALLOWED_ORIGINS=http://localhost:3000
```

(Leave `ALLOWED_ORIGINS` at localhost for now — we'll update it after Vercel.)

Click **Create Web Service**. Wait ~5 min for first deploy.

When it's done you'll get a URL like `https://routeflow-backend.onrender.com`. **Copy it.**

Test it: open `https://routeflow-backend.onrender.com/health` in a browser. You should see JSON like `{"status":"ok",...}`.

> 💤 **Free tier note**: Render sleeps the service after 15 min of inactivity. First request after sleep takes ~30s to wake up. Upgrade to Starter ($7/mo) to keep it awake.

---

## ▲ Step 3 — Deploy frontend to Vercel

1. Go to https://vercel.com → sign up (free, use GitHub)
2. **Add New** → **Project** → import your `routeflow` repo
3. Fill in:

| Field | Value |
|---|---|
| **Framework Preset** | Next.js (auto-detected) |
| **Root Directory** | `frontend` |
| **Build Command** | (leave default) |
| **Output Directory** | (leave default) |

### Environment variables

Add these three:

```
NEXT_PUBLIC_SUPABASE_URL=https://XXXXX.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...anon-key...
NEXT_PUBLIC_API_URL=https://routeflow-backend.onrender.com
```

> ⚠️ `NEXT_PUBLIC_API_URL` should be the Render URL from Step 2, **no trailing slash**.

Click **Deploy**. Wait ~2–3 min.

You'll get a URL like `https://routeflow-XXXXX.vercel.app`. **Copy it.**

---

## 🔁 Step 4 — Connect Vercel back to Render

Render needs to know your Vercel URL so CORS works.

1. Render dashboard → your `routeflow-backend` service
2. **Environment** tab → edit `ALLOWED_ORIGINS`:

```
ALLOWED_ORIGINS=http://localhost:3000,https://routeflow-XXXXX.vercel.app
```

3. Click **Save Changes** — Render redeploys automatically (~1 min)

---

## ✅ Step 5 — Verify

1. Open `https://your-app.vercel.app/diagnostic`
2. All 5 checks should pass ✓
3. Sign up, add drivers, import orders, optimize.

---

## 🌐 Custom domain (optional)

### Vercel (frontend)

Vercel dashboard → project → **Settings** → **Domains** → add your domain. Follow the DNS instructions Vercel shows.

### After adding a domain

Update Render's `ALLOWED_ORIGINS` to include your domain:

```
ALLOWED_ORIGINS=https://yourdomain.com,https://routeflow-XXXXX.vercel.app
```

---

## 🔄 Updating after the first deploy

Just push to GitHub:

```bash
git add .
git commit -m "your change"
git push
```

- Vercel auto-deploys frontend on every push (~2 min)
- Render auto-deploys backend on every push (~3 min)

---

## 👥 Onboarding customers manually

You're not using Stripe — that's fine. To onboard a paying customer:

1. Send them your Vercel URL
2. They go to `/signup` and create an account
3. They start using it

Each user automatically gets isolated data via Row-Level Security — they can only see their own orders, drivers, routes. No multi-tenant configuration required.

To track who's paying, just look at Supabase **Authentication → Users**.
