# RouteFlow AI — Setup Guide (Beginner-Friendly)

This guide gets you from zero to a working app in **about 30 minutes**.

> 💡 If anything breaks while following this, open `http://localhost:3000/diagnostic` — it will tell you exactly which step failed.

---

## ✅ Step 0 — Check prerequisites

Open a terminal and run these:

```bash
node --version    # should be v18 or higher
python3 --version # should be 3.10 or higher (Windows: just `python --version`)
```

If either is missing:
- **Node.js**: https://nodejs.org (download LTS)
- **Python**: https://python.org/downloads

> **Mac M1/M2 users**: if you have multiple Python versions, use Python **3.11** specifically (`brew install python@3.11`) — OR-Tools sometimes struggles on 3.12 on Apple Silicon.

---

## 📦 Step 1 — Unzip the project

```bash
unzip routeflow-v3.zip
cd routeflow-v3
```

You should see folders: `frontend/`, `backend/`, `supabase/`, `docs/`, `data/`.

---

## 🗄 Step 2 — Set up Supabase (database + auth)

### 2a. Create a project (skip if you already have one)

1. Go to https://supabase.com → **Sign up** (free)
2. Click **New project**
3. Name: `routeflow` · Region: pick the closest to you · Password: pick anything strong → **Save it!**
4. Wait ~2 minutes for it to provision.

### 2b. Wipe any old tables (only if you're re-running v2/v3 setup)

If this is a fresh project, **skip this**. Otherwise:

1. In your Supabase dashboard, left sidebar → **SQL Editor** (the `</>` icon)
2. Click **+ New query**, paste this, and click **RUN**:

```sql
DROP TABLE IF EXISTS delivery_stops, driver_positions, routes, orders, drivers, geocode_cache, profiles CASCADE;
```

### 2c. Install the v3 schema

1. Still in the **SQL Editor**, click **+ New query**
2. Open the file `supabase/schema.sql` from this project (any text editor will do)
3. **Copy the entire file**, paste it into the Supabase query box
4. Click the green **RUN** button
5. You should see "Success. No rows returned." ✅

Verify: left sidebar → **Table Editor**. You should see **7 tables**: `profiles`, `drivers`, `orders`, `routes`, `delivery_stops`, `driver_positions`, `geocode_cache`.

### 2d. Disable email confirmation (makes testing easier)

1. Left sidebar → **Authentication** → **Providers**
2. Click **Email**
3. Toggle **OFF** "Confirm email"
4. Click **Save**

> You can turn this back on for production. While building, it lets you sign up without checking email.

### 2e. Copy your keys

Left sidebar → **Project Settings** (gear icon) → **API**

You need 4 values:

| What | Where it's shown |
|---|---|
| **Project URL** | `https://XXXXX.supabase.co` |
| **anon public key** | starts with `eyJ...`, labeled "anon" / "public" |
| **service_role key** | starts with `eyJ...`, labeled "service_role" — **secret!** |
| **JWT Secret** | Settings → API → scroll to "JWT Settings" → "JWT Secret" |

Keep this tab open — you'll paste these into env files in Step 4.

---

## 🌍 Step 3 — Get OpenRouteService API key

1. Go to https://openrouteservice.org/dev/#/signup
2. Sign up (free, 2,000 requests/day)
3. After login → **Dashboard** → click **Create Token**
4. Token name: `routeflow` → **Create**
5. Copy the long key — it starts with `5b3ce3597851...`

---

## 🔧 Step 4 — Configure environment files

### Backend env

```bash
cd backend
cp .env.example .env       # Windows: copy .env.example .env
```

Open `backend/.env` in any text editor and fill in:

```ini
SUPABASE_URL=https://XXXXX.supabase.co              # from step 2e
SUPABASE_SERVICE_KEY=eyJ...your-service_role-key... # from step 2e ⚠️ service_role, NOT anon
SUPABASE_JWT_SECRET=your-jwt-secret                 # from step 2e
ORS_API_KEY=5b3ce3597851...                         # from step 3
ALLOWED_ORIGINS=http://localhost:3000
PORT=8000
```

### Frontend env

```bash
cd ../frontend
cp .env.local.example .env.local   # Windows: copy .env.local.example .env.local
```

Open `frontend/.env.local` and fill in:

```ini
NEXT_PUBLIC_SUPABASE_URL=https://XXXXX.supabase.co   # from step 2e
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...anon-key...      # ⚠️ anon, NOT service_role
NEXT_PUBLIC_API_URL=http://localhost:8000
```

> ⚠️ **Easy beginner mistake**: don't mix up `anon` and `service_role`. Frontend uses **anon**. Backend uses **service_role**.

---

## 🚀 Step 5 — Install everything

From the project root (`routeflow-v3/`):

**Mac/Linux:**
```bash
bash setup.sh
```

**Windows:**
```bash
setup.bat
```

This:
- Creates a Python virtualenv and installs backend dependencies
- Clears any stale Next.js cache
- Installs frontend dependencies (~2–3 min)

---

## ▶️ Step 6 — Start the servers

You need **two terminals** running at the same time.

### Terminal 1 — Backend

```bash
cd backend
source venv/bin/activate          # Windows: venv\Scripts\activate
uvicorn main:app --reload --port 8000
```

You should see:
```
🚀 RouteFlow backend starting
   CORS origins: ['http://localhost:3000']
   Supabase URL: https://xxxxx.supabase.co
   ORS API key:  set
   OR-Tools:     installed
Uvicorn running on http://0.0.0.0:8000
```

### Terminal 2 — Frontend

```bash
cd frontend
npm run dev
```

You should see:
```
▲ Next.js 14.2.13
  - Local:        http://localhost:3000
✓ Ready in 2s
```

---

## 🩺 Step 7 — Verify everything works

**Before signing up, open:**

```
http://localhost:3000/diagnostic
```

This page runs 5 checks:
1. ✅ Environment variables loaded
2. ✅ Supabase REST API reachable
3. ✅ `profiles` table exists
4. ✅ Auth session check
5. ✅ Backend `/health` reachable

**All 5 should show green ✓**. If any are red ✗, the page will tell you exactly how to fix it.

---

## 🎉 Step 8 — Use the app!

1. Go to `http://localhost:3000/signup`
2. Create an account (e.g. `you@example.com`, any password ≥6 chars)
3. You'll land on the **Dashboard**
4. Click **Drivers** in sidebar → add 2 drivers
5. Click **Orders** → **Import CSV** → click **Load demo (24)** → click **Import & geocode**
6. Wait ~30 seconds while it geocodes the addresses
7. Click **Live Routes** → click **Optimize Routes**
8. 🎉 You'll see optimized routes drawn on the map

### Share a tracking link with a "customer"

After optimizing, go to Supabase **Table Editor** → `delivery_stops` → copy any `customer_token` value → open `http://localhost:3000/track/PASTE_TOKEN_HERE` to see the customer view.

### Test the driver app

**Drivers** page → click any driver → **Copy driver app link** → open that URL on your phone (or another browser tab) — it's a mobile-friendly app where the driver marks stops complete.

---

## ✅ You're done!

Next: see `docs/DEPLOY.md` to put this on the public internet (Vercel + Render + Supabase), or `docs/TROUBLESHOOTING.md` if anything broke.
