import { ReactNode } from 'react';

export default function Topbar({ title, subtitle, actions }: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="flex items-center gap-5 px-6 py-3.5 border-b border-white/[.08] bg-bg0/50 backdrop-blur-xl">
      <div className="flex-1">
        <div className="text-sm">
          <span className="text-ink font-medium">{title}</span>
          {subtitle && <span className="text-ink-dim"> · {subtitle}</span>}
        </div>
      </div>
      {actions}
    </header>
  );
}
