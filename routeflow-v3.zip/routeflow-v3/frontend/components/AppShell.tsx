import { ReactNode } from 'react';
import { useAuth } from '@/lib/useAuth';
import Sidebar from './Sidebar';

export default function AppShell({ children }: { children: ReactNode }) {
  const { user, profile, loading } = useAuth(true);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-ink-dim text-sm">
        Loading…
      </div>
    );
  }
  if (!user) return null; // redirect happening

  return (
    <div className="flex min-h-screen">
      <Sidebar profile={profile || { email: user.email || '' }} />
      <main className="flex-1 flex flex-col overflow-hidden">{children}</main>
    </div>
  );
}
