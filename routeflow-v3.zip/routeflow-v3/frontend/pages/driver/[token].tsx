import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';
import { MapPin, Phone, Check, X, Navigation } from 'lucide-react';

export default function DriverApp() {
  const router = useRouter();
  const token = router.query.token as string | undefined;

  const [driver, setDriver] = useState<any>(null);
  const [stops, setStops] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tracking, setTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!token) return;
    const sb = supabase();
    const { data: d, error: dErr } = await sb.from('drivers').select('*').eq('access_token', token).single();
    if (dErr || !d) { setError('Invalid driver link'); setLoading(false); return; }
    setDriver(d);

    const { data: routes } = await sb.from('routes').select('*')
      .eq('driver_id', d.id)
      .in('status', ['planned', 'in_progress'])
      .order('created_at', { ascending: false })
      .limit(1);

    if (routes && routes[0]) {
      const { data: stopData } = await sb.from('delivery_stops').select('*, orders(*)')
        .eq('route_id', routes[0].id).order('sequence');
      setStops(stopData || []);
    }
    setLoading(false);
  }
  useEffect(() => { if (token) load(); }, [token]);

  function startTracking() {
    if (!navigator.geolocation || !driver) return;
    setTracking(true);
    navigator.geolocation.watchPosition(
      async (pos) => {
        const sb = supabase();
        await sb.from('driver_positions').insert({
          driver_id: driver.id,
          user_id: driver.user_id,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          speed_kmh: pos.coords.speed ? pos.coords.speed * 3.6 : null,
          heading: pos.coords.heading,
        });
        await sb.from('drivers').update({
          current_lat: pos.coords.latitude,
          current_lng: pos.coords.longitude,
          last_seen: new Date().toISOString(),
        }).eq('id', driver.id);
      },
      (err) => alert(`Location error: ${err.message}`),
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 30000 },
    );
  }

  async function markComplete(stopId: string) {
    await supabase().from('delivery_stops').update({
      status: 'completed', completed_at: new Date().toISOString(),
    }).eq('id', stopId);
    load();
  }

  async function markFailed(stopId: string) {
    const note = prompt('Reason for failure?') || 'Customer not available';
    await supabase().from('delivery_stops').update({
      status: 'failed', completed_at: new Date().toISOString(), notes: note,
    }).eq('id', stopId);
    load();
  }

  if (loading) return <main className="min-h-screen flex items-center justify-center text-ink-dim">Loading…</main>;
  if (error) return <main className="min-h-screen flex items-center justify-center text-bad">{error}</main>;

  const pending = stops.filter((s) => s.status === 'pending').length;
  const done = stops.filter((s) => s.status === 'completed').length;
  const failed = stops.filter((s) => s.status === 'failed').length;

  return (
    <main className="min-h-screen pb-32 max-w-md mx-auto px-4 pt-6">
      <div className="glass-strong p-5 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-semibold text-white"
               style={{ background: `linear-gradient(135deg,${driver.color},${driver.color}aa)` }}>
            {driver.name.split(' ').map((n: string) => n[0]).slice(0, 2).join('')}
          </div>
          <div className="flex-1">
            <div className="text-sm font-semibold">{driver.name}</div>
            <div className="text-[11px] text-ink-mute">{driver.vehicle || 'Driver app'}</div>
          </div>
          {tracking && <div className="w-2 h-2 rounded-full bg-good" />}
        </div>
        <div className="grid grid-cols-3 gap-2 mt-4 text-center">
          <div className="bg-white/[.04] rounded-lg p-2">
            <div className="font-serif text-2xl text-accent-2">{pending}</div>
            <div className="text-[9px] uppercase tracking-wider text-ink-mute">Pending</div>
          </div>
          <div className="bg-white/[.04] rounded-lg p-2">
            <div className="font-serif text-2xl text-good">{done}</div>
            <div className="text-[9px] uppercase tracking-wider text-ink-mute">Done</div>
          </div>
          <div className="bg-white/[.04] rounded-lg p-2">
            <div className="font-serif text-2xl text-bad">{failed}</div>
            <div className="text-[9px] uppercase tracking-wider text-ink-mute">Failed</div>
          </div>
        </div>
        {!tracking && stops.length > 0 && (
          <button onClick={startTracking} className="btn btn-primary w-full mt-4 justify-center">
            <Navigation size={14} />Start route & share location
          </button>
        )}
      </div>

      {stops.length === 0 && (
        <div className="text-center py-10 text-ink-dim text-sm">
          No route assigned yet.
        </div>
      )}

      <div className="space-y-3">
        {stops.map((s) => {
          const o = s.orders;
          const isDone = s.status === 'completed';
          const isFailed = s.status === 'failed';
          const dim = isDone || isFailed;
          return (
            <div key={s.id} className={`glass p-4 ${dim ? 'opacity-50' : ''}`}>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white text-xs"
                     style={{ background: isDone ? '#3ddc97' : isFailed ? '#ff5d6c' : `linear-gradient(135deg,${driver.color},${driver.color}aa)` }}>
                  {isDone ? <Check size={14} /> : isFailed ? <X size={14} /> : s.sequence}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{o.customer_name}</div>
                  <div className="text-xs text-ink-dim mt-0.5">{o.address}</div>
                  <div className="text-xs text-ink-mute mt-0.5">{o.postcode} · ETA <span className="text-accent-2 font-mono">{s.eta_clock}</span></div>
                </div>
              </div>
              {!dim && (
                <>
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    {o.phone ? (
                      <a href={`tel:${o.phone}`} className="btn btn-ghost justify-center text-xs py-2"><Phone size={12} />Call</a>
                    ) : <div />}
                    <a href={`https://www.google.com/maps/dir/?api=1&destination=${o.lat},${o.lng}`} target="_blank" rel="noreferrer" className="btn btn-ghost justify-center text-xs py-2">
                      <MapPin size={12} />Navigate
                    </a>
                    <button onClick={() => markComplete(s.id)} className="btn btn-primary justify-center text-xs py-2">
                      <Check size={12} />Done
                    </button>
                  </div>
                  <button onClick={() => markFailed(s.id)} className="text-[11px] text-bad/70 hover:text-bad mt-2 w-full text-center">
                    Mark as failed
                  </button>
                </>
              )}
            </div>
          );
        })}
      </div>
    </main>
  );
}
