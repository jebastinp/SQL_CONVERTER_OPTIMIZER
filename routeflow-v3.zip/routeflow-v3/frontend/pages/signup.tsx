import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      const sb = supabase();
      const { data, error } = await sb.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName },
          emailRedirectTo: typeof window !== 'undefined' ? `${window.location.origin}/dashboard` : undefined,
        },
      });
      if (error) throw error;

      if (data.user && companyName) {
        // Best-effort update — won't fail signup if it errors
        await sb.from('profiles').update({ company_name: companyName }).eq('id', data.user.id);
      }
      if (data.session) {
        router.push('/dashboard');
      } else {
        setInfo('Check your email to confirm your account, then sign in.');
      }
    } catch (e: any) {
      setError(e.message || 'Signup failed');
    }
    setLoading(false);
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="glass-strong p-10 w-full max-w-md">
        <Link href="/" className="text-ink-dim text-sm hover:text-ink mb-6 inline-block">← Back</Link>
        <h1 className="font-serif text-4xl mb-2">
          Get <em className="text-accent-2">started</em>
        </h1>
        <p className="text-ink-dim text-sm mb-8">Create your RouteFlow account</p>

        <form onSubmit={signUp} className="space-y-4">
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Full name</label>
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} required className="input mt-1.5" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Company</label>
            <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="input mt-1.5" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="input mt-1.5" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Password (min 6)</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="input mt-1.5" />
          </div>
          {error && <div className="text-bad text-sm bg-bad/10 border border-bad/20 rounded-lg p-3">{error}</div>}
          {info && <div className="text-good text-sm bg-good/10 border border-good/20 rounded-lg p-3">{info}</div>}
          <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-3">
            {loading ? 'Creating…' : 'Create account'}
          </button>
        </form>

        <p className="text-center text-sm text-ink-dim mt-8">
          Already have an account? <Link href="/login" className="text-accent-2 hover:underline">Sign in</Link>
        </p>

        <div className="mt-6 text-center text-[11px] text-ink-mute">
          Trouble? Visit <Link href="/diagnostic" className="text-accent-2 underline">/diagnostic</Link>
        </div>
      </div>
    </main>
  );
}
