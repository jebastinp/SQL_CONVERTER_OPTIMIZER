import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase().auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/dashboard');
    });
  }, [router]);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { error } = await supabase().auth.signInWithPassword({ email, password });
      if (error) throw error;
      router.push('/dashboard');
    } catch (e: any) {
      setError(e.message || 'Sign in failed');
    }
    setLoading(false);
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="glass-strong p-10 w-full max-w-md">
        <Link href="/" className="text-ink-dim text-sm hover:text-ink mb-6 inline-block">← Back</Link>
        <h1 className="font-serif text-4xl mb-2">
          Welcome <em className="text-accent-2">back</em>
        </h1>
        <p className="text-ink-dim text-sm mb-8">Sign in to RouteFlow AI</p>

        <form onSubmit={signIn} className="space-y-4">
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
              className="input mt-1.5" placeholder="you@company.co.uk" />
          </div>
          <div>
            <label className="text-xs text-ink-mute uppercase tracking-wider">Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required
              className="input mt-1.5" placeholder="••••••••" />
          </div>
          {error && (
            <div className="text-bad text-sm bg-bad/10 border border-bad/20 rounded-lg p-3">{error}</div>
          )}
          <button type="submit" disabled={loading} className="btn btn-primary w-full justify-center py-3">
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="text-center text-sm text-ink-dim mt-8">
          No account? <Link href="/signup" className="text-accent-2 hover:underline">Sign up</Link>
        </p>
      </div>
    </main>
  );
}
