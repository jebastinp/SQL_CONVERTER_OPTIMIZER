import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import { supabase } from '@/lib/supabase';
import { MapPin, Truck, Clock, CheckCircle2 } from 'lucide-react';

const TrackMap = dynamic(() => import('@/components/TrackMap'), { ssr: false });

export default function CustomerTrackingPage() {
  const router = useRouter();
  const token = router.query.token as string | undefined;

  const [stop, setStop] = useState<any>(null);
  const [route, setRoute] = useState<any>(null);
  const [driver, setDriver] = useState<any>(null);
  const [allStops, setAllStops] = useState<any[]>([]);
  const [driverPos, setDriverPos] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!token) return;
    const sb = supabase();
    const { data: stopData, error: sErr } = await sb.from('delivery_stops').select('*, orders(*)')
      .eq('customer_token', token).single();
    if (sErr || !stopData) { setError('Invalid tracking link'); setLoading(false); return; }
    setStop(stopData);

    const { data: routeData } = await sb.from('routes').select('*').eq('id', stopData.route_id).single();
    setRoute(routeData);

    if (routeData) {
      const { data: driverData } = await sb.from('drivers')
        .select('id,name,vehicle,color,current_lat,current_lng,last_seen')
        .eq('id', routeData.driver_id).single();
      setDriver(driverData);
      if (driverData?.current_lat && driverData?.current_lng) {
        setDriverPos({ lat: Number(driverData.current_lat), lng: Number(driverData.current_lng) });
      }
      const { data: stopsData } = await sb.from('delivery_stops').select('id,sequence,status,eta_clock')
        .eq('route_id', stopData.route_id).order('sequence');
      setAllStops(stopsData || []);
    }
    setLoading(false);
  }
  useEffect(() => { if (token) load(); }, [token]);

  useEffect(() => {
    if (!driver?.id) return;
    const sb = supabase();
    const channel = sb.channel(`track_${token}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'driver_positions', filter: `driver_id=eq.${driver.id}` },
        (payload: any) => { setDriverPos({ lat: Number(payload.new.lat), lng: Number(payload.new.lng) }); })
      .subscribe();
    return () => { sb.removeChannel(channel); };
  }, [driver?.id, token]);

  if (loading) return <main className="min-h-screen flex items-center justify-center text-ink-dim">Loading…</main>;
  if (error) return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="glass-strong p-8 text-center max-w-sm">
        <div className="text-4xl mb-3">📦</div>
        <div className="text-bad mb-2">{error}</div>
      </div>
    </main>
  );

  const order = stop.orders;
  const isDone = stop.status === 'completed';
  const isFailed = stop.status === 'failed';
  const myIndex = allStops.findIndex((s) => s.id === stop.id);
  const completedBefore = allStops.slice(0, myIndex).filter((s) => s.status === 'completed').length;
  const remainingBefore = myIndex - completedBefore;

  let statusBadge = { color: 'pill-info', text: 'Scheduled' };
  if (route?.status === 'in_progress') statusBadge = { color: 'pill-warn', text: remainingBefore === 0 ? 'On the way' : `${remainingBefore} stops ahead` };
  if (isDone) statusBadge = { color: 'pill-ok', text: 'Delivered ✓' };
  if (isFailed) statusBadge = { color: 'pill-bad', text: 'Could not deliver' };

  return (
    <main className="min-h-screen max-w-md mx-auto px-4 pt-6 pb-12">
      <div className="glass-strong p-5 mb-4">
        <div className="text-[11px] uppercase tracking-widest text-ink-mute mb-1">Tracking your delivery</div>
        <div className="font-serif text-3xl mb-3">
          Hi, <em className="text-accent-2">{order.customer_name.split(' ')[0]}</em>
        </div>
        <div className="flex items-center gap-2 mb-4">
          <span className={`pill ${statusBadge.color}`}>{statusBadge.text}</span>
          {!isDone && !isFailed && (
            <span className="text-xs text-ink-dim">ETA <span className="font-mono text-accent-2">{stop.eta_clock}</span></span>
          )}
        </div>
        {allStops.length > 0 && (
          <div>
            <div className="h-1.5 bg-white/[.04] rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-accent to-accent-2 transition-all"
                   style={{ width: `${isDone ? 100 : ((completedBefore + 0.3) / allStops.length) * 100}%` }} />
            </div>
            <div className="flex justify-between text-[10px] text-ink-mute mt-1.5">
              <span>Depot</span><span>Stop {stop.sequence} of {allStops.length}</span><span>Done</span>
            </div>
          </div>
        )}
      </div>

      <div className="glass overflow-hidden h-72 mb-4 relative">
        <TrackMap
          stopLat={Number(order.lat)}
          stopLng={Number(order.lng)}
          driverPos={driverPos}
          driverColor={driver?.color || '#5b8cff'}
        />
      </div>

      <div className="glass p-5 mb-4">
        <div className="text-[11px] uppercase tracking-widest text-ink-mute mb-3">Delivery to</div>
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-accent/15 flex items-center justify-center flex-shrink-0">
            <MapPin size={15} className="text-accent-2" />
          </div>
          <div>
            <div className="font-medium text-sm">{order.address}</div>
            <div className="text-ink-dim text-xs mt-0.5">{order.postcode}</div>
          </div>
        </div>
      </div>

      {driver && (
        <div className="glass p-5 mb-4">
          <div className="text-[11px] uppercase tracking-widest text-ink-mute mb-3">Your driver</div>
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl flex items-center justify-center font-semibold text-white text-sm flex-shrink-0"
                 style={{ background: `linear-gradient(135deg,${driver.color},${driver.color}aa)` }}>
              {driver.name.split(' ').map((n: string) => n[0]).slice(0, 2).join('').toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-sm">{driver.name}</div>
              <div className="text-ink-dim text-xs">{driver.vehicle || 'Delivery van'}</div>
            </div>
          </div>
        </div>
      )}

      <div className="glass p-5">
        <div className="text-[11px] uppercase tracking-widest text-ink-mute mb-3">Today's progress</div>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-full bg-good/20 border border-good/40 flex items-center justify-center">
              <CheckCircle2 size={13} className="text-good" />
            </div>
            <div className="flex-1"><div className="text-sm">Route planned & dispatched</div></div>
          </div>
          <div className="flex items-center gap-3">
            <div className={`w-7 h-7 rounded-full border flex items-center justify-center
                ${remainingBefore === 0 || isDone ? 'bg-accent/20 border-accent/40' : 'bg-white/[.04] border-white/[.08]'}`}>
              <Truck size={13} className={remainingBefore === 0 || isDone ? 'text-accent-2' : 'text-ink-mute'} />
            </div>
            <div className="flex-1">
              <div className="text-sm">{remainingBefore === 0 && !isDone ? 'On the way to you' : 'Heading your way'}</div>
              <div className="text-[11px] text-ink-mute">{remainingBefore > 0 ? `${remainingBefore} stops before yours` : 'Next stop is yours'}</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className={`w-7 h-7 rounded-full border flex items-center justify-center
                ${isDone ? 'bg-good/20 border-good/40' : 'bg-white/[.04] border-white/[.08]'}`}>
              {isDone ? <CheckCircle2 size={13} className="text-good" /> : <Clock size={13} className="text-ink-mute" />}
            </div>
            <div className="flex-1">
              <div className="text-sm">{isDone ? 'Delivered' : 'Delivery'}</div>
              <div className="text-[11px] text-ink-mute">{isDone ? `Completed at ${new Date(stop.completed_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}` : `Estimated ${stop.eta_clock}`}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 text-center text-[10.5px] text-ink-mute">
        Powered by <span className="font-serif italic text-ink-dim">RouteFlow AI</span>
      </div>
    </main>
  );
}
