import { useEffect, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { Sparkles, AlertTriangle, CheckCircle2, RotateCw } from 'lucide-react';

export default function DashboardPage() {
  const [stats, setStats] = useState({ orders: 0, drivers: 0, routes: [] as any[] });

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const [o, d, r] = await Promise.all([
        sb.from('orders').select('id', { count: 'exact', head: true }),
        sb.from('drivers').select('id', { count: 'exact', head: true }),
        sb.from('routes').select('*').order('created_at', { ascending: false }).limit(20),
      ]);
      setStats({
        orders: o.count || 0,
        drivers: d.count || 0,
        routes: r.data || [],
      });
    })();
  }, []);

  const completed = stats.routes.filter((r: any) => r.status === 'completed').length;
  const totalFuel = stats.routes.reduce((s: number, r: any) => s + Number(r.fuel_saved_gbp || 0), 0);
  const onTime = stats.routes.length > 0 ? Math.round((completed / stats.routes.length) * 100) : 0;

  return (
    <AppShell>
      <Topbar title="Dashboard" subtitle="Live operational overview"
        actions={<Link href="/routes" className="btn btn-primary"><Sparkles size={14} />Optimize Routes</Link>} />

      <div className="p-6 overflow-auto flex-1">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-5">
          <KPI label="Total Orders" value={String(stats.orders)} sub="All time" />
          <KPI label="Fuel Saved" value={`£${totalFuel.toFixed(0)}`} sub="Cumulative" />
          <KPI label="On-Time Rate" value={`${onTime}%`} sub={`${completed}/${stats.routes.length} routes`} />
          <KPI label="Active Drivers" value={String(stats.drivers)} sub="In fleet" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
          <div className="lg:col-span-2 glass p-5">
            <div className="text-sm font-semibold mb-3.5">Recent Routes</div>
            {stats.routes.length === 0 ? (
              <div className="text-center py-10 text-ink-dim text-sm">
                <div className="text-4xl mb-2 opacity-40">⌖</div>
                No routes yet.<br/>
                <Link href="/orders" className="text-accent-2 hover:underline">Import orders</Link> to get started.
              </div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-[10.5px] uppercase tracking-wider text-ink-mute border-b border-white/[.08]">
                    <th className="text-left py-2.5 font-medium">Date</th>
                    <th className="text-left py-2.5 font-medium">Distance</th>
                    <th className="text-left py-2.5 font-medium">Fuel saved</th>
                    <th className="text-left py-2.5 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.routes.slice(0, 8).map((r: any) => (
                    <tr key={r.id} className="border-b border-white/[.08] last:border-0 text-ink-dim hover:text-ink">
                      <td className="py-2.5">{new Date(r.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</td>
                      <td className="py-2.5">{Number(r.distance_km || 0).toFixed(1)} km</td>
                      <td className="py-2.5 text-good">£{Number(r.fuel_saved_gbp || 0).toFixed(2)}</td>
                      <td className="py-2.5">
                        <span className={`pill ${r.status === 'completed' ? 'pill-ok' : r.status === 'in_progress' ? 'pill-info' : 'pill-warn'}`}>{r.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="glass p-5">
            <div className="text-sm font-semibold mb-3.5">AI Insights</div>
            <div className="flex flex-col gap-2.5">
              {[
                { icon: Sparkles, color: 'text-accent-2 bg-accent/15', title: 'Optimize all pending orders', body: `You have ${stats.orders} orders. Run optimization to assign them.` },
                { icon: AlertTriangle, color: 'text-warn bg-warn/15', title: 'Set depot location', body: 'Adjust your warehouse coordinates in Settings.' },
                { icon: CheckCircle2, color: 'text-good bg-good/15', title: 'Best dispatch window', body: '9:15–10:00 has 31% less congestion than 8:00.' },
                { icon: RotateCw, color: 'text-purple bg-purple/15', title: 'Recurring routes', body: 'Same 12 stops appear weekly — consider a template.' },
              ].map((i, idx) => {
                const Icon = i.icon;
                return (
                  <div key={idx} className="p-3 rounded-lg bg-white/[.04] border border-white/[.08] flex gap-3">
                    <div className={`w-7 h-7 rounded-lg ${i.color} flex items-center justify-center flex-shrink-0`}>
                      <Icon size={13} />
                    </div>
                    <div>
                      <div className="text-xs font-medium mb-1">{i.title}</div>
                      <div className="text-[11px] text-ink-dim leading-relaxed">{i.body}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function KPI({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="glass p-5">
      <div className="text-[11px] uppercase tracking-wider text-ink-mute mb-2">{label}</div>
      <div className="font-serif text-3xl">{value}</div>
      <div className="text-[11px] text-ink-dim mt-1.5">{sub}</div>
    </div>
  );
}
