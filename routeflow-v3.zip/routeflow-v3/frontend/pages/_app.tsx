import type { AppProps } from 'next/app';
import Head from 'next/head';
import '@/styles/globals.css';

export default function App({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <title>RouteFlow AI</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="AI route optimization for UK delivery operations" />
        <link rel="icon" href="/favicon.svg" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#05070d" />
      </Head>
      <div className="ambient" />
      <div className="grid-bg" />
      <div className="relative z-10">
        <Component {...pageProps} />
      </div>
    </>
  );
}
