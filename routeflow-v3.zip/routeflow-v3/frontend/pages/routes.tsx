import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { apiOptimize } from '@/lib/api';
import type { Order, Driver, Profile, OptimizeResponse } from '@/lib/types';
import { Zap, Download } from 'lucide-react';

const RouteMap = dynamic(() => import('@/components/RouteMap'), { ssr: false });

export default function RoutesPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [optimization, setOptimization] = useState<OptimizeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [driverPositions, setDriverPositions] = useState<Record<string, { lat: number; lng: number }>>({});

  useEffect(() => {
    (async () => {
      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      const [o, d, p] = await Promise.all([
        sb.from('orders').select('*').eq('geocoded', true),
        sb.from('drivers').select('*'),
        sb.from('profiles').select('*').eq('id', user.id).single(),
      ]);
      setOrders((o.data as Order[]) || []);
      setDrivers((d.data as Driver[]) || []);
      setProfile(p.data as Profile);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const sb = supabase();
    const channel = sb.channel('driver_positions_live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'driver_positions' }, (payload: any) => {
        const p = payload.new;
        setDriverPositions((prev) => ({ ...prev, [p.driver_id]: { lat: p.lat, lng: p.lng } }));
      })
      .subscribe();
    return () => { sb.removeChannel(channel); };
  }, []);

  async function optimize() {
    if (!profile) return;
    if (orders.length === 0) { setError('No geocoded orders. Import & geocode first.'); return; }
    if (drivers.length === 0) { setError('No drivers. Add drivers first.'); return; }
    setError(null); setOptimizing(true);
    try {
      const body = {
        depot: { lat: Number(profile.depot_lat), lng: Number(profile.depot_lng) },
        orders: orders.map((o) => ({
          id: o.id, customer_name: o.customer_name, address: o.address, postcode: o.postcode,
          lat: Number(o.lat), lng: Number(o.lng),
          delivery_window: o.delivery_window, priority: o.priority, service_minutes: o.service_minutes,
        })),
        drivers: drivers.map((d) => ({
          id: d.id, name: d.name, vehicle: d.vehicle || '', capacity: d.capacity,
          shift_start: d.shift_start.substring(0, 5), color: d.color,
        })),
        avg_speed_kmh: Number(profile.avg_speed_kmh),
        fuel_price_gbp: Number(profile.fuel_price_gbp),
        vehicle_kml: Number(profile.vehicle_kml),
      };
      const result: OptimizeResponse = await apiOptimize(body);
      setOptimization(result);

      const sb = supabase();
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      for (const route of result.routes) {
        const { data: routeRow } = await sb.from('routes').insert({
          user_id: user.id,
          driver_id: route.driver_id,
          status: 'planned',
          depot_lat: profile.depot_lat,
          depot_lng: profile.depot_lng,
          distance_km: route.distance_km,
          duration_minutes: route.duration_minutes,
          fuel_saved_gbp: (result.fuel_saved_gbp / result.routes.length),
          baseline_km: result.baseline_distance_km / result.routes.length,
        }).select().single();
        if (routeRow) {
          await sb.from('delivery_stops').insert(route.stops.map((s) => ({
            route_id: routeRow.id,
            order_id: s.order_id,
            user_id: user.id,
            sequence: s.sequence,
            eta_minutes: s.eta_minutes,
            eta_clock: s.eta_clock,
            status: 'pending',
          })));
          await sb.from('orders').update({ status: 'assigned' })
            .in('id', route.stops.map((s) => s.order_id).filter(Boolean));
        }
      }
    } catch (e: any) {
      setError(e.message);
    }
    setOptimizing(false);
  }

  function exportCSV() {
    if (!optimization) return;
    let csv = 'Driver,Sequence,Customer,Address,Postcode,ETA,Lat,Lng\n';
    for (const r of optimization.routes) {
      for (const s of r.stops) {
        csv += `"${r.driver_name}",${s.sequence},"${s.customer_name}","${s.address}","${s.postcode}","${s.eta_clock}",${s.lat},${s.lng}\n`;
      }
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `routes-${new Date().toISOString().split('T')[0]}.csv`; a.click();
  }

  return (
    <AppShell>
      <Topbar
        title="Live Routes"
        subtitle={optimization ? `${optimization.routes.length} routes · saved ${optimization.distance_saved_km.toFixed(1)}km` : 'Plan and dispatch'}
        actions={
          <div className="flex gap-2">
            {optimization && (
              <button onClick={exportCSV} className="btn btn-ghost"><Download size={13} />Export</button>
            )}
            <button onClick={optimize} disabled={optimizing || loading} className="btn btn-primary">
              <Zap size={13} />{optimizing ? 'Optimizing…' : 'Optimize Routes'}
            </button>
          </div>
        }
      />

      {error && (
        <div className="mx-6 mt-4 px-4 py-3 rounded-lg bg-bad/10 border border-bad/20 text-bad text-sm">
          {error}
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[340px_1fr] overflow-hidden">
        <aside className="bg-bg1/60 backdrop-blur-xl border-r border-white/[.08] overflow-auto p-4">
          {!optimization ? (
            <div className="text-center py-10 text-ink-mute text-sm">
              <div className="text-4xl mb-3 opacity-40">⌖</div>
              {loading ? 'Loading…' : (
                <>
                  Click <b className="text-ink">Optimize Routes</b> to plan your fleet.<br />
                  <div className="text-[11px] mt-3">{orders.length} geocoded orders · {drivers.length} drivers ready</div>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="glass p-3">
                <div className="text-[10px] uppercase tracking-wider text-ink-mute mb-2">Summary</div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><div className="text-ink-mute text-[10px]">Total km</div><div className="font-mono">{optimization.total_distance_km.toFixed(1)}</div></div>
                  <div><div className="text-ink-mute text-[10px]">Saved km</div><div className="font-mono text-good">{optimization.distance_saved_km.toFixed(1)}</div></div>
                  <div><div className="text-ink-mute text-[10px]">Fuel £</div><div className="font-mono text-good">£{optimization.fuel_saved_gbp.toFixed(2)}</div></div>
                  <div><div className="text-ink-mute text-[10px]">Algo</div><div className="font-mono text-[10px] text-ink-dim">{optimization.algorithm}</div></div>
                </div>
              </div>

              {optimization.routes.map((route) => (
                <div key={route.driver_id}>
                  <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg bg-white/[.04] mb-2 border-l-[3px]" style={{ borderColor: route.driver_color }}>
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: route.driver_color }} />
                    <div className="text-sm font-medium flex-1">{route.driver_name}</div>
                    <div className="text-[10.5px] text-ink-mute font-mono">{route.stops.length}·{route.distance_km.toFixed(1)}km</div>
                  </div>
                  <div className="space-y-1.5">
                    {route.stops.map((s) => (
                      <div key={s.sequence} className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg bg-white/[.04] border border-white/[.08] text-xs">
                        <div className="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-bold text-white font-mono flex-shrink-0"
                             style={{ background: `linear-gradient(135deg,${route.driver_color},${route.driver_color}aa)` }}>
                          {s.sequence}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-ink truncate">{s.customer_name}</div>
                          <div className="text-[10.5px] text-ink-mute truncate">{s.postcode} · {s.address}</div>
                        </div>
                        <div className="text-[10.5px] text-accent-2 font-mono">{s.eta_clock}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </aside>

        <div className="relative bg-bg1">
          <RouteMap optimization={optimization} profile={profile} driverPositions={driverPositions} />
        </div>
      </div>
    </AppShell>
  );
}
