import { useEffect, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import Topbar from '@/components/Topbar';
import { supabase } from '@/lib/supabase';
import { apiGeocodeBatch } from '@/lib/api';
import type { Order } from '@/lib/types';
import { Plus, MapPin, Upload, Trash2 } from 'lucide-react';

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [geocoding, setGeocoding] = useState(false);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({
    customer_name: '', address: '', postcode: '', phone: '',
    delivery_window: 'Anytime', priority: 'Med',
  });

  async function refresh() {
    const { data } = await supabase().from('orders').select('*').order('created_at', { ascending: false });
    setOrders((data as Order[]) || []);
    setLoading(false);
  }
  useEffect(() => { refresh(); }, []);

  async function addOrder(e: React.FormEvent) {
    e.preventDefault();
    setAdding(true);
    const sb = supabase();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) { setAdding(false); return; }
    await sb.from('orders').insert({ ...form, user_id: user.id });
    setForm({ customer_name: '', address: '', postcode: '', phone: '', delivery_window: 'Anytime', priority: 'Med' });
    await refresh();
    setAdding(false);
  }

  async function geocodeAll() {
    const pending = orders.filter((o) => !o.geocoded);
    if (!pending.length) return alert('All orders already geocoded.');
    setGeocoding(true);
    try {
      const items = pending.map((o) => ({ address: o.address, postcode: o.postcode, country: 'GB' }));
      const result = await apiGeocodeBatch(items);
      const sb = supabase();
      for (let i = 0; i < pending.length; i++) {
        const r = result.results[i]?.result;
        if (r) {
          await sb.from('orders').update({ lat: r.lat, lng: r.lng, geocoded: true }).eq('id', pending[i].id);
        }
      }
      await refresh();
    } catch (e: any) {
      alert(`Geocoding failed: ${e.message}`);
    }
    setGeocoding(false);
  }

  async function deleteOrder(id: string) {
    if (!confirm('Delete this order?')) return;
    await supabase().from('orders').delete().eq('id', id);
    await refresh();
  }

  return (
    <AppShell>
      <Topbar title="Orders" subtitle={`${orders.length} total · ${orders.filter((o) => !o.geocoded).length} need geocoding`}
        actions={
          <div className="flex gap-2">
            <Link href="/import" className="btn btn-ghost"><Upload size={13} />Import CSV</Link>
            <button onClick={geocodeAll} disabled={geocoding} className="btn btn-primary">
              <MapPin size={13} />{geocoding ? 'Geocoding…' : 'Geocode all'}
            </button>
          </div>
        } />

      <div className="p-6 overflow-auto flex-1 grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 glass p-5">
          <div className="text-sm font-semibold mb-3.5">All orders</div>
          {loading ? <div className="text-ink-dim text-sm">Loading…</div> :
            orders.length === 0 ? (
              <div className="text-center py-10 text-ink-dim text-sm">No orders yet.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-[10.5px] uppercase tracking-wider text-ink-mute border-b border-white/[.08]">
                      <th className="text-left py-2 font-medium">Customer</th>
                      <th className="text-left py-2 font-medium">Address</th>
                      <th className="text-left py-2 font-medium">Postcode</th>
                      <th className="text-left py-2 font-medium">Window</th>
                      <th className="text-left py-2 font-medium">Pri</th>
                      <th className="text-left py-2 font-medium">Geo</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((o) => (
                      <tr key={o.id} className="border-b border-white/[.08] last:border-0 text-ink-dim hover:text-ink">
                        <td className="py-2.5 text-ink">{o.customer_name}</td>
                        <td className="py-2.5 max-w-[200px] truncate">{o.address}</td>
                        <td className="py-2.5"><span className="pill pill-info">{o.postcode}</span></td>
                        <td className="py-2.5 text-[11px]">{o.delivery_window}</td>
                        <td className="py-2.5">
                          <span className={`pill ${o.priority === 'High' ? 'pill-bad' : o.priority === 'Low' ? 'pill-ok' : 'pill-warn'}`}>{o.priority}</span>
                        </td>
                        <td className="py-2.5">{o.geocoded ? <span className="pill pill-ok">✓</span> : <span className="pill pill-warn">—</span>}</td>
                        <td className="py-2.5">
                          <button onClick={() => deleteOrder(o.id)} className="text-ink-mute hover:text-bad p-1"><Trash2 size={13} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          }
        </div>

        <div className="glass p-5">
          <div className="text-sm font-semibold mb-3.5 flex items-center gap-2"><Plus size={14} />Add manually</div>
          <form onSubmit={addOrder} className="space-y-3">
            <input className="input" placeholder="Customer name" value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} required />
            <input className="input" placeholder="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} required />
            <input className="input" placeholder="Postcode (e.g. SW1A 1AA)" value={form.postcode} onChange={(e) => setForm({ ...form, postcode: e.target.value })} required />
            <input className="input" placeholder="Phone (optional)" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <select className="input" value={form.delivery_window} onChange={(e) => setForm({ ...form, delivery_window: e.target.value })}>
              <option>Anytime</option><option>Morning</option><option>Afternoon</option>
            </select>
            <select className="input" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
              <option>Low</option><option>Med</option><option>High</option>
            </select>
            <button type="submit" disabled={adding} className="btn btn-primary w-full justify-center">{adding ? 'Adding…' : 'Add order'}</button>
          </form>
        </div>
      </div>
    </AppShell>
  );
}
