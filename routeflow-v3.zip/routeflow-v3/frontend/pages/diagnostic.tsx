import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { apiHealth } from '@/lib/api';

type Check = {
  name: string;
  status: 'pending' | 'pass' | 'fail';
  message?: string;
  fix?: string;
};

export default function Diagnostic() {
  const [checks, setChecks] = useState<Check[]>([]);

  useEffect(() => {
    runChecks();
  }, []);

  async function runChecks() {
    const results: Check[] = [];

    // Check 1: env vars present
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    const apiUrl = process.env.NEXT_PUBLIC_API_URL;

    results.push({
      name: 'NEXT_PUBLIC_SUPABASE_URL set',
      status: url ? 'pass' : 'fail',
      message: url ? url : 'missing',
      fix: !url ? 'Add NEXT_PUBLIC_SUPABASE_URL to frontend/.env.local, then restart npm run dev' : undefined,
    });
    results.push({
      name: 'NEXT_PUBLIC_SUPABASE_ANON_KEY set',
      status: key ? 'pass' : 'fail',
      message: key ? `${key.substring(0, 20)}…` : 'missing',
      fix: !key ? 'Add NEXT_PUBLIC_SUPABASE_ANON_KEY to frontend/.env.local, then restart npm run dev' : undefined,
    });
    results.push({
      name: 'NEXT_PUBLIC_API_URL set',
      status: apiUrl ? 'pass' : 'fail',
      message: apiUrl ? apiUrl : 'missing (will default to http://localhost:8000)',
    });
    setChecks([...results]);

    // Check 2: Supabase REST reachable
    if (url && key) {
      try {
        const r = await fetch(`${url}/rest/v1/`, { headers: { apikey: key } });
        results.push({
          name: 'Supabase REST API reachable',
          status: r.status < 500 ? 'pass' : 'fail',
          message: `HTTP ${r.status}`,
          fix: r.status >= 500 ? 'Supabase project may be paused or has an outage' : undefined,
        });
      } catch (e: any) {
        results.push({
          name: 'Supabase REST API reachable',
          status: 'fail',
          message: e.message,
          fix: 'Check your internet connection and that SUPABASE_URL is correct',
        });
      }
    }
    setChecks([...results]);

    // Check 3: Can read profiles table (tests schema is installed)
    if (url && key) {
      try {
        const sb = supabase();
        const { error } = await sb.from('profiles').select('id').limit(1);
        if (error) {
          results.push({
            name: 'profiles table exists',
            status: 'fail',
            message: error.message,
            fix: error.message.includes('does not exist')
              ? 'Run supabase/schema.sql in your Supabase SQL Editor'
              : 'Check Supabase RLS policies',
          });
        } else {
          results.push({ name: 'profiles table exists', status: 'pass', message: 'OK' });
        }
      } catch (e: any) {
        results.push({ name: 'profiles table exists', status: 'fail', message: e.message });
      }
    }
    setChecks([...results]);

    // Check 4: auth session
    if (url && key) {
      try {
        const { data, error } = await supabase().auth.getSession();
        results.push({
          name: 'Auth session check',
          status: error ? 'fail' : 'pass',
          message: data.session ? `Logged in as ${data.session.user.email}` : 'Not logged in (this is fine if you haven\'t signed up yet)',
        });
      } catch (e: any) {
        results.push({ name: 'Auth session check', status: 'fail', message: e.message });
      }
    }
    setChecks([...results]);

    // Check 5: Backend API reachable
    try {
      const h = await apiHealth();
      results.push({
        name: 'Backend /health reachable',
        status: 'pass',
        message: `ortools=${h.ortools}, ors=${h.ors_configured}, supabase=${h.supabase_configured}`,
        fix: !h.ors_configured ? 'Set ORS_API_KEY in backend/.env to enable geocoding' : undefined,
      });
    } catch (e: any) {
      // Backend requires JWT, so a 401 here is actually a sign the backend is up
      const msg = e.message || '';
      if (msg.includes('401')) {
        results.push({
          name: 'Backend reachable',
          status: 'pass',
          message: 'Backend is up (returned 401, which is expected when not signed in)',
        });
      } else {
        results.push({
          name: 'Backend reachable',
          status: 'fail',
          message: msg,
          fix: 'Make sure backend is running: cd backend && uvicorn main:app --reload --port 8000',
        });
      }
    }
    setChecks([...results]);
  }

  const allPassed = checks.length > 0 && checks.every((c) => c.status === 'pass');
  const anyFailed = checks.some((c) => c.status === 'fail');

  return (
    <main className="min-h-screen px-6 py-12">
      <div className="max-w-2xl mx-auto">
        <Link href="/" className="text-ink-dim text-sm hover:text-ink mb-4 inline-block">← Back</Link>
        <h1 className="font-serif text-4xl mb-2">Diagnostic</h1>
        <p className="text-ink-dim text-sm mb-8">Verifies your setup is connected correctly.</p>

        <div className="space-y-2">
          {checks.length === 0 && (
            <div className="text-ink-dim text-sm">Running checks…</div>
          )}
          {checks.map((c, i) => (
            <div key={i} className={`glass p-4 flex items-start gap-3 border-l-4
              ${c.status === 'pass' ? 'border-good' : c.status === 'fail' ? 'border-bad' : 'border-warn'}`}>
              <div className="text-lg leading-none mt-0.5">
                {c.status === 'pass' ? '✓' : c.status === 'fail' ? '✗' : '⋯'}
              </div>
              <div className="flex-1">
                <div className="font-medium text-sm">{c.name}</div>
                {c.message && <div className="text-xs text-ink-dim mt-1 font-mono break-all">{c.message}</div>}
                {c.fix && <div className="text-xs text-warn mt-2">→ {c.fix}</div>}
              </div>
            </div>
          ))}
        </div>

        {allPassed && (
          <div className="mt-6 p-4 glass border-l-4 border-good">
            <div className="text-good font-medium">All checks passed! 🎉</div>
            <div className="text-xs text-ink-dim mt-1">You're ready to <Link href="/signup" className="text-accent-2 underline">sign up</Link> or <Link href="/login" className="text-accent-2 underline">log in</Link>.</div>
          </div>
        )}
        {anyFailed && (
          <div className="mt-6 p-4 glass border-l-4 border-bad">
            <div className="text-bad font-medium">Some checks failed.</div>
            <div className="text-xs text-ink-dim mt-1">Fix the items above (orange arrows show what to do), then refresh this page.</div>
          </div>
        )}

        <button onClick={() => { setChecks([]); runChecks(); }} className="btn btn-ghost mt-6">
          Re-run checks
        </button>
      </div>
    </main>
  );
}
