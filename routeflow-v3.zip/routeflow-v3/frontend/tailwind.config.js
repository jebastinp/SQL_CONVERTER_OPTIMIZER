/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        bg0: '#05070d',
        bg1: '#0a0e1a',
        ink: '#e7ecf5',
        'ink-dim': '#8893a8',
        'ink-mute': '#5b6478',
        accent: '#5b8cff',
        'accent-2': '#7af6ff',
        good: '#3ddc97',
        warn: '#ffb547',
        bad: '#ff5d6c',
        purple: '#b48cff',
      },
      fontFamily: {
        sans: ['Geist', 'system-ui', 'sans-serif'],
        serif: ['"Instrument Serif"', 'serif'],
        mono: ['"Geist Mono"', 'monospace'],
      },
    },
  },
  plugins: [],
};
