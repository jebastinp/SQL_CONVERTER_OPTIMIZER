#!/bin/bash
# RouteFlow AI — One-step setup (Mac/Linux)
# Usage: bash setup.sh
set -e

echo "🚀 RouteFlow AI setup"
echo "===================="

# Check prerequisites
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org (LTS)"; exit 1
fi
if ! command -v python3 &> /dev/null; then
  echo "❌ Python 3 not found. Install from https://python.org"; exit 1
fi

echo "✓ Node.js $(node --version)"
echo "✓ Python  $(python3 --version)"
echo ""

# Backend
echo "📦 Setting up backend..."
cd backend
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "⚠️  Created backend/.env from example — EDIT IT with your real keys"
fi
deactivate
cd ..
echo "✓ Backend installed"
echo ""

# Frontend
echo "📦 Setting up frontend..."
cd frontend
rm -rf .next  # clear stale Next.js cache
npm install --silent --no-audit --no-fund
if [ ! -f ".env.local" ]; then
  cp .env.local.example .env.local
  echo "⚠️  Created frontend/.env.local from example — EDIT IT with your real keys"
fi
cd ..
echo "✓ Frontend installed"
echo ""

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Edit backend/.env       with your Supabase & ORS keys"
echo "  2. Edit frontend/.env.local with your Supabase keys"
echo "  3. Run the backend:   cd backend && source venv/bin/activate && uvicorn main:app --reload --port 8000"
echo "  4. Run the frontend:  cd frontend && npm run dev"
echo "  5. Open http://localhost:3000/diagnostic to verify everything is connected"
