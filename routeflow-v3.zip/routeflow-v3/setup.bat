@echo off
REM RouteFlow AI - One-step setup (Windows)
REM Usage: setup.bat

echo === RouteFlow AI setup ===

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js not found. Install from https://nodejs.org
  exit /b 1
)
where python >nul 2>nul
if errorlevel 1 (
  echo Python not found. Install from https://python.org
  exit /b 1
)

echo Setting up backend...
cd backend
if not exist venv python -m venv venv
call venv\Scripts\activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
if not exist .env (
  copy .env.example .env
  echo Created backend\.env from example - EDIT IT with your real keys
)
call venv\Scripts\deactivate
cd ..
echo Backend installed.
echo.

echo Setting up frontend...
cd frontend
if exist .next rmdir /s /q .next
call npm install --silent --no-audit --no-fund
if not exist .env.local (
  copy .env.local.example .env.local
  echo Created frontend\.env.local from example - EDIT IT with your real keys
)
cd ..
echo Frontend installed.
echo.

echo === Setup complete! ===
echo.
echo Next steps:
echo   1. Edit backend\.env       with your Supabase + ORS keys
echo   2. Edit frontend\.env.local with your Supabase keys
echo   3. Run backend:   cd backend ^&^& venv\Scripts\activate ^&^& uvicorn main:app --reload --port 8000
echo   4. Run frontend:  cd frontend ^&^& npm run dev
echo   5. Open http://localhost:3000/diagnostic to verify
