"""
End-to-end tests for SQL Forge.
Runs against the real Flask app via its test client, using mocked sqlglot/bcrypt
so it works without network access. The real app uses the real libraries.
"""
import os
import sys
import json
import tempfile

# Install mock sqlglot/bcrypt BEFORE importing the app
sys.path.insert(0, os.path.dirname(__file__))
from test_stubs import install_stubs
install_stubs()

# Use an in-memory-ish temp DB so tests don't pollute the real one
TEST_DB = tempfile.mktemp(suffix=".db")
os.environ["SQLFORGE_DB"] = TEST_DB
os.environ["SQLFORGE_SECRET"] = "test-secret"

import app as app_module
app_module.init_db()
client = app_module.app.test_client()

# ---------------------------------------------------------------------------
PASS = 0
FAIL = 0
FAILURES = []

def test(name, fn):
    global PASS, FAIL
    try:
        fn()
        print(f"  ✓ {name}")
        PASS += 1
    except AssertionError as e:
        print(f"  ✗ {name}")
        print(f"    {e}")
        FAIL += 1
        FAILURES.append((name, str(e)))
    except Exception as e:
        print(f"  ✗ {name} — EXCEPTION: {type(e).__name__}: {e}")
        FAIL += 1
        FAILURES.append((name, f"{type(e).__name__}: {e}"))


def section(title):
    print(f"\n── {title} " + "─" * (60 - len(title)))


def post(path, body, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return client.post(path, data=json.dumps(body), headers=headers)


def get(path, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return client.get(path, headers=headers)


def delete(path, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return client.delete(path, headers=headers)


# ===========================================================================
section("Health & metadata")
# ===========================================================================

def t_health():
    r = client.get("/api/health")
    assert r.status_code == 200, r.status_code
    data = r.get_json()
    assert data["ok"] is True
    assert "version" in data

test("GET /api/health", t_health)

def t_dialects():
    r = client.get("/api/dialects")
    assert r.status_code == 200
    ids = [d["id"] for d in r.get_json()["dialects"]]
    for d in ("mssql", "postgresql", "mysql", "oracle", "sqlite"):
        assert d in ids, f"missing dialect {d}"

test("GET /api/dialects", t_dialects)


# ===========================================================================
section("Auth flow")
# ===========================================================================

state = {}

def t_signup_bad_email():
    r = post("/api/auth/signup", {"email": "notanemail", "password": "longenoughpw"})
    assert r.status_code == 400
test("Signup rejects bad email", t_signup_bad_email)

def t_signup_short_password():
    r = post("/api/auth/signup", {"email": "a@b.com", "password": "short"})
    assert r.status_code == 400
test("Signup rejects short password", t_signup_short_password)

def t_signup_ok():
    r = post("/api/auth/signup", {"email": "alice@example.com", "password": "supersecret123"})
    assert r.status_code == 200, r.get_json()
    data = r.get_json()
    assert data["user"]["email"] == "alice@example.com"
    assert "token" in data
    state["token"] = data["token"]
test("Signup creates user + returns token", t_signup_ok)

def t_signup_duplicate():
    r = post("/api/auth/signup", {"email": "alice@example.com", "password": "supersecret123"})
    assert r.status_code == 409
test("Signup rejects duplicate email", t_signup_duplicate)

def t_me_authed():
    r = get("/api/auth/me", token=state["token"])
    assert r.status_code == 200
    data = r.get_json()
    assert data["authenticated"] is True
    assert data["user"]["email"] == "alice@example.com"
test("GET /api/auth/me returns user when authed", t_me_authed)

def t_me_unauthed():
    r = get("/api/auth/me")
    assert r.status_code == 200
    assert r.get_json()["authenticated"] is False
test("GET /api/auth/me returns false when not authed", t_me_unauthed)

def t_login_wrong_password():
    r = post("/api/auth/login", {"email": "alice@example.com", "password": "wrongpass"})
    assert r.status_code == 401
test("Login rejects wrong password", t_login_wrong_password)

def t_login_ok():
    r = post("/api/auth/login", {"email": "alice@example.com", "password": "supersecret123"})
    assert r.status_code == 200
    assert "token" in r.get_json()
test("Login succeeds with right password", t_login_ok)

def t_login_unknown_user():
    r = post("/api/auth/login", {"email": "ghost@example.com", "password": "whatever123"})
    assert r.status_code == 401
test("Login rejects unknown email", t_login_unknown_user)


# ===========================================================================
section("Convert endpoint")
# ===========================================================================

def t_convert_no_auth_works():
    r = post("/api/convert", {
        "sql": "SELECT TOP 5 * FROM customers;",
        "source_dialect": "mssql",
        "target_dialect": "postgresql",
    })
    assert r.status_code == 200
    d = r.get_json()
    assert d["ok"] is True
    assert "LIMIT 5" in d["output_sql"], d["output_sql"]
    # Should also pick up SELECT * issue
    assert any("*" in i["title"] for i in d["issues"]), d["issues"]
test("Anonymous conversion works (MSSQL→PG, TOP→LIMIT)", t_convert_no_auth_works)

def t_convert_empty_sql():
    r = post("/api/convert", {"sql": "  ", "source_dialect": "mssql", "target_dialect": "postgresql"})
    assert r.status_code == 400
test("Convert rejects empty SQL", t_convert_empty_sql)

def t_convert_too_large():
    big = "SELECT 1;" * 20000
    r = post("/api/convert", {"sql": big, "source_dialect": "postgresql", "target_dialect": "postgresql"})
    assert r.status_code == 413
test("Convert rejects oversized payload", t_convert_too_large)

def t_convert_parse_error():
    r = post("/api/convert", {
        "sql": "@@@PARSE_FAIL@@@",
        "source_dialect": "mssql",
        "target_dialect": "postgresql",
    })
    assert r.status_code == 200
    d = r.get_json()
    assert d["ok"] is False
    assert "Parse error" in d["error"], d
test("Convert returns soft parse error", t_convert_parse_error)

def t_convert_isnull_to_coalesce():
    r = post("/api/convert", {
        "sql": "SELECT ISNULL(name, 'unknown') FROM customers;",
        "source_dialect": "mssql",
        "target_dialect": "postgresql",
    })
    assert r.status_code == 200
    d = r.get_json()
    assert "COALESCE" in d["output_sql"], d["output_sql"]
    titles = [n["title"] for n in d["conversion_notes"]]
    assert any("ISNULL" in t for t in titles), titles
test("MSSQL ISNULL → PG COALESCE with note", t_convert_isnull_to_coalesce)

def t_convert_oracle_rownum():
    r = post("/api/convert", {
        "sql": "SELECT name FROM customers WHERE ROWNUM <= 10;",
        "source_dialect": "oracle",
        "target_dialect": "postgresql",
    })
    assert r.status_code == 200
    d = r.get_json()
    assert "LIMIT 10" in d["output_sql"], d["output_sql"]
test("Oracle ROWNUM → PG LIMIT", t_convert_oracle_rownum)

def t_convert_mysql_ifnull():
    r = post("/api/convert", {
        "sql": "SELECT IFNULL(`name`, 'x') FROM `customers`;",
        "source_dialect": "mysql",
        "target_dialect": "postgresql",
    })
    assert r.status_code == 200
    d = r.get_json()
    assert "COALESCE" in d["output_sql"]
    assert '"name"' in d["output_sql"], d["output_sql"]
test("MySQL IFNULL+backticks → PG", t_convert_mysql_ifnull)

def t_convert_complexity_returned():
    r = post("/api/convert", {
        "sql": "SELECT * FROM a JOIN b ON a.id = b.a_id ORDER BY a.name;",
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    })
    d = r.get_json()
    cx = d["complexity"]
    assert "bigO" in cx and "cost" in cx
    assert cx["cost"] > 10  # joins + order should bump it
test("Complexity object returned", t_convert_complexity_returned)

def t_convert_detects_correlated():
    sql = """SELECT c.id, c.name,
        (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) AS order_count
        FROM customers c;"""
    r = post("/api/convert", {
        "sql": sql,
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    })
    d = r.get_json()
    titles = " ".join(i["title"] for i in d["issues"])
    assert "Correlated" in titles, titles
test("Detects correlated subquery", t_convert_detects_correlated)

def t_convert_detects_leading_wildcard():
    r = post("/api/convert", {
        "sql": "SELECT name FROM customers WHERE email LIKE '%@example.com';",
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    })
    d = r.get_json()
    titles = " ".join(i["title"] for i in d["issues"])
    assert "wildcard" in titles.lower(), titles
test("Detects leading-wildcard LIKE", t_convert_detects_leading_wildcard)

def t_convert_detects_select_star():
    r = post("/api/convert", {
        "sql": "SELECT * FROM customers;",
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    })
    d = r.get_json()
    titles = [i["title"] for i in d["issues"]]
    assert any("SELECT *" in t for t in titles), titles
test("Detects SELECT *", t_convert_detects_select_star)

def t_convert_detects_not_in_subquery():
    r = post("/api/convert", {
        "sql": "SELECT name FROM customers WHERE id NOT IN (SELECT customer_id FROM orders);",
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    })
    d = r.get_json()
    titles = " ".join(i["title"] for i in d["issues"])
    assert "NOT IN" in titles, titles
test("Detects NOT IN (subquery)", t_convert_detects_not_in_subquery)

def t_convert_function_in_where():
    r = post("/api/convert", {
        "sql": "SELECT * FROM customers WHERE UPPER(name) = 'ALICE';",
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    })
    d = r.get_json()
    titles = " ".join(i["title"] for i in d["issues"])
    assert "Function on column" in titles, titles
test("Detects function on column in WHERE", t_convert_function_in_where)


# ===========================================================================
section("History (authenticated)")
# ===========================================================================

def t_history_requires_auth():
    r = get("/api/history")
    assert r.status_code == 401
test("History requires auth", t_history_requires_auth)

def t_convert_records_history():
    # Run a conversion as alice
    r = post("/api/convert", {
        "sql": "SELECT 1;",
        "source_dialect": "postgresql",
        "target_dialect": "postgresql",
    }, token=state["token"])
    assert r.status_code == 200
    # Now check history
    r2 = get("/api/history", token=state["token"])
    assert r2.status_code == 200
    hist = r2.get_json()["history"]
    assert len(hist) >= 1
    assert hist[0]["source_sql"] == "SELECT 1;"
test("Authed convert is recorded in history", t_convert_records_history)

def t_history_isolated_per_user():
    # Signup a second user; their history must be empty
    r = post("/api/auth/signup", {"email": "bob@example.com", "password": "anothersecret123"})
    bob_token = r.get_json()["token"]
    r2 = get("/api/history", token=bob_token)
    assert r2.status_code == 200
    assert r2.get_json()["history"] == []
test("History is per-user isolated", t_history_isolated_per_user)


# ===========================================================================
section("Saved queries")
# ===========================================================================

def t_save_requires_auth():
    r = post("/api/saved", {"name": "x"})
    assert r.status_code == 401
test("Save requires auth", t_save_requires_auth)

def t_save_ok():
    r = post("/api/saved", {
        "name": "Daily customers report",
        "source_dialect": "mssql",
        "target_dialect": "postgresql",
        "source_sql": "SELECT TOP 10 * FROM customers;",
        "output_sql": "SELECT * FROM customers LIMIT 10;",
    }, token=state["token"])
    assert r.status_code == 200
    r2 = get("/api/saved", token=state["token"])
    items = r2.get_json()["saved"]
    assert len(items) == 1
    assert items[0]["name"] == "Daily customers report"
    state["saved_id"] = items[0]["id"]
test("Save and list query", t_save_ok)

def t_save_requires_name():
    r = post("/api/saved", {
        "name": "  ",
        "source_dialect": "mssql", "target_dialect": "postgresql",
        "source_sql": "x", "output_sql": "y",
    }, token=state["token"])
    assert r.status_code == 400
test("Save rejects empty name", t_save_requires_name)

def t_delete_saved():
    r = delete(f"/api/saved/{state['saved_id']}", token=state["token"])
    assert r.status_code == 200
    r2 = get("/api/saved", token=state["token"])
    assert r2.get_json()["saved"] == []
test("Delete saved query", t_delete_saved)


# ===========================================================================
section("Logout invalidates session")
# ===========================================================================

def t_logout():
    r = post("/api/auth/logout", {}, token=state["token"])
    assert r.status_code == 200
    r2 = get("/api/auth/me", token=state["token"])
    assert r2.get_json()["authenticated"] is False
test("Logout invalidates token", t_logout)


# ===========================================================================
section("Static frontend served")
# ===========================================================================

def t_index_served():
    r = client.get("/")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    assert "SQL Forge" in body
    assert "/app.js" in body and "/styles.css" in body
test("GET / serves index.html", t_index_served)

def t_landing_page_elements():
    body = client.get("/").get_data(as_text=True)
    # Hero
    assert "Translate any SQL dialect" in body
    assert "view-landing" in body
    # Workspace nav exists
    assert "view-convert" in body
    # Pain section
    assert "Migration sprints" in body
    # Features section
    assert "AST-based dialect conversion" in body
    # How section
    assert "Three steps" in body
    # Final CTA
    assert "Stop hand-converting" in body
    # Footer
    assert "MIT-licensed" in body
test("Landing page sections present", t_landing_page_elements)

def t_responsive_meta():
    body = client.get("/").get_data(as_text=True)
    assert 'name="viewport"' in body
    assert 'initial-scale=1' in body
    assert 'theme-color' in body
test("Mobile viewport + theme-color meta tags present", t_responsive_meta)

def t_mobile_menu_present():
    body = client.get("/").get_data(as_text=True)
    assert 'id="menuToggle"' in body
    assert 'mobile-drawer' in body
test("Mobile menu elements present", t_mobile_menu_present)

def t_css_has_responsive_breakpoints():
    css = client.get("/styles.css").get_data(as_text=True)
    # Check responsive media queries exist
    assert "@media (max-width:" in css
    # Check key responsive breakpoints
    assert "max-width: 760px" in css or "max-width: 720px" in css
    # Reduced motion support
    assert "prefers-reduced-motion" in css
    # Safe area for iOS notches
    assert "safe-area-inset" in css
test("CSS has responsive breakpoints + accessibility", t_css_has_responsive_breakpoints)

def t_static_assets():
    r = client.get("/app.js")
    assert r.status_code == 200
    body = r.get_data(as_text=True)
    assert "tokenize" in body
    r2 = client.get("/styles.css")
    assert r2.status_code == 200
test("Static assets reachable", t_static_assets)


# ===========================================================================
print()
print(f"━━━ {PASS} passed, {FAIL} failed " + "━" * 30)
if FAIL:
    print("\nFailures:")
    for n, e in FAILURES:
        print(f"  • {n}: {e}")
    sys.exit(1)
else:
    sys.exit(0)
